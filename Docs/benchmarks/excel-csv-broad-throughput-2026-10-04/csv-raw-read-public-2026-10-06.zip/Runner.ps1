param(
    [Parameter(Mandatory)][string] $Workspace,
    [string[]] $Runtimes = @('net10.0', 'net8.0'),
    [long[]] $Masks = @([long]65535, [long]4294901760),
    [int] $Warmup = 16,
    [int] $Iterations = 12,
    [int] $Invocations = 4
)

$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
$workspacePath = (Resolve-Path -LiteralPath $Workspace).Path
if (& git -C $workspacePath status --porcelain) { throw 'Benchmark source worktree is dirty.' }
$head = & git -C $workspacePath rev-parse HEAD

$source = @(foreach ($directory in 'OfficeIMO.CSV', 'OfficeIMO.Core', 'OfficeIMO.SharedSource', 'OfficeIMO.CSV.Benchmarks', 'Benchmarks') {
    Get-ChildItem -LiteralPath (Join-Path $workspacePath $directory) -File -Recurse |
        Where-Object { $_.FullName -notmatch '[\\/](bin|obj)[\\/]' -and $_.Extension -in '.cs', '.csproj' } |
        ForEach-Object {
            $relative = [IO.Path]::GetRelativePath($workspacePath, $_.FullName).Replace('\', '/')
            $normalized = [IO.File]::ReadAllText($_.FullName).Replace("`r`n", "`n")
            $digest = [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData([Text.Encoding]::UTF8.GetBytes($normalized)))
            [pscustomobject]@{ Path = $relative; Sha256 = $digest }
        }
})

$filters = @(
    '*CsvBenchmarks.OfficeIMO_ReadDataReaderGetStrings*',
    '*CsvBenchmarks.CsvHelper_ReadFields*',
    '*CsvBenchmarks.Sylvan_ReadFields*',
    '*CsvBenchmarks.Sylvan_ReadFieldSpans*',
    '*CsvBenchmarks.Dataplat_ReadFields*',
    '*CsvBenchmarks.Sep_ReadFields*',
    '*CsvBenchmarks.Sep_ReadFieldSpans*'
)
$env:OFFICEIMO_BENCHMARK_OUTPUT = Join-Path $root 'fixtures'
$env:OFFICEIMO_BENCHMARK_DATA = Join-Path $root 'fixtures'
$reports = @()
foreach ($runtime in $Runtimes) {
    $buildLog = Join-Path $root "build-$runtime.log"
    & dotnet build (Join-Path $workspacePath 'OfficeIMO.CSV.Benchmarks/OfficeIMO.CSV.Benchmarks.csproj') -c Release -f $runtime -m:1 -v:q *> $buildLog
        if ($LASTEXITCODE) { throw "Raw CSV benchmark build failed for $runtime; see $buildLog" }

    $binaryRoot = Join-Path $workspacePath "OfficeIMO.CSV.Benchmarks/bin/Release/$runtime"
    $binaries = @(Get-ChildItem -LiteralPath $binaryRoot -File | ForEach-Object {
        [pscustomobject]@{ Name = $_.Name; Sha256 = (Get-FileHash -LiteralPath $_.FullName).Hash }
    })
    foreach ($mask in $Masks) {
        $output = Join-Path $root "native-$runtime-$mask"
        if (Test-Path -LiteralPath $output) { throw "Refuse existing measurements at $output" }
        $log = Join-Path $root "native-$runtime-$mask.log"
        $arguments = @(
            (Join-Path $binaryRoot 'OfficeIMO.CSV.Benchmarks.dll'),
            '--filter'
        ) + $filters + @(
            '--warmupCount', [string]$Warmup,
            '--iterationCount', [string]$Iterations,
            '--invocationCount', [string]$Invocations,
            '--unrollFactor', '1',
            '--outliers', 'DontRemove',
            '--affinityMasks', [string]$mask,
            '--priority', 'Normal',
            '--artifacts', $output
        )
        & dotnet @arguments *> $log
        if ($LASTEXITCODE) { throw "Raw CSV native job failed for $runtime/$mask; see $log" }

        $files = @(Get-ChildItem -LiteralPath (Join-Path $output 'results') -Filter '*-report-full.json')
        if ($files.Count -ne 1) { throw "Expected one raw CSV report for $runtime/$mask" }
        $report = Get-Content -LiteralPath $files[0].FullName -Raw | ConvertFrom-Json
        if ($report.Benchmarks.Count -ne 63 -or @($report.Benchmarks | Where-Object {
            $_.Statistics.N -ne $Iterations -or $_.Memory.TotalOperations -le 0
        }).Count) { throw "Incomplete raw CSV report for $runtime/$mask" }
        $summary = @($report.Benchmarks | ForEach-Object {
            [pscustomobject]@{
                FullName = $_.FullName
                Method = $_.Method
                Parameters = $_.Parameters
                MedianNs = $_.Statistics.Median
                MeanNs = $_.Statistics.Mean
                AllocatedBytes = $_.Memory.BytesAllocatedPerOperation
                Samples = $_.Statistics.N
            }
        })
        $reports += [pscustomobject]@{
            Runtime = $runtime
            Mask = $mask
            RawReport = [IO.Path]::GetRelativePath($root, $files[0].FullName).Replace('\', '/')
            RawSha256 = (Get-FileHash -LiteralPath $files[0].FullName).Hash
            Binaries = $binaries
            Summary = $summary
        }
        Write-Output "Raw CSV read comparison qualified: $runtime/$mask, 63 observations"
    }
    foreach ($file in $binaries) {
        if ((Get-FileHash -LiteralPath (Join-Path $binaryRoot $file.Name)).Hash -ne $file.Sha256) {
            throw "Benchmark binary changed during measurement: $runtime/$($file.Name)"
        }
    }
}

foreach ($file in $source) {
    $normalized = [IO.File]::ReadAllText((Join-Path $workspacePath $file.Path)).Replace("`r`n", "`n")
    $digest = [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData([Text.Encoding]::UTF8.GetBytes($normalized)))
    if ($digest -ne $file.Sha256) { throw "Benchmark source changed during measurement: $($file.Path)" }
}
if ((& git -C $workspacePath rev-parse HEAD) -ne $head -or (& git -C $workspacePath status --porcelain)) {
    throw 'Benchmark worktree changed during measurement.'
}

$runtimeLabel = $Runtimes -join '-'
$maskLabel = $Masks -join '-'
[ordered]@{
    Head = $head
    Status = @()
    Source = $source
    RunnerSha256 = (Get-FileHash -LiteralPath $PSCommandPath).Hash
    Policy = "Raw CSV read; 1K/10K/25K rows; mixed/quoted/multiline; complete decoded field validation in setup; warmup$Warmup;N$Iterations;invocations$Invocations;all outliers retained; Normal priority; fixed Windows affinity"
    Reports = $reports
} | ConvertTo-Json -Depth 18 | Set-Content -LiteralPath (Join-Path $root "retained-raw-csv-read-$runtimeLabel-$maskLabel.json") -Encoding utf8
