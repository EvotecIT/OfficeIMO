```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-XXLIFY : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=11111111111111110000000000000000  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-e67677",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=15  IterationTime=250ms  LaunchCount=1  
UnrollFactor=1  WarmupCount=12  

```
| Method               | RowCount | Mean     | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1    | Gen2    | Allocated | Alloc Ratio |
|--------------------- |--------- |---------:|----------:|----------:|------:|--------:|---------:|--------:|--------:|----------:|------------:|
| ExcelReaderTypedXlsb | 50000    | 6.831 ms | 0.7839 ms | 0.7333 ms |  1.01 |    0.14 | 142.8571 |       - |       - |   3.93 MB |        1.00 |
| OfficeIMOTypedXlsb   | 50000    | 8.628 ms | 1.0122 ms | 0.9468 ms |  1.28 |    0.18 | 214.2857 | 71.4286 | 71.4286 |   6.13 MB |        1.56 |
