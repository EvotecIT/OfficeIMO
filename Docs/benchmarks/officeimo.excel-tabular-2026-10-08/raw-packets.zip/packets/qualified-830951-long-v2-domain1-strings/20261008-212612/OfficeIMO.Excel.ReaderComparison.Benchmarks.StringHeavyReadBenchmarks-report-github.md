```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-OWHAFV : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=11111111111111110000000000000000  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=12  IterationTime=1s  LaunchCount=1  
UnrollFactor=1  WarmupCount=8  

```
| Method              | Format | RowCount | Mean      | Error     | StdDev   | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated | Alloc Ratio |
|-------------------- |------- |--------- |----------:|----------:|---------:|------:|--------:|---------:|---------:|---------:|----------:|------------:|
| **ExcelReaderOriginal** | **Xlsx**   | **65536**    |  **35.43 ms** |  **1.035 ms** | **0.808 ms** |  **1.00** |    **0.03** |        **-** |        **-** |        **-** |   **2.18 MB** |        **1.00** |
| ExcelReaderPrefetch | Xlsx   | 65536    |  28.05 ms |  0.449 ms | 0.350 ms |  0.79 |    0.02 |        - |        - |        - |   2.26 MB |        1.04 |
| ExcelReaderMemory   | Xlsx   | 65536    |  34.91 ms |  1.755 ms | 1.370 ms |  0.99 |    0.04 |        - |        - |        - |   2.18 MB |        1.00 |
| OfficeIMOBytes      | Xlsx   | 65536    |  91.32 ms | 12.775 ms | 9.974 ms |  2.58 |    0.28 | 454.5455 | 363.6364 |  90.9091 |  19.11 MB |        8.76 |
| OfficeIMOStream     | Xlsx   | 65536    |  72.77 ms |  2.116 ms | 1.652 ms |  2.05 |    0.06 | 416.6667 | 333.3333 |  83.3333 |  25.45 MB |       11.67 |
| Sylvan              | Xlsx   | 65536    | 134.17 ms | 10.080 ms | 7.870 ms |  3.79 |    0.23 | 166.6667 |        - |        - |  17.41 MB |        7.98 |
|                     |        |          |           |           |          |       |         |          |          |          |           |             |
| **ExcelReaderOriginal** | **Xlsb**   | **65536**    |  **31.99 ms** |  **0.543 ms** | **0.424 ms** |  **1.00** |    **0.02** |        **-** |        **-** |        **-** |   **2.18 MB** |        **1.00** |
| ExcelReaderPrefetch | Xlsb   | 65536    |  20.10 ms |  0.999 ms | 0.780 ms |  0.63 |    0.02 |        - |        - |        - |   2.27 MB |        1.04 |
| ExcelReaderMemory   | Xlsb   | 65536    |  30.18 ms |  0.191 ms | 0.149 ms |  0.94 |    0.01 |        - |        - |        - |   6.47 MB |        2.97 |
| OfficeIMOBytes      | Xlsb   | 65536    |  44.37 ms |  0.508 ms | 0.397 ms |  1.39 |    0.02 | 476.1905 | 428.5714 | 142.8571 |  31.55 MB |       14.47 |
| OfficeIMOStream     | Xlsb   | 65536    |  46.12 ms |  1.263 ms | 0.986 ms |  1.44 |    0.03 | 466.6667 | 400.0000 | 133.3333 |   39.3 MB |       18.03 |
| Sylvan              | Xlsb   | 65536    |  46.12 ms |  1.915 ms | 1.495 ms |  1.44 |    0.05 | 363.6364 | 272.7273 |  90.9091 |  17.38 MB |        7.97 |
