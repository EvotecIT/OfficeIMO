```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-OWHAFV : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=11111111111111110000000000000000  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=12  IterationTime=1s  LaunchCount=1  
UnrollFactor=1  WarmupCount=8  

```
| Method                         | Format | RowCount | Mean      | Error     | StdDev   | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated | Alloc Ratio |
|------------------------------- |------- |--------- |----------:|----------:|---------:|------:|--------:|---------:|---------:|---------:|----------:|------------:|
| **ExcelReaderStringsMaterialized** | **Xlsx**   | **65536**    |  **46.95 ms** |  **2.864 ms** | **2.236 ms** |  **1.00** |    **0.06** | **368.4211** | **315.7895** | **105.2632** |  **15.25 MB** |        **1.00** |
| ExcelReaderStringsInterned     | Xlsx   | 65536    |  45.93 ms |  1.602 ms | 1.251 ms |  0.98 |    0.05 | 350.0000 | 300.0000 | 100.0000 |  15.26 MB |        1.00 |
| OfficeIMOBytes                 | Xlsx   | 65536    |  77.03 ms |  6.986 ms | 5.454 ms |  1.64 |    0.13 | 454.5455 | 363.6364 |  90.9091 |  19.11 MB |        1.25 |
| OfficeIMOStream                | Xlsx   | 65536    |  75.29 ms |  6.806 ms | 5.313 ms |  1.61 |    0.13 | 416.6667 | 333.3333 |  83.3333 |  25.45 MB |        1.67 |
| Sylvan                         | Xlsx   | 65536    | 135.31 ms | 10.758 ms | 8.399 ms |  2.89 |    0.21 | 142.8571 |        - |        - |  17.41 MB |        1.14 |
|                                |        |          |           |           |          |       |         |          |          |          |           |             |
| **ExcelReaderStringsMaterialized** | **Xlsb**   | **65536**    |  **46.71 ms** |  **2.900 ms** | **2.264 ms** |  **1.00** |    **0.07** | **368.4211** | **315.7895** | **105.2632** |  **15.25 MB** |        **1.00** |
| ExcelReaderStringsInterned     | Xlsb   | 65536    |  47.28 ms |  2.627 ms | 2.051 ms |  1.01 |    0.06 | 363.6364 | 318.1818 |  90.9091 |  15.26 MB |        1.00 |
| OfficeIMOBytes                 | Xlsb   | 65536    |  49.55 ms |  3.266 ms | 2.550 ms |  1.06 |    0.07 | 526.3158 | 473.6842 | 157.8947 |  31.55 MB |        2.07 |
| OfficeIMOStream                | Xlsb   | 65536    |  47.82 ms |  2.757 ms | 2.152 ms |  1.03 |    0.06 | 500.0000 | 450.0000 | 150.0000 |   39.3 MB |        2.58 |
| Sylvan                         | Xlsb   | 65536    |  57.86 ms |  5.227 ms | 4.081 ms |  1.24 |    0.10 | 388.8889 | 333.3333 | 111.1111 |  17.38 MB |        1.14 |
