```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-OWHAFV : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=11111111111111110000000000000000  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=12  IterationTime=1s  LaunchCount=1  
UnrollFactor=1  WarmupCount=8  

```
| Method                         | RowCount | Storage  | Mean         | Error        | StdDev       | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated   | Alloc Ratio |
|------------------------------- |--------- |--------- |-------------:|-------------:|-------------:|------:|--------:|---------:|---------:|---------:|------------:|------------:|
| **ExcelReaderOpenThroughFirstRow** | **65536**    | **Deflated** | **13,267.99 μs** |   **497.592 μs** |   **388.487 μs** | **1.001** |    **0.04** |        **-** |        **-** |        **-** |    **747.3 KB** |        **1.00** |
| OfficeIMOOpenThroughFirstRow   | 65536    | Deflated | 68,120.31 μs | 7,081.149 μs | 5,528.496 μs | 5.138 |    0.43 | 333.3333 | 266.6667 |  66.6667 | 14958.48 KB |       20.02 |
| SylvanOpenThroughFirstRow      | 65536    | Deflated |     60.79 μs |     5.306 μs |     4.143 μs | 0.005 |    0.00 |   4.7401 |   1.7086 |   0.8268 |   320.92 KB |        0.43 |
|                                |          |          |              |              |              |       |         |          |          |          |             |             |
| **ExcelReaderOpenThroughFirstRow** | **65536**    | **Stored**   |  **3,228.99 μs** |    **41.500 μs** |    **32.401 μs** |  **1.00** |    **0.01** |        **-** |        **-** |        **-** |   **746.25 KB** |        **1.00** |
| OfficeIMOOpenThroughFirstRow   | 65536    | Stored   | 42,783.72 μs | 3,898.120 μs | 3,043.396 μs | 13.25 |    0.91 | 384.6154 | 346.1538 | 115.3846 | 14956.58 KB |       20.04 |
| SylvanOpenThroughFirstRow      | 65536    | Stored   |     57.84 μs |     6.084 μs |     4.750 μs |  0.02 |    0.00 |   5.8116 |   2.6479 |   1.9257 |   320.09 KB |        0.43 |
