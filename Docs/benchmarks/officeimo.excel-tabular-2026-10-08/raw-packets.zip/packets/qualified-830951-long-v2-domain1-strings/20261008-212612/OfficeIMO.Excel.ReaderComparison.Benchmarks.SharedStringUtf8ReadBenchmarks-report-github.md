```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-OWHAFV : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=11111111111111110000000000000000  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=12  IterationTime=1s  LaunchCount=1  
UnrollFactor=1  WarmupCount=8  

```
| Method                      | Format | RowCount | Storage  | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0      | Gen1      | Gen2     | Allocated | Alloc Ratio |
|---------------------------- |------- |--------- |--------- |----------:|----------:|----------:|------:|--------:|----------:|----------:|---------:|----------:|------------:|
| **ExcelReaderBorrowed**         | **Xlsx**   | **100000**   | **Deflated** |  **49.95 ms** |  **2.112 ms** |  **1.649 ms** |  **1.00** |    **0.04** |         **-** |         **-** |        **-** |    **2.9 MB** |        **1.00** |
| ExcelReaderBorrowedPrefetch | Xlsx   | 100000   | Deflated |  40.32 ms |  1.608 ms |  1.255 ms |  0.81 |    0.03 |         - |         - |        - |      3 MB |        1.03 |
| OfficeIMOBorrowedSharedUtf8 | Xlsx   | 100000   | Deflated | 159.41 ms | 11.571 ms |  9.034 ms |  3.19 |    0.20 | 2166.6667 | 1500.0000 | 500.0000 |  88.74 MB |       30.64 |
|                             |        |          |          |           |           |           |       |         |           |           |          |           |             |
| **ExcelReaderBorrowed**         | **Xlsx**   | **100000**   | **Stored**   |  **24.25 ms** |  **1.712 ms** |  **1.336 ms** |  **1.00** |    **0.07** |         **-** |         **-** |        **-** |   **2.89 MB** |        **1.00** |
| ExcelReaderBorrowedPrefetch | Xlsx   | 100000   | Stored   |  24.85 ms |  0.982 ms |  0.767 ms |  1.03 |    0.06 |         - |         - |        - |   2.91 MB |        1.01 |
| OfficeIMOBorrowedSharedUtf8 | Xlsx   | 100000   | Stored   | 204.63 ms | 18.465 ms | 14.416 ms |  8.46 |    0.72 | 3000.0000 | 1750.0000 | 500.0000 |  89.26 MB |       30.83 |
|                             |        |          |          |           |           |           |       |         |           |           |          |           |             |
| **ExcelReaderBorrowed**         | **Xlsb**   | **100000**   | **Deflated** |  **52.85 ms** |  **5.631 ms** |  **4.397 ms** |  **1.01** |    **0.12** |         **-** |         **-** |        **-** |    **2.9 MB** |        **1.00** |
| ExcelReaderBorrowedPrefetch | Xlsb   | 100000   | Deflated |  32.97 ms |  0.396 ms |  0.309 ms |  0.63 |    0.05 |         - |         - |        - |   2.99 MB |        1.03 |
| OfficeIMOBorrowedSharedUtf8 | Xlsb   | 100000   | Deflated | 103.38 ms |  3.624 ms |  2.829 ms |  1.97 |    0.17 | 2142.8571 | 1428.5714 | 428.5714 | 103.44 MB |       35.73 |
|                             |        |          |          |           |           |           |       |         |           |           |          |           |             |
| **ExcelReaderBorrowed**         | **Xlsb**   | **100000**   | **Stored**   |  **20.42 ms** |  **0.635 ms** |  **0.496 ms** |  **1.00** |    **0.03** |         **-** |         **-** |        **-** |   **2.89 MB** |        **1.00** |
| ExcelReaderBorrowedPrefetch | Xlsb   | 100000   | Stored   |  22.94 ms |  1.144 ms |  0.893 ms |  1.12 |    0.05 |         - |         - |        - |   2.91 MB |        1.01 |
| OfficeIMOBorrowedSharedUtf8 | Xlsb   | 100000   | Stored   |  78.48 ms |  3.948 ms |  3.082 ms |  3.85 |    0.17 | 2333.3333 | 1666.6667 | 555.5556 | 103.44 MB |       35.74 |
