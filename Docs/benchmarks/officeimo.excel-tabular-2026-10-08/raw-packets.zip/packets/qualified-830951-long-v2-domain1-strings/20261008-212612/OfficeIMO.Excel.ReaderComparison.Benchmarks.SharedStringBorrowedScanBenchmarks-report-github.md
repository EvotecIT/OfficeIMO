```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-OWHAFV : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=11111111111111110000000000000000  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=12  IterationTime=1s  LaunchCount=1  
UnrollFactor=1  WarmupCount=8  

```
| Method                      | RowCount | Storage  | Mean     | Error    | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|---------------------------- |--------- |--------- |---------:|---------:|---------:|------:|--------:|----------:|------------:|
| **ExcelReaderBorrowed**         | **65536**    | **Deflated** | **35.73 ms** | **1.793 ms** | **1.400 ms** |  **1.00** |    **0.05** |   **2.18 MB** |        **1.00** |
| ExcelReaderBorrowedPrefetch | 65536    | Deflated | 28.28 ms | 1.028 ms | 0.803 ms |  0.79 |    0.04 |   2.26 MB |        1.04 |
|                             |          |          |          |          |          |       |         |           |             |
| **ExcelReaderBorrowed**         | **65536**    | **Stored**   | **14.93 ms** | **1.193 ms** | **0.931 ms** |  **1.00** |    **0.08** |   **2.18 MB** |        **1.00** |
| ExcelReaderBorrowedPrefetch | 65536    | Stored   | 16.68 ms | 0.847 ms | 0.661 ms |  1.12 |    0.08 |   2.19 MB |        1.01 |
