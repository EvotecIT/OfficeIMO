```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-OWHAFV : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=11111111111111110000000000000000  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=12  IterationTime=1s  LaunchCount=1  
UnrollFactor=1  WarmupCount=8  

```
| Method                         | RowCount | Storage | Mean      | Error    | StdDev   | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated | Alloc Ratio |
|------------------------------- |--------- |-------- |----------:|---------:|---------:|------:|--------:|---------:|---------:|---------:|----------:|------------:|
| ExcelReaderStringsMaterialized | 65536    | Stored  |  39.79 ms | 7.227 ms | 5.642 ms |  1.02 |    0.19 | 892.8571 | 857.1429 | 285.7143 |   15.6 MB |        1.00 |
| OfficeIMOStringsMaterialized   | 65536    | Stored  |  63.89 ms | 4.763 ms | 3.719 ms |  1.63 |    0.22 | 466.6667 | 400.0000 | 133.3333 |  19.11 MB |        1.22 |
| SylvanStringsMaterialized      | 65536    | Stored  | 122.70 ms | 9.804 ms | 7.655 ms |  3.14 |    0.43 | 142.8571 |        - |        - |  17.41 MB |        1.12 |
