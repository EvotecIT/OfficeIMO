```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-SVEHGN : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=11111111111111110000000000000000  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=8  IterationTime=250ms  LaunchCount=1  
UnrollFactor=1  WarmupCount=4  

```
| Method                | Input                | Dop | Mean     | Error     | StdDev    | Ratio | RatioSD | Gen0       | Gen1       | Gen2      | Allocated  | Alloc Ratio |
|---------------------- |--------------------- |---- |---------:|----------:|----------:|------:|--------:|-----------:|-----------:|----------:|-----------:|------------:|
| **ExcelReaderParallel**   | **Conve(...)00000 [23]** | **1**   | **618.4 ms** |  **11.22 ms** |   **5.87 ms** |  **1.00** |    **0.01** | **14000.0000** |          **-** |         **-** |  **671.41 MB** |        **1.00** |
| ExcelReaderSequential | Conve(...)00000 [23] | 1   | 834.6 ms |  95.34 ms |  49.86 ms |  1.35 |    0.08 | 13750.0000 |          - |         - |   669.8 MB |        1.00 |
| OfficeIMOCoreParallel | Conve(...)00000 [23] | 1   | 532.4 ms |  14.68 ms |   7.68 ms |  0.86 |    0.01 | 26750.0000 |          - |         - |  1290.2 MB |        1.92 |
| OfficeIMOTextParallel | Conve(...)00000 [23] | 1   | 612.5 ms |  16.80 ms |   8.79 ms |  0.99 |    0.02 | 24750.0000 | 11750.0000 | 2500.0000 | 1463.52 MB |        2.18 |
| SylvanSequential      | Conve(...)00000 [23] | 1   | 890.9 ms |  60.16 ms |  31.46 ms |  1.44 |    0.05 | 26750.0000 |          - |         - | 1292.01 MB |        1.92 |
|                       |                      |     |          |           |           |       |         |            |            |           |            |             |
| **ExcelReaderParallel**   | **Conve(...)00000 [25]** | **1**   | **474.5 ms** |  **42.23 ms** |  **22.09 ms** |  **1.00** |    **0.06** |  **9750.0000** |          **-** |         **-** |  **468.43 MB** |        **1.00** |
| ExcelReaderSequential | Conve(...)00000 [25] | 1   | 427.4 ms |  19.04 ms |   9.96 ms |  0.90 |    0.04 |  9750.0000 |          - |         - |   467.3 MB |        1.00 |
| OfficeIMOCoreParallel | Conve(...)00000 [25] | 1   | 499.7 ms |  59.89 ms |  31.32 ms |  1.06 |    0.08 | 18750.0000 |          - |         - |  900.14 MB |        1.92 |
| OfficeIMOTextParallel | Conve(...)00000 [25] | 1   | 570.5 ms |  33.88 ms |  17.72 ms |  1.20 |    0.06 | 25250.0000 | 14500.0000 | 3000.0000 | 1021.41 MB |        2.18 |
| SylvanSequential      | Conve(...)00000 [25] | 1   | 761.2 ms |  56.80 ms |  29.71 ms |  1.61 |    0.09 | 18750.0000 |          - |         - |  901.42 MB |        1.92 |
|                       |                      |     |          |           |           |       |         |            |            |           |            |             |
| **ExcelReaderParallel**   | **NarrowInt-8000000**    | **1**   | **487.7 ms** |  **36.12 ms** |  **18.89 ms** |  **1.00** |    **0.05** |  **5000.0000** |          **-** |         **-** |  **245.75 MB** |        **1.00** |
| ExcelReaderSequential | NarrowInt-8000000    | 1   | 385.6 ms | 121.76 ms |  63.68 ms |  0.79 |    0.13 |  5000.0000 |          - |         - |  244.14 MB |        0.99 |
| OfficeIMOCoreParallel | NarrowInt-8000000    | 1   | 491.1 ms |  16.87 ms |   8.82 ms |  1.01 |    0.04 | 24000.0000 |          - |         - | 1158.54 MB |        4.71 |
| OfficeIMOTextParallel | NarrowInt-8000000    | 1   | 894.3 ms |  63.25 ms |  33.08 ms |  1.84 |    0.09 | 16000.0000 | 11500.0000 | 2500.0000 | 1045.73 MB |        4.26 |
| SylvanSequential      | NarrowInt-8000000    | 1   | 649.8 ms | 215.79 ms | 112.86 ms |  1.33 |    0.22 | 24000.0000 |          - |         - | 1158.58 MB |        4.71 |
