```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-SVEHGN : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=11111111111111110000000000000000  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=8  IterationTime=250ms  LaunchCount=1  
UnrollFactor=1  WarmupCount=4  

```
| Method                        | Input                | Dop | Mean       | Error     | StdDev    | Ratio | RatioSD | Gen0       | Gen1       | Gen2      | Allocated     | Alloc Ratio |
|------------------------------ |--------------------- |---- |-----------:|----------:|----------:|------:|--------:|-----------:|-----------:|----------:|--------------:|------------:|
| **ExcelReaderAggregate**          | **Conve(...)00000 [23]** | **1**   |   **599.4 ms** |  **69.45 ms** |  **36.32 ms** |  **1.00** |    **0.08** |          **-** |          **-** |         **-** |    **1228.89 KB** |        **1.00** |
| OfficeIMOTextOwnedAggregate   | Conve(...)00000 [23] | 1   |   588.7 ms |  70.30 ms |  36.77 ms |  0.99 |    0.08 | 10500.0000 | 10250.0000 | 2250.0000 |  812776.71 KB |      661.39 |
| OfficeIMOAsyncPathAggregate   | Conve(...)00000 [23] | 1   | 2,197.8 ms | 361.28 ms | 188.96 ms |  3.68 |    0.36 | 38750.0000 |   250.0000 |         - | 1903103.02 KB |    1,548.63 |
| OfficeIMOAsyncStreamAggregate | Conve(...)00000 [23] | 1   | 2,262.4 ms | 185.54 ms |  97.04 ms |  3.79 |    0.25 | 38750.0000 |   250.0000 |         - | 1903113.93 KB |    1,548.64 |
|                               |                      |     |            |           |           |       |         |            |            |           |               |             |
| **ExcelReaderAggregate**          | **Conve(...)00000 [25]** | **1**   |   **445.8 ms** |  **40.86 ms** |  **21.37 ms** |  **1.00** |    **0.06** |          **-** |          **-** |         **-** |     **858.16 KB** |        **1.00** |
| OfficeIMOTextOwnedAggregate   | Conve(...)00000 [25] | 1   |   468.7 ms |  27.02 ms |  14.13 ms |  1.05 |    0.06 |  8000.0000 |  7750.0000 | 2250.0000 |  567066.42 KB |      660.80 |
| OfficeIMOAsyncPathAggregate   | Conve(...)00000 [25] | 1   | 1,551.4 ms | 188.41 ms |  98.54 ms |  3.49 |    0.26 | 27500.0000 |   500.0000 |         - | 1327763.03 KB |    1,547.23 |
| OfficeIMOAsyncStreamAggregate | Conve(...)00000 [25] | 1   | 1,632.9 ms | 152.35 ms |  79.68 ms |  3.67 |    0.24 | 27000.0000 |   250.0000 |         - | 1327760.91 KB |    1,547.23 |
|                               |                      |     |            |           |           |       |         |            |            |           |               |             |
| **ExcelReaderAggregate**          | **NarrowInt-8000000**    | **1**   |   **489.0 ms** |  **56.36 ms** |  **29.48 ms** |  **1.00** |    **0.08** |          **-** |          **-** |         **-** |    **1227.54 KB** |        **1.00** |
| OfficeIMOTextOwnedAggregate   | NarrowInt-8000000    | 1   |   685.1 ms |  47.42 ms |  24.80 ms |  1.41 |    0.09 | 10500.0000 | 10250.0000 | 2250.0000 |   820833.9 KB |      668.68 |
| OfficeIMOAsyncPathAggregate   | NarrowInt-8000000    | 1   | 2,621.9 ms | 294.42 ms | 153.99 ms |  5.38 |    0.43 | 45000.0000 |   250.0000 |         - | 2207893.19 KB |    1,798.64 |
| OfficeIMOAsyncStreamAggregate | NarrowInt-8000000    | 1   | 2,378.8 ms | 491.55 ms | 257.09 ms |  4.88 |    0.57 | 45000.0000 |   250.0000 |         - |  2207895.8 KB |    1,798.64 |
