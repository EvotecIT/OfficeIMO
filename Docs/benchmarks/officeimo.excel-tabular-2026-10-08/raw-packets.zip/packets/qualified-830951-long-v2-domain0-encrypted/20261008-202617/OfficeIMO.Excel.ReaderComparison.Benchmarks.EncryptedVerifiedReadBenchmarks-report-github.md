```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-BHAAQB : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=00000000000000001111111111111111  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=12  IterationTime=1s  LaunchCount=1  
UnrollFactor=1  WarmupCount=8  

```
| Method                        | Input              | MemoryInput | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0     | Allocated   | Alloc Ratio |
|------------------------------ |------------------- |------------ |----------:|----------:|----------:|------:|--------:|---------:|------------:|------------:|
| **ExcelReaderVerifiedFullFields** | **OriginalSmallXlsx**  | **False**       |  **21.92 ms** |  **1.879 ms** |  **1.467 ms** |  **1.00** |    **0.09** |        **-** |    **40.59 KB** |        **1.00** |
| OfficeIMOVerifiedFullFields   | OriginalSmallXlsx  | False       |  24.06 ms |  1.214 ms |  0.948 ms |  1.10 |    0.08 |        - |   261.44 KB |        6.44 |
|                               |                    |             |           |           |           |       |         |          |             |             |
| **ExcelReaderVerifiedFullFields** | **OriginalSmallXlsx**  | **True**        |  **23.22 ms** |  **1.587 ms** |  **1.239 ms** |  **1.00** |    **0.07** |        **-** |    **53.57 KB** |        **1.00** |
| OfficeIMOVerifiedFullFields   | OriginalSmallXlsx  | True        |  23.87 ms |  2.197 ms |  1.715 ms |  1.03 |    0.09 |        - |   242.14 KB |        4.52 |
|                               |                    |             |           |           |           |       |         |          |             |             |
| **ExcelReaderVerifiedFullFields** | **GeneratedLargeXlsx** | **False**       |  **71.67 ms** |  **6.712 ms** |  **5.240 ms** |  **1.00** |    **0.10** | **100.0000** |  **9699.93 KB** |        **1.00** |
| OfficeIMOVerifiedFullFields   | GeneratedLargeXlsx | False       | 135.53 ms | 17.588 ms | 13.732 ms |  1.90 |    0.23 | 571.4286 | 66663.86 KB |        6.87 |
|                               |                    |             |           |           |           |       |         |          |             |             |
| **ExcelReaderVerifiedFullFields** | **GeneratedLargeXlsx** | **True**        |  **74.23 ms** |  **9.028 ms** |  **7.049 ms** |  **1.01** |    **0.13** | **100.0000** | **18741.63 KB** |        **1.00** |
| OfficeIMOVerifiedFullFields   | GeneratedLargeXlsx | True        | 139.85 ms | 18.592 ms | 14.515 ms |  1.90 |    0.26 | 571.4286 | 62103.77 KB |        3.31 |
