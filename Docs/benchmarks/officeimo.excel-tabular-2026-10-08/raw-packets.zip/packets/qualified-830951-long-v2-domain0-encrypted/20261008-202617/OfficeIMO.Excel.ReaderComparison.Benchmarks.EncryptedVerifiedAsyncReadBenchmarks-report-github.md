```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-BHAAQB : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=00000000000000001111111111111111  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=12  IterationTime=1s  LaunchCount=1  
UnrollFactor=1  WarmupCount=8  

```
| Method                         | Input              | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0     | Allocated   | Alloc Ratio |
|------------------------------- |------------------- |----------:|----------:|----------:|------:|--------:|---------:|------------:|------------:|
| **ExcelReaderVerifiedStreamAsync** | **OriginalSmallXlsx**  |  **23.18 ms** |  **1.976 ms** |  **1.543 ms** |  **1.00** |    **0.09** |        **-** |    **63.35 KB** |        **1.00** |
| OfficeIMOVerifiedStreamAsync   | OriginalSmallXlsx  |  22.74 ms |  0.980 ms |  0.765 ms |  0.98 |    0.07 |        - |   262.74 KB |        4.15 |
|                                |                    |           |           |           |       |         |          |             |             |
| **ExcelReaderVerifiedStreamAsync** | **GeneratedLargeXlsx** |  **72.80 ms** |  **6.595 ms** |  **5.149 ms** |  **1.00** |    **0.09** | **111.1111** | **10052.98 KB** |        **1.00** |
| OfficeIMOVerifiedStreamAsync   | GeneratedLargeXlsx | 157.32 ms | 15.324 ms | 11.964 ms |  2.17 |    0.21 | 500.0000 | 66664.58 KB |        6.63 |
