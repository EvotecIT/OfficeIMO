```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-JTLREC : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=11111111111111110000000000000000  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-ba9",/p:OfficeIMOBenchmarkNewApis=true  
InvocationCount=4  IterationCount=10  LaunchCount=1  
UnrollFactor=1  WarmupCount=8  

```
| Method                      | Input             | MemoryInput | Mean     | Error    | StdDev   | Gen0      | Allocated |
|---------------------------- |------------------ |------------ |---------:|---------:|---------:|----------:|----------:|
| **OfficeIMOVerifiedFullFields** | **OriginalSmallXlsx** | **False**       | **141.9 ms** | **19.20 ms** | **12.70 ms** | **2750.0000** | **137.88 MB** |
| **OfficeIMOVerifiedFullFields** | **OriginalSmallXlsx** | **True**        | **140.5 ms** |  **9.24 ms** |  **6.11 ms** | **2750.0000** | **137.86 MB** |
