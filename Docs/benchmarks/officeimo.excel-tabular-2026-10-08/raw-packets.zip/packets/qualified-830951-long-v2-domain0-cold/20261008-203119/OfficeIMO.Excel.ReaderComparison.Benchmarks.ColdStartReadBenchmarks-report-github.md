```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-CNKMYX : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=00000000000000001111111111111111  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
InvocationCount=1  IterationCount=1  LaunchCount=16  
RunStrategy=ColdStart  UnrollFactor=1  WarmupCount=0  

```
| Method                       | Mean     | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------------------------- |---------:|----------:|----------:|------:|--------:|----------:|------------:|
| ExcelReaderAttributes        | 29.21 ms |  4.417 ms |  4.338 ms |  1.02 |    0.18 |  21.09 KB |        1.00 |
| OfficeIMOAutomaticMapping    | 78.43 ms | 50.564 ms | 49.660 ms |  2.73 |    1.71 |   93.8 KB |        4.45 |
| ExcelReaderFluentMapping     | 24.89 ms |  2.337 ms |  2.296 ms |  0.87 |    0.12 |  24.03 KB |        1.14 |
| ExcelReaderAttributeFallback | 30.04 ms |  1.857 ms |  1.823 ms |  1.04 |    0.13 |  26.16 KB |        1.24 |
