```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-CPEWJC : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=11111111111111110000000000000000  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=15  IterationTime=1s  LaunchCount=1  
UnrollFactor=1  WarmupCount=12  

```
| Method                         | Format | Mean      | Error    | StdDev   | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated   | Alloc Ratio |
|------------------------------- |------- |----------:|---------:|---------:|------:|--------:|---------:|---------:|---------:|------------:|------------:|
| **ExcelReaderStringsMaterialized** | **Xlsx**   |  **42.63 ms** | **2.686 ms** | **2.513 ms** |  **1.00** |    **0.08** |        **-** |        **-** |        **-** |    **17.09 KB** |        **1.00** |
| OfficeIMOBytes                 | Xlsx   |  67.23 ms | 6.448 ms | 6.031 ms |  1.58 |    0.16 | 250.0000 |        - |        - | 13939.88 KB |      815.50 |
| OfficeIMOStream                | Xlsx   |  64.93 ms | 5.817 ms | 5.441 ms |  1.53 |    0.15 | 250.0000 |        - |        - | 20503.75 KB |    1,199.49 |
| Sylvan                         | Xlsx   | 155.75 ms | 7.883 ms | 7.374 ms |  3.66 |    0.27 |        - |        - |        - |   644.56 KB |       37.71 |
|                                |        |           |          |          |       |         |          |          |          |             |             |
| **ExcelReaderStringsMaterialized** | **Xlsm**   |  **41.23 ms** | **1.383 ms** | **1.293 ms** |  **1.00** |    **0.04** |        **-** |        **-** |        **-** |    **17.09 KB** |        **1.00** |
| OfficeIMOBytes                 | Xlsm   |  61.14 ms | 3.517 ms | 3.290 ms |  1.48 |    0.09 | 266.6667 |        - |        - |  13939.9 KB |      815.50 |
| OfficeIMOStream                | Xlsm   |  63.58 ms | 3.760 ms | 3.517 ms |  1.54 |    0.09 | 214.2857 |        - |        - | 20503.73 KB |    1,199.49 |
| Sylvan                         | Xlsm   | 151.19 ms | 4.897 ms | 4.580 ms |  3.67 |    0.15 |        - |        - |        - |   644.64 KB |       37.71 |
|                                |        |           |          |          |       |         |          |          |          |             |             |
| **ExcelReaderStringsMaterialized** | **Xlsb**   |  **25.15 ms** | **0.811 ms** | **0.758 ms** |  **1.00** |    **0.04** |        **-** |        **-** |        **-** |    **16.65 KB** |        **1.00** |
| OfficeIMOBytes                 | Xlsb   |  25.20 ms | 0.771 ms | 0.721 ms |  1.00 |    0.04 | 275.0000 |        - |        - | 13986.21 KB |      840.09 |
| OfficeIMOStream                | Xlsb   |  26.36 ms | 1.326 ms | 1.240 ms |  1.05 |    0.06 | 333.3333 |  51.2821 |  51.2821 | 17770.89 KB |    1,067.42 |
| Sylvan                         | Xlsb   |  26.15 ms | 1.098 ms | 1.027 ms |  1.04 |    0.05 |        - |        - |        - |   338.87 KB |       20.35 |
|                                |        |           |          |          |       |         |          |          |          |             |             |
| **ExcelReaderStringsMaterialized** | **Xls**    |  **10.74 ms** | **0.721 ms** | **0.675 ms** |  **1.00** |    **0.09** |        **-** |        **-** |        **-** |    **21.48 KB** |        **1.00** |
| OfficeIMOBytes                 | Xls    |  14.72 ms | 1.162 ms | 1.087 ms |  1.38 |    0.13 | 271.6049 |  12.3457 |        - | 13990.08 KB |      651.17 |
| OfficeIMOStream                | Xls    |  15.84 ms | 0.825 ms | 0.772 ms |  1.48 |    0.11 | 396.8254 | 126.9841 | 126.9841 | 25538.02 KB |    1,188.68 |
| Sylvan                         | Xls    |  18.23 ms | 0.725 ms | 0.678 ms |  1.70 |    0.12 |        - |        - |        - |   186.29 KB |        8.67 |
