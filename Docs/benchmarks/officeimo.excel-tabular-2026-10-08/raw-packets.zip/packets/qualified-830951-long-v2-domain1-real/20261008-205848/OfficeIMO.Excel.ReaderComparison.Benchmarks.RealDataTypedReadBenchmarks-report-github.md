```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-CPEWJC : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=11111111111111110000000000000000  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=15  IterationTime=1s  LaunchCount=1  
UnrollFactor=1  WarmupCount=12  

```
| Method               | Format | Mean     | Error    | StdDev   | Ratio | RatioSD | Gen0     | Gen1    | Allocated | Alloc Ratio |
|--------------------- |------- |---------:|---------:|---------:|------:|--------:|---------:|--------:|----------:|------------:|
| **ExcelReaderAutomatic** | **Xlsx**   | **47.45 ms** | **2.563 ms** | **2.397 ms** |  **1.00** |    **0.07** | **142.8571** |       **-** |   **8.02 MB** |        **1.00** |
| OfficeIMOAutomatic   | Xlsx   | 61.43 ms | 3.842 ms | 3.594 ms |  1.30 |    0.09 |        - |       - |   8.12 MB |        1.01 |
|                      |        |          |          |          |       |         |          |         |           |             |
| **ExcelReaderAutomatic** | **Xlsb**   | **29.90 ms** | **2.012 ms** | **1.882 ms** |  **1.00** |    **0.08** | **166.6667** |       **-** |   **8.02 MB** |        **1.00** |
| OfficeIMOAutomatic   | Xlsb   | 35.61 ms | 1.293 ms | 1.209 ms |  1.20 |    0.08 | 482.7586 | 34.4828 |  24.66 MB |        3.08 |
