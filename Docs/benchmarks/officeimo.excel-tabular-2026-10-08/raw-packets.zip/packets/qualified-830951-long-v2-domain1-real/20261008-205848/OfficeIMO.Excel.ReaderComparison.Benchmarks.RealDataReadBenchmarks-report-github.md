```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-CPEWJC : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=11111111111111110000000000000000  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=15  IterationTime=1s  LaunchCount=1  
UnrollFactor=1  WarmupCount=12  

```
| Method              | Format | Mean       | Error      | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated   | Alloc Ratio |
|-------------------- |------- |-----------:|-----------:|----------:|------:|--------:|---------:|---------:|---------:|------------:|------------:|
| **ExcelReaderOriginal** | **Xlsx**   |  **39.014 ms** |  **1.0641 ms** | **0.9953 ms** |  **1.00** |    **0.03** |        **-** |        **-** |        **-** |     **7.63 KB** |        **1.00** |
| ExcelReaderMemory   | Xlsx   |  39.695 ms |  1.0834 ms | 1.0134 ms |  1.02 |    0.03 |        - |        - |        - |     7.38 KB |        0.97 |
| OfficeIMOBytes      | Xlsx   |  63.332 ms |  3.0994 ms | 2.8992 ms |  1.62 |    0.08 | 250.0000 |        - |        - | 13939.94 KB |    1,828.19 |
| OfficeIMOStream     | Xlsx   |  60.637 ms |  7.5709 ms | 7.0818 ms |  1.56 |    0.18 | 250.0000 |        - |        - | 20503.75 KB |    2,689.02 |
| Sylvan              | Xlsx   | 154.145 ms | 10.3071 ms | 9.6413 ms |  3.95 |    0.26 |        - |        - |        - |   644.56 KB |       84.53 |
|                     |        |            |            |           |       |         |          |          |          |             |             |
| **ExcelReaderOriginal** | **Xlsm**   |  **40.535 ms** |  **1.7824 ms** | **1.6672 ms** |  **1.00** |    **0.06** |        **-** |        **-** |        **-** |     **7.63 KB** |        **1.00** |
| ExcelReaderMemory   | Xlsm   |  40.127 ms |  1.3181 ms | 1.2329 ms |  0.99 |    0.05 |        - |        - |        - |     7.38 KB |        0.97 |
| OfficeIMOBytes      | Xlsm   |  62.898 ms |  4.6439 ms | 4.3439 ms |  1.55 |    0.12 | 250.0000 |        - |        - | 13939.89 KB |    1,828.18 |
| OfficeIMOStream     | Xlsm   |  61.788 ms |  4.1383 ms | 3.8710 ms |  1.53 |    0.11 | 250.0000 |        - |        - | 20503.89 KB |    2,689.03 |
| Sylvan              | Xlsm   | 155.175 ms |  9.6963 ms | 9.0699 ms |  3.83 |    0.26 |        - |        - |        - |    644.6 KB |       84.54 |
|                     |        |            |            |           |       |         |          |          |          |             |             |
| **ExcelReaderOriginal** | **Xlsb**   |  **24.147 ms** |  **0.6893 ms** | **0.6448 ms** |  **1.00** |    **0.04** |        **-** |        **-** |        **-** |     **7.18 KB** |        **1.00** |
| ExcelReaderMemory   | Xlsb   |  24.437 ms |  0.7554 ms | 0.7066 ms |  1.01 |    0.04 |        - |        - |        - |     8.88 KB |        1.24 |
| OfficeIMOBytes      | Xlsb   |  26.162 ms |  1.5234 ms | 1.4250 ms |  1.08 |    0.06 | 282.0513 |        - |        - | 13985.91 KB |    1,947.98 |
| OfficeIMOStream     | Xlsb   |  26.537 ms |  1.2263 ms | 1.1471 ms |  1.10 |    0.05 | 388.8889 | 111.1111 | 111.1111 | 17771.28 KB |    2,475.22 |
| Sylvan              | Xlsb   |  30.174 ms |  1.8938 ms | 1.7715 ms |  1.25 |    0.08 |        - |        - |        - |   338.87 KB |       47.20 |
|                     |        |            |            |           |       |         |          |          |          |             |             |
| **ExcelReaderOriginal** | **Xls**    |   **9.089 ms** |  **0.3941 ms** | **0.3686 ms** |  **1.00** |    **0.06** |        **-** |        **-** |        **-** |    **12.02 KB** |        **1.00** |
| ExcelReaderMemory   | Xls    |   9.664 ms |  0.7303 ms | 0.6831 ms |  1.06 |    0.08 |        - |        - |        - |    11.88 KB |        0.99 |
| OfficeIMOBytes      | Xls    |  13.401 ms |  0.6530 ms | 0.6109 ms |  1.48 |    0.09 | 275.3623 |  14.4928 |        - | 13990.09 KB |    1,164.32 |
| OfficeIMOStream     | Xls    |  15.065 ms |  1.6750 ms | 1.5668 ms |  1.66 |    0.18 | 416.6667 | 133.3333 | 133.3333 | 25538.06 KB |    2,125.40 |
| Sylvan              | Xls    |  17.305 ms |  1.3064 ms | 1.2220 ms |  1.91 |    0.15 |        - |        - |        - |   186.29 KB |       15.50 |
