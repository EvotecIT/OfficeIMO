```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-CPEWJC : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=11111111111111110000000000000000  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=15  IterationTime=1s  LaunchCount=1  
UnrollFactor=1  WarmupCount=12  

```
| Method                    | Format | Mean      | Error    | StdDev   | Ratio | RatioSD | Gen0     | Allocated   | Alloc Ratio |
|-------------------------- |------- |----------:|---------:|---------:|------:|--------:|---------:|------------:|------------:|
| **ExcelReaderPrefetch**       | **Xlsx**   |  **28.12 ms** | **0.895 ms** | **0.837 ms** |  **1.00** |    **0.04** |        **-** |    **22.64 KB** |        **1.00** |
| ExcelReaderMemoryPrefetch | Xlsx   |  28.13 ms | 1.038 ms | 0.971 ms |  1.00 |    0.04 |        - |    24.53 KB |        1.08 |
| OfficeIMOBytes            | Xlsx   |  60.82 ms | 1.947 ms | 1.821 ms |  2.16 |    0.09 | 266.6667 | 13939.94 KB |      615.73 |
| Sylvan                    | Xlsx   | 156.40 ms | 4.967 ms | 4.646 ms |  5.57 |    0.23 |        - |   644.56 KB |       28.47 |
|                           |        |           |          |          |       |         |          |             |             |
| **ExcelReaderPrefetch**       | **Xlsm**   |  **28.03 ms** | **0.857 ms** | **0.801 ms** |  **1.00** |    **0.04** |        **-** |    **24.76 KB** |        **1.00** |
| ExcelReaderMemoryPrefetch | Xlsm   |  29.15 ms | 1.028 ms | 0.962 ms |  1.04 |    0.04 |        - |     23.2 KB |        0.94 |
| OfficeIMOBytes            | Xlsm   |  63.07 ms | 3.253 ms | 3.043 ms |  2.25 |    0.12 | 214.2857 | 13939.97 KB |      563.01 |
| Sylvan                    | Xlsm   | 149.78 ms | 8.987 ms | 8.407 ms |  5.35 |    0.33 |        - |    644.6 KB |       26.03 |
|                           |        |           |          |          |       |         |          |             |             |
| **ExcelReaderPrefetch**       | **Xlsb**   |  **15.48 ms** | **0.296 ms** | **0.277 ms** |  **1.00** |    **0.02** |        **-** |    **16.23 KB** |        **1.00** |
| ExcelReaderMemoryPrefetch | Xlsb   |  15.60 ms | 0.259 ms | 0.242 ms |  1.01 |    0.02 |        - |    19.23 KB |        1.19 |
| OfficeIMOBytes            | Xlsb   |  24.76 ms | 1.246 ms | 1.166 ms |  1.60 |    0.08 | 282.0513 | 13985.91 KB |      861.97 |
| Sylvan                    | Xlsb   |  26.10 ms | 1.066 ms | 0.997 ms |  1.69 |    0.07 |        - |   338.86 KB |       20.88 |
