```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-CPEWJC : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=11111111111111110000000000000000  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=15  IterationTime=1s  LaunchCount=1  
UnrollFactor=1  WarmupCount=12  

```
| Method                | RowCount | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated | Alloc Ratio |
|---------------------- |--------- |----------:|----------:|----------:|------:|--------:|---------:|---------:|---------:|----------:|------------:|
| ExcelReaderWriter     | 50000    |  3.721 ms | 0.1842 ms | 0.1723 ms |  1.00 |    0.06 | 500.0000 | 500.0000 | 500.0000 |      4 MB |        1.00 |
| OfficeIMOWriteObjects | 50000    | 10.978 ms | 1.0974 ms | 1.0265 ms |  2.96 |    0.30 | 691.5888 | 542.0561 | 542.0561 |  11.26 MB |        2.81 |
| SylvanWriter          | 50000    |  5.427 ms | 0.3345 ms | 0.3128 ms |  1.46 |    0.10 | 500.0000 | 500.0000 | 500.0000 |   4.04 MB |        1.01 |
