```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-CPEWJC : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=11111111111111110000000000000000  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=15  IterationTime=1s  LaunchCount=1  
UnrollFactor=1  WarmupCount=12  

```
| Method                  | RowCount | Mean     | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1   | Allocated | Alloc Ratio |
|------------------------ |--------- |---------:|----------:|----------:|------:|--------:|---------:|-------:|----------:|------------:|
| ExcelReaderMaterialized | 50000    | 2.407 ms | 0.0869 ms | 0.0812 ms |  1.00 |    0.05 |  30.8057 |      - |   1.57 MB |        1.00 |
| OfficeIMOMaterialized   | 50000    | 5.034 ms | 0.2959 ms | 0.2767 ms |  2.09 |    0.13 | 180.2575 |      - |   8.63 MB |        5.48 |
| SylvanMaterialized      | 50000    | 3.160 ms | 0.1226 ms | 0.1146 ms |  1.31 |    0.06 |  32.6797 | 3.2680 |   1.61 MB |        1.02 |
