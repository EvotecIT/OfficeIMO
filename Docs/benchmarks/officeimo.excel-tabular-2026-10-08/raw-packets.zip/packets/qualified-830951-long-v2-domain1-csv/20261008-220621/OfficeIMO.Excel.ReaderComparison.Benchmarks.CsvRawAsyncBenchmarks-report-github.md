```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-CPEWJC : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=11111111111111110000000000000000  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=15  IterationTime=1s  LaunchCount=1  
UnrollFactor=1  WarmupCount=12  

```
| Method           | RowCount | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1    | Allocated | Alloc Ratio |
|----------------- |--------- |----------:|----------:|----------:|------:|--------:|---------:|--------:|----------:|------------:|
| ExcelReaderAsync | 50000    |  2.514 ms | 0.1458 ms | 0.1364 ms |  1.00 |    0.07 |  32.1839 |       - |   1.57 MB |        1.00 |
| OfficeIMOAsync   | 50000    | 10.801 ms | 0.4394 ms | 0.4110 ms |  4.31 |    0.28 | 288.8889 | 22.2222 |  14.18 MB |        9.01 |
| SylvanAsync      | 50000    |  3.666 ms | 0.1544 ms | 0.1444 ms |  1.46 |    0.10 |  33.5570 |  3.3557 |   1.62 MB |        1.03 |
