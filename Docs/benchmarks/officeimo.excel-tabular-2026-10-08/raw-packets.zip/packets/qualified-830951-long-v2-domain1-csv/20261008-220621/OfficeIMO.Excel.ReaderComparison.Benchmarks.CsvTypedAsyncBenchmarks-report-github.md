```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-CPEWJC : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=11111111111111110000000000000000  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=15  IterationTime=1s  LaunchCount=1  
UnrollFactor=1  WarmupCount=12  

```
| Method                | RowCount | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1    | Allocated | Alloc Ratio |
|---------------------- |--------- |----------:|----------:|----------:|------:|--------:|---------:|--------:|----------:|------------:|
| ExcelReaderTypedAsync | 50000    |  4.311 ms | 0.4236 ms | 0.3962 ms |  1.01 |    0.13 |  80.0000 |       - |   3.86 MB |        1.00 |
| OfficeIMORowsAsAsync  | 50000    | 13.541 ms | 0.6190 ms | 0.5790 ms |  3.17 |    0.31 | 333.3333 | 24.6914 |  16.47 MB |        4.26 |
| SylvanTypedAsync      | 50000    |  8.721 ms | 0.4959 ms | 0.4639 ms |  2.04 |    0.21 | 222.2222 | 23.8095 |  10.96 MB |        2.84 |
