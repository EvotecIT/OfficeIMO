```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-CPEWJC : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=11111111111111110000000000000000  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=15  IterationTime=1s  LaunchCount=1  
UnrollFactor=1  WarmupCount=12  

```
| Method          | RowCount | MaterializeStrings | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0      | Gen1     | Allocated  | Alloc Ratio |
|---------------- |--------- |------------------- |----------:|----------:|----------:|------:|--------:|----------:|---------:|-----------:|------------:|
| **ExcelReaderWide** | **50000**    | **False**              |  **5.487 ms** | **0.2710 ms** | **0.2535 ms** |  **1.00** |    **0.06** |         **-** |        **-** |      **848 B** |        **1.00** |
| OfficeIMOWide   | 50000    | False              |  6.678 ms | 0.4516 ms | 0.4224 ms |  1.22 |    0.09 |         - |        - |     4360 B |        5.14 |
| SylvanWide      | 50000    | False              |  4.650 ms | 0.4114 ms | 0.3848 ms |  0.85 |    0.08 |         - |        - |    46377 B |       54.69 |
|                 |          |                    |           |           |           |       |         |           |          |            |             |
| **ExcelReaderWide** | **50000**    | **True**               | **20.947 ms** | **2.0688 ms** | **1.9351 ms** |  **1.01** |    **0.12** | **1037.7358** |        **-** | **52800848 B** |        **1.00** |
| OfficeIMOWide   | 50000    | True               | 14.023 ms | 0.9493 ms | 0.8880 ms |  0.67 |    0.07 | 1049.3827 |  12.3457 | 52804360 B |        1.00 |
| SylvanWide      | 50000    | True               | 11.755 ms | 0.8562 ms | 0.8009 ms |  0.57 |    0.06 | 1043.9560 | 164.8352 | 52846584 B |        1.00 |
