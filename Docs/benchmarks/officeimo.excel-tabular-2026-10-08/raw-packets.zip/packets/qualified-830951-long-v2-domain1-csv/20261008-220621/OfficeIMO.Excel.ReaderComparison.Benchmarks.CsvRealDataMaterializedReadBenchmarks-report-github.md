```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-CPEWJC : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=11111111111111110000000000000000  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=15  IterationTime=1s  LaunchCount=1  
UnrollFactor=1  WarmupCount=12  

```
| Method                  | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Allocated | Alloc Ratio |
|------------------------ |----------:|----------:|----------:|------:|--------:|---------:|---------:|----------:|------------:|
| ExcelReaderMaterialized | 23.008 ms | 1.0159 ms | 0.9503 ms |  1.00 |    0.06 | 739.1304 |        - |  35.71 MB |        1.00 |
| OfficeIMOMaterialized   | 13.001 ms | 0.4700 ms | 0.4397 ms |  0.57 |    0.03 | 702.7027 |        - |  34.21 MB |        0.96 |
| SylvanMaterialized      |  9.353 ms | 0.4793 ms | 0.4483 ms |  0.41 |    0.02 | 745.6140 | 105.2632 |  35.75 MB |        1.00 |
