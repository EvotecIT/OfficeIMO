```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-CPEWJC : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=11111111111111110000000000000000  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=15  IterationTime=1s  LaunchCount=1  
UnrollFactor=1  WarmupCount=12  

```
| Method                      | Mean     | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|---------------------------- |---------:|----------:|----------:|------:|--------:|----------:|------------:|
| ExcelReaderStream           | 6.691 ms | 0.1285 ms | 0.1202 ms |  1.00 |    0.02 |     848 B |        1.00 |
| ExcelReaderMemory           | 7.281 ms | 0.2017 ms | 0.1887 ms |  1.09 |    0.03 |     576 B |        0.68 |
| OfficeIMOStreamBorrowedUtf8 | 4.863 ms | 0.2364 ms | 0.2212 ms |  0.73 |    0.03 |    2920 B |        3.44 |
| SylvanFieldSpan             | 6.380 ms | 0.3409 ms | 0.3189 ms |  0.95 |    0.05 |   41225 B |       48.61 |
