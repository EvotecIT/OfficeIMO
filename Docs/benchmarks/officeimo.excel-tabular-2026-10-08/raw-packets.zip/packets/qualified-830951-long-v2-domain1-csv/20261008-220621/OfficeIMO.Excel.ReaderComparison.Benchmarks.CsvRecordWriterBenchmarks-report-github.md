```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-CPEWJC : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=11111111111111110000000000000000  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=15  IterationTime=1s  LaunchCount=1  
UnrollFactor=1  WarmupCount=12  

```
| Method                  | Mapped | RowCount | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated | Alloc Ratio |
|------------------------ |------- |--------- |----------:|----------:|----------:|------:|--------:|---------:|---------:|---------:|----------:|------------:|
| **ExcelReaderRecordLayout** | **False**  | **50000**    |  **3.626 ms** | **0.1733 ms** | **0.1621 ms** |  **1.00** |    **0.06** | **333.3333** | **333.3333** | **333.3333** |      **4 MB** |        **1.00** |
| OfficeIMOWriteObjects   | False  | 50000    | 10.275 ms | 0.2333 ms | 0.2183 ms |  2.84 |    0.13 | 489.7959 | 346.9388 | 346.9388 |  11.26 MB |        2.81 |
|                         |        |          |           |           |           |       |         |          |          |          |           |             |
| **ExcelReaderRecordLayout** | **True**   | **50000**    |  **4.321 ms** | **0.1334 ms** | **0.1248 ms** |  **1.00** |    **0.04** | **331.8777** | **331.8777** | **331.8777** |      **4 MB** |        **1.00** |
| OfficeIMOWriteObjects   | True   | 50000    | 10.126 ms | 0.2796 ms | 0.2615 ms |  2.35 |    0.09 | 484.5361 | 340.2062 | 340.2062 |  11.26 MB |        2.81 |
