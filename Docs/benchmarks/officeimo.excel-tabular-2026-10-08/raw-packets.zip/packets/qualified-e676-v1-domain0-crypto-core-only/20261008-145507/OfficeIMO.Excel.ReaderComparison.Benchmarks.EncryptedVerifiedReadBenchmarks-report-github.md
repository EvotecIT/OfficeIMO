```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-VBBITA : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=00000000000000001111111111111111  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\crypto-only-bundle-4ee00b",/p:OfficeIMOBenchmarkNewApis=true  
IterationCount=15  IterationTime=250ms  LaunchCount=1  
UnrollFactor=1  WarmupCount=12  

```
| Method                      | Input             | MemoryInput | Mean     | Error    | StdDev   | Allocated |
|---------------------------- |------------------ |------------ |---------:|---------:|---------:|----------:|
| **OfficeIMOVerifiedFullFields** | **OriginalSmallXlsx** | **False**       | **28.10 ms** | **2.434 ms** | **2.276 ms** | **558.83 KB** |
| **OfficeIMOVerifiedFullFields** | **OriginalSmallXlsx** | **True**        | **27.53 ms** | **1.656 ms** | **1.549 ms** |  **539.6 KB** |
