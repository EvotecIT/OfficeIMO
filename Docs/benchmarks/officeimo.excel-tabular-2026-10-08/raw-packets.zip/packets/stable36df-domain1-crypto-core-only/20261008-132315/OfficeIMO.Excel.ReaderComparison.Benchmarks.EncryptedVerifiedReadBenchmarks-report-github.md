```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-KJBLOG : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=11111111111111110000000000000000  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\crypto-only-bundle-4ee00b",/p:OfficeIMOBenchmarkNewApis=true  
InvocationCount=4  IterationCount=10  LaunchCount=1  
UnrollFactor=1  WarmupCount=8  

```
| Method                      | Input             | MemoryInput | Mean     | Error    | StdDev   | Allocated |
|---------------------------- |------------------ |------------ |---------:|---------:|---------:|----------:|
| **OfficeIMOVerifiedFullFields** | **OriginalSmallXlsx** | **False**       | **24.06 ms** | **2.733 ms** | **1.808 ms** | **559.98 KB** |
| **OfficeIMOVerifiedFullFields** | **OriginalSmallXlsx** | **True**        | **23.23 ms** | **2.128 ms** | **1.407 ms** | **540.12 KB** |
