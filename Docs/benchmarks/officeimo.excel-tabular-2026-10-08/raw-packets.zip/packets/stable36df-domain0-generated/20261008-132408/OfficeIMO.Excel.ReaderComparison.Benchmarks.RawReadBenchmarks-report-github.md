```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-ULQWZY : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=00000000000000001111111111111111  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-36df28",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
InvocationCount=4  IterationCount=10  LaunchCount=1  
UnrollFactor=1  WarmupCount=6  

```
| Method              | RowCount | Format | Mean      | Error      | StdDev     | Median    | Ratio | RatioSD | Gen0     | Allocated   | Alloc Ratio |
|-------------------- |--------- |------- |----------:|-----------:|-----------:|----------:|------:|--------:|---------:|------------:|------------:|
| **ExcelReaderOriginal** | **50000**    | **Xlsx**   | **10.081 ms** |  **5.8359 ms** |  **3.8601 ms** | **10.698 ms** |  **1.16** |    **0.64** |        **-** |     **3.82 KB** |        **1.00** |
| OfficeIMOOriginal   | 50000    | Xlsx   | 18.401 ms | 19.6052 ms | 12.9677 ms | 13.840 ms |  2.12 |    1.74 |        - |  3592.42 KB |      940.35 |
| Sylvan              | 50000    | Xlsx   | 33.715 ms | 11.4682 ms |  7.5855 ms | 31.402 ms |  3.88 |    1.77 |        - |     1939 KB |      507.55 |
|                     |          |        |           |            |            |           |       |         |          |             |             |
| **ExcelReaderOriginal** | **50000**    | **Xlsb**   |  **4.747 ms** |  **0.7071 ms** |  **0.4677 ms** |  **4.583 ms** |  **1.01** |    **0.13** |        **-** |     **4.13 KB** |        **1.00** |
| OfficeIMOOriginal   | 50000    | Xlsb   | 17.546 ms |  3.4874 ms |  2.3067 ms | 17.510 ms |  3.72 |    0.56 |        - |  6858.42 KB |    1,659.50 |
| Sylvan              | 50000    | Xlsb   | 16.404 ms |  6.8017 ms |  4.4989 ms | 18.875 ms |  3.48 |    0.96 |        - |  1865.65 KB |      451.42 |
|                     |          |        |           |            |            |           |       |         |          |             |             |
| **ExcelReaderOriginal** | **50000**    | **Xls**    |  **4.742 ms** |  **0.3313 ms** |  **0.2191 ms** |  **4.698 ms** |  **1.00** |    **0.06** |        **-** |    **30.26 KB** |        **1.00** |
| OfficeIMOOriginal   | 50000    | Xls    |  9.160 ms |  0.6787 ms |  0.4489 ms |  9.264 ms |  1.94 |    0.12 | 250.0000 | 11587.52 KB |      382.98 |
| Sylvan              | 50000    | Xls    |  9.619 ms |  1.5098 ms |  0.9986 ms |  9.189 ms |  2.03 |    0.22 |        - |  1725.85 KB |       57.04 |
