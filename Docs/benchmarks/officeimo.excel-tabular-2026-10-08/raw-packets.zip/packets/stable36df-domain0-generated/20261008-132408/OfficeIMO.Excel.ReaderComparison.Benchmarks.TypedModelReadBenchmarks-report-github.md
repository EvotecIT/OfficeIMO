```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-ULQWZY : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=00000000000000001111111111111111  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-36df28",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
InvocationCount=4  IterationCount=10  LaunchCount=1  
UnrollFactor=1  WarmupCount=6  

```
| Method               | RowCount | Model  | Mean     | Error     | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|--------------------- |--------- |------- |---------:|----------:|---------:|------:|--------:|----------:|------------:|
| **ExcelReaderAutomatic** | **50000**    | **Class**  | **12.53 ms** |  **3.266 ms** | **2.160 ms** |  **1.03** |    **0.24** |   **3.87 MB** |        **1.00** |
| OfficeIMOAutomatic   | 50000    | Class  | 25.51 ms | 11.050 ms | 7.309 ms |  2.09 |    0.68 |   6.94 MB |        1.80 |
|                      |          |        |          |           |          |       |         |           |             |
| **ExcelReaderAutomatic** | **50000**    | **Struct** | **12.78 ms** |  **2.229 ms** | **1.474 ms** |  **1.01** |    **0.16** |   **1.58 MB** |        **1.00** |
| OfficeIMOAutomatic   | 50000    | Struct | 23.04 ms |  1.741 ms | 1.152 ms |  1.83 |    0.23 |   4.65 MB |        2.95 |
