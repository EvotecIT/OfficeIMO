```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-ULQWZY : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=00000000000000001111111111111111  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-36df28",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
InvocationCount=4  IterationCount=10  LaunchCount=1  
UnrollFactor=1  WarmupCount=6  

```
| Method                         | RowCount | Format | Mean      | Error     | StdDev     | Median    | Ratio | RatioSD | Allocated | Alloc Ratio |
|------------------------------- |--------- |------- |----------:|----------:|-----------:|----------:|------:|--------:|----------:|------------:|
| **ExcelReaderStringsMaterialized** | **50000**    | **Xlsx**   |  **8.788 ms** |  **4.579 ms** |  **3.0285 ms** |  **6.821 ms** |  **1.09** |    **0.47** |   **1.58 MB** |        **1.00** |
| OfficeIMOOriginal              | 50000    | Xlsx   | 22.633 ms | 22.550 ms | 14.9152 ms | 14.673 ms |  2.82 |    1.97 |   3.51 MB |        2.22 |
| Sylvan                         | 50000    | Xlsx   | 39.742 ms | 14.194 ms |  9.3884 ms | 39.608 ms |  4.94 |    1.74 |   1.89 MB |        1.20 |
|                                |          |        |           |           |            |           |       |         |           |             |
| **ExcelReaderStringsMaterialized** | **50000**    | **Xlsb**   |  **5.992 ms** |  **1.327 ms** |  **0.8775 ms** |  **5.920 ms** |  **1.02** |    **0.20** |   **1.58 MB** |        **1.00** |
| OfficeIMOOriginal              | 50000    | Xlsb   | 10.358 ms |  1.814 ms |  1.2001 ms |  9.823 ms |  1.76 |    0.31 |    6.7 MB |        4.25 |
| Sylvan                         | 50000    | Xlsb   | 14.574 ms |  3.366 ms |  2.2262 ms | 13.447 ms |  2.48 |    0.50 |   1.82 MB |        1.15 |
|                                |          |        |           |           |            |           |       |         |           |             |
| **ExcelReaderStringsMaterialized** | **50000**    | **Xls**    |  **5.028 ms** |  **1.074 ms** |  **0.7102 ms** |  **5.101 ms** |  **1.02** |    **0.23** |   **1.58 MB** |        **1.00** |
| OfficeIMOOriginal              | 50000    | Xls    |  8.425 ms |  1.878 ms |  1.2425 ms |  8.784 ms |  1.71 |    0.38 |  10.25 MB |        6.50 |
| Sylvan                         | 50000    | Xls    |  7.582 ms |  2.372 ms |  1.5688 ms |  7.822 ms |  1.54 |    0.41 |   1.68 MB |        1.06 |
