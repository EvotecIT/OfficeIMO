```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-ULQWZY : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=00000000000000001111111111111111  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-36df28",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
InvocationCount=4  IterationCount=10  LaunchCount=1  
UnrollFactor=1  WarmupCount=6  

```
| Method           | RowCount | Format | Mean      | Error      | StdDev     | Median    | Ratio | RatioSD | Allocated   | Alloc Ratio |
|----------------- |--------- |------- |----------:|-----------:|-----------:|----------:|------:|--------:|------------:|------------:|
| **ExcelReaderAsync** | **50000**    | **Xlsx**   | **13.318 ms** |  **3.8138 ms** |  **2.5226 ms** | **13.069 ms** |  **1.03** |    **0.26** |     **3.89 KB** |        **1.00** |
| OfficeIMOAsync   | 50000    | Xlsx   | 19.276 ms | 23.2478 ms | 15.3770 ms | 13.581 ms |  1.49 |    1.18 |  3592.43 KB |      923.36 |
| SylvanAsync      | 50000    | Xlsx   | 38.833 ms |  6.8633 ms |  4.5397 ms | 39.819 ms |  3.01 |    0.62 |  1939.91 KB |      498.61 |
|                  |          |        |           |            |            |           |       |         |             |             |
| **ExcelReaderAsync** | **50000**    | **Xlsb**   |  **5.404 ms** |  **0.9636 ms** |  **0.6374 ms** |  **5.313 ms** |  **1.01** |    **0.16** |      **4.2 KB** |        **1.00** |
| OfficeIMOAsync   | 50000    | Xlsb   | 12.031 ms |  1.9288 ms |  1.2758 ms | 12.109 ms |  2.25 |    0.34 |  6858.49 KB |    1,631.76 |
| SylvanAsync      | 50000    | Xlsb   | 22.536 ms |  3.1932 ms |  2.1121 ms | 22.413 ms |  4.22 |    0.61 |  1866.56 KB |      444.09 |
|                  |          |        |           |            |            |           |       |         |             |             |
| **ExcelReaderAsync** | **50000**    | **Xls**    |  **2.921 ms** |  **0.6067 ms** |  **0.4013 ms** |  **2.742 ms** |  **1.01** |    **0.17** |     **2.91 KB** |        **1.00** |
| OfficeIMOAsync   | 50000    | Xls    |  6.942 ms |  2.0808 ms |  1.3763 ms |  6.850 ms |  2.41 |    0.53 | 10499.45 KB |    3,612.71 |
| SylvanAsync      | 50000    | Xls    |  8.308 ms |  2.2537 ms |  1.4907 ms |  8.777 ms |  2.88 |    0.59 |  1719.08 KB |      591.51 |
