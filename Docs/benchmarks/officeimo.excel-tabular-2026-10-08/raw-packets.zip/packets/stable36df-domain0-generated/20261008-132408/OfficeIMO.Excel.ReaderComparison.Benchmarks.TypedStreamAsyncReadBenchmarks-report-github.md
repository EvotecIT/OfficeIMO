```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-ULQWZY : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=00000000000000001111111111111111  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-36df28",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
InvocationCount=4  IterationCount=10  LaunchCount=1  
UnrollFactor=1  WarmupCount=6  

```
| Method                          | RowCount | Shape    | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0      | Gen1      | Gen2      | Allocated | Alloc Ratio |
|-------------------------------- |--------- |--------- |----------:|----------:|----------:|------:|--------:|----------:|----------:|----------:|----------:|------------:|
| OfficeIMOStreamOpenTypedAsync   | 50000    | Original | 622.55 ms | 46.471 ms | 30.738 ms | 55.48 |    7.27 | 9750.0000 | 6750.0000 | 1250.0000 | 411.01 MB |      106.29 |
| ExcelReaderStreamOpenTypedAsync | 50000    | Original |  11.43 ms |  2.717 ms |  1.797 ms |  1.02 |    0.20 |         - |         - |         - |   3.87 MB |        1.00 |
| SylvanStreamOpenTypedAsync      | 50000    | Original |  60.55 ms |  9.435 ms |  6.241 ms |  5.40 |    0.85 |         - |         - |         - |  10.48 MB |        2.71 |
