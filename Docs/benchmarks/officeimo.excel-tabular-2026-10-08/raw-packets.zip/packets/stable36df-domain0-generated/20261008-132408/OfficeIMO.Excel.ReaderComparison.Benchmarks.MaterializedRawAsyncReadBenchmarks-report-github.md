```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-ULQWZY : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=00000000000000001111111111111111  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-36df28",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
InvocationCount=4  IterationCount=10  LaunchCount=1  
UnrollFactor=1  WarmupCount=6  

```
| Method                              | RowCount | Format | Mean      | Error     | StdDev    | Median    | Ratio | RatioSD | Allocated | Alloc Ratio |
|------------------------------------ |--------- |------- |----------:|----------:|----------:|----------:|------:|--------:|----------:|------------:|
| **ExcelReaderStringsMaterializedAsync** | **50000**    | **Xlsx**   | **13.120 ms** |  **5.475 ms** | **3.6213 ms** | **11.551 ms** |  **1.07** |    **0.38** |   **1.58 MB** |        **1.00** |
| OfficeIMOAsync                      | 50000    | Xlsx   | 16.675 ms | 12.636 ms | 8.3578 ms | 13.606 ms |  1.35 |    0.74 |   3.51 MB |        2.22 |
| SylvanAsync                         | 50000    | Xlsx   | 35.994 ms |  6.126 ms | 4.0517 ms | 35.692 ms |  2.92 |    0.77 |   1.89 MB |        1.20 |
|                                     |          |        |           |           |           |           |       |         |           |             |
| **ExcelReaderStringsMaterializedAsync** | **50000**    | **Xlsb**   |  **5.883 ms** |  **1.195 ms** | **0.7907 ms** |  **5.549 ms** |  **1.02** |    **0.18** |   **1.58 MB** |        **1.00** |
| OfficeIMOAsync                      | 50000    | Xlsb   | 14.419 ms |  2.758 ms | 1.8240 ms | 13.808 ms |  2.49 |    0.43 |    6.7 MB |        4.25 |
| SylvanAsync                         | 50000    | Xlsb   | 11.819 ms | 11.507 ms | 7.6114 ms |  8.590 ms |  2.04 |    1.29 |   1.82 MB |        1.16 |
|                                     |          |        |           |           |           |           |       |         |           |             |
| **ExcelReaderStringsMaterializedAsync** | **50000**    | **Xls**    |  **4.736 ms** |  **1.114 ms** | **0.7367 ms** |  **4.881 ms** |  **1.02** |    **0.23** |   **1.58 MB** |        **1.00** |
| OfficeIMOAsync                      | 50000    | Xls    |  6.320 ms |  1.480 ms | 0.9788 ms |  5.936 ms |  1.37 |    0.30 |  10.25 MB |        6.50 |
| SylvanAsync                         | 50000    | Xls    | 10.343 ms |  9.737 ms | 6.4404 ms |  7.978 ms |  2.24 |    1.39 |   1.68 MB |        1.06 |
