```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-ULQWZY : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=00000000000000001111111111111111  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-36df28",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
InvocationCount=4  IterationCount=10  LaunchCount=1  
UnrollFactor=1  WarmupCount=6  

```
| Method                | RowCount | Shape    | Mean     | Error    | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|---------------------- |--------- |--------- |---------:|---------:|---------:|------:|--------:|----------:|------------:|
| OfficeIMOTypedAsync   | 50000    | Original | 21.79 ms | 4.107 ms | 2.716 ms |  1.45 |    0.23 |   6.94 MB |        1.80 |
| ExcelReaderTypedAsync | 50000    | Original | 15.19 ms | 2.446 ms | 1.618 ms |  1.01 |    0.14 |   3.87 MB |        1.00 |
| SylvanTypedAsync      | 50000    | Original | 68.53 ms | 7.577 ms | 5.011 ms |  4.56 |    0.56 |  10.48 MB |        2.71 |
