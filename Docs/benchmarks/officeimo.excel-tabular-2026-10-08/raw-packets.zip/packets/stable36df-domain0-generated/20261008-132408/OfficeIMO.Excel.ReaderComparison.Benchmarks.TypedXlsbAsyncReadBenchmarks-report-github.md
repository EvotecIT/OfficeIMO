```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-ULQWZY : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=00000000000000001111111111111111  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-36df28",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
InvocationCount=4  IterationCount=10  LaunchCount=1  
UnrollFactor=1  WarmupCount=6  

```
| Method                    | RowCount | Mean      | Error    | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|-------------------------- |--------- |----------:|---------:|---------:|------:|--------:|----------:|------------:|
| ExcelReaderTypedXlsbAsync | 50000    |  8.358 ms | 1.607 ms | 1.063 ms |  1.01 |    0.17 |   3.87 MB |        1.00 |
| OfficeIMOTypedXlsbAsync   | 50000    | 22.494 ms | 4.708 ms | 3.114 ms |  2.73 |    0.48 |  10.13 MB |        2.62 |
| SylvanTypedXlsbAsync      | 50000    | 25.629 ms | 3.910 ms | 2.586 ms |  3.11 |    0.47 |   10.4 MB |        2.69 |
