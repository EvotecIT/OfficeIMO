```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-ULQWZY : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=00000000000000001111111111111111  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-36df28",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
InvocationCount=4  IterationCount=10  LaunchCount=1  
UnrollFactor=1  WarmupCount=6  

```
| Method               | RowCount | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|--------------------- |--------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| ExcelReaderTypedXlsb | 50000    |  8.109 ms | 1.6995 ms | 1.1241 ms |  1.02 |    0.19 |   3.87 MB |        1.00 |
| OfficeIMOTypedXlsb   | 50000    | 21.268 ms | 0.8497 ms | 0.5620 ms |  2.67 |    0.34 |   5.55 MB |        1.44 |
| SylvanTypedXlsb      | 50000    | 26.022 ms | 4.5290 ms | 2.9956 ms |  3.26 |    0.54 |   10.4 MB |        2.69 |
