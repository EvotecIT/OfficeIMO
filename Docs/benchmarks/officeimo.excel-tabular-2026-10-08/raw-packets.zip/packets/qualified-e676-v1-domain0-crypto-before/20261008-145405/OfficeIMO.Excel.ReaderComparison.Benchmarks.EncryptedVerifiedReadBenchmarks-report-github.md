```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-OVQHXH : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=00000000000000001111111111111111  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-ba9",/p:OfficeIMOBenchmarkNewApis=true  
IterationCount=15  IterationTime=250ms  LaunchCount=1  
UnrollFactor=1  WarmupCount=12  

```
| Method                      | Input             | MemoryInput | Mean     | Error   | StdDev  | Gen0      | Allocated |
|---------------------------- |------------------ |------------ |---------:|--------:|--------:|----------:|----------:|
| **OfficeIMOVerifiedFullFields** | **OriginalSmallXlsx** | **False**       | **189.9 ms** | **8.48 ms** | **7.93 ms** | **3000.0000** | **137.89 MB** |
| **OfficeIMOVerifiedFullFields** | **OriginalSmallXlsx** | **True**        | **182.8 ms** | **7.93 ms** | **7.42 ms** | **3000.0000** | **137.87 MB** |
