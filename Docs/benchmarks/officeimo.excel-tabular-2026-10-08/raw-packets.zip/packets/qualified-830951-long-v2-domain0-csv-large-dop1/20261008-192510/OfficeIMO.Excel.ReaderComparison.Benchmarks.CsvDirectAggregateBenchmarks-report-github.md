```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-THMKXO : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=00000000000000001111111111111111  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=8  IterationTime=250ms  LaunchCount=1  
UnrollFactor=1  WarmupCount=4  

```
| Method                        | Input                | Dop | Mean       | Error     | StdDev    | Ratio | RatioSD | Gen0       | Gen1       | Gen2      | Allocated     | Alloc Ratio |
|------------------------------ |--------------------- |---- |-----------:|----------:|----------:|------:|--------:|-----------:|-----------:|----------:|--------------:|------------:|
| **ExcelReaderAggregate**          | **Conve(...)00000 [23]** | **1**   |   **696.8 ms** | **267.40 ms** | **139.86 ms** |  **1.04** |    **0.28** |          **-** |          **-** |         **-** |    **1228.73 KB** |        **1.00** |
| OfficeIMOTextOwnedAggregate   | Conve(...)00000 [23] | 1   |   724.7 ms |  55.83 ms |  29.20 ms |  1.08 |    0.21 | 10500.0000 | 10250.0000 | 2250.0000 |   812778.7 KB |      661.48 |
| OfficeIMOAsyncPathAggregate   | Conve(...)00000 [23] | 1   | 2,600.0 ms | 333.90 ms | 174.64 ms |  3.87 |    0.78 | 38750.0000 |   250.0000 |         - | 1903086.21 KB |    1,548.82 |
| OfficeIMOAsyncStreamAggregate | Conve(...)00000 [23] | 1   | 2,196.9 ms | 656.28 ms | 343.25 ms |  3.27 |    0.80 | 39000.0000 |   250.0000 |         - | 1903092.23 KB |    1,548.82 |
|                               |                      |     |            |           |           |       |         |            |            |           |               |             |
| **ExcelReaderAggregate**          | **Conve(...)00000 [25]** | **1**   |   **582.8 ms** | **115.14 ms** |  **60.22 ms** |  **1.01** |    **0.14** |          **-** |          **-** |         **-** |     **929.15 KB** |        **1.00** |
| OfficeIMOTextOwnedAggregate   | Conve(...)00000 [25] | 1   |   499.0 ms |  50.40 ms |  26.36 ms |  0.86 |    0.09 | 16750.0000 | 16500.0000 | 3000.0000 |  567413.63 KB |      610.68 |
| OfficeIMOAsyncPathAggregate   | Conve(...)00000 [25] | 1   | 1,843.2 ms | 526.00 ms | 275.11 ms |  3.19 |    0.54 | 27250.0000 |   250.0000 |         - | 1327730.37 KB |    1,428.97 |
| OfficeIMOAsyncStreamAggregate | Conve(...)00000 [25] | 1   | 2,049.4 ms | 704.87 ms | 368.66 ms |  3.55 |    0.69 | 27000.0000 |   250.0000 |         - | 1327745.75 KB |    1,428.99 |
|                               |                      |     |            |           |           |       |         |            |            |           |               |             |
| **ExcelReaderAggregate**          | **NarrowInt-8000000**    | **1**   |   **586.7 ms** |  **38.53 ms** |  **20.15 ms** |  **1.00** |    **0.04** |          **-** |          **-** |         **-** |    **1281.29 KB** |        **1.00** |
| OfficeIMOTextOwnedAggregate   | NarrowInt-8000000    | 1   |   894.4 ms |  87.03 ms |  45.52 ms |  1.53 |    0.09 | 23000.0000 | 22750.0000 | 3000.0000 |  821055.97 KB |      640.80 |
| OfficeIMOAsyncPathAggregate   | NarrowInt-8000000    | 1   | 3,182.5 ms | 360.70 ms | 188.65 ms |  5.43 |    0.35 | 45250.0000 |   250.0000 |         - | 2207873.59 KB |    1,723.17 |
| OfficeIMOAsyncStreamAggregate | NarrowInt-8000000    | 1   | 3,291.0 ms | 270.04 ms | 141.23 ms |  5.62 |    0.29 | 45000.0000 |   250.0000 |         - | 2207872.72 KB |    1,723.17 |
