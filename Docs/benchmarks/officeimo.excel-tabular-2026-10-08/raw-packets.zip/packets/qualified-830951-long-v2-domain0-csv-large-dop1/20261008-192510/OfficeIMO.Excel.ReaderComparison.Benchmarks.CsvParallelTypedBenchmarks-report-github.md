```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-THMKXO : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=00000000000000001111111111111111  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=8  IterationTime=250ms  LaunchCount=1  
UnrollFactor=1  WarmupCount=4  

```
| Method                | Input                | Dop | Mean       | Error     | StdDev    | Ratio | RatioSD | Gen0       | Gen1       | Gen2      | Allocated  | Alloc Ratio |
|---------------------- |--------------------- |---- |-----------:|----------:|----------:|------:|--------:|-----------:|-----------:|----------:|-----------:|------------:|
| **ExcelReaderParallel**   | **Conve(...)00000 [23]** | **1**   |   **977.8 ms** | **119.55 ms** |  **62.53 ms** |  **1.00** |    **0.09** | **14250.0000** |   **250.0000** |         **-** |  **671.46 MB** |        **1.00** |
| ExcelReaderSequential | Conve(...)00000 [23] | 1   |   927.1 ms | 111.48 ms |  58.30 ms |  0.95 |    0.08 | 14000.0000 |          - |         - |  669.82 MB |        1.00 |
| OfficeIMOCoreParallel | Conve(...)00000 [23] | 1   |   762.8 ms |  28.02 ms |  14.65 ms |  0.78 |    0.05 | 27000.0000 |          - |         - | 1290.27 MB |        1.92 |
| OfficeIMOTextParallel | Conve(...)00000 [23] | 1   |   936.5 ms |  88.72 ms |  46.40 ms |  0.96 |    0.07 | 35750.0000 | 20750.0000 | 2750.0000 | 1463.86 MB |        2.18 |
| SylvanSequential      | Conve(...)00000 [23] | 1   | 1,222.9 ms | 211.76 ms | 110.75 ms |  1.26 |    0.13 | 27000.0000 |          - |         - | 1292.01 MB |        1.92 |
|                       |                      |     |            |           |           |       |         |            |            |           |            |             |
| **ExcelReaderParallel**   | **Conve(...)00000 [25]** | **1**   |   **700.6 ms** |  **65.45 ms** |  **34.23 ms** |  **1.00** |    **0.07** |  **9750.0000** |          **-** |         **-** |  **468.42 MB** |        **1.00** |
| ExcelReaderSequential | Conve(...)00000 [25] | 1   |   702.5 ms |  34.88 ms |  18.24 ms |  1.00 |    0.05 |  9750.0000 |          - |         - |   467.3 MB |        1.00 |
| OfficeIMOCoreParallel | Conve(...)00000 [25] | 1   |   531.6 ms |  73.31 ms |  38.34 ms |  0.76 |    0.06 | 18750.0000 |          - |         - |  900.14 MB |        1.92 |
| OfficeIMOTextParallel | Conve(...)00000 [25] | 1   |   672.6 ms |  39.62 ms |  20.72 ms |  0.96 |    0.05 | 19250.0000 |  9250.0000 | 2500.0000 | 1021.41 MB |        2.18 |
| SylvanSequential      | Conve(...)00000 [25] | 1   |   987.3 ms | 107.26 ms |  56.10 ms |  1.41 |    0.10 | 18750.0000 |          - |         - |  901.42 MB |        1.92 |
|                       |                      |     |            |           |           |       |         |            |            |           |            |             |
| **ExcelReaderParallel**   | **NarrowInt-8000000**    | **1**   |   **577.0 ms** |  **21.79 ms** |  **11.40 ms** |  **1.00** |    **0.03** |  **5000.0000** |          **-** |         **-** |  **245.75 MB** |        **1.00** |
| ExcelReaderSequential | NarrowInt-8000000    | 1   |   547.3 ms |  39.01 ms |  20.40 ms |  0.95 |    0.04 |  5000.0000 |          - |         - |  244.14 MB |        0.99 |
| OfficeIMOCoreParallel | NarrowInt-8000000    | 1   |   728.1 ms |  52.86 ms |  27.65 ms |  1.26 |    0.05 | 24000.0000 |          - |         - | 1158.54 MB |        4.71 |
| OfficeIMOTextParallel | NarrowInt-8000000    | 1   |   818.6 ms | 100.46 ms |  52.54 ms |  1.42 |    0.09 | 16000.0000 | 11500.0000 | 2500.0000 | 1045.73 MB |        4.26 |
| SylvanSequential      | NarrowInt-8000000    | 1   |   694.1 ms |  63.61 ms |  33.27 ms |  1.20 |    0.06 | 24000.0000 |          - |         - | 1158.58 MB |        4.71 |
