```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-ULQWZY : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=00000000000000001111111111111111  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-36df28",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
InvocationCount=4  IterationCount=10  LaunchCount=1  
UnrollFactor=1  WarmupCount=6  

```
| Method              | Format | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated   | Alloc Ratio |
|-------------------- |------- |----------:|----------:|----------:|------:|--------:|---------:|---------:|---------:|------------:|------------:|
| **ExcelReaderOriginal** | **Xlsx**   |  **39.82 ms** |  **5.328 ms** |  **3.524 ms** |  **1.01** |    **0.11** |        **-** |        **-** |        **-** |     **7.63 KB** |        **1.00** |
| ExcelReaderMemory   | Xlsx   |  40.82 ms |  7.375 ms |  4.878 ms |  1.03 |    0.14 |        - |        - |        - |     7.38 KB |        0.97 |
| OfficeIMOBytes      | Xlsx   |  66.04 ms | 18.373 ms | 12.153 ms |  1.67 |    0.32 | 250.0000 |        - |        - | 13939.88 KB |    1,828.18 |
| OfficeIMOStream     | Xlsx   |  63.47 ms | 11.034 ms |  7.298 ms |  1.60 |    0.21 | 250.0000 |        - |        - | 20503.74 KB |    2,689.02 |
| Sylvan              | Xlsx   | 156.56 ms | 13.060 ms |  8.639 ms |  3.96 |    0.36 |        - |        - |        - |   644.52 KB |       84.53 |
|                     |        |           |           |           |       |         |          |          |          |             |             |
| **ExcelReaderOriginal** | **Xlsm**   |  **47.31 ms** | **10.874 ms** |  **7.192 ms** |  **1.02** |    **0.19** |        **-** |        **-** |        **-** |     **7.63 KB** |        **1.00** |
| ExcelReaderMemory   | Xlsm   |  53.97 ms | 10.929 ms |  7.229 ms |  1.16 |    0.21 |        - |        - |        - |    83.75 KB |       10.98 |
| OfficeIMOBytes      | Xlsm   |  83.52 ms | 12.024 ms |  7.953 ms |  1.80 |    0.28 | 250.0000 |        - |        - | 16483.94 KB |    2,161.83 |
| OfficeIMOStream     | Xlsm   |  68.97 ms | 12.204 ms |  8.072 ms |  1.48 |    0.25 | 250.0000 |        - |        - | 23048.07 KB |    3,022.70 |
| Sylvan              | Xlsm   | 194.68 ms | 58.872 ms | 38.940 ms |  4.19 |    0.96 |        - |        - |        - |   647.63 KB |       84.93 |
|                     |        |           |           |           |       |         |          |          |          |             |             |
| **ExcelReaderOriginal** | **Xlsb**   |  **26.58 ms** |  **3.368 ms** |  **2.228 ms** |  **1.01** |    **0.11** |        **-** |        **-** |        **-** |   **123.76 KB** |        **1.00** |
| ExcelReaderMemory   | Xlsb   |  26.49 ms |  3.619 ms |  2.394 ms |  1.00 |    0.12 |        - |        - |        - |    76.88 KB |        0.62 |
| OfficeIMOBytes      | Xlsb   |  34.41 ms |  7.219 ms |  4.775 ms |  1.30 |    0.20 | 500.0000 | 250.0000 | 250.0000 | 18090.28 KB |      146.17 |
| OfficeIMOStream     | Xlsb   |  35.37 ms |  8.070 ms |  5.338 ms |  1.34 |    0.22 | 500.0000 | 250.0000 | 250.0000 | 25971.34 KB |      209.85 |
| Sylvan              | Xlsb   |  30.63 ms |  7.175 ms |  4.746 ms |  1.16 |    0.19 |        - |        - |        - |   341.98 KB |        2.76 |
|                     |        |           |           |           |       |         |          |          |          |             |             |
| **ExcelReaderOriginal** | **Xls**    |  **11.43 ms** |  **2.606 ms** |  **1.724 ms** |  **1.02** |    **0.21** |        **-** |        **-** |        **-** |     **73.5 KB** |        **1.00** |
| ExcelReaderMemory   | Xls    |  11.23 ms |  2.705 ms |  1.789 ms |  1.00 |    0.21 |        - |        - |        - |     57.3 KB |        0.78 |
| OfficeIMOBytes      | Xls    |  14.18 ms |  3.411 ms |  2.256 ms |  1.27 |    0.26 | 250.0000 |        - |        - | 18150.23 KB |      246.96 |
| OfficeIMOStream     | Xls    |  14.96 ms |  2.639 ms |  1.746 ms |  1.34 |    0.24 | 250.0000 |        - |        - | 25537.18 KB |      347.46 |
| Sylvan              | Xls    |  24.28 ms |  6.091 ms |  4.029 ms |  2.17 |    0.46 |        - |        - |        - |   186.34 KB |        2.54 |
