```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-ULQWZY : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=00000000000000001111111111111111  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-36df28",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
InvocationCount=4  IterationCount=10  LaunchCount=1  
UnrollFactor=1  WarmupCount=6  

```
| Method                    | Format | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Allocated   | Alloc Ratio |
|-------------------------- |------- |----------:|----------:|----------:|------:|--------:|---------:|---------:|------------:|------------:|
| **ExcelReaderPrefetch**       | **Xlsx**   |  **27.64 ms** |  **3.109 ms** |  **2.056 ms** |  **1.00** |    **0.10** |        **-** |        **-** |    **163.8 KB** |        **1.00** |
| ExcelReaderMemoryPrefetch | Xlsx   |  25.99 ms |  4.228 ms |  2.797 ms |  0.94 |    0.12 |        - |        - |   127.54 KB |        0.78 |
| OfficeIMOBytes            | Xlsx   |  64.15 ms |  3.227 ms |  2.135 ms |  2.33 |    0.18 | 250.0000 |        - | 16484.24 KB |      100.63 |
| Sylvan                    | Xlsx   | 228.11 ms | 33.741 ms | 22.318 ms |  8.29 |    0.97 |        - |        - |   647.55 KB |        3.95 |
|                           |        |           |           |           |       |         |          |          |             |             |
| **ExcelReaderPrefetch**       | **Xlsm**   |  **33.78 ms** |  **4.744 ms** |  **3.138 ms** |  **1.01** |    **0.12** |        **-** |        **-** |   **151.53 KB** |        **1.00** |
| ExcelReaderMemoryPrefetch | Xlsm   |  38.66 ms |  6.179 ms |  4.087 ms |  1.15 |    0.15 |        - |        - |   135.59 KB |        0.89 |
| OfficeIMOBytes            | Xlsm   |  66.14 ms | 10.652 ms |  7.046 ms |  1.97 |    0.26 | 250.0000 |        - | 16484.29 KB |      108.79 |
| Sylvan                    | Xlsm   | 158.62 ms | 19.824 ms | 13.113 ms |  4.73 |    0.54 |        - |        - |   647.63 KB |        4.27 |
|                           |        |           |           |           |       |         |          |          |             |             |
| **ExcelReaderPrefetch**       | **Xlsb**   |  **16.90 ms** |  **1.730 ms** |  **1.144 ms** |  **1.00** |    **0.09** |        **-** |        **-** |   **149.61 KB** |        **1.00** |
| ExcelReaderMemoryPrefetch | Xlsb   |  17.20 ms |  2.442 ms |  1.615 ms |  1.02 |    0.12 |        - |        - |    114.5 KB |        0.77 |
| OfficeIMOBytes            | Xlsb   |  33.02 ms |  5.120 ms |  3.387 ms |  1.96 |    0.23 | 500.0000 | 500.0000 | 18087.12 KB |      120.90 |
| Sylvan                    | Xlsb   |  30.37 ms |  5.457 ms |  3.609 ms |  1.81 |    0.24 |        - |        - |   341.98 KB |        2.29 |
