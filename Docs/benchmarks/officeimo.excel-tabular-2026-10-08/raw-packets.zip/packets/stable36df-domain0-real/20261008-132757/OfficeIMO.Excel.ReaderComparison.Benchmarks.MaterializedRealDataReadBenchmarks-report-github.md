```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-ULQWZY : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=00000000000000001111111111111111  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-36df28",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
InvocationCount=4  IterationCount=10  LaunchCount=1  
UnrollFactor=1  WarmupCount=6  

```
| Method                         | Format | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated   | Alloc Ratio |
|------------------------------- |------- |----------:|----------:|----------:|------:|--------:|---------:|---------:|---------:|------------:|------------:|
| **ExcelReaderStringsMaterialized** | **Xlsx**   |  **44.20 ms** |  **6.083 ms** |  **4.024 ms** |  **1.01** |    **0.12** |        **-** |        **-** |        **-** |    **17.09 KB** |        **1.00** |
| OfficeIMOBytes                 | Xlsx   |  69.63 ms | 13.581 ms |  8.983 ms |  1.59 |    0.23 | 250.0000 |        - |        - | 13939.88 KB |      815.50 |
| OfficeIMOStream                | Xlsx   |  76.84 ms | 16.720 ms | 11.059 ms |  1.75 |    0.28 | 250.0000 |        - |        - | 23048.04 KB |    1,348.33 |
| Sylvan                         | Xlsx   | 205.29 ms | 59.036 ms | 39.049 ms |  4.68 |    0.92 |        - |        - |        - |   647.55 KB |       37.88 |
|                                |        |           |           |           |       |         |          |          |          |             |             |
| **ExcelReaderStringsMaterialized** | **Xlsm**   |  **44.31 ms** |  **7.338 ms** |  **4.854 ms** |  **1.01** |    **0.14** |        **-** |        **-** |        **-** |   **141.48 KB** |        **1.00** |
| OfficeIMOBytes                 | Xlsm   |  65.59 ms | 11.612 ms |  7.681 ms |  1.50 |    0.22 | 250.0000 |        - |        - | 16484.18 KB |      116.51 |
| OfficeIMOStream                | Xlsm   |  79.36 ms | 15.431 ms | 10.206 ms |  1.81 |    0.28 | 250.0000 |        - |        - | 23048.07 KB |      162.90 |
| Sylvan                         | Xlsm   | 164.20 ms | 45.743 ms | 30.256 ms |  3.74 |    0.75 |        - |        - |        - |   647.63 KB |        4.58 |
|                                |        |           |           |           |       |         |          |          |          |             |             |
| **ExcelReaderStringsMaterialized** | **Xlsb**   |  **27.26 ms** |  **1.683 ms** |  **1.113 ms** |  **1.00** |    **0.06** |        **-** |        **-** |        **-** |   **133.23 KB** |        **1.00** |
| OfficeIMOBytes                 | Xlsb   |  31.96 ms |  2.626 ms |  1.737 ms |  1.17 |    0.08 | 500.0000 | 250.0000 | 250.0000 | 18089.64 KB |      135.78 |
| OfficeIMOStream                | Xlsb   |  31.79 ms |  3.526 ms |  2.332 ms |  1.17 |    0.09 | 500.0000 | 250.0000 | 250.0000 | 25970.95 KB |      194.93 |
| Sylvan                         | Xlsb   |  27.61 ms |  2.128 ms |  1.408 ms |  1.01 |    0.06 |        - |        - |        - |   341.98 KB |        2.57 |
|                                |        |           |           |           |       |         |          |          |          |             |             |
| **ExcelReaderStringsMaterialized** | **Xls**    |  **11.42 ms** |  **3.155 ms** |  **2.087 ms** |  **1.02** |    **0.23** |        **-** |        **-** |        **-** |    **82.96 KB** |        **1.00** |
| OfficeIMOBytes                 | Xls    |  14.85 ms |  3.299 ms |  2.182 ms |  1.33 |    0.27 | 250.0000 |        - |        - | 18150.29 KB |      218.77 |
| OfficeIMOStream                | Xls    |  17.25 ms |  3.799 ms |  2.513 ms |  1.55 |    0.31 | 500.0000 | 250.0000 | 250.0000 | 33859.17 KB |      408.11 |
| Sylvan                         | Xls    |  18.57 ms |  5.101 ms |  3.374 ms |  1.67 |    0.37 |        - |        - |        - |    218.4 KB |        2.63 |
