```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-ULQWZY : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=00000000000000001111111111111111  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-36df28",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
InvocationCount=4  IterationCount=10  LaunchCount=1  
UnrollFactor=1  WarmupCount=6  

```
| Method               | Format | Mean     | Error     | StdDev    | Ratio | RatioSD | Gen0     | Allocated | Alloc Ratio |
|--------------------- |------- |---------:|----------:|----------:|------:|--------:|---------:|----------:|------------:|
| **ExcelReaderAutomatic** | **Xlsx**   | **53.55 ms** | **15.902 ms** | **10.518 ms** |  **1.03** |    **0.25** |        **-** |   **8.02 MB** |        **1.00** |
| OfficeIMOAutomatic   | Xlsx   | 73.12 ms |  9.797 ms |  6.480 ms |  1.41 |    0.25 | 500.0000 |  24.62 MB |        3.07 |
|                      |        |          |           |           |       |         |          |           |             |
| **ExcelReaderAutomatic** | **Xlsb**   | **34.38 ms** |  **5.613 ms** |  **3.713 ms** |  **1.01** |    **0.15** |        **-** |   **8.02 MB** |        **1.00** |
| OfficeIMOAutomatic   | Xlsb   | 38.68 ms |  8.118 ms |  5.370 ms |  1.14 |    0.19 | 500.0000 |  24.66 MB |        3.08 |
