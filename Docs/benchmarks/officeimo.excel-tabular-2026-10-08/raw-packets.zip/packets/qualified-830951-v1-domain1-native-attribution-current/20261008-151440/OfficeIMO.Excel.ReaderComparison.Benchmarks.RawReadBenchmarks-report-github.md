```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-PEWTIJ : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=11111111111111110000000000000000  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=15  IterationTime=250ms  LaunchCount=1  
UnrollFactor=1  WarmupCount=12  

```
| Method              | RowCount | Format | Mean     | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1    | Gen2    | Allocated  | Alloc Ratio |
|-------------------- |--------- |------- |---------:|----------:|----------:|------:|--------:|---------:|--------:|--------:|-----------:|------------:|
| ExcelReaderOriginal | 50000    | Xlsb   | 5.037 ms | 0.6617 ms | 0.6190 ms |  1.01 |    0.17 |        - |       - |       - |   55.73 KB |        1.00 |
| OfficeIMOOriginal   | 50000    | Xlsb   | 9.274 ms | 0.6803 ms | 0.6363 ms |  1.87 |    0.25 | 153.8462 | 76.9231 | 76.9231 | 5878.96 KB |      105.49 |
