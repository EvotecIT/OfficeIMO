```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-GAYBJO : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=00000000000000001111111111111111  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-e67677",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=15  IterationTime=250ms  LaunchCount=1  
UnrollFactor=1  WarmupCount=12  

```
| Method              | RowCount | Format | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Allocated  | Alloc Ratio |
|-------------------- |--------- |------- |----------:|----------:|----------:|------:|--------:|--------:|-----------:|------------:|
| ExcelReaderOriginal | 50000    | Xlsb   |  4.749 ms | 0.5294 ms | 0.4952 ms |  1.01 |    0.15 |       - |    4.13 KB |        1.00 |
| OfficeIMOOriginal   | 50000    | Xlsb   | 11.158 ms | 0.9913 ms | 0.9272 ms |  2.37 |    0.31 | 76.9231 | 6857.92 KB |    1,659.38 |
