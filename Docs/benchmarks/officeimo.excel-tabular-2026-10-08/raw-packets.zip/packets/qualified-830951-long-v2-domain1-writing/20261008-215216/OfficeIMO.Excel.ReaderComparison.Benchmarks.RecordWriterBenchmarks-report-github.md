```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-OWHAFV : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=11111111111111110000000000000000  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=12  IterationTime=1s  LaunchCount=1  
UnrollFactor=1  WarmupCount=8  

```
| Method                    | Format | RowCount | Mean       | Error      | StdDev     | Ratio  | RatioSD | Gen0      | Gen1      | Gen2      | Allocated | Alloc Ratio |
|-------------------------- |------- |--------- |-----------:|-----------:|-----------:|-------:|--------:|----------:|----------:|----------:|----------:|------------:|
| **OfficeIMOPublicTypedWrite** | **Xlsx**   | **50000**    |  **14.743 ms** |  **0.5948 ms** |  **0.4644 ms** |   **1.66** |    **0.09** |  **250.0000** |  **250.0000** |  **250.0000** |   **4.04 MB** |        **1.00** |
| ExcelReaderWriteRecords   | Xlsx   | 50000    |   8.909 ms |  0.5192 ms |  0.4053 ms |   1.00 |    0.06 |  250.0000 |  250.0000 |  250.0000 |   4.02 MB |        1.00 |
|                           |        |          |            |            |            |        |         |           |           |           |           |             |
| **OfficeIMOPublicTypedWrite** | **Xlsb**   | **50000**    | **603.284 ms** | **25.9465 ms** | **20.2573 ms** | **106.42** |    **4.65** | **9750.0000** | **8250.0000** | **2500.0000** | **439.72 MB** |      **109.36** |
| ExcelReaderWriteRecords   | Xlsb   | 50000    |   5.674 ms |  0.2221 ms |  0.1734 ms |   1.00 |    0.04 |  329.2683 |  329.2683 |  329.2683 |   4.02 MB |        1.00 |
