```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-OWHAFV : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=11111111111111110000000000000000  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=12  IterationTime=1s  LaunchCount=1  
UnrollFactor=1  WarmupCount=8  

```
| Method                             | RowCount | Mean       | Error      | StdDev     | Ratio | RatioSD | Gen0      | Gen1      | Gen2      | Allocated | Alloc Ratio |
|----------------------------------- |--------- |-----------:|-----------:|-----------:|------:|--------:|----------:|----------:|----------:|----------:|------------:|
| OfficeIMOModelAndSaveInlineStrings | 50000    | 545.752 ms | 17.0112 ms | 13.2812 ms | 98.02 |    3.13 | 9750.0000 | 8250.0000 | 2500.0000 | 439.73 MB |      108.36 |
| OfficeIMOModelAndSaveSharedStrings | 50000    | 543.015 ms | 13.8026 ms | 10.7761 ms | 97.53 |    2.82 | 9500.0000 | 8000.0000 | 2250.0000 | 430.12 MB |      106.00 |
| ExcelReaderXlsbWriterSharedStrings | 50000    |   5.570 ms |  0.1655 ms |  0.1292 ms |  1.00 |    0.03 |  329.2683 |  329.2683 |  329.2683 |   4.06 MB |        1.00 |
| ExcelReaderXlsbWriterPrefetch      | 50000    |   4.345 ms |  0.0586 ms |  0.0457 ms |  0.78 |    0.02 |  331.8966 |  331.8966 |  331.8966 |   4.03 MB |        0.99 |
