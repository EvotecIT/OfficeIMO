```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-OWHAFV : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=11111111111111110000000000000000  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=12  IterationTime=1s  LaunchCount=1  
UnrollFactor=1  WarmupCount=8  

```
| Method                     | RowCount | Mean     | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated | Alloc Ratio |
|--------------------------- |--------- |---------:|----------:|----------:|------:|--------:|---------:|---------:|---------:|----------:|------------:|
| OfficeIMOWithoutReferences | 50000    | 7.309 ms | 0.1404 ms | 0.1097 ms |  0.93 |    0.02 | 328.0000 | 328.0000 | 328.0000 |   4.04 MB |        1.00 |
| ExcelReaderWriter          | 50000    | 7.893 ms | 0.2093 ms | 0.1634 ms |  1.00 |    0.03 | 328.2443 | 328.2443 | 328.2443 |   4.02 MB |        1.00 |
| ExcelReaderWriterPrefetch  | 50000    | 4.441 ms | 0.2375 ms | 0.1854 ms |  0.56 |    0.03 | 333.3333 | 333.3333 | 333.3333 |   4.02 MB |        1.00 |
