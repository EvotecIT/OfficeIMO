```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-OWHAFV : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=11111111111111110000000000000000  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=12  IterationTime=1s  LaunchCount=1  
UnrollFactor=1  WarmupCount=8  

```
| Method                        | Mean     | Error     | StdDev    | Ratio | RatioSD | Gen0    | Allocated  | Alloc Ratio |
|------------------------------ |---------:|----------:|----------:|------:|--------:|--------:|-----------:|------------:|
| OfficeIMODefaultRowStyle      | 8.763 ms | 0.5457 ms | 0.4261 ms |  1.70 |    0.12 | 52.1739 | 2563.11 KB |      140.87 |
| ExcelReaderOriginalStyledRows | 5.171 ms | 0.3944 ms | 0.3079 ms |  1.00 |    0.08 |       - |    18.2 KB |        1.00 |
