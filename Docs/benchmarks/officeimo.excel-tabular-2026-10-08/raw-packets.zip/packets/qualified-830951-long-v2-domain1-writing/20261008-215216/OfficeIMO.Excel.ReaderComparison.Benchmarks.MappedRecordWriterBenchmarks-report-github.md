```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-OWHAFV : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=11111111111111110000000000000000  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=12  IterationTime=1s  LaunchCount=1  
UnrollFactor=1  WarmupCount=8  

```
| Method                    | Format | RowCount | Mean       | Error      | StdDev     | Ratio | RatioSD | Gen0      | Gen1      | Gen2      | Allocated | Alloc Ratio |
|-------------------------- |------- |--------- |-----------:|-----------:|-----------:|------:|--------:|----------:|----------:|----------:|----------:|------------:|
| **OfficeIMOPublicTypedWrite** | **Xlsx**   | **50000**    |  **15.021 ms** |  **0.5552 ms** |  **0.4335 ms** |  **1.52** |    **0.13** |  **246.1538** |  **246.1538** |  **246.1538** |   **4.04 MB** |        **1.00** |
| ExcelReaderMappedRecords  | Xlsx   | 50000    |   9.941 ms |  1.2096 ms |  0.9443 ms |  1.01 |    0.12 |  238.0952 |  238.0952 |  238.0952 |   4.02 MB |        1.00 |
|                           |        |          |            |            |            |       |         |           |           |           |           |             |
| **OfficeIMOPublicTypedWrite** | **Xlsb**   | **50000**    | **620.726 ms** | **55.3748 ms** | **43.2330 ms** | **93.93** |    **7.14** | **9500.0000** | **8000.0000** | **2250.0000** | **439.72 MB** |      **109.36** |
| ExcelReaderMappedRecords  | Xlsb   | 50000    |   6.617 ms |  0.3174 ms |  0.2478 ms |  1.00 |    0.05 |  326.5306 |  326.5306 |  326.5306 |   4.02 MB |        1.00 |
