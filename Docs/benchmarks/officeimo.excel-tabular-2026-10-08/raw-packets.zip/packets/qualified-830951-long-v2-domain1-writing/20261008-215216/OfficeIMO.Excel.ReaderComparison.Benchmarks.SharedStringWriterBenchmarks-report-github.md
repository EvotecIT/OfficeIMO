```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-OWHAFV : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=11111111111111110000000000000000  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=12  IterationTime=1s  LaunchCount=1  
UnrollFactor=1  WarmupCount=8  

```
| Method                                  | RowCount | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated | Alloc Ratio |
|---------------------------------------- |--------- |----------:|----------:|----------:|------:|--------:|---------:|---------:|---------:|----------:|------------:|
| OfficeIMOSharedStrings                  | 50000    | 15.575 ms | 0.5416 ms | 0.4228 ms |  1.94 |    0.06 | 323.0769 | 323.0769 | 323.0769 |   4.04 MB |        1.00 |
| OfficeIMOSharedStringsWithoutReferences | 50000    |  8.630 ms | 0.7475 ms | 0.5836 ms |  1.08 |    0.07 | 333.3333 | 333.3333 | 333.3333 |   4.04 MB |        1.00 |
| ExcelReaderWriterSharedStrings          | 50000    |  8.017 ms | 0.1860 ms | 0.1453 ms |  1.00 |    0.02 | 333.3333 | 333.3333 | 333.3333 |   4.06 MB |        1.00 |
