```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-CPEWJC : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=11111111111111110000000000000000  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=15  IterationTime=1s  LaunchCount=1  
UnrollFactor=1  WarmupCount=12  

```
| Method      | RowCount | Scenario     | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0      | Gen1      | Gen2     | Allocated | Alloc Ratio |
|------------ |--------- |------------- |----------:|----------:|----------:|------:|--------:|----------:|----------:|---------:|----------:|------------:|
| **ExcelReader** | **100000**   | **CsvAllString** | **11.420 ms** | **1.0953 ms** | **1.0246 ms** |  **1.01** |    **0.12** |  **588.2353** |  **564.7059** | **541.1765** |  **16.27 MB** |        **1.00** |
| OfficeIMO   | 100000   | CsvAllString | 38.486 ms | 2.2481 ms | 2.1029 ms |  3.39 |    0.32 | 1384.6154 | 1000.0000 | 846.1538 |  49.42 MB |        3.04 |
|             |          |              |           |           |           |       |         |           |           |          |           |             |
| **ExcelReader** | **100000**   | **CsvTyped**     |  **8.074 ms** | **0.8849 ms** | **0.8277 ms** |  **1.01** |    **0.14** |  **488.5496** |  **473.2824** | **473.2824** |   **8.13 MB** |        **1.00** |
| OfficeIMO   | 100000   | CsvTyped     | 22.283 ms | 1.7481 ms | 1.6351 ms |  2.79 |    0.34 |  657.1429 |  314.2857 | 257.1429 |  21.55 MB |        2.65 |
|             |          |              |           |           |           |       |         |           |           |          |           |             |
| **ExcelReader** | **100000**   | **XlsbTyped**    | **12.134 ms** | **0.4051 ms** | **0.3789 ms** |  **1.00** |    **0.04** |  **462.5000** |  **450.0000** | **450.0000** |   **8.19 MB** |        **1.00** |
| OfficeIMO   | 100000   | XlsbTyped    | 17.631 ms | 1.0734 ms | 1.0040 ms |  1.45 |    0.09 |  166.6667 |  100.0000 | 100.0000 |   9.09 MB |        1.11 |
