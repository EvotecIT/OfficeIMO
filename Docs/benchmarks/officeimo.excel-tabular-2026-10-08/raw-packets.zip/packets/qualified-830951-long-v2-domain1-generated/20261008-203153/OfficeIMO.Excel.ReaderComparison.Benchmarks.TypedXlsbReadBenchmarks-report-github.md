```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-CPEWJC : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=11111111111111110000000000000000  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=15  IterationTime=1s  LaunchCount=1  
UnrollFactor=1  WarmupCount=12  

```
| Method               | RowCount | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1    | Allocated | Alloc Ratio |
|--------------------- |--------- |----------:|----------:|----------:|------:|--------:|---------:|--------:|----------:|------------:|
| ExcelReaderTypedXlsb | 50000    |  6.156 ms | 0.1886 ms | 0.1765 ms |  1.00 |    0.04 |  77.4194 |       - |   3.87 MB |        1.00 |
| OfficeIMOTypedXlsb   | 50000    |  6.954 ms | 0.1790 ms | 0.1674 ms |  1.13 |    0.04 |  77.4648 |       - |   3.98 MB |        1.03 |
| SylvanTypedXlsb      | 50000    | 19.545 ms | 1.4768 ms | 1.3814 ms |  3.18 |    0.23 | 208.3333 | 41.6667 |   10.4 MB |        2.69 |
