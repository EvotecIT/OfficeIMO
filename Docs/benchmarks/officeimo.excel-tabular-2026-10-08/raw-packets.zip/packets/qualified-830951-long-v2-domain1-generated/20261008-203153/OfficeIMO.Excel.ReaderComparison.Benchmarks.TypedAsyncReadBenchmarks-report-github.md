```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-CPEWJC : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=11111111111111110000000000000000  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=15  IterationTime=1s  LaunchCount=1  
UnrollFactor=1  WarmupCount=12  

```
| Method                | RowCount | Shape    | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0     | Allocated | Alloc Ratio |
|---------------------- |--------- |--------- |----------:|----------:|----------:|------:|--------:|---------:|----------:|------------:|
| OfficeIMOTypedAsync   | 50000    | Original | 11.038 ms | 1.0608 ms | 0.9923 ms |  1.44 |    0.13 |        - |   2.36 MB |        0.61 |
| ExcelReaderTypedAsync | 50000    | Original |  7.680 ms | 0.1508 ms | 0.1411 ms |  1.00 |    0.02 |  75.7576 |   3.87 MB |        1.00 |
| SylvanTypedAsync      | 50000    | Original | 43.822 ms | 1.1125 ms | 1.0406 ms |  5.71 |    0.16 | 200.0000 |  10.48 MB |        2.71 |
