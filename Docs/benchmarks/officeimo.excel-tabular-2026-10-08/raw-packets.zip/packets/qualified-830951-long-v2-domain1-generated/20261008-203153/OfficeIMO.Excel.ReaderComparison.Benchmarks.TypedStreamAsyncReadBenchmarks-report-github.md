```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-CPEWJC : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=11111111111111110000000000000000  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=15  IterationTime=1s  LaunchCount=1  
UnrollFactor=1  WarmupCount=12  

```
| Method                          | RowCount | Shape    | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0     | Allocated | Alloc Ratio |
|-------------------------------- |--------- |--------- |----------:|----------:|----------:|------:|--------:|---------:|----------:|------------:|
| OfficeIMOStreamOpenTypedAsync   | 50000    | Original | 11.045 ms | 0.2415 ms | 0.2259 ms |  1.46 |    0.03 |        - |    3.1 MB |        0.80 |
| ExcelReaderStreamOpenTypedAsync | 50000    | Original |  7.544 ms | 0.0438 ms | 0.0409 ms |  1.00 |    0.01 |  75.1880 |   3.87 MB |        1.00 |
| SylvanStreamOpenTypedAsync      | 50000    | Original | 43.647 ms | 0.7136 ms | 0.6675 ms |  5.79 |    0.09 | 181.8182 |  10.48 MB |        2.71 |
