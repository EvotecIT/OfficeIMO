```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-CPEWJC : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=11111111111111110000000000000000  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=15  IterationTime=1s  LaunchCount=1  
UnrollFactor=1  WarmupCount=12  

```
| Method           | RowCount | Format | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1   | Allocated   | Alloc Ratio |
|----------------- |--------- |------- |----------:|----------:|----------:|------:|--------:|---------:|-------:|------------:|------------:|
| **ExcelReaderAsync** | **50000**    | **Xlsx**   |  **5.501 ms** | **0.1047 ms** | **0.0980 ms** |  **1.00** |    **0.02** |        **-** |      **-** |     **3.89 KB** |        **1.00** |
| OfficeIMOAsync   | 50000    | Xlsx   |  9.962 ms | 0.0794 ms | 0.0743 ms |  1.81 |    0.03 |  52.6316 |      - |  3592.14 KB |      923.28 |
| SylvanAsync      | 50000    | Xlsx   | 29.912 ms | 2.6887 ms | 2.5150 ms |  5.44 |    0.45 |  27.0270 |      - |  1940.06 KB |      498.65 |
|                  |          |        |           |           |           |       |         |          |        |             |             |
| **ExcelReaderAsync** | **50000**    | **Xlsb**   |  **4.745 ms** | **0.4350 ms** | **0.4069 ms** |  **1.01** |    **0.12** |        **-** |      **-** |      **4.2 KB** |        **1.00** |
| OfficeIMOAsync   | 50000    | Xlsb   |  6.939 ms | 0.0641 ms | 0.0600 ms |  1.47 |    0.12 | 104.8951 |      - |  5246.52 KB |    1,248.24 |
| SylvanAsync      | 50000    | Xlsb   |  6.201 ms | 0.2891 ms | 0.2705 ms |  1.32 |    0.12 |  22.2222 |      - |  1866.42 KB |      444.06 |
|                  |          |        |           |           |           |       |         |          |        |             |             |
| **ExcelReaderAsync** | **50000**    | **Xls**    |  **2.794 ms** | **0.3912 ms** | **0.3659 ms** |  **1.02** |    **0.18** |        **-** |      **-** |     **2.91 KB** |        **1.00** |
| OfficeIMOAsync   | 50000    | Xls    |  5.266 ms | 0.0754 ms | 0.0705 ms |  1.91 |    0.23 | 213.9037 |      - | 10499.22 KB |    3,612.64 |
| SylvanAsync      | 50000    | Xls    |  5.406 ms | 0.5196 ms | 0.4860 ms |  1.96 |    0.29 |  33.3333 | 5.5556 |  1719.04 KB |      591.50 |
