```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-CPEWJC : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=11111111111111110000000000000000  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=15  IterationTime=1s  LaunchCount=1  
UnrollFactor=1  WarmupCount=12  

```
| Method              | RowCount | Format | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1   | Allocated   | Alloc Ratio |
|-------------------- |--------- |------- |----------:|----------:|----------:|------:|--------:|---------:|-------:|------------:|------------:|
| **ExcelReaderOriginal** | **50000**    | **Xlsx**   |  **5.322 ms** | **0.0483 ms** | **0.0452 ms** |  **1.00** |    **0.01** |        **-** |      **-** |     **3.82 KB** |        **1.00** |
| OfficeIMOOriginal   | 50000    | Xlsx   | 16.714 ms | 0.3323 ms | 0.3109 ms |  3.14 |    0.06 | 100.0000 |      - |  3719.13 KB |      973.51 |
| Sylvan              | 50000    | Xlsx   | 26.888 ms | 0.5443 ms | 0.5091 ms |  5.05 |    0.10 |  33.3333 |      - |  1939.16 KB |      507.59 |
|                     |          |        |           |           |           |       |         |          |        |             |             |
| **ExcelReaderOriginal** | **50000**    | **Xlsb**   |  **4.010 ms** | **0.1678 ms** | **0.1569 ms** |  **1.00** |    **0.05** |        **-** |      **-** |     **4.13 KB** |        **1.00** |
| OfficeIMOOriginal   | 50000    | Xlsb   |  7.778 ms | 0.7981 ms | 0.7466 ms |  1.94 |    0.19 | 104.0000 |      - |  5246.45 KB |    1,269.46 |
| Sylvan              | 50000    | Xlsb   |  5.571 ms | 0.1658 ms | 0.1551 ms |  1.39 |    0.06 |  43.7158 | 5.4645 |  1865.58 KB |      451.41 |
|                     |          |        |           |           |           |       |         |          |        |             |             |
| **ExcelReaderOriginal** | **50000**    | **Xls**    |  **2.533 ms** | **0.0194 ms** | **0.0181 ms** |  **1.00** |    **0.01** |        **-** |      **-** |     **3.11 KB** |        **1.00** |
| OfficeIMOOriginal   | 50000    | Xls    |  4.878 ms | 0.1437 ms | 0.1344 ms |  1.93 |    0.05 | 212.5604 |      - | 10520.18 KB |    3,382.31 |
| Sylvan              | 50000    | Xls    |  4.437 ms | 0.2843 ms | 0.2659 ms |  1.75 |    0.10 |  30.8370 | 4.4053 |  1717.76 KB |      552.27 |
