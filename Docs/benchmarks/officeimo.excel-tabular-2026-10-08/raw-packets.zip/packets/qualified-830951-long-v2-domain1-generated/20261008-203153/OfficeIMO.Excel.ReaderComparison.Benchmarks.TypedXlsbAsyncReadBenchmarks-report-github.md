```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-CPEWJC : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=11111111111111110000000000000000  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=15  IterationTime=1s  LaunchCount=1  
UnrollFactor=1  WarmupCount=12  

```
| Method                    | RowCount | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0     | Allocated | Alloc Ratio |
|-------------------------- |--------- |----------:|----------:|----------:|------:|--------:|---------:|----------:|------------:|
| ExcelReaderTypedXlsbAsync | 50000    |  6.162 ms | 0.2952 ms | 0.2762 ms |  1.00 |    0.06 |  76.9231 |   3.87 MB |        1.00 |
| OfficeIMOTypedXlsbAsync   | 50000    | 11.090 ms | 1.0249 ms | 0.9587 ms |  1.80 |    0.17 | 171.8750 |   8.56 MB |        2.21 |
| SylvanTypedXlsbAsync      | 50000    | 23.807 ms | 3.1492 ms | 2.9458 ms |  3.87 |    0.49 | 190.4762 |   10.4 MB |        2.69 |
