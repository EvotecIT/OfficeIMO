```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-CPEWJC : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=11111111111111110000000000000000  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=15  IterationTime=1s  LaunchCount=1  
UnrollFactor=1  WarmupCount=12  

```
| Method                         | RowCount | Format | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1   | Allocated | Alloc Ratio |
|------------------------------- |--------- |------- |----------:|----------:|----------:|------:|--------:|---------:|-------:|----------:|------------:|
| **ExcelReaderStringsMaterialized** | **50000**    | **Xlsx**   |  **5.972 ms** | **0.0915 ms** | **0.0856 ms** |  **1.00** |    **0.02** |  **29.9401** |      **-** |   **1.58 MB** |        **1.00** |
| OfficeIMOOriginal              | 50000    | Xlsx   |  9.958 ms | 0.8808 ms | 0.8239 ms |  1.67 |    0.14 |  52.6316 |      - |   3.51 MB |        2.22 |
| Sylvan                         | 50000    | Xlsx   | 25.989 ms | 0.1915 ms | 0.1791 ms |  4.35 |    0.07 |  27.0270 |      - |   1.89 MB |        1.20 |
|                                |          |        |           |           |           |       |         |          |        |           |             |
| **ExcelReaderStringsMaterialized** | **50000**    | **Xlsb**   |  **4.372 ms** | **0.0260 ms** | **0.0243 ms** |  **1.00** |    **0.01** |  **30.5677** |      **-** |   **1.58 MB** |        **1.00** |
| OfficeIMOOriginal              | 50000    | Xlsb   |  6.555 ms | 0.1127 ms | 0.1054 ms |  1.50 |    0.02 | 100.0000 |      - |   5.12 MB |        3.25 |
| Sylvan                         | 50000    | Xlsb   |  5.449 ms | 0.1037 ms | 0.0970 ms |  1.25 |    0.02 |  38.0435 | 5.4348 |   1.82 MB |        1.15 |
|                                |          |        |           |           |           |       |         |          |        |           |             |
| **ExcelReaderStringsMaterialized** | **50000**    | **Xls**    |  **2.960 ms** | **0.1148 ms** | **0.1074 ms** |  **1.00** |    **0.05** |  **32.2581** |      **-** |   **1.58 MB** |        **1.00** |
| OfficeIMOOriginal              | 50000    | Xls    |  4.803 ms | 0.0589 ms | 0.0551 ms |  1.62 |    0.05 | 211.5385 |      - |  10.25 MB |        6.50 |
| Sylvan                         | 50000    | Xls    |  4.268 ms | 0.0298 ms | 0.0279 ms |  1.44 |    0.05 |  34.1880 | 4.2735 |   1.68 MB |        1.06 |
