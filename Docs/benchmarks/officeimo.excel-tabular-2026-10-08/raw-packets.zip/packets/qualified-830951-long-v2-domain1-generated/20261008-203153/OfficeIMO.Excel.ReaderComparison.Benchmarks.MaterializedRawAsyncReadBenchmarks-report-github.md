```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-CPEWJC : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=11111111111111110000000000000000  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=15  IterationTime=1s  LaunchCount=1  
UnrollFactor=1  WarmupCount=12  

```
| Method                              | RowCount | Format | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1   | Allocated | Alloc Ratio |
|------------------------------------ |--------- |------- |----------:|----------:|----------:|------:|--------:|---------:|-------:|----------:|------------:|
| **ExcelReaderStringsMaterializedAsync** | **50000**    | **Xlsx**   |  **6.840 ms** | **0.4101 ms** | **0.3836 ms** |  **1.00** |    **0.08** |  **26.4901** |      **-** |   **1.58 MB** |        **1.00** |
| OfficeIMOAsync                      | 50000    | Xlsx   | 11.800 ms | 1.2146 ms | 1.1361 ms |  1.73 |    0.19 |  71.4286 |      - |   3.51 MB |        2.22 |
| SylvanAsync                         | 50000    | Xlsx   | 28.504 ms | 2.0869 ms | 1.9521 ms |  4.18 |    0.36 |  35.7143 |      - |   1.89 MB |        1.20 |
|                                     |          |        |           |           |           |       |         |          |        |           |             |
| **ExcelReaderStringsMaterializedAsync** | **50000**    | **Xlsb**   |  **4.459 ms** | **0.0420 ms** | **0.0393 ms** |  **1.00** |    **0.01** |  **30.9735** |      **-** |   **1.58 MB** |        **1.00** |
| OfficeIMOAsync                      | 50000    | Xlsb   |  7.157 ms | 0.3374 ms | 0.3156 ms |  1.61 |    0.07 | 104.8951 |      - |   5.12 MB |        3.24 |
| SylvanAsync                         | 50000    | Xlsb   |  5.816 ms | 0.0758 ms | 0.0709 ms |  1.30 |    0.02 |  32.4675 |      - |   1.82 MB |        1.15 |
|                                     |          |        |           |           |           |       |         |          |        |           |             |
| **ExcelReaderStringsMaterializedAsync** | **50000**    | **Xls**    |  **2.820 ms** | **0.0170 ms** | **0.0159 ms** |  **1.00** |    **0.01** |  **30.8123** |      **-** |   **1.58 MB** |        **1.00** |
| OfficeIMOAsync                      | 50000    | Xls    |  5.454 ms | 0.1017 ms | 0.0951 ms |  1.93 |    0.03 | 208.7912 |      - |  10.25 MB |        6.50 |
| SylvanAsync                         | 50000    | Xls    |  4.813 ms | 0.1293 ms | 0.1209 ms |  1.71 |    0.04 |  34.3137 | 4.9020 |   1.68 MB |        1.06 |
