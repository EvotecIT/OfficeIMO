```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-CPEWJC : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=11111111111111110000000000000000  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=15  IterationTime=1s  LaunchCount=1  
UnrollFactor=1  WarmupCount=12  

```
| Method               | RowCount | Model  | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Allocated  | Alloc Ratio |
|--------------------- |--------- |------- |----------:|----------:|----------:|------:|--------:|--------:|-----------:|------------:|
| **ExcelReaderAutomatic** | **50000**    | **Class**  |  **7.528 ms** | **0.1741 ms** | **0.1628 ms** |  **1.00** |    **0.03** | **75.1880** | **3959.57 KB** |        **1.00** |
| OfficeIMOAutomatic   | 50000    | Class  |  9.978 ms | 0.3203 ms | 0.2996 ms |  1.33 |    0.05 | 40.4040 |  2421.6 KB |        0.61 |
|                      |          |        |           |           |           |       |         |         |            |             |
| **ExcelReaderAutomatic** | **50000**    | **Struct** |  **7.408 ms** | **0.1834 ms** | **0.1716 ms** |  **1.00** |    **0.03** | **29.1971** | **1615.82 KB** |        **1.00** |
| OfficeIMOAutomatic   | 50000    | Struct | 10.144 ms | 0.2793 ms | 0.2612 ms |  1.37 |    0.04 |       - |   77.75 KB |        0.05 |
