```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-NHIUTL : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=00000000000000001111111111111111  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\baseline-owner-bundle-78bfbd"  
InvocationCount=32  IterationCount=15  LaunchCount=1  
UnrollFactor=1  WarmupCount=12  

```
| Method           | RowCount | Shape         | Mean      | Error    | StdDev   | Ratio | RatioSD | Gen0     | Gen1    | Allocated | Alloc Ratio |
|----------------- |--------- |-------------- |----------:|---------:|---------:|------:|--------:|---------:|--------:|----------:|------------:|
| **ExcelReaderTyped** | **50000**    | **Original**      |  **14.42 ms** | **0.479 ms** | **0.448 ms** |  **1.00** |    **0.04** |  **62.5000** |       **-** |   **3.87 MB** |        **1.00** |
| OfficeIMOTyped   | 50000    | Original      | 112.13 ms | 3.980 ms | 3.723 ms |  7.78 |    0.34 |  31.2500 |       - |   2.42 MB |        0.63 |
| SylvanTyped      | 50000    | Original      |  65.99 ms | 1.845 ms | 1.726 ms |  4.58 |    0.18 | 187.5000 | 31.2500 |  10.48 MB |        2.71 |
|                  |          |               |           |          |          |       |         |          |         |           |             |
| **ExcelReaderTyped** | **50000**    | **SharedStrings** |  **11.66 ms** | **0.465 ms** | **0.435 ms** |  **1.00** |    **0.05** |  **31.2500** |       **-** |   **2.29 MB** |        **1.00** |
| OfficeIMOTyped   | 50000    | SharedStrings |  71.97 ms | 2.431 ms | 2.274 ms |  6.18 |    0.28 |  62.5000 |       - |   3.62 MB |        1.58 |
| SylvanTyped      | 50000    | SharedStrings |  62.38 ms | 3.748 ms | 3.506 ms |  5.35 |    0.35 | 156.2500 | 31.2500 |   8.91 MB |        3.88 |
