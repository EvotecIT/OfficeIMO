```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-WWMGIL : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=11111111111111110000000000000000  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-36df28",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
InvocationCount=32  IterationCount=15  LaunchCount=1  
UnrollFactor=1  WarmupCount=12  

```
| Method           | RowCount | Shape         | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1    | Allocated | Alloc Ratio |
|----------------- |--------- |-------------- |----------:|----------:|----------:|------:|--------:|---------:|--------:|----------:|------------:|
| **ExcelReaderTyped** | **50000**    | **Original**      |  **9.555 ms** | **1.8363 ms** | **1.7177 ms** |  **1.03** |    **0.24** |  **93.7500** |       **-** |   **3.88 MB** |        **1.00** |
| OfficeIMOTyped   | 50000    | Original      |  8.393 ms | 0.9252 ms | 0.8654 ms |  0.90 |    0.17 |  31.2500 |       - |   2.36 MB |        0.61 |
| SylvanTyped      | 50000    | Original      | 40.082 ms | 0.3166 ms | 0.2962 ms |  4.31 |    0.67 | 187.5000 | 31.2500 |  10.48 MB |        2.70 |
|                  |          |               |           |           |           |       |         |          |         |           |             |
| **ExcelReaderTyped** | **50000**    | **SharedStrings** |  **8.131 ms** | **1.0322 ms** | **0.9656 ms** |  **1.01** |    **0.15** |  **31.2500** |       **-** |   **2.29 MB** |        **1.00** |
| OfficeIMOTyped   | 50000    | SharedStrings |  8.330 ms | 1.0391 ms | 0.9719 ms |  1.04 |    0.15 |  31.2500 |       - |   2.36 MB |        1.03 |
| SylvanTyped      | 50000    | SharedStrings | 41.065 ms | 1.4850 ms | 1.3891 ms |  5.10 |    0.50 | 156.2500 | 31.2500 |   8.91 MB |        3.88 |
