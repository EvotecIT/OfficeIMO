```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-KJRLRQ : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=00000000000000001111111111111111  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=15  IterationTime=1s  LaunchCount=1  
UnrollFactor=1  WarmupCount=12  

```
| Method                | RowCount | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1    | Allocated | Alloc Ratio |
|---------------------- |--------- |----------:|----------:|----------:|------:|--------:|---------:|--------:|----------:|------------:|
| ExcelReaderTypedAsync | 50000    |  5.523 ms | 0.1607 ms | 0.1503 ms |  1.00 |    0.04 |  77.7385 |       - |   3.86 MB |        1.00 |
| OfficeIMORowsAsAsync  | 50000    | 13.342 ms | 0.6694 ms | 0.6261 ms |  2.42 |    0.13 | 333.3333 | 17.5439 |  16.47 MB |        4.26 |
| SylvanTypedAsync      | 50000    | 10.099 ms | 2.4265 ms | 2.2697 ms |  1.83 |    0.40 | 223.1405 | 24.7934 |  10.96 MB |        2.84 |
