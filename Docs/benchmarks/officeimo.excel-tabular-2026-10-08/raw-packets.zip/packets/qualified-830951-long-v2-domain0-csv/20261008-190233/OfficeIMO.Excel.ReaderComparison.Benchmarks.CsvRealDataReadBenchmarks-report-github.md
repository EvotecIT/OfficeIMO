```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-KJRLRQ : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=00000000000000001111111111111111  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=15  IterationTime=1s  LaunchCount=1  
UnrollFactor=1  WarmupCount=12  

```
| Method                      | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|---------------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| ExcelReaderStream           | 11.049 ms | 0.8898 ms | 0.8323 ms |  1.01 |    0.11 |    1712 B |        1.00 |
| ExcelReaderMemory           | 11.309 ms | 0.8946 ms | 0.8369 ms |  1.03 |    0.11 |     738 B |        0.43 |
| OfficeIMOStreamBorrowedUtf8 |  6.415 ms | 0.4758 ms | 0.4451 ms |  0.58 |    0.06 |    2920 B |        1.71 |
| SylvanFieldSpan             | 10.612 ms | 0.2819 ms | 0.2637 ms |  0.97 |    0.08 |   41226 B |       24.08 |
