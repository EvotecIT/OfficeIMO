```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-KJRLRQ : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=00000000000000001111111111111111  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=15  IterationTime=1s  LaunchCount=1  
UnrollFactor=1  WarmupCount=12  

```
| Method                  | Mean     | Error    | StdDev   | Ratio | RatioSD | Gen0     | Gen1    | Allocated | Alloc Ratio |
|------------------------ |---------:|---------:|---------:|------:|--------:|---------:|--------:|----------:|------------:|
| ExcelReaderMaterialized | 30.62 ms | 1.703 ms | 1.593 ms |  1.00 |    0.07 | 735.2941 |       - |  35.71 MB |        1.00 |
| OfficeIMOMaterialized   | 20.18 ms | 2.222 ms | 2.078 ms |  0.66 |    0.07 | 720.0000 |       - |  34.21 MB |        0.96 |
| SylvanMaterialized      | 16.16 ms | 0.440 ms | 0.412 ms |  0.53 |    0.03 | 806.4516 | 96.7742 |  35.75 MB |        1.00 |
