```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-KJRLRQ : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=00000000000000001111111111111111  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=15  IterationTime=1s  LaunchCount=1  
UnrollFactor=1  WarmupCount=12  

```
| Method                  | Mapped | RowCount | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated | Alloc Ratio |
|------------------------ |------- |--------- |----------:|----------:|----------:|------:|--------:|---------:|---------:|---------:|----------:|------------:|
| **ExcelReaderRecordLayout** | **False**  | **50000**    |  **5.098 ms** | **0.2976 ms** | **0.2784 ms** |  **1.00** |    **0.08** | **329.7872** | **329.7872** | **329.7872** |      **4 MB** |        **1.00** |
| OfficeIMOWriteObjects   | False  | 50000    | 12.567 ms | 1.2511 ms | 1.1703 ms |  2.47 |    0.26 | 484.5361 | 340.2062 | 340.2062 |  11.26 MB |        2.81 |
|                         |        |          |           |           |           |       |         |          |          |          |           |             |
| **ExcelReaderRecordLayout** | **True**   | **50000**    |  **5.411 ms** | **0.3128 ms** | **0.2926 ms** |  **1.00** |    **0.07** | **331.3953** | **331.3953** | **331.3953** |      **4 MB** |        **1.00** |
| OfficeIMOWriteObjects   | True   | 50000    | 12.820 ms | 0.7471 ms | 0.6988 ms |  2.38 |    0.18 | 486.4865 | 337.8378 | 337.8378 |  11.26 MB |        2.81 |
