```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-KJRLRQ : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=00000000000000001111111111111111  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=15  IterationTime=1s  LaunchCount=1  
UnrollFactor=1  WarmupCount=12  

```
| Method                  | RowCount | Mean     | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1   | Allocated | Alloc Ratio |
|------------------------ |--------- |---------:|----------:|----------:|------:|--------:|---------:|-------:|----------:|------------:|
| ExcelReaderMaterialized | 50000    | 2.932 ms | 0.2182 ms | 0.2041 ms |  1.00 |    0.09 |  32.0285 |      - |   1.57 MB |        1.00 |
| OfficeIMOMaterialized   | 50000    | 6.412 ms | 0.8281 ms | 0.7746 ms |  2.20 |    0.29 | 183.4320 |      - |   8.63 MB |        5.48 |
| SylvanMaterialized      | 50000    | 3.154 ms | 0.3363 ms | 0.3146 ms |  1.08 |    0.13 |  36.2319 | 3.6232 |   1.61 MB |        1.02 |
