```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-KJRLRQ : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=00000000000000001111111111111111  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=15  IterationTime=1s  LaunchCount=1  
UnrollFactor=1  WarmupCount=12  

```
| Method                | RowCount | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated | Alloc Ratio |
|---------------------- |--------- |----------:|----------:|----------:|------:|--------:|---------:|---------:|---------:|----------:|------------:|
| ExcelReaderWriter     | 50000    |  4.057 ms | 0.3368 ms | 0.3150 ms |  1.01 |    0.11 | 498.1132 | 498.1132 | 498.1132 |      4 MB |        1.00 |
| OfficeIMOWriteObjects | 50000    | 14.167 ms | 0.9393 ms | 0.8786 ms |  3.51 |    0.36 | 693.3333 | 546.6667 | 546.6667 |  11.26 MB |        2.81 |
| SylvanWriter          | 50000    |  6.674 ms | 0.8882 ms | 0.8308 ms |  1.66 |    0.24 | 500.0000 | 500.0000 | 500.0000 |   4.04 MB |        1.01 |
