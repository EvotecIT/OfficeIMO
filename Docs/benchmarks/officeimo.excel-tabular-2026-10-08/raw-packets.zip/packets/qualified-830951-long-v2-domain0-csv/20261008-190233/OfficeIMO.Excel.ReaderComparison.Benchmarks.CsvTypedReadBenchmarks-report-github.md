```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-KJRLRQ : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=00000000000000001111111111111111  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=15  IterationTime=1s  LaunchCount=1  
UnrollFactor=1  WarmupCount=12  

```
| Method           | RowCount | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1    | Allocated | Alloc Ratio |
|----------------- |--------- |----------:|----------:|----------:|------:|--------:|---------:|--------:|----------:|------------:|
| ExcelReaderTyped | 50000    |  3.800 ms | 0.8532 ms | 0.7981 ms |  1.03 |    0.27 |  80.3571 |       - |   3.86 MB |        1.00 |
| OfficeIMORowsAs  | 50000    |  8.014 ms | 0.6568 ms | 0.6143 ms |  2.18 |    0.39 | 226.8908 |       - |  10.92 MB |        2.83 |
| SylvanTyped      | 50000    | 11.577 ms | 0.9166 ms | 0.8573 ms |  3.15 |    0.56 | 252.7473 | 32.9670 |  10.95 MB |        2.83 |
