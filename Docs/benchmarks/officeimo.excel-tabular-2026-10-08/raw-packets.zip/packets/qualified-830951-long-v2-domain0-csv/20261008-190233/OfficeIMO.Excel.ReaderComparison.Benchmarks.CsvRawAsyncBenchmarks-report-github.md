```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-KJRLRQ : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=00000000000000001111111111111111  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=15  IterationTime=1s  LaunchCount=1  
UnrollFactor=1  WarmupCount=12  

```
| Method           | RowCount | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1    | Allocated | Alloc Ratio |
|----------------- |--------- |----------:|----------:|----------:|------:|--------:|---------:|--------:|----------:|------------:|
| ExcelReaderAsync | 50000    |  3.179 ms | 0.5961 ms | 0.5576 ms |  1.03 |    0.26 |  32.1839 |       - |   1.57 MB |        1.00 |
| OfficeIMOAsync   | 50000    | 12.624 ms | 2.0272 ms | 1.8963 ms |  4.10 |    0.97 | 313.2530 | 24.0964 |  14.18 MB |        9.01 |
| SylvanAsync      | 50000    |  4.168 ms | 0.7507 ms | 0.7022 ms |  1.35 |    0.34 |  36.4964 |  3.6496 |   1.62 MB |        1.03 |
