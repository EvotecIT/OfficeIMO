```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-KJRLRQ : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=00000000000000001111111111111111  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=15  IterationTime=1s  LaunchCount=1  
UnrollFactor=1  WarmupCount=12  

```
| Method                | RowCount | Mean     | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|---------------------- |--------- |---------:|----------:|----------:|------:|--------:|----------:|------------:|
| ExcelReaderOriginal   | 50000    | 2.129 ms | 0.3389 ms | 0.3170 ms |  1.02 |    0.20 |     997 B |        1.00 |
| OfficeIMOBorrowedUtf8 | 50000    | 6.641 ms | 0.3740 ms | 0.3499 ms |  3.18 |    0.44 |    3849 B |        3.86 |
| SylvanOriginal        | 50000    | 4.115 ms | 0.3752 ms | 0.3510 ms |  1.97 |    0.30 |   38681 B |       38.80 |
