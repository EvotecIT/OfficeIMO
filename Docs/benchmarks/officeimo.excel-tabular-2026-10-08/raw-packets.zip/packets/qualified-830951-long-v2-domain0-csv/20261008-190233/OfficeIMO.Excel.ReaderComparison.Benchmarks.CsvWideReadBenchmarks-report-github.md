```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-KJRLRQ : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=00000000000000001111111111111111  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=15  IterationTime=1s  LaunchCount=1  
UnrollFactor=1  WarmupCount=12  

```
| Method          | RowCount | MaterializeStrings | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0      | Gen1     | Allocated   | Alloc Ratio |
|---------------- |--------- |------------------- |----------:|----------:|----------:|------:|--------:|----------:|---------:|------------:|------------:|
| **ExcelReaderWide** | **50000**    | **False**              |  **6.071 ms** | **1.6035 ms** | **1.4999 ms** |  **1.05** |    **0.33** |         **-** |        **-** |     **1.21 KB** |        **1.00** |
| OfficeIMOWide   | 50000    | False              |  6.348 ms | 0.9906 ms | 0.9266 ms |  1.10 |    0.27 |         - |        - |     4.26 KB |        3.51 |
| SylvanWide      | 50000    | False              |  4.364 ms | 0.4441 ms | 0.4154 ms |  0.75 |    0.16 |         - |        - |    45.29 KB |       37.31 |
|                 |          |                    |           |           |           |       |         |           |          |             |             |
| **ExcelReaderWide** | **50000**    | **True**               | **25.899 ms** | **4.0062 ms** | **3.7474 ms** |  **1.02** |    **0.21** | **1039.2157** |        **-** | **51564.85 KB** |        **1.00** |
| OfficeIMOWide   | 50000    | True               | 12.973 ms | 1.2585 ms | 1.1772 ms |  0.51 |    0.09 | 1048.7805 |  12.1951 | 51569.89 KB |        1.00 |
| SylvanWide      | 50000    | True               | 15.417 ms | 1.3172 ms | 1.2321 ms |  0.61 |    0.10 | 1042.5532 | 159.5745 | 51607.99 KB |        1.00 |
