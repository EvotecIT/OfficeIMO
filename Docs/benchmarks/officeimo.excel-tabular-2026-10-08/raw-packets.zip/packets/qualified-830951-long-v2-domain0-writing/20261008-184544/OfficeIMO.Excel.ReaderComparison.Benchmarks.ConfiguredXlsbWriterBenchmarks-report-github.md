```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-BHAAQB : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=00000000000000001111111111111111  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=12  IterationTime=1s  LaunchCount=1  
UnrollFactor=1  WarmupCount=8  

```
| Method                             | RowCount | Mean       | Error       | StdDev      | Ratio  | RatioSD | Gen0       | Gen1       | Gen2      | Allocated | Alloc Ratio |
|----------------------------------- |--------- |-----------:|------------:|------------:|-------:|--------:|-----------:|-----------:|----------:|----------:|------------:|
| OfficeIMOModelAndSaveInlineStrings | 50000    | 864.295 ms | 110.3692 ms |  86.1690 ms | 120.27 |   16.20 | 14000.0000 | 10000.0000 | 2000.0000 | 439.99 MB |      108.44 |
| OfficeIMOModelAndSaveSharedStrings | 50000    | 894.027 ms | 172.7214 ms | 134.8495 ms | 124.41 |   21.58 |  9500.0000 |  8000.0000 | 2250.0000 | 430.12 MB |      106.00 |
| ExcelReaderXlsbWriterSharedStrings | 50000    |   7.247 ms |   0.8654 ms |   0.6757 ms |   1.01 |    0.13 |   330.6452 |   330.6452 |  330.6452 |   4.06 MB |        1.00 |
| ExcelReaderXlsbWriterPrefetch      | 50000    |   4.681 ms |   0.1547 ms |   0.1208 ms |   0.65 |    0.06 |   333.3333 |   333.3333 |  333.3333 |   4.03 MB |        0.99 |
