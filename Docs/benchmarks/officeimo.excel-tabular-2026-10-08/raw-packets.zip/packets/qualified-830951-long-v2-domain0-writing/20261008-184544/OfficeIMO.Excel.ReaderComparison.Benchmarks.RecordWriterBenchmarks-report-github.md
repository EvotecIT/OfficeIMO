```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-BHAAQB : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=00000000000000001111111111111111  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=12  IterationTime=1s  LaunchCount=1  
UnrollFactor=1  WarmupCount=8  

```
| Method                    | Format | RowCount | Mean       | Error       | StdDev     | Ratio  | RatioSD | Gen0       | Gen1       | Gen2      | Allocated | Alloc Ratio |
|-------------------------- |------- |--------- |-----------:|------------:|-----------:|-------:|--------:|-----------:|-----------:|----------:|----------:|------------:|
| **OfficeIMOPublicTypedWrite** | **Xlsx**   | **50000**    |  **22.134 ms** |   **0.4378 ms** |  **0.3418 ms** |   **1.72** |    **0.05** |   **244.4444** |   **244.4444** |  **244.4444** |   **4.04 MB** |        **1.00** |
| ExcelReaderWriteRecords   | Xlsx   | 50000    |  12.838 ms |   0.3817 ms |  0.2980 ms |   1.00 |    0.03 |   243.5897 |   243.5897 |  243.5897 |   4.02 MB |        1.00 |
|                           |        |          |            |             |            |        |         |            |            |           |           |             |
| **OfficeIMOPublicTypedWrite** | **Xlsb**   | **50000**    | **869.726 ms** | **112.3029 ms** | **87.6787 ms** | **130.41** |   **18.09** | **14000.0000** | **10000.0000** | **2000.0000** | **439.99 MB** |      **109.36** |
| ExcelReaderWriteRecords   | Xlsb   | 50000    |   6.732 ms |   0.8590 ms |  0.6707 ms |   1.01 |    0.14 |   330.9859 |   330.9859 |  330.9859 |   4.02 MB |        1.00 |
