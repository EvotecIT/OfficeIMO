```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-BHAAQB : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=00000000000000001111111111111111  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=12  IterationTime=1s  LaunchCount=1  
UnrollFactor=1  WarmupCount=8  

```
| Method                                  | RowCount | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated | Alloc Ratio |
|---------------------------------------- |--------- |----------:|----------:|----------:|------:|--------:|---------:|---------:|---------:|----------:|------------:|
| OfficeIMOSharedStrings                  | 50000    | 18.568 ms | 0.6220 ms | 0.4856 ms |  1.84 |    0.08 | 327.8689 | 327.8689 | 327.8689 |   4.04 MB |        1.00 |
| OfficeIMOSharedStringsWithoutReferences | 50000    |  9.126 ms | 0.5840 ms | 0.4559 ms |  0.90 |    0.05 | 330.2752 | 330.2752 | 330.2752 |   4.04 MB |        1.00 |
| ExcelReaderWriterSharedStrings          | 50000    | 10.130 ms | 0.4919 ms | 0.3840 ms |  1.00 |    0.05 | 310.3448 | 310.3448 | 310.3448 |   4.06 MB |        1.00 |
