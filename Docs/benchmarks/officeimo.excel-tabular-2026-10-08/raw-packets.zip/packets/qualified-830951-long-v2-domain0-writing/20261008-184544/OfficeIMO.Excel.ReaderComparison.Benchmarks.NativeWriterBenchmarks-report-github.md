```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-BHAAQB : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=00000000000000001111111111111111  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=12  IterationTime=1s  LaunchCount=1  
UnrollFactor=1  WarmupCount=8  

```
| Method                | Format | RowCount | Mean       | Error      | StdDev     | Ratio | RatioSD | Gen0      | Gen1      | Gen2      | Allocated | Alloc Ratio |
|---------------------- |------- |--------- |-----------:|-----------:|-----------:|------:|--------:|----------:|----------:|----------:|----------:|------------:|
| OfficeIMOModelAndSave | Xlsb   | 50000    | 857.791 ms | 62.2843 ms | 48.6275 ms | 97.27 |    6.26 | 9500.0000 | 8000.0000 | 2250.0000 | 439.72 MB |      109.30 |
| ExcelReaderWriter     | Xlsb   | 50000    |   8.828 ms |  0.3897 ms |  0.3043 ms |  1.00 |    0.05 |  355.9322 |  355.9322 |  313.5593 |   4.02 MB |        1.00 |
