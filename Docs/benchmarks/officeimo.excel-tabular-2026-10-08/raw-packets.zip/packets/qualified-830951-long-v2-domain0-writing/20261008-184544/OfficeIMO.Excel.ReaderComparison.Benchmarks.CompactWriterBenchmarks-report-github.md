```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-BHAAQB : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=00000000000000001111111111111111  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=12  IterationTime=1s  LaunchCount=1  
UnrollFactor=1  WarmupCount=8  

```
| Method                     | RowCount | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated | Alloc Ratio |
|--------------------------- |--------- |----------:|----------:|----------:|------:|--------:|---------:|---------:|---------:|----------:|------------:|
| OfficeIMOWithoutReferences | 50000    | 10.371 ms | 0.3437 ms | 0.2683 ms |  1.08 |    0.06 | 326.9231 | 326.9231 | 326.9231 |   4.04 MB |        1.00 |
| ExcelReaderWriter          | 50000    |  9.610 ms | 0.6535 ms | 0.5102 ms |  1.00 |    0.07 | 329.7872 | 329.7872 | 329.7872 |   4.02 MB |        1.00 |
| ExcelReaderWriterPrefetch  | 50000    |  6.739 ms | 0.4017 ms | 0.3136 ms |  0.70 |    0.05 | 329.1139 | 329.1139 | 329.1139 |   4.06 MB |        1.01 |
