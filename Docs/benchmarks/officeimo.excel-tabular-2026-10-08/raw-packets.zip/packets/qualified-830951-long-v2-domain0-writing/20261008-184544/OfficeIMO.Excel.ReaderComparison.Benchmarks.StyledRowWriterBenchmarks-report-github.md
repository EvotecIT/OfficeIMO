```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-BHAAQB : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=00000000000000001111111111111111  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=12  IterationTime=1s  LaunchCount=1  
UnrollFactor=1  WarmupCount=8  

```
| Method                        | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0    | Allocated  | Alloc Ratio |
|------------------------------ |----------:|----------:|----------:|------:|--------:|--------:|-----------:|------------:|
| OfficeIMODefaultRowStyle      | 11.407 ms | 0.6634 ms | 0.5179 ms |  1.84 |    0.18 | 45.4545 | 2562.91 KB |      140.86 |
| ExcelReaderOriginalStyledRows |  6.227 ms | 0.6672 ms | 0.5209 ms |  1.01 |    0.12 |       - |    18.2 KB |        1.00 |
