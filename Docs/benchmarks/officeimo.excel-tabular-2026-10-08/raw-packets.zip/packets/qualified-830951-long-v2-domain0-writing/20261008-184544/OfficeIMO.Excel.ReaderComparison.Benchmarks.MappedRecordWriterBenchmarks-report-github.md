```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-BHAAQB : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=00000000000000001111111111111111  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=12  IterationTime=1s  LaunchCount=1  
UnrollFactor=1  WarmupCount=8  

```
| Method                    | Format | RowCount | Mean       | Error       | StdDev     | Ratio  | RatioSD | Gen0       | Gen1       | Gen2      | Allocated | Alloc Ratio |
|-------------------------- |------- |--------- |-----------:|------------:|-----------:|-------:|--------:|-----------:|-----------:|----------:|----------:|------------:|
| **OfficeIMOPublicTypedWrite** | **Xlsx**   | **50000**    |  **16.992 ms** |   **1.2190 ms** |  **0.9517 ms** |   **1.62** |    **0.20** |   **246.1538** |   **246.1538** |  **246.1538** |   **4.04 MB** |        **1.00** |
| ExcelReaderMappedRecords  | Xlsx   | 50000    |  10.616 ms |   1.5680 ms |  1.2242 ms |   1.01 |    0.16 |   242.4242 |   242.4242 |  242.4242 |   4.02 MB |        1.00 |
|                           |        |          |            |             |            |        |         |            |            |           |           |             |
| **OfficeIMOPublicTypedWrite** | **Xlsb**   | **50000**    | **910.491 ms** | **127.6255 ms** | **99.6416 ms** | **123.57** |   **14.29** | **14500.0000** | **10750.0000** | **1750.0000** | **439.99 MB** |      **109.43** |
| ExcelReaderMappedRecords  | Xlsb   | 50000    |   7.385 ms |   0.4742 ms |  0.3702 ms |   1.00 |    0.07 |   330.3571 |   330.3571 |  330.3571 |   4.02 MB |        1.00 |
