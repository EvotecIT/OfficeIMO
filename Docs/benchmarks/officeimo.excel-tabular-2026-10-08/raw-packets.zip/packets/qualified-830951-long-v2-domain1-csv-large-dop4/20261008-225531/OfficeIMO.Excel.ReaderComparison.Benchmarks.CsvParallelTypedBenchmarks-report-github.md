```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-SVEHGN : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=11111111111111110000000000000000  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=8  IterationTime=250ms  LaunchCount=1  
UnrollFactor=1  WarmupCount=4  

```
| Method                | Input                | Dop | Mean       | Error     | StdDev    | Ratio | RatioSD | Gen0       | Gen1       | Gen2      | Allocated  | Alloc Ratio |
|---------------------- |--------------------- |---- |-----------:|----------:|----------:|------:|--------:|-----------:|-----------:|----------:|-----------:|------------:|
| **ExcelReaderParallel**   | **Conve(...)00000 [23]** | **4**   |   **231.0 ms** |  **44.88 ms** |  **23.47 ms** |  **1.01** |    **0.13** | **14250.0000** | **11750.0000** |         **-** |  **680.18 MB** |        **1.00** |
| OfficeIMOCoreParallel | Conve(...)00000 [23] | 4   | 1,242.6 ms | 387.03 ms | 202.42 ms |  5.42 |    0.96 | 39750.0000 | 10500.0000 |         - | 1831.32 MB |        2.69 |
| OfficeIMOTextParallel | Conve(...)00000 [23] | 4   |   385.0 ms |  81.10 ms |  42.42 ms |  1.68 |    0.23 | 25000.0000 | 24750.0000 | 2750.0000 | 1464.38 MB |        2.15 |
|                       |                      |     |            |           |           |       |         |            |            |           |            |             |
| **ExcelReaderParallel**   | **Conve(...)00000 [25]** | **4**   |   **151.9 ms** |  **15.92 ms** |   **8.32 ms** |  **1.00** |    **0.07** |  **9750.0000** |  **8500.0000** |         **-** |  **474.57 MB** |        **1.00** |
| OfficeIMOCoreParallel | Conve(...)00000 [25] | 4   |   756.6 ms |  34.80 ms |  18.20 ms |  4.99 |    0.27 | 26750.0000 |  7250.0000 |         - | 1277.62 MB |        2.69 |
| OfficeIMOTextParallel | Conve(...)00000 [25] | 4   |   372.7 ms |  51.37 ms |  26.87 ms |  2.46 |    0.21 | 18250.0000 | 17000.0000 | 2750.0000 | 1022.27 MB |        2.15 |
|                       |                      |     |            |           |           |       |         |            |            |           |            |             |
| **ExcelReaderParallel**   | **NarrowInt-8000000**    | **4**   |   **153.6 ms** |  **31.98 ms** |  **16.73 ms** |  **1.01** |    **0.14** |  **5250.0000** |   **750.0000** |         **-** |  **254.58 MB** |        **1.00** |
| OfficeIMOCoreParallel | NarrowInt-8000000    | 4   | 1,427.0 ms | 144.31 ms |  75.48 ms |  9.38 |    0.99 | 39250.0000 |  3500.0000 |         - | 1859.97 MB |        7.31 |
| OfficeIMOTextParallel | NarrowInt-8000000    | 4   |   446.1 ms |  93.93 ms |  49.13 ms |  2.93 |    0.41 | 27250.0000 | 21750.0000 | 3250.0000 | 1047.82 MB |        4.12 |
