```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-SVEHGN : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=11111111111111110000000000000000  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=8  IterationTime=250ms  LaunchCount=1  
UnrollFactor=1  WarmupCount=4  

```
| Method                        | Input                | Dop | Mean       | Error     | StdDev    | Ratio | RatioSD | Gen0       | Gen1       | Gen2      | Allocated  | Alloc Ratio |
|------------------------------ |--------------------- |---- |-----------:|----------:|----------:|------:|--------:|-----------:|-----------:|----------:|-----------:|------------:|
| **ExcelReaderAggregate**          | **Conve(...)00000 [23]** | **4**   |   **157.8 ms** |  **35.16 ms** |  **18.39 ms** |  **1.01** |    **0.15** |          **-** |          **-** |         **-** |    **1.45 MB** |        **1.00** |
| OfficeIMOTextOwnedAggregate   | Conve(...)00000 [23] | 4   |   525.7 ms |  39.89 ms |  20.86 ms |  3.37 |    0.38 | 11000.0000 | 10750.0000 | 2750.0000 |   794.3 MB |      547.31 |
| OfficeIMOAsyncPathAggregate   | Conve(...)00000 [23] | 4   | 2,154.5 ms | 851.05 ms | 445.12 ms | 13.81 |    3.07 | 39500.0000 |  4500.0000 |         - | 1864.92 MB |    1,285.02 |
| OfficeIMOAsyncStreamAggregate | Conve(...)00000 [23] | 4   | 1,706.7 ms | 261.12 ms | 136.57 ms | 10.94 |    1.42 | 38750.0000 |  4500.0000 |         - | 1864.92 MB |    1,285.02 |
|                               |                      |     |            |           |           |       |         |            |            |           |            |             |
| **ExcelReaderAggregate**          | **Conve(...)00000 [25]** | **4**   |   **128.4 ms** |  **12.24 ms** |   **6.40 ms** |  **1.00** |    **0.07** |          **-** |          **-** |         **-** |    **1.02 MB** |        **1.00** |
| OfficeIMOTextOwnedAggregate   | Conve(...)00000 [25] | 4   |   409.4 ms | 121.33 ms |  63.46 ms |  3.19 |    0.49 | 16500.0000 | 16250.0000 | 2750.0000 |  555.06 MB |      543.58 |
| OfficeIMOAsyncPathAggregate   | Conve(...)00000 [25] | 4   | 1,261.2 ms | 319.56 ms | 167.14 ms |  9.84 |    1.31 | 27000.0000 |  3000.0000 |         - | 1301.11 MB |    1,274.20 |
| OfficeIMOAsyncStreamAggregate | Conve(...)00000 [25] | 4   | 1,169.4 ms | 206.43 ms | 107.97 ms |  9.12 |    0.90 | 27000.0000 |  3250.0000 |         - | 1301.11 MB |    1,274.21 |
|                               |                      |     |            |           |           |       |         |            |            |           |            |             |
| **ExcelReaderAggregate**          | **NarrowInt-8000000**    | **4**   |   **134.1 ms** |  **25.22 ms** |  **13.19 ms** |  **1.01** |    **0.13** |          **-** |          **-** |         **-** |    **1.61 MB** |        **1.00** |
| OfficeIMOTextOwnedAggregate   | NarrowInt-8000000    | 4   |   825.0 ms | 109.75 ms |  57.40 ms |  6.20 |    0.69 | 22750.0000 | 22000.0000 | 3500.0000 |  802.39 MB |      498.01 |
| OfficeIMOAsyncPathAggregate   | NarrowInt-8000000    | 4   | 2,456.0 ms | 761.79 ms | 398.43 ms | 18.46 |    3.28 | 47250.0000 |  3250.0000 |  500.0000 | 2168.08 MB |    1,345.65 |
| OfficeIMOAsyncStreamAggregate | NarrowInt-8000000    | 4   | 2,780.6 ms | 441.52 ms | 230.92 ms | 20.90 |    2.49 | 45250.0000 |  3250.0000 |         - | 2168.06 MB |    1,345.63 |
