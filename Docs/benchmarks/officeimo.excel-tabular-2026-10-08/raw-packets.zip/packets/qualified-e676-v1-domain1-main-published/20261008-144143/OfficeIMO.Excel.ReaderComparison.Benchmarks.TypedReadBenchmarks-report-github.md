```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-WOOUEG : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=11111111111111110000000000000000  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkPackageVersion=3.4.4  
InvocationCount=32  IterationCount=15  LaunchCount=1  
UnrollFactor=1  WarmupCount=12  

```
| Method           | RowCount | Shape         | Mean      | Error    | StdDev   | Ratio | RatioSD | Gen0     | Gen1    | Allocated | Alloc Ratio |
|----------------- |--------- |-------------- |----------:|---------:|---------:|------:|--------:|---------:|--------:|----------:|------------:|
| **ExcelReaderTyped** | **50000**    | **Original**      |  **12.19 ms** | **1.292 ms** | **1.209 ms** |  **1.01** |    **0.15** |  **93.7500** |       **-** |   **3.88 MB** |        **1.00** |
| OfficeIMOTyped   | 50000    | Original      | 121.82 ms | 6.124 ms | 5.729 ms | 10.09 |    1.19 | 125.0000 | 31.2500 |   5.77 MB |        1.49 |
| SylvanTyped      | 50000    | Original      |  66.77 ms | 2.985 ms | 2.792 ms |  5.53 |    0.64 | 250.0000 | 62.5000 |  10.48 MB |        2.70 |
|                  |          |               |           |          |          |       |         |          |         |           |             |
| **ExcelReaderTyped** | **50000**    | **SharedStrings** |  **11.00 ms** | **0.660 ms** | **0.617 ms** |  **1.00** |    **0.08** |  **62.5000** |       **-** |   **2.31 MB** |        **1.00** |
| OfficeIMOTyped   | 50000    | SharedStrings |  83.64 ms | 4.617 ms | 4.319 ms |  7.63 |    0.56 | 156.2500 | 31.2500 |   6.23 MB |        2.70 |
| SylvanTyped      | 50000    | SharedStrings |  60.74 ms | 2.514 ms | 2.351 ms |  5.54 |    0.36 | 187.5000 | 31.2500 |   8.91 MB |        3.86 |
