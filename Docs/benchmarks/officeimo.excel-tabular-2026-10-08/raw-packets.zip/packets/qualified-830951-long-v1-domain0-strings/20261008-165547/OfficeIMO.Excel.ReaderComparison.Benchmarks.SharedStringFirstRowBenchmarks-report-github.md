```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-BHAAQB : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=00000000000000001111111111111111  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=12  IterationTime=1s  LaunchCount=1  
UnrollFactor=1  WarmupCount=8  

```
| Method                         | RowCount | Storage  | Mean         | Error        | StdDev       | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated   | Alloc Ratio |
|------------------------------- |--------- |--------- |-------------:|-------------:|-------------:|------:|--------:|---------:|---------:|---------:|------------:|------------:|
| **ExcelReaderOpenThroughFirstRow** | **65536**    | **Deflated** | **16,308.50 μs** |   **297.283 μs** |   **232.099 μs** | **1.000** |    **0.02** |        **-** |        **-** |        **-** |   **886.92 KB** |        **1.00** |
| OfficeIMOOpenThroughFirstRow   | 65536    | Deflated | 93,223.37 μs | 4,794.746 μs | 3,743.423 μs | 5.717 |    0.23 | 636.3636 | 545.4545 | 181.8182 | 20464.23 KB |       23.07 |
| SylvanOpenThroughFirstRow      | 65536    | Deflated |    100.06 μs |     3.869 μs |     3.021 μs | 0.006 |    0.00 |   7.5512 |   4.0661 |   2.9873 |   321.13 KB |        0.36 |
|                                |          |          |              |              |              |       |         |          |          |          |             |             |
| **ExcelReaderOpenThroughFirstRow** | **65536**    | **Stored**   |  **4,215.24 μs** |   **117.410 μs** |    **91.666 μs** |  **1.00** |    **0.03** |   **4.0816** |   **4.0816** |   **4.0816** |   **782.37 KB** |        **1.00** |
| OfficeIMOOpenThroughFirstRow   | 65536    | Stored   | 71,484.95 μs | 2,565.155 μs | 2,002.704 μs | 16.97 |    0.58 | 714.2857 | 642.8571 | 214.2857 | 20716.42 KB |       26.48 |
| SylvanOpenThroughFirstRow      | 65536    | Stored   |     88.62 μs |    15.592 μs |    12.173 μs |  0.02 |    0.00 |   6.2764 |   2.8653 |   1.9102 |   320.09 KB |        0.41 |
