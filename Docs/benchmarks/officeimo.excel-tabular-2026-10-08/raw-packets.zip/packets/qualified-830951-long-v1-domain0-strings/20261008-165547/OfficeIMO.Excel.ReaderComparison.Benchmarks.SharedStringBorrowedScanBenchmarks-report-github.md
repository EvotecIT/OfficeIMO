```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-BHAAQB : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=00000000000000001111111111111111  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=12  IterationTime=1s  LaunchCount=1  
UnrollFactor=1  WarmupCount=8  

```
| Method                      | RowCount | Storage  | Mean     | Error    | StdDev   | Ratio | RatioSD | Allocated | Alloc Ratio |
|---------------------------- |--------- |--------- |---------:|---------:|---------:|------:|--------:|----------:|------------:|
| **ExcelReaderBorrowed**         | **65536**    | **Deflated** | **46.11 ms** | **1.356 ms** | **1.059 ms** |  **1.00** |    **0.03** |   **2.56 MB** |        **1.00** |
| ExcelReaderBorrowedPrefetch | 65536    | Deflated | 34.42 ms | 1.046 ms | 0.816 ms |  0.75 |    0.02 |   2.55 MB |        0.99 |
|                             |          |          |          |          |          |       |         |           |             |
| **ExcelReaderBorrowed**         | **65536**    | **Stored**   | **23.71 ms** | **1.057 ms** | **0.826 ms** |  **1.00** |    **0.05** |   **2.38 MB** |        **1.00** |
| ExcelReaderBorrowedPrefetch | 65536    | Stored   | 23.91 ms | 1.252 ms | 0.977 ms |  1.01 |    0.05 |   2.42 MB |        1.02 |
