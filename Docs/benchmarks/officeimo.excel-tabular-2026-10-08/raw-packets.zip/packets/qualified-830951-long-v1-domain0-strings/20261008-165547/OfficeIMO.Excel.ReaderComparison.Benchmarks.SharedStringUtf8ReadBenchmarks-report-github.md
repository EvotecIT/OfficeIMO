```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-BHAAQB : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=00000000000000001111111111111111  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=12  IterationTime=1s  LaunchCount=1  
UnrollFactor=1  WarmupCount=8  

```
| Method                      | Format | RowCount | Storage  | Mean      | Error     | StdDev   | Ratio | RatioSD | Gen0      | Gen1      | Gen2     | Allocated | Alloc Ratio |
|---------------------------- |------- |--------- |--------- |----------:|----------:|---------:|------:|--------:|----------:|----------:|---------:|----------:|------------:|
| **ExcelReaderBorrowed**         | **Xlsx**   | **100000**   | **Deflated** |  **66.66 ms** |  **1.743 ms** | **1.361 ms** |  **1.00** |    **0.03** |         **-** |         **-** |        **-** |   **3.99 MB** |        **1.00** |
| ExcelReaderBorrowedPrefetch | Xlsx   | 100000   | Deflated |  44.20 ms |  1.091 ms | 0.852 ms |  0.66 |    0.02 |         - |         - |        - |      3 MB |        0.75 |
| OfficeIMOBorrowedSharedUtf8 | Xlsx   | 100000   | Deflated | 232.66 ms |  5.665 ms | 4.422 ms |  3.49 |    0.09 | 2000.0000 | 1000.0000 | 250.0000 |  89.14 MB |       22.33 |
|                             |        |          |          |           |           |          |       |         |           |           |          |           |             |
| **ExcelReaderBorrowed**         | **Xlsx**   | **100000**   | **Stored**   |  **33.34 ms** |  **1.779 ms** | **1.389 ms** |  **1.00** |    **0.06** |         **-** |         **-** |        **-** |   **2.89 MB** |        **1.00** |
| ExcelReaderBorrowedPrefetch | Xlsx   | 100000   | Stored   |  34.15 ms |  3.765 ms | 2.939 ms |  1.03 |    0.09 |         - |         - |        - |   2.91 MB |        1.01 |
| OfficeIMOBorrowedSharedUtf8 | Xlsx   | 100000   | Stored   | 195.68 ms | 10.104 ms | 7.889 ms |  5.88 |    0.32 | 2250.0000 | 1750.0000 | 500.0000 |  88.74 MB |       30.66 |
|                             |        |          |          |           |           |          |       |         |           |           |          |           |             |
| **ExcelReaderBorrowed**         | **Xlsb**   | **100000**   | **Deflated** |  **55.14 ms** |  **2.043 ms** | **1.595 ms** |  **1.00** |    **0.04** |         **-** |         **-** |        **-** |   **3.84 MB** |        **1.00** |
| ExcelReaderBorrowedPrefetch | Xlsb   | 100000   | Deflated |  37.03 ms |  1.700 ms | 1.328 ms |  0.67 |    0.03 |         - |         - |        - |   3.62 MB |        0.94 |
| OfficeIMOBorrowedSharedUtf8 | Xlsb   | 100000   | Deflated | 154.87 ms | 12.628 ms | 9.859 ms |  2.81 |    0.19 | 3428.5714 | 2285.7143 | 714.2857 | 112.59 MB |       29.35 |
|                             |        |          |          |           |           |          |       |         |           |           |          |           |             |
| **ExcelReaderBorrowed**         | **Xlsb**   | **100000**   | **Stored**   |  **27.69 ms** |  **0.337 ms** | **0.263 ms** |  **1.00** |    **0.01** |         **-** |         **-** |        **-** |   **2.89 MB** |        **1.00** |
| ExcelReaderBorrowedPrefetch | Xlsb   | 100000   | Stored   |  34.03 ms |  4.420 ms | 3.451 ms |  1.23 |    0.12 |         - |         - |        - |   3.38 MB |        1.17 |
| OfficeIMOBorrowedSharedUtf8 | Xlsb   | 100000   | Stored   | 119.64 ms |  7.939 ms | 6.198 ms |  4.32 |    0.22 | 3375.0000 | 2250.0000 | 750.0000 | 111.44 MB |       38.50 |
