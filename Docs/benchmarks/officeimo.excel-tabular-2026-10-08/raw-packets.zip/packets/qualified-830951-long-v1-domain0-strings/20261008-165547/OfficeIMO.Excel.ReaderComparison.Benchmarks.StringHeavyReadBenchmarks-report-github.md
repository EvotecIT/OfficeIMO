```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-BHAAQB : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=00000000000000001111111111111111  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=12  IterationTime=1s  LaunchCount=1  
UnrollFactor=1  WarmupCount=8  

```
| Method              | Format | RowCount | Mean      | Error    | StdDev   | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated | Alloc Ratio |
|-------------------- |------- |--------- |----------:|---------:|---------:|------:|--------:|---------:|---------:|---------:|----------:|------------:|
| **ExcelReaderOriginal** | **Xlsx**   | **65536**    |  **46.18 ms** | **1.950 ms** | **1.522 ms** |  **1.00** |    **0.04** |        **-** |        **-** |        **-** |   **2.18 MB** |        **1.00** |
| ExcelReaderPrefetch | Xlsx   | 65536    |  26.08 ms | 2.964 ms | 2.314 ms |  0.57 |    0.05 |        - |        - |        - |   2.26 MB |        1.04 |
| ExcelReaderMemory   | Xlsx   | 65536    |  37.89 ms | 7.451 ms | 5.817 ms |  0.82 |    0.12 |        - |        - |        - |   2.18 MB |        1.00 |
| OfficeIMOBytes      | Xlsx   | 65536    | 101.56 ms | 3.162 ms | 2.469 ms |  2.20 |    0.09 | 250.0000 |        - |        - |  19.11 MB |        8.76 |
| OfficeIMOStream     | Xlsx   | 65536    | 106.82 ms | 3.964 ms | 3.094 ms |  2.32 |    0.10 | 444.4444 | 333.3333 | 111.1111 |  25.45 MB |       11.67 |
| Sylvan              | Xlsx   | 65536    | 219.17 ms | 7.714 ms | 6.022 ms |  4.75 |    0.20 | 250.0000 |        - |        - |  17.41 MB |        7.98 |
|                     |        |          |           |          |          |       |         |          |          |          |           |             |
| **ExcelReaderOriginal** | **Xlsb**   | **65536**    |  **40.01 ms** | **1.830 ms** | **1.428 ms** |  **1.00** |    **0.05** |        **-** |        **-** |        **-** |   **2.18 MB** |        **1.00** |
| ExcelReaderPrefetch | Xlsb   | 65536    |  31.16 ms | 2.287 ms | 1.786 ms |  0.78 |    0.05 |        - |        - |        - |   2.66 MB |        1.22 |
| ExcelReaderMemory   | Xlsb   | 65536    |  39.49 ms | 0.986 ms | 0.770 ms |  0.99 |    0.04 |  41.6667 |  41.6667 |  41.6667 |   7.14 MB |        3.28 |
| OfficeIMOBytes      | Xlsb   | 65536    |  63.53 ms | 2.574 ms | 2.009 ms |  1.59 |    0.07 | 466.6667 | 400.0000 | 133.3333 |  31.55 MB |       14.47 |
| OfficeIMOStream     | Xlsb   | 65536    |  69.33 ms | 2.511 ms | 1.961 ms |  1.73 |    0.08 | 785.7143 | 714.2857 | 357.1429 |  46.16 MB |       21.18 |
| Sylvan              | Xlsb   | 65536    |  68.32 ms | 5.727 ms | 4.471 ms |  1.71 |    0.12 | 250.0000 |        - |        - |  17.38 MB |        7.98 |
