```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-BHAAQB : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=00000000000000001111111111111111  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=12  IterationTime=1s  LaunchCount=1  
UnrollFactor=1  WarmupCount=8  

```
| Method                         | RowCount | Storage | Mean      | Error    | StdDev   | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated | Alloc Ratio |
|------------------------------- |--------- |-------- |----------:|---------:|---------:|------:|--------:|---------:|---------:|---------:|----------:|------------:|
| ExcelReaderStringsMaterialized | 65536    | Stored  |  43.74 ms | 2.090 ms | 1.632 ms |  1.00 |    0.05 | 320.0000 | 280.0000 |  80.0000 |  15.25 MB |        1.00 |
| OfficeIMOStringsMaterialized   | 65536    | Stored  |  91.61 ms | 3.108 ms | 2.427 ms |  2.10 |    0.09 | 500.0000 | 400.0000 | 100.0000 |  23.06 MB |        1.51 |
| SylvanStringsMaterialized      | 65536    | Stored  | 202.68 ms | 8.764 ms | 6.842 ms |  4.64 |    0.22 | 250.0000 |        - |        - |  17.41 MB |        1.14 |
