```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-BHAAQB : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=00000000000000001111111111111111  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=12  IterationTime=1s  LaunchCount=1  
UnrollFactor=1  WarmupCount=8  

```
| Method                         | Format | RowCount | Mean      | Error    | StdDev   | Ratio | RatioSD | Gen0      | Gen1      | Gen2     | Allocated | Alloc Ratio |
|------------------------------- |------- |--------- |----------:|---------:|---------:|------:|--------:|----------:|----------:|---------:|----------:|------------:|
| **ExcelReaderStringsMaterialized** | **Xlsx**   | **65536**    |  **69.11 ms** | **2.683 ms** | **2.095 ms** |  **1.00** |    **0.04** |  **333.3333** |  **266.6667** |  **66.6667** |  **15.25 MB** |        **1.00** |
| ExcelReaderStringsInterned     | Xlsx   | 65536    |  75.56 ms | 4.258 ms | 3.324 ms |  1.09 |    0.06 |  714.2857 |  642.8571 | 214.2857 |  15.89 MB |        1.04 |
| OfficeIMOBytes                 | Xlsx   | 65536    | 136.58 ms | 8.713 ms | 6.803 ms |  1.98 |    0.11 |  875.0000 |  750.0000 | 250.0000 |  25.23 MB |        1.65 |
| OfficeIMOStream                | Xlsx   | 65536    | 125.66 ms | 9.431 ms | 7.363 ms |  1.82 |    0.12 |  875.0000 |  750.0000 | 250.0000 |  31.57 MB |        2.07 |
| Sylvan                         | Xlsx   | 65536    | 219.55 ms | 9.687 ms | 7.563 ms |  3.18 |    0.14 |  250.0000 |         - |        - |  17.41 MB |        1.14 |
|                                |        |          |           |          |          |       |         |           |           |          |           |             |
| **ExcelReaderStringsMaterialized** | **Xlsb**   | **65536**    |  **62.71 ms** | **4.303 ms** | **3.360 ms** |  **1.00** |    **0.07** |  **333.3333** |  **266.6667** |  **66.6667** |  **15.25 MB** |        **1.00** |
| ExcelReaderStringsInterned     | Xlsb   | 65536    |  72.33 ms | 3.152 ms | 2.461 ms |  1.16 |    0.07 |  687.5000 |  625.0000 | 187.5000 |   17.7 MB |        1.16 |
| OfficeIMOBytes                 | Xlsb   | 65536    |  75.65 ms | 4.051 ms | 3.163 ms |  1.21 |    0.08 | 1076.9231 | 1000.0000 | 307.6923 |  36.48 MB |        2.39 |
| OfficeIMOStream                | Xlsb   | 65536    |  70.82 ms | 2.556 ms | 1.996 ms |  1.13 |    0.06 | 1076.9231 | 1000.0000 | 384.6154 |  46.69 MB |        3.06 |
| Sylvan                         | Xlsb   | 65536    |  63.84 ms | 9.496 ms | 7.414 ms |  1.02 |    0.13 |  733.3333 |  666.6667 | 200.0000 |  17.38 MB |        1.14 |
