```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-CPEWJC : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=11111111111111110000000000000000  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=15  IterationTime=1s  LaunchCount=1  
UnrollFactor=1  WarmupCount=12  

```
| Method               | RowCount | Mean     | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1    | Gen2   | Allocated | Alloc Ratio |
|--------------------- |--------- |---------:|----------:|----------:|------:|--------:|---------:|--------:|-------:|----------:|------------:|
| ExcelReaderTypedXlsb | 50000    | 7.151 ms | 1.4734 ms | 1.3782 ms |  1.03 |    0.26 |  80.7453 |       - |      - |   3.87 MB |        1.00 |
| OfficeIMOTypedXlsb   | 50000    | 7.142 ms | 0.5217 ms | 0.4880 ms |  1.03 |    0.19 | 111.1111 | 41.6667 | 6.9444 |   4.04 MB |        1.04 |
