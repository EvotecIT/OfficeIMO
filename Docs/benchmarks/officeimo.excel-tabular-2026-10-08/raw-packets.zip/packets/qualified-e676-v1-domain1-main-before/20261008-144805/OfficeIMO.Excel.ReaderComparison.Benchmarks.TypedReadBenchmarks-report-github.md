```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-FCNDUJ : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=11111111111111110000000000000000  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\baseline-owner-bundle-78bfbd"  
InvocationCount=32  IterationCount=15  LaunchCount=1  
UnrollFactor=1  WarmupCount=12  

```
| Method           | RowCount | Shape         | Mean      | Error    | StdDev   | Ratio | RatioSD | Gen0     | Gen1    | Allocated | Alloc Ratio |
|----------------- |--------- |-------------- |----------:|---------:|---------:|------:|--------:|---------:|--------:|----------:|------------:|
| **ExcelReaderTyped** | **50000**    | **Original**      |  **12.13 ms** | **0.593 ms** | **0.554 ms** |  **1.00** |    **0.06** |  **93.7500** |       **-** |   **3.88 MB** |        **1.00** |
| OfficeIMOTyped   | 50000    | Original      | 107.82 ms | 7.392 ms | 6.915 ms |  8.91 |    0.69 |  31.2500 |       - |    2.5 MB |        0.64 |
| SylvanTyped      | 50000    | Original      |  67.63 ms | 2.650 ms | 2.479 ms |  5.59 |    0.32 | 250.0000 | 62.5000 |  10.48 MB |        2.70 |
|                  |          |               |           |          |          |       |         |          |         |           |             |
| **ExcelReaderTyped** | **50000**    | **SharedStrings** |  **10.79 ms** | **0.418 ms** | **0.391 ms** |  **1.00** |    **0.05** |  **62.5000** |       **-** |   **2.31 MB** |        **1.00** |
| OfficeIMOTyped   | 50000    | SharedStrings |  69.57 ms | 3.591 ms | 3.359 ms |  6.45 |    0.38 |  93.7500 | 31.2500 |    3.7 MB |        1.60 |
| SylvanTyped      | 50000    | SharedStrings |  60.61 ms | 2.243 ms | 2.098 ms |  5.62 |    0.27 | 218.7500 | 62.5000 |   8.91 MB |        3.86 |
