```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-WZUHJM : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=00000000000000001111111111111111  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-ba9",/p:OfficeIMOBenchmarkNewApis=true  
InvocationCount=4  IterationCount=10  LaunchCount=1  
UnrollFactor=1  WarmupCount=8  

```
| Method                      | Input             | MemoryInput | Mean     | Error    | StdDev  | Gen0      | Allocated |
|---------------------------- |------------------ |------------ |---------:|---------:|--------:|----------:|----------:|
| **OfficeIMOVerifiedFullFields** | **OriginalSmallXlsx** | **False**       | **135.9 ms** |  **7.11 ms** | **4.70 ms** | **2750.0000** | **137.88 MB** |
| **OfficeIMOVerifiedFullFields** | **OriginalSmallXlsx** | **True**        | **151.0 ms** | **10.10 ms** | **6.68 ms** | **2750.0000** | **137.86 MB** |
