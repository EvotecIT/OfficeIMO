```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-IJNEND : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=11111111111111110000000000000000  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
InvocationCount=1  IterationCount=1  LaunchCount=16  
RunStrategy=ColdStart  UnrollFactor=1  WarmupCount=0  

```
| Method                       | Mean      | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|----------------------------- |----------:|----------:|----------:|------:|--------:|----------:|------------:|
| ExcelReaderAttributes        |  41.25 ms |  8.912 ms |  8.753 ms |  1.05 |    0.33 | 133.02 KB |        1.00 |
| OfficeIMOAutomaticMapping    | 104.12 ms | 60.643 ms | 59.560 ms |  2.65 |    1.63 | 112.98 KB |        0.85 |
| ExcelReaderFluentMapping     |  28.77 ms |  4.096 ms |  4.023 ms |  0.73 |    0.20 | 136.05 KB |        1.02 |
| ExcelReaderAttributeFallback |  32.21 ms |  1.811 ms |  1.779 ms |  0.82 |    0.19 | 138.09 KB |        1.04 |
