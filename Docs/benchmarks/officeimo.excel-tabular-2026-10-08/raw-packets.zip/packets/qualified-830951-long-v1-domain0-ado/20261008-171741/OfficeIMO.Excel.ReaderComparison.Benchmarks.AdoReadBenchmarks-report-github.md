```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-KJRLRQ : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=00000000000000001111111111111111  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=15  IterationTime=1s  LaunchCount=1  
UnrollFactor=1  WarmupCount=12  

```
| Method      | RowCount | Access       | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1    | Gen2    | Allocated  | Alloc Ratio |
|------------ |--------- |------------- |----------:|----------:|----------:|------:|--------:|---------:|--------:|--------:|-----------:|------------:|
| **ExcelReader** | **50000**    | **GetValue**     | **10.359 ms** | **0.6254 ms** | **0.5850 ms** |  **1.00** |    **0.08** | **108.6957** |       **-** |       **-** | **5136.55 KB** |        **1.00** |
| OfficeIMO   | 50000    | GetValue     | 14.931 ms | 0.7828 ms | 0.7322 ms |  1.45 |    0.10 |  52.6316 |       - |       - | 4482.33 KB |        0.87 |
| Sylvan      | 50000    | GetValue     | 37.024 ms | 3.6508 ms | 3.4150 ms |  3.58 |    0.37 | 157.8947 |       - |       - | 8382.87 KB |        1.63 |
|             |          |              |           |           |           |       |         |          |         |         |            |             |
| **ExcelReader** | **50000**    | **TypedGetters** |  **8.511 ms** | **1.1360 ms** | **1.0626 ms** |  **1.02** |    **0.18** |  **36.2319** |       **-** |       **-** | **1619.25 KB** |        **1.00** |
| OfficeIMO   | 50000    | TypedGetters | 12.573 ms | 0.4880 ms | 0.4565 ms |  1.50 |    0.19 |        - |       - |       - |  833.01 KB |        0.51 |
| Sylvan      | 50000    | TypedGetters | 36.204 ms | 7.1431 ms | 6.6817 ms |  4.32 |    0.95 |        - |       - |       - | 1939.62 KB |        1.20 |
|             |          |              |           |           |           |       |         |          |         |         |            |             |
| **ExcelReader** | **50000**    | **Utf8TextCopy** |  **8.130 ms** | **0.5258 ms** | **0.4918 ms** |  **1.00** |    **0.08** |        **-** |       **-** |       **-** |    **4.55 KB** |        **1.00** |
| OfficeIMO   | 50000    | Utf8TextCopy |  9.597 ms | 0.4454 ms | 0.4166 ms |  1.18 |    0.08 |  31.5789 | 31.5789 | 31.5789 |  832.98 KB |      182.88 |
| Sylvan      | 50000    | Utf8TextCopy | 38.674 ms | 1.4343 ms | 1.3417 ms |  4.77 |    0.31 |  76.9231 |       - |       - | 4283.37 KB |      940.43 |
