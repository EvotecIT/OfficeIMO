```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-KEXHOX : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=11111111111111110000000000000000  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
InvocationCount=32  IterationCount=15  LaunchCount=1  
UnrollFactor=1  WarmupCount=12  

```
| Method            | RowCount | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated | Alloc Ratio |
|------------------ |--------- |----------:|----------:|----------:|------:|--------:|---------:|---------:|---------:|----------:|------------:|
| OfficeIMO         | 50000    | 15.193 ms | 0.3901 ms | 0.3649 ms |  1.55 |    0.09 | 312.5000 | 312.5000 | 312.5000 |   4.04 MB |        1.00 |
| ExcelReaderWriter | 50000    |  9.854 ms | 0.5480 ms | 0.5126 ms |  1.00 |    0.07 | 312.5000 | 312.5000 | 312.5000 |   4.02 MB |        1.00 |
