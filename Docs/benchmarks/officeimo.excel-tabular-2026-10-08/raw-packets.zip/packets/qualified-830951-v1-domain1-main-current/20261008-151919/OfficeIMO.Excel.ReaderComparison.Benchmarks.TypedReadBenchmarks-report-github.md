```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-KEXHOX : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=11111111111111110000000000000000  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
InvocationCount=32  IterationCount=15  LaunchCount=1  
UnrollFactor=1  WarmupCount=12  

```
| Method           | RowCount | Shape         | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1    | Allocated | Alloc Ratio |
|----------------- |--------- |-------------- |----------:|----------:|----------:|------:|--------:|---------:|--------:|----------:|------------:|
| **ExcelReaderTyped** | **50000**    | **Original**      |  **9.659 ms** | **0.4714 ms** | **0.4409 ms** |  **1.00** |    **0.06** |  **93.7500** |       **-** |   **3.88 MB** |        **1.00** |
| OfficeIMOTyped   | 50000    | Original      | 10.616 ms | 0.8994 ms | 0.8413 ms |  1.10 |    0.10 |  62.5000 |       - |   2.44 MB |        0.63 |
| SylvanTyped      | 50000    | Original      | 48.564 ms | 2.1612 ms | 2.0216 ms |  5.04 |    0.30 | 250.0000 | 62.5000 |  10.48 MB |        2.70 |
|                  |          |               |           |           |           |       |         |          |         |           |             |
| **ExcelReaderTyped** | **50000**    | **SharedStrings** |  **8.399 ms** | **0.3552 ms** | **0.3323 ms** |  **1.00** |    **0.06** |  **31.2500** |       **-** |   **2.31 MB** |        **1.00** |
| OfficeIMOTyped   | 50000    | SharedStrings |  8.325 ms | 0.5546 ms | 0.5187 ms |  0.99 |    0.07 |  31.2500 |       - |   2.44 MB |        1.06 |
| SylvanTyped      | 50000    | SharedStrings | 45.500 ms | 2.0857 ms | 1.9510 ms |  5.43 |    0.31 | 156.2500 | 31.2500 |   8.91 MB |        3.86 |
