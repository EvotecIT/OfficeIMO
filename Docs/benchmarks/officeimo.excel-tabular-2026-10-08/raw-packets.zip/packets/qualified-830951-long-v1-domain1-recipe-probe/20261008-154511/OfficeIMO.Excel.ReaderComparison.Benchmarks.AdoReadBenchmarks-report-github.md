```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-CPEWJC : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=11111111111111110000000000000000  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=15  IterationTime=1s  LaunchCount=1  
UnrollFactor=1  WarmupCount=12  

```
| Method      | RowCount | Access       | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0     | Allocated  | Alloc Ratio |
|------------ |--------- |------------- |----------:|----------:|----------:|------:|--------:|---------:|-----------:|------------:|
| **ExcelReader** | **50000**    | **GetValue**     |  **7.713 ms** | **0.3863 ms** | **0.3614 ms** |  **1.00** |    **0.06** | **100.0000** | **5131.51 KB** |        **1.00** |
| OfficeIMO   | 50000    | GetValue     | 10.877 ms | 1.5583 ms | 1.4576 ms |  1.41 |    0.19 |        - |  4348.5 KB |        0.85 |
| Sylvan      | 50000    | GetValue     | 40.767 ms | 6.7315 ms | 6.2966 ms |  5.30 |    0.82 | 137.9310 | 8382.24 KB |        1.63 |
|             |          |              |           |           |           |       |         |          |            |             |
| **ExcelReader** | **50000**    | **TypedGetters** | **11.934 ms** | **0.2864 ms** | **0.2679 ms** |  **1.00** |    **0.03** |  **36.1446** | **1621.47 KB** |        **1.00** |
| OfficeIMO   | 50000    | TypedGetters | 11.698 ms | 0.7688 ms | 0.7191 ms |  0.98 |    0.06 |        - |  1002.5 KB |        0.62 |
| Sylvan      | 50000    | TypedGetters | 37.534 ms | 6.8721 ms | 6.4281 ms |  3.15 |    0.53 |  35.7143 | 1940.05 KB |        1.20 |
|             |          |              |           |           |           |       |         |          |            |             |
| **ExcelReader** | **50000**    | **Utf8TextCopy** |  **6.397 ms** | **0.9466 ms** | **0.8854 ms** |  **1.02** |    **0.19** |        **-** |    **8.45 KB** |        **1.00** |
| OfficeIMO   | 50000    | Utf8TextCopy |  9.256 ms | 1.4896 ms | 1.3934 ms |  1.47 |    0.29 |        - |  974.04 KB |      115.21 |
| Sylvan      | 50000    | Utf8TextCopy | 41.735 ms | 2.1267 ms | 1.9893 ms |  6.64 |    0.91 |  78.9474 | 4283.68 KB |      506.70 |
