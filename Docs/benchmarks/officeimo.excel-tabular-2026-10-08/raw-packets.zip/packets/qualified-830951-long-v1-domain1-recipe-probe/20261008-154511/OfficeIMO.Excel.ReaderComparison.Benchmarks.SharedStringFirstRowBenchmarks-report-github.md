```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-CPEWJC : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=11111111111111110000000000000000  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=15  IterationTime=1s  LaunchCount=1  
UnrollFactor=1  WarmupCount=12  

```
| Method                         | RowCount | Storage | Mean         | Error        | StdDev       | Ratio | RatioSD | Gen0     | Gen1     | Gen2    | Allocated   | Alloc Ratio |
|------------------------------- |--------- |-------- |-------------:|-------------:|-------------:|------:|--------:|---------:|---------:|--------:|------------:|------------:|
| ExcelReaderOpenThroughFirstRow | 65536    | Stored  |  4,122.34 μs |   366.796 μs |   343.101 μs |  1.01 |    0.12 |        - |        - |       - |   784.69 KB |        1.00 |
| OfficeIMOOpenThroughFirstRow   | 65536    | Stored  | 70,871.95 μs | 2,357.920 μs | 2,205.599 μs | 17.31 |    1.56 | 384.6154 | 307.6923 | 76.9231 | 18070.33 KB |       23.03 |
| SylvanOpenThroughFirstRow      | 65536    | Stored  |     72.69 μs |     2.773 μs |     2.594 μs |  0.02 |    0.00 |   5.9216 |   2.7286 |  1.9158 |   320.09 KB |        0.41 |
