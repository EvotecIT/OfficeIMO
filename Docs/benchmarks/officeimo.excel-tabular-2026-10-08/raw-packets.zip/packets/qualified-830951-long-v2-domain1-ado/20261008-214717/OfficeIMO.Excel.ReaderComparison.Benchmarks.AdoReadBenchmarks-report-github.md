```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-CPEWJC : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=11111111111111110000000000000000  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=15  IterationTime=1s  LaunchCount=1  
UnrollFactor=1  WarmupCount=12  

```
| Method      | RowCount | Access       | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1    | Gen2    | Allocated  | Alloc Ratio |
|------------ |--------- |------------- |----------:|----------:|----------:|------:|--------:|---------:|--------:|--------:|-----------:|------------:|
| **ExcelReader** | **50000**    | **GetValue**     |  **6.784 ms** | **0.1010 ms** | **0.0945 ms** |  **1.00** |    **0.02** | **100.0000** |       **-** |       **-** | **5131.51 KB** |        **1.00** |
| OfficeIMO   | 50000    | GetValue     |  9.782 ms | 0.1302 ms | 0.1218 ms |  1.44 |    0.03 | 107.8431 | 39.2157 | 39.2157 | 4348.84 KB |        0.85 |
| Sylvan      | 50000    | GetValue     | 33.418 ms | 0.3170 ms | 0.2966 ms |  4.93 |    0.08 | 137.9310 |       - |       - | 8382.24 KB |        1.63 |
|             |          |              |           |           |           |       |         |          |         |         |            |             |
| **ExcelReader** | **50000**    | **TypedGetters** |  **6.904 ms** | **0.0589 ms** | **0.0551 ms** |  **1.00** |    **0.01** |  **27.7778** |       **-** |       **-** | **1615.88 KB** |        **1.00** |
| OfficeIMO   | 50000    | TypedGetters |  8.398 ms | 0.0696 ms | 0.0651 ms |  1.22 |    0.01 |  61.4035 | 61.4035 | 61.4035 | 1011.23 KB |        0.63 |
| Sylvan      | 50000    | TypedGetters | 25.106 ms | 0.2429 ms | 0.2272 ms |  3.64 |    0.04 |  25.0000 |       - |       - | 1939.92 KB |        1.20 |
|             |          |              |           |           |           |       |         |          |         |         |            |             |
| **ExcelReader** | **50000**    | **Utf8TextCopy** |  **5.141 ms** | **0.0463 ms** | **0.0433 ms** |  **1.00** |    **0.01** |        **-** |       **-** |       **-** |    **6.93 KB** |        **1.00** |
| OfficeIMO   | 50000    | Utf8TextCopy |  6.227 ms | 0.1093 ms | 0.1022 ms |  1.21 |    0.02 |  42.8571 | 42.8571 | 42.8571 |   832.9 KB |      120.11 |
| Sylvan      | 50000    | Utf8TextCopy | 21.799 ms | 0.1943 ms | 0.1817 ms |  4.24 |    0.05 |  66.6667 |       - |       - | 4283.37 KB |      617.68 |
