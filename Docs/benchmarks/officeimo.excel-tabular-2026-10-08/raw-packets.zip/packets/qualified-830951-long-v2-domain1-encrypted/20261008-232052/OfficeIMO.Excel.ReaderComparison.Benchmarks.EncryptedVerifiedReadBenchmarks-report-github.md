```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-OWHAFV : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=11111111111111110000000000000000  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=12  IterationTime=1s  LaunchCount=1  
UnrollFactor=1  WarmupCount=8  

```
| Method                        | Input              | MemoryInput | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated   | Alloc Ratio |
|------------------------------ |------------------- |------------ |----------:|----------:|----------:|------:|--------:|---------:|---------:|---------:|------------:|------------:|
| **ExcelReaderVerifiedFullFields** | **OriginalSmallXlsx**  | **False**       |  **22.63 ms** |  **0.774 ms** |  **0.605 ms** |  **1.00** |    **0.04** |        **-** |        **-** |        **-** |    **45.19 KB** |        **1.00** |
| OfficeIMOVerifiedFullFields   | OriginalSmallXlsx  | False       |  21.62 ms |  1.791 ms |  1.398 ms |  0.96 |    0.06 |        - |        - |        - |   261.42 KB |        5.79 |
|                               |                    |             |           |           |           |       |         |          |          |          |             |             |
| **ExcelReaderVerifiedFullFields** | **OriginalSmallXlsx**  | **True**        |  **25.15 ms** |  **3.076 ms** |  **2.402 ms** |  **1.01** |    **0.13** |        **-** |        **-** |        **-** |    **53.61 KB** |        **1.00** |
| OfficeIMOVerifiedFullFields   | OriginalSmallXlsx  | True        |  21.29 ms |  3.246 ms |  2.535 ms |  0.85 |    0.13 |        - |        - |        - |   242.14 KB |        4.52 |
|                               |                    |             |           |           |           |       |         |          |          |          |             |             |
| **ExcelReaderVerifiedFullFields** | **GeneratedLargeXlsx** | **False**       |  **86.09 ms** |  **9.122 ms** |  **7.122 ms** |  **1.01** |    **0.12** | **181.8182** |        **-** |        **-** |  **9749.42 KB** |        **1.00** |
| OfficeIMOVerifiedFullFields   | GeneratedLargeXlsx | False       | 140.36 ms | 23.918 ms | 18.673 ms |  1.64 |    0.25 | 833.3333 | 166.6667 | 166.6667 | 68040.43 KB |        6.98 |
|                               |                    |             |           |           |           |       |         |          |          |          |             |             |
| **ExcelReaderVerifiedFullFields** | **GeneratedLargeXlsx** | **True**        |  **62.24 ms** |  **0.926 ms** |  **0.723 ms** |  **1.00** |    **0.02** | **200.0000** |        **-** |        **-** | **18773.67 KB** |        **1.00** |
| OfficeIMOVerifiedFullFields   | GeneratedLargeXlsx | True        | 134.10 ms | 10.279 ms |  8.025 ms |  2.15 |    0.13 | 777.7778 | 222.2222 | 222.2222 | 62105.49 KB |        3.31 |
