```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-OWHAFV : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=11111111111111110000000000000000  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=12  IterationTime=1s  LaunchCount=1  
UnrollFactor=1  WarmupCount=8  

```
| Method                         | Input              | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0     | Allocated   | Alloc Ratio |
|------------------------------- |------------------- |----------:|----------:|----------:|------:|--------:|---------:|------------:|------------:|
| **ExcelReaderVerifiedStreamAsync** | **OriginalSmallXlsx**  |  **20.81 ms** |  **0.154 ms** |  **0.121 ms** |  **1.00** |    **0.01** |        **-** |    **59.64 KB** |        **1.00** |
| OfficeIMOVerifiedStreamAsync   | OriginalSmallXlsx  |  22.27 ms |  1.384 ms |  1.081 ms |  1.07 |    0.05 |        - |   263.09 KB |        4.41 |
|                                |                    |           |           |           |       |         |          |             |             |
| **ExcelReaderVerifiedStreamAsync** | **GeneratedLargeXlsx** |  **78.91 ms** | **16.037 ms** | **12.521 ms** |  **1.02** |    **0.22** | **222.2222** | **10265.68 KB** |        **1.00** |
| OfficeIMOVerifiedStreamAsync   | GeneratedLargeXlsx | 136.27 ms |  8.793 ms |  6.865 ms |  1.77 |    0.28 | 750.0000 |  67696.8 KB |        6.59 |
