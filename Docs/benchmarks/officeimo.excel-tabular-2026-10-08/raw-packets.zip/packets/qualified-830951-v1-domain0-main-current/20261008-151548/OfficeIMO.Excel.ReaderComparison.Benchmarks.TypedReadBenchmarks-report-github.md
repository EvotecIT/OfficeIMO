```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-OSBIKL : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=00000000000000001111111111111111  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
InvocationCount=32  IterationCount=15  LaunchCount=1  
UnrollFactor=1  WarmupCount=12  

```
| Method           | RowCount | Shape         | Mean     | Error    | StdDev   | Ratio | RatioSD | Gen0     | Gen1    | Allocated | Alloc Ratio |
|----------------- |--------- |-------------- |---------:|---------:|---------:|------:|--------:|---------:|--------:|----------:|------------:|
| **ExcelReaderTyped** | **50000**    | **Original**      | **12.06 ms** | **0.295 ms** | **0.276 ms** |  **1.00** |    **0.03** |  **93.7500** |       **-** |   **3.88 MB** |        **1.00** |
| OfficeIMOTyped   | 50000    | Original      | 12.09 ms | 0.552 ms | 0.516 ms |  1.00 |    0.05 |  62.5000 |       - |   2.44 MB |        0.63 |
| SylvanTyped      | 50000    | Original      | 62.95 ms | 3.003 ms | 2.809 ms |  5.22 |    0.25 | 250.0000 | 62.5000 |  10.48 MB |        2.70 |
|                  |          |               |          |          |          |       |         |          |         |           |             |
| **ExcelReaderTyped** | **50000**    | **SharedStrings** | **11.07 ms** | **0.766 ms** | **0.717 ms** |  **1.00** |    **0.09** |  **62.5000** |       **-** |   **2.31 MB** |        **1.00** |
| OfficeIMOTyped   | 50000    | SharedStrings | 10.89 ms | 0.816 ms | 0.763 ms |  0.99 |    0.09 |  62.5000 |       - |   2.44 MB |        1.06 |
| SylvanTyped      | 50000    | SharedStrings | 64.60 ms | 2.130 ms | 1.993 ms |  5.86 |    0.40 | 218.7500 | 62.5000 |   8.91 MB |        3.86 |
