```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-KJRLRQ : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=00000000000000001111111111111111  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=15  IterationTime=1s  LaunchCount=1  
UnrollFactor=1  WarmupCount=12  

```
| Method                | RowCount | Mean     | Error     | StdDev    | Ratio | RatioSD | Allocated | Alloc Ratio |
|---------------------- |--------- |---------:|----------:|----------:|------:|--------:|----------:|------------:|
| ExcelReaderOriginal   | 50000    | 2.760 ms | 0.0703 ms | 0.0658 ms |  1.00 |    0.03 |     848 B |        1.00 |
| OfficeIMOBorrowedUtf8 | 50000    | 7.777 ms | 0.2454 ms | 0.2296 ms |  2.82 |    0.10 |    3970 B |        4.68 |
| SylvanOriginal        | 50000    | 4.460 ms | 0.1085 ms | 0.1014 ms |  1.62 |    0.05 |   38681 B |       45.61 |
