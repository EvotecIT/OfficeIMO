```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-KJRLRQ : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=00000000000000001111111111111111  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=15  IterationTime=1s  LaunchCount=1  
UnrollFactor=1  WarmupCount=12  

```
| Method      | RowCount | Access       | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1    | Gen2    | Allocated  | Alloc Ratio |
|------------ |--------- |------------- |----------:|----------:|----------:|------:|--------:|---------:|--------:|--------:|-----------:|------------:|
| **ExcelReader** | **50000**    | **GetValue**     | **11.961 ms** | **0.2544 ms** | **0.2379 ms** |  **1.00** |    **0.03** | **107.1429** |       **-** |       **-** | **5137.03 KB** |        **1.00** |
| OfficeIMO   | 50000    | GetValue     | 18.177 ms | 0.3851 ms | 0.3602 ms |  1.52 |    0.04 | 127.2727 | 54.5455 | 36.3636 | 4487.26 KB |        0.87 |
| Sylvan      | 50000    | GetValue     | 61.266 ms | 2.2958 ms | 2.1475 ms |  5.12 |    0.20 | 187.5000 |       - |       - | 8382.99 KB |        1.63 |
|             |          |              |           |           |           |       |         |          |         |         |            |             |
| **ExcelReader** | **50000**    | **TypedGetters** | **12.381 ms** | **0.5104 ms** | **0.4774 ms** |  **1.00** |    **0.05** |  **36.5854** |       **-** |       **-** | **1621.54 KB** |        **1.00** |
| OfficeIMO   | 50000    | TypedGetters | 13.956 ms | 0.5484 ms | 0.5130 ms |  1.13 |    0.06 |        - |       - |       - | 1014.61 KB |        0.63 |
| Sylvan      | 50000    | TypedGetters | 45.093 ms | 2.5187 ms | 2.3560 ms |  3.65 |    0.23 |  47.6190 |       - |       - | 1940.19 KB |        1.20 |
|             |          |              |           |           |           |       |         |          |         |         |            |             |
| **ExcelReader** | **50000**    | **Utf8TextCopy** |  **8.444 ms** | **0.2315 ms** | **0.2166 ms** |  **1.00** |    **0.04** |        **-** |       **-** |       **-** |    **8.77 KB** |        **1.00** |
| OfficeIMO   | 50000    | Utf8TextCopy | 10.706 ms | 0.3860 ms | 0.3611 ms |  1.27 |    0.05 |        - |       - |       - |  959.91 KB |      109.41 |
| Sylvan      | 50000    | Utf8TextCopy | 40.231 ms | 1.8774 ms | 1.7561 ms |  4.77 |    0.24 |  74.0741 |       - |       - | 4283.37 KB |      488.22 |
