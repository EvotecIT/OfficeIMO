```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-KJRLRQ : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=00000000000000001111111111111111  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=15  IterationTime=1s  LaunchCount=1  
UnrollFactor=1  WarmupCount=12  

```
| Method                         | RowCount | Storage | Mean         | Error        | StdDev       | Ratio | RatioSD | Gen0     | Gen1     | Gen2    | Allocated  | Alloc Ratio |
|------------------------------- |--------- |-------- |-------------:|-------------:|-------------:|------:|--------:|---------:|---------:|--------:|-----------:|------------:|
| ExcelReaderOpenThroughFirstRow | 65536    | Stored  |  4,312.61 μs |    70.781 μs |    66.208 μs |  1.00 |    0.02 |        - |        - |       - |  746.25 KB |        1.00 |
| OfficeIMOOpenThroughFirstRow   | 65536    | Stored  | 60,558.08 μs | 1,977.606 μs | 1,849.854 μs | 14.05 |    0.47 | 294.1176 | 235.2941 | 58.8235 | 14956.6 KB |       20.04 |
| SylvanOpenThroughFirstRow      | 65536    | Stored  |     54.79 μs |     5.292 μs |     4.950 μs |  0.01 |    0.00 |   4.6527 |   1.6421 |  0.7663 |  320.08 KB |        0.43 |
