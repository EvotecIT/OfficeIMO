```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-THMKXO : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=00000000000000001111111111111111  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=8  IterationTime=250ms  LaunchCount=1  
UnrollFactor=1  WarmupCount=4  

```
| Method                | Input                | Dop | Mean       | Error     | StdDev    | Ratio | RatioSD | Gen0       | Gen1       | Gen2      | Allocated  | Alloc Ratio |
|---------------------- |--------------------- |---- |-----------:|----------:|----------:|------:|--------:|-----------:|-----------:|----------:|-----------:|------------:|
| **ExcelReaderParallel**   | **Conve(...)00000 [23]** | **4**   |   **325.8 ms** |  **34.82 ms** |  **18.21 ms** |  **1.00** |    **0.08** | **14250.0000** |   **250.0000** |         **-** |   **680.2 MB** |        **1.00** |
| OfficeIMOCoreParallel | Conve(...)00000 [23] | 4   | 1,256.5 ms | 226.38 ms | 118.40 ms |  3.87 |    0.40 | 38250.0000 | 10000.0000 |         - | 1831.32 MB |        2.69 |
| OfficeIMOTextParallel | Conve(...)00000 [23] | 4   |   562.5 ms | 126.07 ms |  65.93 ms |  1.73 |    0.21 | 57000.0000 | 56250.0000 | 3750.0000 | 1466.62 MB |        2.16 |
|                       |                      |     |            |           |           |       |         |            |            |           |            |             |
| **ExcelReaderParallel**   | **Conve(...)00000 [25]** | **4**   |   **240.2 ms** |  **28.78 ms** |  **15.05 ms** |  **1.00** |    **0.08** | **18750.0000** | **15000.0000** |  **250.0000** |  **474.73 MB** |        **1.00** |
| OfficeIMOCoreParallel | Conve(...)00000 [25] | 4   |   871.3 ms | 144.18 ms |  75.41 ms |  3.64 |    0.36 | 31750.0000 |  8250.0000 |         - | 1277.68 MB |        2.69 |
| OfficeIMOTextParallel | Conve(...)00000 [25] | 4   |   437.4 ms |  43.47 ms |  22.74 ms |  1.83 |    0.14 | 39500.0000 | 38500.0000 | 3000.0000 | 1022.45 MB |        2.15 |
|                       |                      |     |            |           |           |       |         |            |            |           |            |             |
| **ExcelReaderParallel**   | **NarrowInt-8000000**    | **4**   |   **223.2 ms** |   **8.10 ms** |   **4.23 ms** |  **1.00** |    **0.03** |  **5500.0000** |   **250.0000** |         **-** |  **254.81 MB** |        **1.00** |
| OfficeIMOCoreParallel | NarrowInt-8000000    | 4   | 1,951.7 ms | 218.11 ms | 114.07 ms |  8.75 |    0.51 | 41250.0000 |  3750.0000 |         - | 1860.04 MB |        7.30 |
| OfficeIMOTextParallel | NarrowInt-8000000    | 4   |   570.8 ms |  49.88 ms |  26.09 ms |  2.56 |    0.12 | 16000.0000 | 12750.0000 | 2500.0000 | 1046.84 MB |        4.11 |
