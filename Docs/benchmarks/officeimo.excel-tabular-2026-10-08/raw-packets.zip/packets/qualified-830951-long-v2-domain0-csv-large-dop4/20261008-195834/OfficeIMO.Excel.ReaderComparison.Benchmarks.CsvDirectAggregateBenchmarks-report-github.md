```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-THMKXO : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=00000000000000001111111111111111  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=8  IterationTime=250ms  LaunchCount=1  
UnrollFactor=1  WarmupCount=4  

```
| Method                        | Input                | Dop | Mean       | Error     | StdDev    | Ratio | RatioSD | Gen0       | Gen1       | Gen2      | Allocated  | Alloc Ratio |
|------------------------------ |--------------------- |---- |-----------:|----------:|----------:|------:|--------:|-----------:|-----------:|----------:|-----------:|------------:|
| **ExcelReaderAggregate**          | **Conve(...)00000 [23]** | **4**   |   **214.1 ms** |   **8.95 ms** |   **4.68 ms** |  **1.00** |    **0.03** |          **-** |          **-** |         **-** |    **1.45 MB** |        **1.00** |
| OfficeIMOTextOwnedAggregate   | Conve(...)00000 [23] | 4   |   622.8 ms |  88.45 ms |  46.26 ms |  2.91 |    0.21 | 11000.0000 | 10750.0000 | 2750.0000 |   794.3 MB |      547.44 |
| OfficeIMOAsyncPathAggregate   | Conve(...)00000 [23] | 4   | 2,501.2 ms | 632.17 ms | 330.64 ms | 11.69 |    1.48 | 38750.0000 |  4500.0000 |         - | 1864.89 MB |    1,285.30 |
| OfficeIMOAsyncStreamAggregate | Conve(...)00000 [23] | 4   | 2,662.9 ms | 500.20 ms | 261.62 ms | 12.44 |    1.18 | 38750.0000 |  4500.0000 |         - | 1864.88 MB |    1,285.30 |
|                               |                      |     |            |           |           |       |         |            |            |           |            |             |
| **ExcelReaderAggregate**          | **Conve(...)00000 [25]** | **4**   |   **137.9 ms** |  **18.89 ms** |   **9.88 ms** |  **1.00** |    **0.09** |          **-** |          **-** |         **-** |    **1.08 MB** |        **1.00** |
| OfficeIMOTextOwnedAggregate   | Conve(...)00000 [25] | 4   |   351.1 ms |  29.58 ms |  15.47 ms |  2.56 |    0.19 | 16750.0000 | 16500.0000 | 3000.0000 |  555.06 MB |      513.64 |
| OfficeIMOAsyncPathAggregate   | Conve(...)00000 [25] | 4   | 1,606.2 ms | 685.03 ms | 358.28 ms | 11.70 |    2.58 | 27000.0000 |  3250.0000 |         - |  1301.1 MB |    1,204.01 |
| OfficeIMOAsyncStreamAggregate | Conve(...)00000 [25] | 4   | 1,626.7 ms | 242.63 ms | 126.90 ms | 11.85 |    1.15 | 27000.0000 |  3000.0000 |         - |  1301.1 MB |    1,204.01 |
|                               |                      |     |            |           |           |       |         |            |            |           |            |             |
| **ExcelReaderAggregate**          | **NarrowInt-8000000**    | **4**   |   **117.0 ms** |  **15.76 ms** |   **8.24 ms** |  **1.00** |    **0.09** |          **-** |          **-** |         **-** |    **1.49 MB** |        **1.00** |
| OfficeIMOTextOwnedAggregate   | NarrowInt-8000000    | 4   |   608.6 ms |  47.69 ms |  24.94 ms |  5.22 |    0.40 | 11250.0000 | 11000.0000 | 3000.0000 |  802.18 MB |      539.97 |
| OfficeIMOAsyncPathAggregate   | NarrowInt-8000000    | 4   | 2,521.2 ms | 646.08 ms | 337.91 ms | 21.64 |    3.10 | 45250.0000 |  3000.0000 |         - | 2168.05 MB |    1,459.38 |
| OfficeIMOAsyncStreamAggregate | NarrowInt-8000000    | 4   | 2,634.0 ms | 432.38 ms | 226.14 ms | 22.61 |    2.38 | 45500.0000 |  3000.0000 |         - | 2168.06 MB |    1,459.39 |
