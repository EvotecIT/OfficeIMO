```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-GXIQPA : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=00000000000000001111111111111111  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=15  IterationTime=250ms  LaunchCount=1  
UnrollFactor=1  WarmupCount=12  

```
| Method              | RowCount | Format | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1    | Gen2    | Allocated  | Alloc Ratio |
|-------------------- |--------- |------- |----------:|----------:|----------:|------:|--------:|---------:|--------:|--------:|-----------:|------------:|
| ExcelReaderOriginal | 50000    | Xlsb   |  5.118 ms | 0.1467 ms | 0.1373 ms |  1.00 |    0.04 |        - |       - |       - |      12 KB |        1.00 |
| OfficeIMOOriginal   | 50000    | Xlsb   | 10.568 ms | 1.4228 ms | 1.3309 ms |  2.07 |    0.26 | 142.8571 | 71.4286 | 71.4286 | 5833.02 KB |      485.93 |
