```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-FDSVGA : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=11111111111111110000000000000000  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\crypto-only-bundle-4ee00b",/p:OfficeIMOBenchmarkNewApis=true  
IterationCount=15  IterationTime=250ms  LaunchCount=1  
UnrollFactor=1  WarmupCount=12  

```
| Method                      | Input             | MemoryInput | Mean     | Error    | StdDev   | Allocated |
|---------------------------- |------------------ |------------ |---------:|---------:|---------:|----------:|
| **OfficeIMOVerifiedFullFields** | **OriginalSmallXlsx** | **False**       | **27.66 ms** | **1.285 ms** | **1.202 ms** | **557.36 KB** |
| **OfficeIMOVerifiedFullFields** | **OriginalSmallXlsx** | **True**        | **27.30 ms** | **1.502 ms** | **1.405 ms** | **537.97 KB** |
