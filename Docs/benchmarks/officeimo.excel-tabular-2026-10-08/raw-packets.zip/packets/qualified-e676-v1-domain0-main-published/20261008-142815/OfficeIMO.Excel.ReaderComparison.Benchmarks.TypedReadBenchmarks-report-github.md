```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-RTSYPM : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=00000000000000001111111111111111  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkPackageVersion=3.4.4  
InvocationCount=32  IterationCount=15  LaunchCount=1  
UnrollFactor=1  WarmupCount=12  

```
| Method           | RowCount | Shape         | Mean      | Error    | StdDev   | Ratio | RatioSD | Gen0     | Gen1    | Allocated | Alloc Ratio |
|----------------- |--------- |-------------- |----------:|---------:|---------:|------:|--------:|---------:|--------:|----------:|------------:|
| **ExcelReaderTyped** | **50000**    | **Original**      |  **12.70 ms** | **0.465 ms** | **0.435 ms** |  **1.00** |    **0.05** |  **62.5000** |       **-** |   **3.87 MB** |        **1.00** |
| OfficeIMOTyped   | 50000    | Original      | 123.64 ms | 3.908 ms | 3.655 ms |  9.75 |    0.43 |  93.7500 |       - |   5.69 MB |        1.47 |
| SylvanTyped      | 50000    | Original      |  66.36 ms | 2.456 ms | 2.297 ms |  5.23 |    0.25 | 250.0000 | 62.5000 |  10.48 MB |        2.71 |
|                  |          |               |           |          |          |       |         |          |         |           |             |
| **ExcelReaderTyped** | **50000**    | **SharedStrings** |  **10.97 ms** | **0.306 ms** | **0.286 ms** |  **1.00** |    **0.04** |  **31.2500** |       **-** |   **2.31 MB** |        **1.00** |
| OfficeIMOTyped   | 50000    | SharedStrings |  80.22 ms | 2.496 ms | 2.335 ms |  7.32 |    0.28 | 125.0000 | 31.2500 |   6.23 MB |        2.70 |
| SylvanTyped      | 50000    | SharedStrings |  61.15 ms | 5.549 ms | 5.191 ms |  5.58 |    0.48 | 156.2500 | 31.2500 |   8.91 MB |        3.86 |
