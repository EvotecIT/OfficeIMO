```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-LVIGEW : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=00000000000000001111111111111111  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-36df28",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
InvocationCount=32  IterationCount=15  LaunchCount=1  
UnrollFactor=1  WarmupCount=12  

```
| Method           | RowCount | Shape         | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1    | Allocated | Alloc Ratio |
|----------------- |--------- |-------------- |----------:|----------:|----------:|------:|--------:|---------:|--------:|----------:|------------:|
| **ExcelReaderTyped** | **50000**    | **Original**      |  **8.150 ms** | **0.4721 ms** | **0.4416 ms** |  **1.00** |    **0.07** |  **62.5000** |       **-** |   **3.87 MB** |        **1.00** |
| OfficeIMOTyped   | 50000    | Original      | 10.429 ms | 1.9733 ms | 1.8459 ms |  1.28 |    0.23 |  31.2500 |       - |   2.36 MB |        0.61 |
| SylvanTyped      | 50000    | Original      | 51.899 ms | 7.9879 ms | 7.4719 ms |  6.38 |    0.94 | 187.5000 | 31.2500 |  10.48 MB |        2.71 |
|                  |          |               |           |           |           |       |         |          |         |           |             |
| **ExcelReaderTyped** | **50000**    | **SharedStrings** | **10.451 ms** | **1.6427 ms** | **1.5366 ms** |  **1.02** |    **0.22** |  **31.2500** |       **-** |   **2.29 MB** |        **1.00** |
| OfficeIMOTyped   | 50000    | SharedStrings |  9.907 ms | 1.4808 ms | 1.3851 ms |  0.97 |    0.21 |  31.2500 |       - |   2.36 MB |        1.03 |
| SylvanTyped      | 50000    | SharedStrings | 46.708 ms | 8.2217 ms | 7.6906 ms |  4.57 |    1.05 | 156.2500 | 31.2500 |   8.91 MB |        3.88 |
