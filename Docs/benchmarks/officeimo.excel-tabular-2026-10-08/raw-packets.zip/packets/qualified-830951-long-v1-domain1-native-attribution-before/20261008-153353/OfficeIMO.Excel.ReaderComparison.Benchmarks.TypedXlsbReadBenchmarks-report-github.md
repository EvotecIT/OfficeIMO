```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-JONANS : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=11111111111111110000000000000000  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-e67677",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=15  IterationTime=1s  LaunchCount=1  
UnrollFactor=1  WarmupCount=12  

```
| Method               | RowCount | Mean      | Error    | StdDev   | Ratio | RatioSD | Gen0     | Gen1    | Gen2    | Allocated | Alloc Ratio |
|--------------------- |--------- |----------:|---------:|---------:|------:|--------:|---------:|--------:|--------:|----------:|------------:|
| ExcelReaderTypedXlsb | 50000    |  7.975 ms | 1.100 ms | 1.029 ms |  1.02 |    0.19 |  83.9161 |       - |       - |   3.87 MB |        1.00 |
| OfficeIMOTypedXlsb   | 50000    | 10.281 ms | 1.361 ms | 1.273 ms |  1.31 |    0.24 | 162.7907 | 69.7674 | 11.6279 |   5.65 MB |        1.46 |
