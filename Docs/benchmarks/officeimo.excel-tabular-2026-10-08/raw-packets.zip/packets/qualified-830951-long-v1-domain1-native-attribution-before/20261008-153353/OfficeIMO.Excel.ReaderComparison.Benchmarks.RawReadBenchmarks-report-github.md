```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-JONANS : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=11111111111111110000000000000000  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-e67677",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=15  IterationTime=1s  LaunchCount=1  
UnrollFactor=1  WarmupCount=12  

```
| Method              | RowCount | Format | Mean     | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1   | Gen2   | Allocated  | Alloc Ratio |
|-------------------- |--------- |------- |---------:|----------:|----------:|------:|--------:|---------:|-------:|-------:|-----------:|------------:|
| ExcelReaderOriginal | 50000    | Xlsb   | 4.056 ms | 0.1420 ms | 0.1328 ms |  1.00 |    0.04 |        - |      - |      - |    6.04 KB |        1.00 |
| OfficeIMOOriginal   | 50000    | Xlsb   | 8.269 ms | 1.1757 ms | 1.0998 ms |  2.04 |    0.27 | 148.9362 | 7.0922 | 7.0922 | 6916.28 KB |    1,145.81 |
