```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-PUTKPF : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=00000000000000001111111111111111  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-e67677",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
InvocationCount=32  IterationCount=15  LaunchCount=1  
UnrollFactor=1  WarmupCount=12  

```
| Method           | RowCount | Shape         | Mean     | Error    | StdDev   | Ratio | RatioSD | Gen0     | Gen1    | Allocated | Alloc Ratio |
|----------------- |--------- |-------------- |---------:|---------:|---------:|------:|--------:|---------:|--------:|----------:|------------:|
| **ExcelReaderTyped** | **50000**    | **Original**      | **11.88 ms** | **0.543 ms** | **0.508 ms** |  **1.00** |    **0.06** |  **62.5000** |       **-** |   **3.87 MB** |        **1.00** |
| OfficeIMOTyped   | 50000    | Original      | 12.82 ms | 0.288 ms | 0.269 ms |  1.08 |    0.05 |  31.2500 |       - |   2.36 MB |        0.61 |
| SylvanTyped      | 50000    | Original      | 65.10 ms | 2.630 ms | 2.460 ms |  5.49 |    0.31 | 187.5000 | 31.2500 |  10.48 MB |        2.71 |
|                  |          |               |          |          |          |       |         |          |         |           |             |
| **ExcelReaderTyped** | **50000**    | **SharedStrings** | **11.70 ms** | **0.637 ms** | **0.595 ms** |  **1.00** |    **0.07** |  **31.2500** |       **-** |   **2.31 MB** |        **1.00** |
| OfficeIMOTyped   | 50000    | SharedStrings | 12.95 ms | 0.245 ms | 0.230 ms |  1.11 |    0.06 |  62.5000 |       - |   2.44 MB |        1.06 |
| SylvanTyped      | 50000    | SharedStrings | 61.29 ms | 2.157 ms | 2.017 ms |  5.25 |    0.31 | 218.7500 | 62.5000 |   8.91 MB |        3.86 |
