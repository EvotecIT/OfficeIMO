```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-PUTKPF : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=00000000000000001111111111111111  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-e67677",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
InvocationCount=32  IterationCount=15  LaunchCount=1  
UnrollFactor=1  WarmupCount=12  

```
| Method            | RowCount | Mean     | Error    | StdDev   | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated | Alloc Ratio |
|------------------ |--------- |---------:|---------:|---------:|------:|--------:|---------:|---------:|---------:|----------:|------------:|
| OfficeIMO         | 50000    | 17.95 ms | 0.777 ms | 0.727 ms |  1.74 |    0.08 | 312.5000 | 312.5000 | 312.5000 |   4.04 MB |        1.01 |
| ExcelReaderWriter | 50000    | 10.32 ms | 0.233 ms | 0.218 ms |  1.00 |    0.03 | 312.5000 | 312.5000 | 312.5000 |   4.02 MB |        1.00 |
