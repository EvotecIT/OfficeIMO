```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-KJRLRQ : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=00000000000000001111111111111111  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=15  IterationTime=1s  LaunchCount=1  
UnrollFactor=1  WarmupCount=12  

```
| Method      | RowCount | Scenario     | Mean      | Error    | StdDev    | Ratio | RatioSD | Gen0      | Gen1     | Gen2     | Allocated | Alloc Ratio |
|------------ |--------- |------------- |----------:|---------:|----------:|------:|--------:|----------:|---------:|---------:|----------:|------------:|
| **ExcelReader** | **100000**   | **CsvAllString** | **14.611 ms** | **1.205 ms** | **1.1270 ms** |  **1.01** |    **0.10** |  **647.0588** | **602.9412** | **602.9412** |  **16.27 MB** |        **1.00** |
| OfficeIMO   | 100000   | CsvAllString | 42.747 ms | 3.865 ms | 3.6149 ms |  2.94 |    0.32 | 1269.2308 | 923.0769 | 769.2308 |   49.4 MB |        3.04 |
|             |          |              |           |          |           |       |         |           |          |          |           |             |
| **ExcelReader** | **100000**   | **CsvTyped**     |  **9.691 ms** | **1.007 ms** | **0.9417 ms** |  **1.01** |    **0.14** |  **530.6122** | **520.4082** | **520.4082** |   **8.13 MB** |        **1.00** |
| OfficeIMO   | 100000   | CsvTyped     | 26.870 ms | 1.583 ms | 1.4808 ms |  2.80 |    0.32 |  575.0000 | 275.0000 | 225.0000 |  21.55 MB |        2.65 |
|             |          |              |           |          |           |       |         |           |          |          |           |             |
| **ExcelReader** | **100000**   | **XlsbTyped**    | **15.154 ms** | **1.032 ms** | **0.9650 ms** |  **1.00** |    **0.09** |  **530.3030** | **515.1515** | **515.1515** |   **8.14 MB** |        **1.00** |
| OfficeIMO   | 100000   | XlsbTyped    | 24.170 ms | 2.513 ms | 2.3510 ms |  1.60 |    0.18 |  157.8947 | 105.2632 | 105.2632 |   9.09 MB |        1.12 |
