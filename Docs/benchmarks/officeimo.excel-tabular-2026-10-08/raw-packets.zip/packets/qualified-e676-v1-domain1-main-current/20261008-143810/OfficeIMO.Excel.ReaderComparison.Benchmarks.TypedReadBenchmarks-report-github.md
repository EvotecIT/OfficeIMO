```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-BJXTQL : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=11111111111111110000000000000000  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-e67677",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
InvocationCount=32  IterationCount=15  LaunchCount=1  
UnrollFactor=1  WarmupCount=12  

```
| Method           | RowCount | Shape         | Mean     | Error    | StdDev   | Ratio | RatioSD | Gen0     | Gen1    | Allocated | Alloc Ratio |
|----------------- |--------- |-------------- |---------:|---------:|---------:|------:|--------:|---------:|--------:|----------:|------------:|
| **ExcelReaderTyped** | **50000**    | **Original**      | **12.94 ms** | **0.577 ms** | **0.539 ms** |  **1.00** |    **0.06** |  **93.7500** |       **-** |   **3.88 MB** |        **1.00** |
| OfficeIMOTyped   | 50000    | Original      | 12.05 ms | 0.478 ms | 0.447 ms |  0.93 |    0.05 |  62.5000 |       - |   2.44 MB |        0.63 |
| SylvanTyped      | 50000    | Original      | 71.12 ms | 2.083 ms | 1.948 ms |  5.50 |    0.27 | 250.0000 | 62.5000 |  10.48 MB |        2.70 |
|                  |          |               |          |          |          |       |         |          |         |           |             |
| **ExcelReaderTyped** | **50000**    | **SharedStrings** | **11.74 ms** | **0.438 ms** | **0.410 ms** |  **1.00** |    **0.05** |  **62.5000** |       **-** |   **2.31 MB** |        **1.00** |
| OfficeIMOTyped   | 50000    | SharedStrings | 11.83 ms | 0.780 ms | 0.729 ms |  1.01 |    0.07 |  62.5000 |       - |   2.44 MB |        1.06 |
| SylvanTyped      | 50000    | SharedStrings | 58.70 ms | 2.811 ms | 2.629 ms |  5.01 |    0.28 | 218.7500 | 62.5000 |   8.91 MB |        3.86 |
