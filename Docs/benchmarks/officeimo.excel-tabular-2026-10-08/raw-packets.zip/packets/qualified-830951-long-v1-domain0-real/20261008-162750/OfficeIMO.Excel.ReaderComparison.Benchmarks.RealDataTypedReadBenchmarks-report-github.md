```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-KJRLRQ : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=00000000000000001111111111111111  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=15  IterationTime=1s  LaunchCount=1  
UnrollFactor=1  WarmupCount=12  

```
| Method               | Format | Mean     | Error    | StdDev   | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated | Alloc Ratio |
|--------------------- |------- |---------:|---------:|---------:|------:|--------:|---------:|---------:|---------:|----------:|------------:|
| **ExcelReaderAutomatic** | **Xlsx**   | **66.24 ms** | **2.546 ms** | **2.382 ms** |  **1.00** |    **0.05** | **125.0000** |        **-** |        **-** |   **8.02 MB** |        **1.00** |
| OfficeIMOAutomatic   | Xlsx   | 94.64 ms | 2.018 ms | 1.888 ms |  1.43 |    0.06 | 200.0000 |        - |        - |   9.11 MB |        1.14 |
|                      |        |          |          |          |       |         |          |          |          |           |             |
| **ExcelReaderAutomatic** | **Xlsb**   | **39.79 ms** | **0.991 ms** | **0.927 ms** |  **1.00** |    **0.03** | **166.6667** |        **-** |        **-** |   **8.04 MB** |        **1.00** |
| OfficeIMOAutomatic   | Xlsb   | 56.44 ms | 1.663 ms | 1.556 ms |  1.42 |    0.05 | 750.0000 | 250.0000 | 250.0000 |  28.67 MB |        3.57 |
