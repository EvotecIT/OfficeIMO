```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-KJRLRQ : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=00000000000000001111111111111111  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=15  IterationTime=1s  LaunchCount=1  
UnrollFactor=1  WarmupCount=12  

```
| Method              | Format | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated   | Alloc Ratio |
|-------------------- |------- |----------:|----------:|----------:|------:|--------:|---------:|---------:|---------:|------------:|------------:|
| **ExcelReaderOriginal** | **Xlsx**   |  **57.55 ms** |  **1.242 ms** |  **1.161 ms** |  **1.00** |    **0.03** |        **-** |        **-** |        **-** |    **35.27 KB** |        **1.00** |
| ExcelReaderMemory   | Xlsx   |  53.11 ms |  6.072 ms |  5.680 ms |  0.92 |    0.10 |        - |        - |        - |    23.46 KB |        0.67 |
| OfficeIMOBytes      | Xlsx   |  92.50 ms |  6.087 ms |  5.694 ms |  1.61 |    0.10 | 272.7273 |        - |        - |  14865.1 KB |      421.49 |
| OfficeIMOStream     | Xlsx   |  91.86 ms |  4.586 ms |  4.289 ms |  1.60 |    0.08 | 272.7273 |        - |        - | 21428.96 KB |      607.61 |
| Sylvan              | Xlsx   | 193.65 ms | 35.875 ms | 33.557 ms |  3.37 |    0.57 |        - |        - |        - |   647.55 KB |       18.36 |
|                     |        |           |           |           |       |         |          |          |          |             |             |
| **ExcelReaderOriginal** | **Xlsm**   |  **48.14 ms** |  **6.248 ms** |  **5.844 ms** |  **1.01** |    **0.17** |        **-** |        **-** |        **-** |    **26.76 KB** |        **1.00** |
| ExcelReaderMemory   | Xlsm   |  53.22 ms |  5.236 ms |  4.898 ms |  1.12 |    0.16 |        - |        - |        - |     7.38 KB |        0.28 |
| OfficeIMOBytes      | Xlsm   |  83.85 ms |  9.574 ms |  8.956 ms |  1.77 |    0.28 | 333.3333 |  83.3333 |        - | 14787.98 KB |      552.58 |
| OfficeIMOStream     | Xlsm   |  67.95 ms | 15.439 ms | 14.442 ms |  1.43 |    0.34 | 312.5000 |  62.5000 |        - | 21139.92 KB |      789.93 |
| Sylvan              | Xlsm   | 161.55 ms | 32.703 ms | 30.590 ms |  3.40 |    0.74 |        - |        - |        - |   647.63 KB |       24.20 |
|                     |        |           |           |           |       |         |          |          |          |             |             |
| **ExcelReaderOriginal** | **Xlsb**   |  **25.21 ms** |  **2.173 ms** |  **2.032 ms** |  **1.01** |    **0.10** |        **-** |        **-** |        **-** |    **19.14 KB** |        **1.00** |
| ExcelReaderMemory   | Xlsb   |  28.00 ms |  1.702 ms |  1.592 ms |  1.12 |    0.10 |        - |        - |        - |    16.44 KB |        0.86 |
| OfficeIMOBytes      | Xlsb   |  34.11 ms |  2.911 ms |  2.723 ms |  1.36 |    0.14 | 394.7368 | 157.8947 |  26.3158 | 14418.03 KB |      753.42 |
| OfficeIMOStream     | Xlsb   |  37.78 ms |  1.135 ms |  1.061 ms |  1.51 |    0.11 | 296.2963 |  37.0370 |  37.0370 | 18985.34 KB |      992.09 |
| Sylvan              | Xlsb   |  37.13 ms |  1.793 ms |  1.677 ms |  1.48 |    0.12 |        - |        - |        - |   338.87 KB |       17.71 |
|                     |        |           |           |           |       |         |          |          |          |             |             |
| **ExcelReaderOriginal** | **Xls**    |  **13.82 ms** |  **0.479 ms** |  **0.448 ms** |  **1.00** |    **0.04** |        **-** |        **-** |        **-** |    **12.02 KB** |        **1.00** |
| ExcelReaderMemory   | Xls    |  15.47 ms |  0.337 ms |  0.316 ms |  1.12 |    0.04 |        - |        - |        - |    11.88 KB |        0.99 |
| OfficeIMOBytes      | Xls    |  19.43 ms |  1.043 ms |  0.975 ms |  1.41 |    0.08 | 274.5098 |        - |        - | 14316.37 KB |    1,191.48 |
| OfficeIMOStream     | Xls    |  24.37 ms |  0.912 ms |  0.853 ms |  1.77 |    0.08 | 450.0000 | 175.0000 | 175.0000 | 26408.83 KB |    2,197.87 |
| Sylvan              | Xls    |  26.16 ms |  1.009 ms |  0.944 ms |  1.90 |    0.09 |        - |        - |        - |    186.3 KB |       15.50 |
