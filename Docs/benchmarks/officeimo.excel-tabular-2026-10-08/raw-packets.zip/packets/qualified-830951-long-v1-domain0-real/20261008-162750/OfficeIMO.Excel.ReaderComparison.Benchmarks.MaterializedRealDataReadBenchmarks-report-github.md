```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-KJRLRQ : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=00000000000000001111111111111111  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=15  IterationTime=1s  LaunchCount=1  
UnrollFactor=1  WarmupCount=12  

```
| Method                         | Format | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1     | Gen2     | Allocated   | Alloc Ratio |
|------------------------------- |------- |----------:|----------:|----------:|------:|--------:|---------:|---------:|---------:|------------:|------------:|
| **ExcelReaderStringsMaterialized** | **Xlsx**   |  **57.50 ms** |  **3.587 ms** |  **3.355 ms** |  **1.00** |    **0.08** |        **-** |        **-** |        **-** |    **17.09 KB** |        **1.00** |
| OfficeIMOBytes                 | Xlsx   |  82.61 ms |  2.787 ms |  2.607 ms |  1.44 |    0.09 | 250.0000 |        - |        - | 13940.02 KB |      815.50 |
| OfficeIMOStream                | Xlsx   |  87.26 ms |  2.369 ms |  2.216 ms |  1.52 |    0.09 | 272.7273 |        - |        - | 20503.83 KB |    1,199.49 |
| Sylvan                         | Xlsx   | 242.15 ms | 10.928 ms | 10.222 ms |  4.22 |    0.29 |        - |        - |        - |   645.53 KB |       37.76 |
|                                |        |           |           |           |       |         |          |          |          |             |             |
| **ExcelReaderStringsMaterialized** | **Xlsm**   |  **58.11 ms** |  **1.427 ms** |  **1.334 ms** |  **1.00** |    **0.03** |        **-** |        **-** |        **-** |    **17.09 KB** |        **1.00** |
| OfficeIMOBytes                 | Xlsm   |  80.43 ms |  4.403 ms |  4.118 ms |  1.38 |    0.08 | 272.7273 |        - |        - | 13939.97 KB |      815.50 |
| OfficeIMOStream                | Xlsm   |  80.43 ms |  2.391 ms |  2.237 ms |  1.38 |    0.05 | 272.7273 |        - |        - | 20503.87 KB |    1,199.50 |
| Sylvan                         | Xlsm   | 219.00 ms |  9.391 ms |  8.784 ms |  3.77 |    0.17 |        - |        - |        - |    644.6 KB |       37.71 |
|                                |        |           |           |           |       |         |          |          |          |             |             |
| **ExcelReaderStringsMaterialized** | **Xlsb**   |  **30.50 ms** |  **0.773 ms** |  **0.723 ms** |  **1.00** |    **0.03** |        **-** |        **-** |        **-** |    **16.65 KB** |        **1.00** |
| OfficeIMOBytes                 | Xlsb   |  31.72 ms |  1.554 ms |  1.454 ms |  1.04 |    0.05 | 266.6667 |        - |        - | 13985.93 KB |      840.07 |
| OfficeIMOStream                | Xlsb   |  37.48 ms |  0.909 ms |  0.850 ms |  1.23 |    0.04 | 451.6129 | 193.5484 |  32.2581 | 18828.52 KB |    1,130.95 |
| Sylvan                         | Xlsb   |  36.64 ms |  3.359 ms |  3.142 ms |  1.20 |    0.10 |        - |        - |        - |   338.87 KB |       20.35 |
|                                |        |           |           |           |       |         |          |          |          |             |             |
| **ExcelReaderStringsMaterialized** | **Xls**    |  **15.95 ms** |  **0.363 ms** |  **0.340 ms** |  **1.00** |    **0.03** |        **-** |        **-** |        **-** |    **21.48 KB** |        **1.00** |
| OfficeIMOBytes                 | Xls    |  21.60 ms |  0.353 ms |  0.330 ms |  1.35 |    0.03 | 279.0698 |        - |        - | 13990.08 KB |      651.17 |
| OfficeIMOStream                | Xls    |  22.75 ms |  1.347 ms |  1.260 ms |  1.43 |    0.08 | 404.7619 | 142.8571 | 142.8571 | 25538.11 KB |    1,188.68 |
| Sylvan                         | Xls    |  25.97 ms |  1.204 ms |  1.126 ms |  1.63 |    0.08 |        - |        - |        - |   189.67 KB |        8.83 |
