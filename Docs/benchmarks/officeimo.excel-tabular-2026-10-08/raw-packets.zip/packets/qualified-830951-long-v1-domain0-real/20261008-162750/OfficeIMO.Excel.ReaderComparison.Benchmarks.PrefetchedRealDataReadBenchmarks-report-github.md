```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-KJRLRQ : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=00000000000000001111111111111111  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=15  IterationTime=1s  LaunchCount=1  
UnrollFactor=1  WarmupCount=12  

```
| Method                    | Format | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1    | Gen2    | Allocated   | Alloc Ratio |
|-------------------------- |------- |----------:|----------:|----------:|------:|--------:|---------:|--------:|--------:|------------:|------------:|
| **ExcelReaderPrefetch**       | **Xlsx**   |  **35.32 ms** |  **1.709 ms** |  **1.599 ms** |  **1.00** |    **0.06** |        **-** |       **-** |       **-** |    **46.02 KB** |        **1.00** |
| ExcelReaderMemoryPrefetch | Xlsx   |  34.10 ms |  1.432 ms |  1.339 ms |  0.97 |    0.06 |        - |       - |       - |    25.33 KB |        0.55 |
| OfficeIMOBytes            | Xlsx   |  84.68 ms |  4.560 ms |  4.266 ms |  2.40 |    0.16 | 250.0000 |       - |       - | 15393.67 KB |      334.50 |
| Sylvan                    | Xlsx   | 242.42 ms | 11.967 ms | 11.194 ms |  6.88 |    0.43 |        - |       - |       - |   647.57 KB |       14.07 |
|                           |        |           |           |           |       |         |          |         |         |             |             |
| **ExcelReaderPrefetch**       | **Xlsm**   |  **44.81 ms** |  **6.554 ms** |  **6.130 ms** |  **1.02** |    **0.18** |        **-** |       **-** |       **-** |       **62 KB** |        **1.00** |
| ExcelReaderMemoryPrefetch | Xlsm   |  39.77 ms |  3.342 ms |  3.126 ms |  0.90 |    0.12 |        - |       - |       - |    45.24 KB |        0.73 |
| OfficeIMOBytes            | Xlsm   |  94.67 ms |  2.668 ms |  2.496 ms |  2.14 |    0.25 | 300.0000 |       - |       - | 14957.65 KB |      241.24 |
| Sylvan                    | Xlsm   | 248.34 ms | 10.654 ms |  9.966 ms |  5.63 |    0.68 |        - |       - |       - |   647.63 KB |       10.45 |
|                           |        |           |           |           |       |         |          |         |         |             |             |
| **ExcelReaderPrefetch**       | **Xlsb**   |  **18.36 ms** |  **2.330 ms** |  **2.179 ms** |  **1.01** |    **0.15** |        **-** |       **-** |       **-** |    **28.67 KB** |        **1.00** |
| ExcelReaderMemoryPrefetch | Xlsb   |  16.67 ms |  0.618 ms |  0.578 ms |  0.92 |    0.09 |        - |       - |       - |    17.54 KB |        0.61 |
| OfficeIMOBytes            | Xlsb   |  35.35 ms |  1.481 ms |  1.386 ms |  1.95 |    0.20 | 333.3333 | 37.0370 | 37.0370 | 14593.86 KB |      509.05 |
| Sylvan                    | Xlsb   |  36.87 ms |  0.641 ms |  0.599 ms |  2.03 |    0.20 |        - |       - |       - |   339.35 KB |       11.84 |
