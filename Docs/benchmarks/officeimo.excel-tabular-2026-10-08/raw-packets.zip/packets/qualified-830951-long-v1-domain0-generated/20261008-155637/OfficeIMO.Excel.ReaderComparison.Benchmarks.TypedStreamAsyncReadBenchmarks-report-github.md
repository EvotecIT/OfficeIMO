```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-KJRLRQ : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=00000000000000001111111111111111  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=15  IterationTime=1s  LaunchCount=1  
UnrollFactor=1  WarmupCount=12  

```
| Method                          | RowCount | Shape    | Mean     | Error    | StdDev   | Ratio | RatioSD | Gen0     | Gen1    | Gen2    | Allocated | Alloc Ratio |
|-------------------------------- |--------- |--------- |---------:|---------:|---------:|------:|--------:|---------:|--------:|--------:|----------:|------------:|
| OfficeIMOStreamOpenTypedAsync   | 50000    | Original | 17.51 ms | 0.602 ms | 0.563 ms |  1.26 |    0.05 |  54.5455 | 18.1818 | 18.1818 |    3.1 MB |        0.80 |
| ExcelReaderStreamOpenTypedAsync | 50000    | Original | 13.86 ms | 0.374 ms | 0.350 ms |  1.00 |    0.03 |  82.1918 |       - |       - |   3.87 MB |        1.00 |
| SylvanStreamOpenTypedAsync      | 50000    | Original | 71.62 ms | 2.835 ms | 2.652 ms |  5.17 |    0.23 | 250.0000 |       - |       - |  10.49 MB |        2.71 |
