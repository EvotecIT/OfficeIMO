```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-KJRLRQ : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=00000000000000001111111111111111  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=15  IterationTime=1s  LaunchCount=1  
UnrollFactor=1  WarmupCount=12  

```
| Method                              | RowCount | Format | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1   | Allocated | Alloc Ratio |
|------------------------------------ |--------- |------- |----------:|----------:|----------:|------:|--------:|---------:|-------:|----------:|------------:|
| **ExcelReaderStringsMaterializedAsync** | **50000**    | **Xlsx**   |  **9.980 ms** | **0.3401 ms** | **0.3181 ms** |  **1.00** |    **0.04** |  **31.2500** |      **-** |   **1.58 MB** |        **1.00** |
| OfficeIMOAsync                      | 50000    | Xlsx   | 15.774 ms | 0.7774 ms | 0.7272 ms |  1.58 |    0.09 |  65.5738 |      - |   3.51 MB |        2.22 |
| SylvanAsync                         | 50000    | Xlsx   | 41.083 ms | 4.6902 ms | 4.3872 ms |  4.12 |    0.44 |        - |      - |   1.89 MB |        1.20 |
|                                     |          |        |           |           |           |       |         |          |        |           |             |
| **ExcelReaderStringsMaterializedAsync** | **50000**    | **Xlsb**   |  **4.710 ms** | **0.5389 ms** | **0.5041 ms** |  **1.01** |    **0.13** |  **31.2500** |      **-** |   **1.58 MB** |        **1.00** |
| OfficeIMOAsync                      | 50000    | Xlsb   |  8.950 ms | 1.5159 ms | 1.4180 ms |  1.92 |    0.33 | 106.8702 |      - |   5.12 MB |        3.25 |
| SylvanAsync                         | 50000    | Xlsb   |  8.760 ms | 0.3248 ms | 0.3038 ms |  1.88 |    0.16 |  33.8983 |      - |   1.82 MB |        1.16 |
|                                     |          |        |           |           |           |       |         |          |        |           |             |
| **ExcelReaderStringsMaterializedAsync** | **50000**    | **Xls**    |  **5.236 ms** | **0.1466 ms** | **0.1372 ms** |  **1.00** |    **0.04** |  **33.6538** |      **-** |   **1.58 MB** |        **1.00** |
| OfficeIMOAsync                      | 50000    | Xls    |  7.390 ms | 0.9881 ms | 0.9242 ms |  1.41 |    0.17 | 211.5385 |      - |  10.25 MB |        6.50 |
| SylvanAsync                         | 50000    | Xls    |  6.004 ms | 0.3341 ms | 0.3125 ms |  1.15 |    0.06 |  32.4324 | 5.4054 |   1.68 MB |        1.06 |
