```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-KJRLRQ : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=00000000000000001111111111111111  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=15  IterationTime=1s  LaunchCount=1  
UnrollFactor=1  WarmupCount=12  

```
| Method           | RowCount | Format | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1    | Allocated   | Alloc Ratio |
|----------------- |--------- |------- |----------:|----------:|----------:|------:|--------:|---------:|--------:|------------:|------------:|
| **ExcelReaderAsync** | **50000**    | **Xlsx**   |  **8.900 ms** | **0.1590 ms** | **0.1487 ms** |  **1.00** |    **0.02** |        **-** |       **-** |     **8.39 KB** |        **1.00** |
| OfficeIMOAsync   | 50000    | Xlsx   | 13.111 ms | 1.7681 ms | 1.6539 ms |  1.47 |    0.18 |  70.5882 | 11.7647 |  3621.97 KB |      431.47 |
| SylvanAsync      | 50000    | Xlsx   | 40.077 ms | 4.8203 ms | 4.5089 ms |  4.50 |    0.50 |  27.7778 |       - |  1940.06 KB |      231.11 |
|                  |          |        |           |           |           |       |         |          |         |             |             |
| **ExcelReaderAsync** | **50000**    | **Xlsb**   |  **5.687 ms** | **0.2105 ms** | **0.1969 ms** |  **1.00** |    **0.05** |        **-** |       **-** |     **6.38 KB** |        **1.00** |
| OfficeIMOAsync   | 50000    | Xlsb   |  8.370 ms | 0.9320 ms | 0.8718 ms |  1.47 |    0.16 |  98.5915 |       - |  5246.66 KB |      822.00 |
| SylvanAsync      | 50000    | Xlsb   |  8.156 ms | 1.1360 ms | 1.0626 ms |  1.44 |    0.19 |  34.4828 |       - |  1866.42 KB |      292.41 |
|                  |          |        |           |           |           |       |         |          |         |             |             |
| **ExcelReaderAsync** | **50000**    | **Xls**    |  **4.291 ms** | **0.3084 ms** | **0.2885 ms** |  **1.00** |    **0.09** |        **-** |       **-** |     **2.91 KB** |        **1.00** |
| OfficeIMOAsync   | 50000    | Xls    |  8.265 ms | 0.3991 ms | 0.3733 ms |  1.93 |    0.15 | 213.6752 |       - | 10499.22 KB |    3,612.64 |
| SylvanAsync      | 50000    | Xls    |  7.953 ms | 0.4456 ms | 0.4168 ms |  1.86 |    0.15 |  35.2113 |  7.0423 |  1719.72 KB |      591.73 |
