```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-KJRLRQ : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=00000000000000001111111111111111  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=15  IterationTime=1s  LaunchCount=1  
UnrollFactor=1  WarmupCount=12  

```
| Method                    | RowCount | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1    | Gen2    | Allocated | Alloc Ratio |
|-------------------------- |--------- |----------:|----------:|----------:|------:|--------:|---------:|--------:|--------:|----------:|------------:|
| ExcelReaderTypedXlsbAsync | 50000    |  9.191 ms | 0.6246 ms | 0.5843 ms |  1.00 |    0.09 |  79.6460 |       - |       - |   3.87 MB |        1.00 |
| OfficeIMOTypedXlsbAsync   | 50000    | 17.560 ms | 0.9084 ms | 0.8498 ms |  1.92 |    0.14 | 196.4286 | 17.8571 | 17.8571 |    8.7 MB |        2.25 |
| SylvanTypedXlsbAsync      | 50000    | 26.582 ms | 1.7965 ms | 1.6804 ms |  2.90 |    0.25 | 200.0000 | 28.5714 |       - |   10.4 MB |        2.69 |
