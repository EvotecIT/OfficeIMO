```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-KJRLRQ : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=00000000000000001111111111111111  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=15  IterationTime=1s  LaunchCount=1  
UnrollFactor=1  WarmupCount=12  

```
| Method                | RowCount | Shape    | Mean     | Error    | StdDev   | Ratio | RatioSD | Gen0     | Allocated | Alloc Ratio |
|---------------------- |--------- |--------- |---------:|---------:|---------:|------:|--------:|---------:|----------:|------------:|
| OfficeIMOTypedAsync   | 50000    | Original | 16.93 ms | 0.768 ms | 0.719 ms |  1.39 |    0.08 |        - |   2.36 MB |        0.61 |
| ExcelReaderTypedAsync | 50000    | Original | 12.20 ms | 0.585 ms | 0.547 ms |  1.00 |    0.06 |  58.8235 |   3.87 MB |        1.00 |
| SylvanTypedAsync      | 50000    | Original | 55.69 ms | 7.514 ms | 7.028 ms |  4.57 |    0.60 | 176.4706 |  10.48 MB |        2.71 |
