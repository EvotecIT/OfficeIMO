```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-KJRLRQ : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=00000000000000001111111111111111  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=15  IterationTime=1s  LaunchCount=1  
UnrollFactor=1  WarmupCount=12  

```
| Method               | RowCount | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1    | Gen2    | Allocated | Alloc Ratio |
|--------------------- |--------- |----------:|----------:|----------:|------:|--------:|---------:|--------:|--------:|----------:|------------:|
| ExcelReaderTypedXlsb | 50000    |  9.340 ms | 0.4484 ms | 0.4194 ms |  1.00 |    0.06 |  84.7458 |       - |       - |   3.87 MB |        1.00 |
| OfficeIMOTypedXlsb   | 50000    | 10.096 ms | 0.2624 ms | 0.2455 ms |  1.08 |    0.05 |  90.9091 | 11.3636 | 11.3636 |   4.07 MB |        1.05 |
| SylvanTypedXlsb      | 50000    | 25.635 ms | 0.8305 ms | 0.7769 ms |  2.75 |    0.14 | 205.1282 | 25.6410 |       - |   10.4 MB |        2.69 |
