```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-KJRLRQ : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=00000000000000001111111111111111  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=15  IterationTime=1s  LaunchCount=1  
UnrollFactor=1  WarmupCount=12  

```
| Method                         | RowCount | Format | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1   | Allocated | Alloc Ratio |
|------------------------------- |--------- |------- |----------:|----------:|----------:|------:|--------:|---------:|-------:|----------:|------------:|
| **ExcelReaderStringsMaterialized** | **50000**    | **Xlsx**   |  **8.701 ms** | **0.3994 ms** | **0.3736 ms** |  **1.00** |    **0.06** |  **26.5487** |      **-** |   **1.58 MB** |        **1.00** |
| OfficeIMOOriginal              | 50000    | Xlsx   | 15.467 ms | 0.5782 ms | 0.5408 ms |  1.78 |    0.09 |  69.4444 |      - |   3.51 MB |        2.22 |
| Sylvan                         | 50000    | Xlsx   | 44.067 ms | 2.3771 ms | 2.2235 ms |  5.07 |    0.32 |        - |      - |   1.89 MB |        1.20 |
|                                |          |        |           |           |           |       |         |          |        |           |             |
| **ExcelReaderStringsMaterialized** | **50000**    | **Xlsb**   |  **5.933 ms** | **0.1926 ms** | **0.1802 ms** |  **1.00** |    **0.04** |  **30.1205** |      **-** |   **1.58 MB** |        **1.00** |
| OfficeIMOOriginal              | 50000    | Xlsb   | 10.318 ms | 0.4381 ms | 0.4098 ms |  1.74 |    0.08 | 106.0606 |      - |   5.12 MB |        3.25 |
| Sylvan                         | 50000    | Xlsb   |  9.194 ms | 0.1894 ms | 0.1772 ms |  1.55 |    0.05 |  42.0168 | 8.4034 |   1.82 MB |        1.15 |
|                                |          |        |           |           |           |       |         |          |        |           |             |
| **ExcelReaderStringsMaterialized** | **50000**    | **Xls**    |  **4.763 ms** | **0.1614 ms** | **0.1510 ms** |  **1.00** |    **0.04** |  **30.0429** |      **-** |   **1.58 MB** |        **1.00** |
| OfficeIMOOriginal              | 50000    | Xls    |  8.068 ms | 0.1814 ms | 0.1697 ms |  1.70 |    0.06 | 209.6774 |      - |  10.25 MB |        6.50 |
| Sylvan                         | 50000    | Xls    |  6.753 ms | 0.3606 ms | 0.3373 ms |  1.42 |    0.08 |  28.3688 |      - |   1.68 MB |        1.06 |
