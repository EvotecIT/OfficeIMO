```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-KJRLRQ : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=00000000000000001111111111111111  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=15  IterationTime=1s  LaunchCount=1  
UnrollFactor=1  WarmupCount=12  

```
| Method               | RowCount | Model  | Mean     | Error    | StdDev   | Ratio | RatioSD | Gen0    | Gen1    | Allocated  | Alloc Ratio |
|--------------------- |--------- |------- |---------:|---------:|---------:|------:|--------:|--------:|--------:|-----------:|------------:|
| **ExcelReaderAutomatic** | **50000**    | **Class**  | **10.86 ms** | **1.655 ms** | **1.548 ms** |  **1.02** |    **0.21** | **71.4286** |       **-** | **3959.57 KB** |        **1.00** |
| OfficeIMOAutomatic   | 50000    | Class  | 17.67 ms | 0.359 ms | 0.335 ms |  1.66 |    0.26 | 61.5385 | 15.3846 | 2460.59 KB |        0.62 |
|                      |          |        |          |          |          |       |         |         |         |            |             |
| **ExcelReaderAutomatic** | **50000**    | **Struct** | **11.79 ms** | **0.955 ms** | **0.893 ms** |  **1.01** |    **0.11** | **37.5000** |       **-** | **1621.62 KB** |        **1.00** |
| OfficeIMOAutomatic   | 50000    | Struct | 15.93 ms | 0.901 ms | 0.842 ms |  1.36 |    0.12 |       - |       - |  171.94 KB |        0.11 |
