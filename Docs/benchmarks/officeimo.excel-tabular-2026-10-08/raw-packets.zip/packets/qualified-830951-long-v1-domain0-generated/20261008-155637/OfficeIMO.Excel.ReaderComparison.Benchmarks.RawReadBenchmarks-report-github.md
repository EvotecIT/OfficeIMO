```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-KJRLRQ : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=00000000000000001111111111111111  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=15  IterationTime=1s  LaunchCount=1  
UnrollFactor=1  WarmupCount=12  

```
| Method              | RowCount | Format | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1    | Gen2   | Allocated   | Alloc Ratio |
|-------------------- |--------- |------- |----------:|----------:|----------:|------:|--------:|---------:|--------:|-------:|------------:|------------:|
| **ExcelReaderOriginal** | **50000**    | **Xlsx**   |  **7.793 ms** | **0.4940 ms** | **0.4621 ms** |  **1.00** |    **0.08** |        **-** |       **-** |      **-** |     **3.82 KB** |        **1.00** |
| OfficeIMOOriginal   | 50000    | Xlsx   | 16.744 ms | 0.3873 ms | 0.3623 ms |  2.16 |    0.12 |  90.9091 | 15.1515 |      - |   3630.6 KB |      950.34 |
| Sylvan              | 50000    | Xlsx   | 46.974 ms | 2.5547 ms | 2.3897 ms |  6.05 |    0.44 |  47.6190 |       - |      - |  1939.73 KB |      507.74 |
|                     |          |        |           |           |           |       |         |          |         |        |             |             |
| **ExcelReaderOriginal** | **50000**    | **Xlsb**   |  **5.355 ms** | **0.1972 ms** | **0.1845 ms** |  **1.00** |    **0.05** |        **-** |       **-** |      **-** |     **6.73 KB** |        **1.00** |
| OfficeIMOOriginal   | 50000    | Xlsb   |  9.265 ms | 1.3454 ms | 1.2585 ms |  1.73 |    0.24 | 120.3704 |  9.2593 | 9.2593 |  5322.57 KB |      791.16 |
| Sylvan              | 50000    | Xlsb   |  6.342 ms | 0.7838 ms | 0.7332 ms |  1.19 |    0.14 |  42.5532 |  7.0922 |      - |   1865.6 KB |      277.31 |
|                     |          |        |           |           |           |       |         |          |         |        |             |             |
| **ExcelReaderOriginal** | **50000**    | **Xls**    |  **3.027 ms** | **0.4884 ms** | **0.4569 ms** |  **1.02** |    **0.20** |        **-** |       **-** |      **-** |     **3.13 KB** |        **1.00** |
| OfficeIMOOriginal   | 50000    | Xls    |  6.126 ms | 0.8375 ms | 0.7834 ms |  2.06 |    0.37 | 216.2162 |       - |      - | 10522.68 KB |    3,356.77 |
| Sylvan              | 50000    | Xls    |  6.410 ms | 1.6293 ms | 1.5240 ms |  2.16 |    0.57 |  40.4624 |  5.7803 |      - |  1717.95 KB |      548.03 |
