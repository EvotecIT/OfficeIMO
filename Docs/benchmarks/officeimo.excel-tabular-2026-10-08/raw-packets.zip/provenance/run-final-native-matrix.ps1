param(
    [ValidateSet('Main', 'Refinements', 'Candidate', 'Remaining', 'Crypto', 'NativeAttribution', 'Probe')][string]$Phase = 'Main',
    [ValidateSet('0', '1', 'Both')][string]$Domain = 'Both',
    [string]$RunTag = 'final'
)
$ErrorActionPreference = 'Stop'
if ($Phase -eq 'Remaining' -and (Test-Path -LiteralPath (Join-Path $PSScriptRoot 'hold-remaining-for-reader-attribution.txt'))) {
    Write-Output 'HOLD remaining matrix until the coordinator settles reader refinement attribution.'
    return
}
$taskRoot = $PSScriptRoot
$sourceRoot = 'C:\Support\GitHub\_worktrees\OfficeIMO-excelreader-performance'
$currentHarness = Join-Path $taskRoot 'matrix-final-native-harness\bin\ExcelReaderTyped.Benchmarks\release\ExcelReaderTyped.Benchmarks.dll'
$refinementBaselineHarness = Join-Path $taskRoot 'refinements-before-harness\bin\ExcelReaderTyped.Benchmarks\release\ExcelReaderTyped.Benchmarks.dll'
$baselineHarness = Join-Path $taskRoot 'matrix-qualified-baseline-harness\bin\ExcelReaderTyped.Benchmarks\release\ExcelReaderTyped.Benchmarks.dll'
$publishedHarness = Join-Path $taskRoot 'matrix-qualified-published-harness\bin\ExcelReaderTyped.Benchmarks\release\ExcelReaderTyped.Benchmarks.dll'
$cryptoHarness = Join-Path $taskRoot 'crypto-only-harness\bin\ExcelReaderTyped.Benchmarks\release\ExcelReaderTyped.Benchmarks.dll'
$beforeCryptoHarness = Join-Path $taskRoot 'encrypted-before-harness\bin\ExcelReaderTyped.Benchmarks\release\ExcelReaderTyped.Benchmarks.dll'
Set-Location -LiteralPath $sourceRoot
Import-Module PSPublishModule -RequiredVersion 3.0.158.3
$env:TEMP = Join-Path $taskRoot 'temp'
$env:TMP = $env:TEMP
$env:OFFICEIMO_BENCHMARK_OUTPUT = $env:TEMP
$env:OFFICEIMO_BENCHMARK_DATA = 'D:\Dev\Scratch\officeimo-excelreader-benchmark-lane\upstream-real-fixtures'
$env:OFFICEIMO_ENCRYPTED_BENCHMARK_CORPUS = 'C:\Support\GitHub\_worktrees\OfficeIMO-excel-encrypted-datareader\OfficeIMO.TestAssets\Documents\ExcelEncryptionCorpus'
$env:OFFICEIMO_ENCRYPTED_BENCHMARK_CACHE = 'D:\Dev\Scratch\officeimo-excelreader-benchmark-lane\encrypted-inputs'
$env:OFFICEIMO_BENCHMARK_PROCESS_PRIORITY = 'High'
$env:OFFICEIMO_TYPED_BENCHMARK_ROWS = '50000'
$env:OFFICEIMO_CSV_PARALLEL_BENCHMARK_DOP = '1,4'
foreach ($name in @('OFFICEIMO_CSV_PARALLEL_BENCHMARK_ROWS', 'OFFICEIMO_STRING_BENCHMARK_ROWS', 'OFFICEIMO_SHARED_UTF8_BENCHMARK_ROWS', 'EXCELREADER_LARGE_ENCRYPTED_ROWS', 'OFFICEIMO_STYLED_WRITE_ARTIFACTS')) {
    Remove-Item -LiteralPath "Env:$name" -ErrorAction SilentlyContinue
}
$ordinary = @('--launchCount','1','--warmupCount','12','--iterationCount','15','--iterationTime','1000','--unrollFactor','1')
$large = @('--launchCount','1','--warmupCount','8','--iterationCount','12','--iterationTime','1000','--unrollFactor','1')
$huge = @('--launchCount','1','--warmupCount','4','--iterationCount','8','--iterationTime','250','--unrollFactor','1')
$main = @('--launchCount','1','--warmupCount','12','--iterationCount','15','--invocationCount','32','--unrollFactor','1')
$domains = if ($Domain -eq 'Both') { @(0,1) } else { @([int]$Domain) }
$runRoot = Join-Path $taskRoot 'final-runs'
New-Item -ItemType Directory -Path $runRoot -Force | Out-Null

function Invoke-DeclaredBdnRun {
    param([string]$Id, [int]$CacheDomain, [string]$Harness, [string[]]$Filters, [string[]]$JobArguments,
        [int]$ExpectedCases, [string]$Shapes = 'Original', [string]$Dop = '1,4')
    $affinity = if ($CacheDomain -eq 0) { '65535' } else { '4294901760' }
    $env:OFFICEIMO_BENCHMARK_AFFINITY_MASK = $affinity
    $env:OFFICEIMO_TYPED_BENCHMARK_SHAPES = $Shapes
    $env:OFFICEIMO_CSV_PARALLEL_BENCHMARK_DOP = $Dop
    $runId = "$RunTag-domain$CacheDomain-$Id"
    $artifacts = Join-Path $runRoot $runId
    if (Test-Path -LiteralPath $artifacts) { throw "Run already exists: $runId" }
    $log = Join-Path $runRoot "$runId.log"
    $args = @($Harness,'--filter') + $Filters + $JobArguments + @('--outliers','DontRemove','--artifacts',$artifacts,'--noOverwrite')
    $sourceCommit = (git rev-parse HEAD).Trim()
    $hostSnapshot = @(Get-Process -Name dotnet,testhost,MSBuild -ErrorAction SilentlyContinue | ForEach-Object {
        [ordered]@{id=$_.Id;name=$_.ProcessName;cpuSeconds=$_.CPU;workingSetBytes=$_.WorkingSet64}
    })
    $metadata = @{
        'benchmark.workload.id' = "officeimo-tabular-$runId"
        'benchmark.workload.framework' = 'net10.0'
        'benchmark.workload.sourceCommit' = $sourceCommit
        'benchmark.measurement.group' = $Id
        'benchmark.cpu.affinity' = $affinity
        'benchmark.cpu.cacheDomain' = "$CacheDomain"
        'benchmark.cpu.priority' = 'High'
        'benchmark.package.excelreader' = '6.0.0'
        'benchmark.package.sylvan.excel' = '0.5.8'
        'benchmark.package.sylvan.data' = '0.2.17'
        'benchmark.package.sylvan.csv' = '1.4.4'
        'benchmark.runtime' = 'net10.0/10.0.12'
        'benchmark.harness.sha256' = (Get-FileHash -LiteralPath $Harness -Algorithm SHA256).Hash
        'benchmark.input.shapes' = $Shapes
        'benchmark.input.parallelDegrees' = $Dop
        'benchmark.job.arguments' = ($args | ConvertTo-Json -Compress)
        'benchmark.expectedCases' = "$ExpectedCases"
        'benchmark.bundle.label' = $Id
    }
    foreach ($owner in @('OfficeIMO.Core','OfficeIMO.Excel','OfficeIMO.CSV','OfficeIMO.Data.Arrow')) {
        $loadedFile = Join-Path (Split-Path -Parent $Harness) "$owner.dll"
        if (Test-Path -LiteralPath $loadedFile) {
            $metadata["benchmark.owner.$owner.version"] = (Get-Item -LiteralPath $loadedFile).VersionInfo.ProductVersion
            $metadata["benchmark.owner.$owner.sha256"] = (Get-FileHash -LiteralPath $loadedFile -Algorithm SHA256).Hash
        }
    }
    $isCryptoSnapshot = $Harness -eq $cryptoHarness -or $Harness -eq $beforeCryptoHarness
    if ($isCryptoSnapshot) {
        $metadata['benchmark.harness.sourceSnapshot.sha256'] = (Get-FileHash -LiteralPath (Join-Path $taskRoot 'crypto-harness-source-ba9-native-affinity\source-identity.json')).Hash
        $metadata['benchmark.harness.sourceSnapshot'] = 'ba9 source plus unchanged4be authenticated workload and native-width affinity wiring'
    }
    $capture = Start-BenchmarkProvenanceCapture -SourceRoot $sourceRoot -ArtifactRoot $artifacts -Metadata $metadata -RunMode full
    Write-Output "START $runId expectedCases=$ExpectedCases source=$sourceCommit UTC=$([DateTime]::UtcNow.ToString('o'))"
    try {
        if ($isCryptoSnapshot) { Set-Location -LiteralPath (Join-Path $taskRoot 'crypto-harness-source-ba9-native-affinity\Benchmarks\ExcelReaderTyped') }
        & dotnet @args *> $log
    } finally {
        Set-Location -LiteralPath $sourceRoot
    }
    $exitCode = $LASTEXITCODE
    $reports = @(Get-ChildItem -LiteralPath $artifacts -Filter '*-report-full.json' -Recurse)
    $caseResults = @($reports | ForEach-Object { (Get-Content -LiteralPath $_.FullName -Raw | ConvertFrom-Json).Benchmarks })
    $failed = @($caseResults | Where-Object { $null -eq $_.Statistics -or $null -eq $_.Statistics.Mean })
    if ($exitCode -ne 0 -or $caseResults.Count -ne $ExpectedCases -or $failed.Count -ne 0) {
        Get-Content -LiteralPath $log -Tail 24
        throw "Incomplete BDN run $runId exit=$exitCode reports=$($caseResults.Count)/$ExpectedCases failures=$($failed.Count)"
    }
    $capture | Complete-BenchmarkProvenanceCapture | Out-Null
    $result = Import-BenchmarkResult -Path $artifacts -Suite 'officeimo-tabular-managed-20261008' -OutputPath (Join-Path $runRoot "$runId-normalized.json")
    $hostAfter = @(Get-Process -Name dotnet,testhost,MSBuild -ErrorAction SilentlyContinue | ForEach-Object {
        [ordered]@{id=$_.Id;name=$_.ProcessName;cpuSeconds=$_.CPU;workingSetBytes=$_.WorkingSet64}
    })
    [ordered]@{run=$runId;sourceCommit=$sourceCommit;affinity=$affinity;harness=$Harness;arguments=$args;expected=$ExpectedCases;completed=$caseResults.Count;hostBefore=$hostSnapshot;hostAfter=$hostAfter;endedUtc=[DateTime]::UtcNow.ToString('o')} |
        ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $runRoot "$runId-context.json") -Encoding utf8
    Write-Output "DONE $runId cases=$($caseResults.Count) UTC=$([DateTime]::UtcNow.ToString('o'))"
    if ($Phase -eq 'Probe' -or $Phase -eq 'NativeAttribution') {
        $shortCases = @(foreach ($case in $caseResults) {
            $actual = @($case.Measurements | Where-Object { $_.IterationMode -eq 'Workload' -and $_.IterationStage -eq 'Actual' })
            $minimum = ($actual | Measure-Object Nanoseconds -Minimum).Minimum
            if ($actual.Count -eq 0 -or $minimum -lt 100000000) {
                [pscustomobject]@{type=$case.Type;method=$case.Method;parameters=$case.Parameters;actualCount=$actual.Count;minimumMilliseconds=$minimum/1000000}
            }
        })
        if ($shortCases.Count) {
            $shortCases | ConvertTo-Json -Depth 4
            throw "Sealed recipe qualification has short warmed iterations: $runId"
        }
        Write-Output "ADEQUATE $runId every measured workload iteration >=100ms"
    }
}

foreach ($cacheDomain in $domains) {
    if ($Phase -eq 'Probe') {
        Invoke-DeclaredBdnRun -Id 'recipe-probe' -CacheDomain $cacheDomain -Harness $currentHarness -Filters @('*.AdoReadBenchmarks.*','*.CsvRawReadBenchmarks.*','*.SharedStringFirstRowBenchmarks.*Storage: Stored*') -JobArguments $ordinary -ExpectedCases 15
    } elseif ($Phase -eq 'NativeAttribution') {
        $order = if ($cacheDomain -eq 0) { @('before','current') } else { @('current','before') }
        foreach ($bundle in $order) {
            $harness = if ($bundle -eq 'before') { Join-Path $taskRoot 'matrix-qualified-harness\bin\ExcelReaderTyped.Benchmarks\release\ExcelReaderTyped.Benchmarks.dll' } else { $currentHarness }
            Invoke-DeclaredBdnRun -Id "native-attribution-$bundle" -CacheDomain $cacheDomain -Harness $harness -Filters @('*.RawReadBenchmarks.ExcelReaderOriginal*Format: Xlsb*','*.RawReadBenchmarks.OfficeIMOOriginal*Format: Xlsb*','*.TypedXlsbReadBenchmarks.ExcelReaderTypedXlsb*','*.TypedXlsbReadBenchmarks.OfficeIMOTypedXlsb*') -JobArguments $ordinary -ExpectedCases 4
        }
    } elseif ($Phase -eq 'Candidate') {
        Invoke-DeclaredBdnRun -Id 'main-current' -CacheDomain $cacheDomain -Harness $currentHarness -Filters @('*.TypedReadBenchmarks.*','*.WriterBenchmarks.*') -JobArguments $main -ExpectedCases 8 -Shapes 'Original,SharedStrings'
    } elseif ($Phase -eq 'Main' -or $Phase -eq 'Refinements') {
        $order = if ($Phase -eq 'Main') {
            if ($cacheDomain -eq 0) { @('before','published','current') } else { @('current','published','before') }
        } else {
            if ($cacheDomain -eq 0) { @('before','current') } else { @('current','before') }
        }
        foreach ($bundle in $order) {
            $harness = if ($bundle -eq 'before') { if ($Phase -eq 'Refinements') { $refinementBaselineHarness } else { $baselineHarness } } elseif ($bundle -eq 'published') { $publishedHarness } else { $currentHarness }
            $lane = if ($Phase -eq 'Refinements') { 'refinements' } else { 'main' }
            Invoke-DeclaredBdnRun -Id "$lane-$bundle" -CacheDomain $cacheDomain -Harness $harness -Filters @('*.TypedReadBenchmarks.*','*.WriterBenchmarks.*') -JobArguments $main -ExpectedCases 8 -Shapes 'Original,SharedStrings'
        }
    } elseif ($Phase -eq 'Crypto') {
        $order = if ($cacheDomain -eq 0) { @('before','core-only') } else { @('core-only','before') }
        foreach ($bundle in $order) {
            $harness = if ($bundle -eq 'before') { $beforeCryptoHarness } else { $cryptoHarness }
            Invoke-DeclaredBdnRun -Id "crypto-$bundle" -CacheDomain $cacheDomain -Harness $harness -Filters @('*.EncryptedVerifiedReadBenchmarks.OfficeIMOVerifiedFullFields*OriginalSmallXlsx*') -JobArguments @('--launchCount','1','--warmupCount','12','--iterationCount','15','--iterationTime','250','--unrollFactor','1') -ExpectedCases 2
        }
    } else {
        Invoke-DeclaredBdnRun -Id 'generated' -CacheDomain $cacheDomain -Harness $currentHarness -Filters @('*.RawReadBenchmarks.*','*.MaterializedRawReadBenchmarks.*','*.RawAsyncReadBenchmarks.*','*.MaterializedRawAsyncReadBenchmarks.*','*.TypedXlsbReadBenchmarks.*','*.TypedAsyncReadBenchmarks.*','*.TypedXlsbAsyncReadBenchmarks.*','*.TypedStreamAsyncReadBenchmarks.*','*.TypedModelReadBenchmarks.*','*.BorrowedRefStructReadBenchmarks.ExcelReaderMappedRefStruct*','*.BorrowedRefStructReadBenchmarks.OfficeIMOFactoryRefStruct*') -JobArguments $ordinary -ExpectedCases 54
        Invoke-DeclaredBdnRun -Id 'real' -CacheDomain $cacheDomain -Harness $currentHarness -Filters @('*.RealDataReadBenchmarks.*','*.PrefetchedRealDataReadBenchmarks.*','*.MaterializedRealDataReadBenchmarks.*','*.RealDataTypedReadBenchmarks.*') -JobArguments $ordinary -ExpectedCases 52
        Invoke-DeclaredBdnRun -Id 'strings' -CacheDomain $cacheDomain -Harness $currentHarness -Filters @('*.StringHeavyReadBenchmarks.*','*.MaterializedStringHeavyReadBenchmarks.*','*.SharedStringFirstRowBenchmarks.*','*.SharedStringFullScanBenchmarks.*Storage: Stored*','*.SharedStringBorrowedScanBenchmarks.*','*.SharedStringUtf8ReadBenchmarks.*') -JobArguments $large -ExpectedCases 47
        Invoke-DeclaredBdnRun -Id 'ado' -CacheDomain $cacheDomain -Harness $currentHarness -Filters @('*.AdoReadBenchmarks.*') -JobArguments $ordinary -ExpectedCases 9
        Invoke-DeclaredBdnRun -Id 'writing' -CacheDomain $cacheDomain -Harness $currentHarness -Filters @('*.SharedStringWriterBenchmarks.*','*.CompactWriterBenchmarks.*','*.NativeWriterBenchmarks.*','*.ConfiguredXlsbWriterBenchmarks.OfficeIMOModelAndSaveInlineStrings*','*.ConfiguredXlsbWriterBenchmarks.OfficeIMOModelAndSaveSharedStrings*','*.ConfiguredXlsbWriterBenchmarks.ExcelReaderXlsbWriter*','*.RecordWriterBenchmarks.*','*.MappedRecordWriterBenchmarks.*','*.Utf8WriterBenchmarks.*','*.ArrowStringWriterBenchmarks.*','*.StyledRowWriterBenchmarks.*') -JobArguments $large -ExpectedCases 26
        Invoke-DeclaredBdnRun -Id 'csv' -CacheDomain $cacheDomain -Harness $currentHarness -Filters @('*.CsvRawReadBenchmarks.*','*.CsvMaterializedReadBenchmarks.*','*.CsvRawAsyncBenchmarks.*','*.CsvTypedReadBenchmarks.*','*.CsvTypedAsyncBenchmarks.*','*.CsvWideReadBenchmarks.*','*.CsvWriterBenchmarks.*','*.CsvRecordWriterBenchmarks.*','*.CsvUtf8WriterBenchmarks.*','*.CsvRealDataReadBenchmarks.*','*.CsvRealDataMaterializedReadBenchmarks.*') -JobArguments $ordinary -ExpectedCases 37
        Invoke-DeclaredBdnRun -Id 'csv-large-dop1' -CacheDomain $cacheDomain -Harness $currentHarness -Filters @('*.CsvParallelTypedBenchmarks.*','*.CsvDirectAggregateBenchmarks.*') -JobArguments $huge -ExpectedCases 27 -Dop '1'
        Invoke-DeclaredBdnRun -Id 'csv-large-dop4' -CacheDomain $cacheDomain -Harness $currentHarness -Filters @('*.CsvParallelTypedBenchmarks.ExcelReaderParallel*','*.CsvParallelTypedBenchmarks.OfficeIMOCoreParallel*','*.CsvParallelTypedBenchmarks.OfficeIMOTextParallel*','*.CsvDirectAggregateBenchmarks.*') -JobArguments $huge -ExpectedCases 21 -Dop '4'
        Invoke-DeclaredBdnRun -Id 'arrow' -CacheDomain $cacheDomain -Harness $currentHarness -Filters @('*.ArrowConversionBenchmarks.*','*.ArrowInferredConversionBenchmarks.*') -JobArguments $ordinary -ExpectedCases 7
        Invoke-DeclaredBdnRun -Id 'encrypted' -CacheDomain $cacheDomain -Harness $currentHarness -Filters @('*.EncryptedVerifiedReadBenchmarks.*','*.EncryptedVerifiedAsyncReadBenchmarks.*') -JobArguments $large -ExpectedCases 12
        Invoke-DeclaredBdnRun -Id 'cold' -CacheDomain $cacheDomain -Harness $currentHarness -Filters @('*.ColdStartReadBenchmarks.*','*.ColdStartWriteBenchmarks.*') -JobArguments @() -ExpectedCases 6
    }
}




