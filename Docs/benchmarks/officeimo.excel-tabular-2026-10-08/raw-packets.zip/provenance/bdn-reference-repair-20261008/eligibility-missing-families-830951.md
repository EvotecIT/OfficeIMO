# Missing-family eligibility for frozen 830951

All 110 expected cases completed in successful child processes. This packet qualifies the unchanged copied harness and generated reference import for build, setup and output execution. It contains no comparative performance result.

| Group | Cases | Successful children | Launches per case | Eligibility wall seconds |
| --- | ---: | ---: | ---: | ---: |
| csv | 37 | 37 | 1 | 40.657 |
| csv-large-dop1 | 27 | 27 | 1 | 308.995 |
| csv-large-dop4 | 21 | 21 | 1 | 257.574 |
| arrow | 7 | 7 | 1 | 18.894 |
| encrypted | 12 | 12 | 1 | 39.408 |
| cold | 6 | 6 | 1 | 11.585 |

The five noncold groups use BDN Dry. The cold group retains the declared ColdStart strategy and overrides only launch/iteration counts for six single-launch children. Its full-field read/write validator ran separately once. The final cold measurement recipe still requests sixteen fresh launches per case.

The original CSV datasets contain 4,300,000, 8,000,000 and 3,000,000 rows. DOP 1 and 4 selectors, real-data files and encrypted corpus/cache routes are unchanged. Exact input declarations, resolved jobs, case identities, native warnings, and host snapshots are retained in the JSON and native logs.

The raw text, materialized, typed, aggregation, writer and Arrow contracts stay distinct. Normal async completion does not prove intentional cancellation. Other host work was allowed during qualification; this packet must not be imported as primary timing evidence.

Source is clean at `83095146282a96143b23a79a7ecca058a24a709b`. All 44 original/copied runtime member pairs have unchanged SHA256 and length after qualification. The repair imports references only into generated BDN projects. No production source or assembly was changed.

The member manifest accounts for native artifacts, imports, contexts, logs, runtime members and derivation sources. No agent cleanup or archives were performed. BDN reports its normal artifact cleanup, and no generated directories remain beside the copied harness. The unchanged 40,098,468-byte runtime copy is retained for the coordinator.
