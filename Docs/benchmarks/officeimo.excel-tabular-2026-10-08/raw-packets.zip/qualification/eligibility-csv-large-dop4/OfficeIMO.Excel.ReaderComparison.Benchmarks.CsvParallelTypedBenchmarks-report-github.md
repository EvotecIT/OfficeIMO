```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host] : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Dry    : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

Job=Dry  Affinity=00000000000000001111111111111111  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=1  LaunchCount=1  RunStrategy=ColdStart  
UnrollFactor=1  WarmupCount=1  

```
| Method                | Input                | Dop | Mean       | Error | Ratio | Gen0       | Gen1       | Gen2      | Allocated  | Alloc Ratio |
|---------------------- |--------------------- |---- |-----------:|------:|------:|-----------:|-----------:|----------:|-----------:|------------:|
| **ExcelReaderParallel**   | **Conve(...)00000 [23]** | **4**   |   **384.6 ms** |    **NA** |  **1.00** | **15000.0000** |  **1000.0000** |         **-** |  **680.81 MB** |        **1.00** |
| OfficeIMOCoreParallel | Conve(...)00000 [23] | 4   | 2,024.2 ms |    NA |  5.26 | 45000.0000 | 11000.0000 |         - | 1831.51 MB |        2.69 |
| OfficeIMOTextParallel | Conve(...)00000 [23] | 4   | 1,103.1 ms |    NA |  2.87 | 62000.0000 | 61000.0000 | 9000.0000 |  1466.4 MB |        2.15 |
|                       |                      |     |            |       |       |            |            |           |            |             |
| **ExcelReaderParallel**   | **Conve(...)00000 [25]** | **4**   |   **293.0 ms** |    **NA** |  **1.00** | **11000.0000** |  **1000.0000** |         **-** |  **475.16 MB** |        **1.00** |
| OfficeIMOCoreParallel | Conve(...)00000 [25] | 4   | 1,353.5 ms |    NA |  4.62 | 31000.0000 |  7000.0000 |         - | 1277.87 MB |        2.69 |
| OfficeIMOTextParallel | Conve(...)00000 [25] | 4   |   743.9 ms |    NA |  2.54 | 38000.0000 | 34000.0000 | 6000.0000 | 1022.47 MB |        2.15 |
|                       |                      |     |            |       |       |            |            |           |            |             |
| **ExcelReaderParallel**   | **NarrowInt-8000000**    | **4**   |   **241.2 ms** |    **NA** |  **1.00** |  **5000.0000** |  **1000.0000** |         **-** |  **254.76 MB** |        **1.00** |
| OfficeIMOCoreParallel | NarrowInt-8000000    | 4   | 1,899.1 ms |    NA |  7.87 | 39000.0000 |  3000.0000 |         - | 1859.98 MB |        7.30 |
| OfficeIMOTextParallel | NarrowInt-8000000    | 4   |   891.2 ms |    NA |  3.70 | 22000.0000 | 16000.0000 | 3000.0000 | 1048.21 MB |        4.11 |
