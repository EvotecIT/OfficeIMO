```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host] : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Dry    : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

Job=Dry  Affinity=00000000000000001111111111111111  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=1  LaunchCount=1  RunStrategy=ColdStart  
UnrollFactor=1  WarmupCount=1  

```
| Method                        | Input                | Dop | Mean       | Error | Ratio | Gen0       | Gen1       | Gen2      | Allocated  | Alloc Ratio |
|------------------------------ |--------------------- |---- |-----------:|------:|------:|-----------:|-----------:|----------:|-----------:|------------:|
| **ExcelReaderAggregate**          | **Conve(...)00000 [23]** | **4**   |   **226.9 ms** |    **NA** |  **1.00** |          **-** |          **-** |         **-** |    **1.76 MB** |        **1.00** |
| OfficeIMOTextOwnedAggregate   | Conve(...)00000 [23] | 4   |   941.6 ms |    NA |  4.15 | 11000.0000 | 10000.0000 | 3000.0000 |   794.3 MB |      452.09 |
| OfficeIMOAsyncPathAggregate   | Conve(...)00000 [23] | 4   | 2,333.3 ms |    NA | 10.29 | 38000.0000 |  4000.0000 |         - | 1864.91 MB |    1,061.44 |
| OfficeIMOAsyncStreamAggregate | Conve(...)00000 [23] | 4   | 2,305.9 ms |    NA | 10.16 | 38000.0000 |  4000.0000 |         - | 1864.89 MB |    1,061.43 |
|                               |                      |     |            |       |       |            |            |           |            |             |
| **ExcelReaderAggregate**          | **Conve(...)00000 [25]** | **4**   |   **163.7 ms** |    **NA** |  **1.00** |          **-** |          **-** |         **-** |    **1.04 MB** |        **1.00** |
| OfficeIMOTextOwnedAggregate   | Conve(...)00000 [25] | 4   |   449.0 ms |    NA |  2.74 |  7000.0000 |  6000.0000 | 2000.0000 |  554.94 MB |      535.94 |
| OfficeIMOAsyncPathAggregate   | Conve(...)00000 [25] | 4   | 1,708.7 ms |    NA | 10.44 | 27000.0000 |  3000.0000 |         - |  1301.1 MB |    1,256.55 |
| OfficeIMOAsyncStreamAggregate | Conve(...)00000 [25] | 4   | 1,822.6 ms |    NA | 11.13 | 27000.0000 |  2000.0000 |         - |  1301.1 MB |    1,256.55 |
|                               |                      |     |            |       |       |            |            |           |            |             |
| **ExcelReaderAggregate**          | **NarrowInt-8000000**    | **4**   |   **155.2 ms** |    **NA** |  **1.00** |          **-** |          **-** |         **-** |    **1.51 MB** |        **1.00** |
| OfficeIMOTextOwnedAggregate   | NarrowInt-8000000    | 4   |   839.7 ms |    NA |  5.41 | 11000.0000 | 10000.0000 | 3000.0000 |  802.17 MB |      532.09 |
| OfficeIMOAsyncPathAggregate   | NarrowInt-8000000    | 4   | 3,212.1 ms |    NA | 20.70 | 45000.0000 |  3000.0000 |         - | 2168.03 MB |    1,438.07 |
| OfficeIMOAsyncStreamAggregate | NarrowInt-8000000    | 4   | 3,322.1 ms |    NA | 21.41 | 45000.0000 |  3000.0000 |         - | 2168.01 MB |    1,438.06 |
