```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host] : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Dry    : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

Job=Dry  Affinity=00000000000000001111111111111111  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=1  LaunchCount=1  RunStrategy=ColdStart  
UnrollFactor=1  WarmupCount=1  

```
| Method          | RowCount | MaterializeStrings | Mean     | Error | Ratio | Gen0      | Allocated  | Alloc Ratio |
|---------------- |--------- |------------------- |---------:|------:|------:|----------:|-----------:|------------:|
| **ExcelReaderWide** | **50000**    | **False**              | **26.78 ms** |    **NA** |  **1.00** |         **-** |      **848 B** |        **1.00** |
| OfficeIMOWide   | 50000    | False              | 45.38 ms |    NA |  1.69 |         - |     4360 B |        5.14 |
| SylvanWide      | 50000    | False              | 13.17 ms |    NA |  0.49 |         - |    46584 B |       54.93 |
|                 |          |                    |          |       |       |           |            |             |
| **ExcelReaderWide** | **50000**    | **True**               | **57.26 ms** |    **NA** |  **1.00** | **1000.0000** | **52800848 B** |        **1.00** |
| OfficeIMOWide   | 50000    | True               | 28.79 ms |    NA |  0.50 | 1000.0000 | 52804360 B |        1.00 |
| SylvanWide      | 50000    | True               | 28.15 ms |    NA |  0.49 | 1000.0000 | 52846584 B |        1.00 |
