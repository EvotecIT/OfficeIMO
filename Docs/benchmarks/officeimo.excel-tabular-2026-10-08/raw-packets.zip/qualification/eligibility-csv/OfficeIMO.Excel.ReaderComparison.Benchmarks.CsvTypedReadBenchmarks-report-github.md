```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host] : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Dry    : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

Job=Dry  Affinity=00000000000000001111111111111111  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=1  LaunchCount=1  RunStrategy=ColdStart  
UnrollFactor=1  WarmupCount=1  

```
| Method           | RowCount | Mean     | Error | Ratio | Allocated | Alloc Ratio |
|----------------- |--------- |---------:|------:|------:|----------:|------------:|
| ExcelReaderTyped | 50000    | 13.68 ms |    NA |  1.00 |   3.86 MB |        1.00 |
| OfficeIMORowsAs  | 50000    | 20.54 ms |    NA |  1.50 |  10.92 MB |        2.83 |
| SylvanTyped      | 50000    | 15.02 ms |    NA |  1.10 |  10.95 MB |        2.83 |
