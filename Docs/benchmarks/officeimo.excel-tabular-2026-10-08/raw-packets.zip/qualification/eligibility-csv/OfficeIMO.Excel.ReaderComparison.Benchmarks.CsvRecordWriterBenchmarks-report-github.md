```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host] : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Dry    : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

Job=Dry  Affinity=00000000000000001111111111111111  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=1  LaunchCount=1  RunStrategy=ColdStart  
UnrollFactor=1  WarmupCount=1  

```
| Method                  | Mapped | RowCount | Mean     | Error | Ratio | Allocated | Alloc Ratio |
|------------------------ |------- |--------- |---------:|------:|------:|----------:|------------:|
| **ExcelReaderRecordLayout** | **False**  | **50000**    | **14.47 ms** |    **NA** |  **1.00** |      **4 MB** |        **1.00** |
| OfficeIMOWriteObjects   | False  | 50000    | 21.14 ms |    NA |  1.46 |  11.26 MB |        2.81 |
|                         |        |          |          |       |       |           |             |
| **ExcelReaderRecordLayout** | **True**   | **50000**    | **21.99 ms** |    **NA** |  **1.00** |      **4 MB** |        **1.00** |
| OfficeIMOWriteObjects   | True   | 50000    | 31.33 ms |    NA |  1.42 |  11.26 MB |        2.81 |
