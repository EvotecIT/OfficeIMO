```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-NXPVQH : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=00000000000000001111111111111111  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
InvocationCount=1  IterationCount=1  LaunchCount=1  
RunStrategy=ColdStart  UnrollFactor=1  WarmupCount=0  

```
| Method                       | Mean      | Error | Ratio | Allocated | Alloc Ratio |
|----------------------------- |----------:|------:|------:|----------:|------------:|
| ExcelReaderAttributes        |  27.46 ms |    NA |  1.00 |  21.09 KB |        1.00 |
| OfficeIMOAutomaticMapping    | 247.01 ms |    NA |  9.00 |   93.8 KB |        4.45 |
| ExcelReaderFluentMapping     |  24.20 ms |    NA |  0.88 |  24.03 KB |        1.14 |
| ExcelReaderAttributeFallback |  29.08 ms |    NA |  1.06 |  26.16 KB |        1.24 |
