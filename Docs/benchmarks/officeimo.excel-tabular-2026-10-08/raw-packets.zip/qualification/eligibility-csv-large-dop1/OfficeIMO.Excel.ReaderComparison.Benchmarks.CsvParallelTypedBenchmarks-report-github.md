```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host] : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Dry    : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

Job=Dry  Affinity=00000000000000001111111111111111  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=1  LaunchCount=1  RunStrategy=ColdStart  
UnrollFactor=1  WarmupCount=1  

```
| Method                | Input                | Dop | Mean       | Error | Ratio | Gen0       | Gen1       | Gen2      | Allocated  | Alloc Ratio |
|---------------------- |--------------------- |---- |-----------:|------:|------:|-----------:|-----------:|----------:|-----------:|------------:|
| **ExcelReaderParallel**   | **Conve(...)00000 [23]** | **1**   |   **824.2 ms** |    **NA** |  **1.00** | **14000.0000** |          **-** |         **-** |  **671.49 MB** |        **1.00** |
| ExcelReaderSequential | Conve(...)00000 [23] | 1   |   866.3 ms |    NA |  1.05 | 13000.0000 |          - |         - |   669.8 MB |        1.00 |
| OfficeIMOCoreParallel | Conve(...)00000 [23] | 1   |   810.1 ms |    NA |  0.98 | 26000.0000 |          - |         - |  1290.2 MB |        1.92 |
| OfficeIMOTextParallel | Conve(...)00000 [23] | 1   |   975.9 ms |    NA |  1.18 | 25000.0000 | 12000.0000 | 3000.0000 | 1463.53 MB |        2.18 |
| SylvanSequential      | Conve(...)00000 [23] | 1   | 1,652.4 ms |    NA |  2.00 | 27000.0000 |          - |         - | 1292.01 MB |        1.92 |
|                       |                      |     |            |       |       |            |            |           |            |             |
| **ExcelReaderParallel**   | **Conve(...)00000 [25]** | **1**   |   **830.4 ms** |    **NA** |  **1.00** | **10000.0000** |          **-** |         **-** |   **468.5 MB** |        **1.00** |
| ExcelReaderSequential | Conve(...)00000 [25] | 1   |   821.3 ms |    NA |  0.99 | 10000.0000 |          - |         - |  467.38 MB |        1.00 |
| OfficeIMOCoreParallel | Conve(...)00000 [25] | 1   |   675.8 ms |    NA |  0.81 | 19000.0000 |          - |         - |  900.39 MB |        1.92 |
| OfficeIMOTextParallel | Conve(...)00000 [25] | 1   |   784.3 ms |    NA |  0.94 | 26000.0000 | 15000.0000 | 3000.0000 | 1021.41 MB |        2.18 |
| SylvanSequential      | Conve(...)00000 [25] | 1   | 1,087.4 ms |    NA |  1.31 | 18000.0000 |          - |         - |  901.42 MB |        1.92 |
|                       |                      |     |            |       |       |            |            |           |            |             |
| **ExcelReaderParallel**   | **NarrowInt-8000000**    | **1**   |   **613.8 ms** |    **NA** |  **1.00** |  **5000.0000** |          **-** |         **-** |  **245.76 MB** |        **1.00** |
| ExcelReaderSequential | NarrowInt-8000000    | 1   |   633.2 ms |    NA |  1.03 |  5000.0000 |          - |         - |  244.22 MB |        0.99 |
| OfficeIMOCoreParallel | NarrowInt-8000000    | 1   |   830.1 ms |    NA |  1.35 | 24000.0000 |          - |         - | 1158.79 MB |        4.72 |
| OfficeIMOTextParallel | NarrowInt-8000000    | 1   | 1,038.1 ms |    NA |  1.69 | 29000.0000 | 23000.0000 | 4000.0000 | 1045.95 MB |        4.26 |
| SylvanSequential      | NarrowInt-8000000    | 1   | 1,092.1 ms |    NA |  1.78 | 24000.0000 |          - |         - | 1158.58 MB |        4.71 |
