```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host] : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Dry    : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

Job=Dry  Affinity=00000000000000001111111111111111  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=1  LaunchCount=1  RunStrategy=ColdStart  
UnrollFactor=1  WarmupCount=1  

```
| Method                        | Input                | Dop | Mean       | Error | Ratio | Gen0       | Gen1      | Gen2      | Allocated     | Alloc Ratio |
|------------------------------ |--------------------- |---- |-----------:|------:|------:|-----------:|----------:|----------:|--------------:|------------:|
| **ExcelReaderAggregate**          | **Conve(...)00000 [23]** | **1**   |   **686.7 ms** |    **NA** |  **1.00** |          **-** |         **-** |         **-** |    **1319.08 KB** |        **1.00** |
| OfficeIMOTextOwnedAggregate   | Conve(...)00000 [23] | 1   |   690.1 ms |    NA |  1.00 | 10000.0000 | 9000.0000 | 2000.0000 |  812776.23 KB |      616.17 |
| OfficeIMOAsyncPathAggregate   | Conve(...)00000 [23] | 1   | 2,301.2 ms |    NA |  3.35 | 38000.0000 |         - |         - | 1903077.75 KB |    1,442.73 |
| OfficeIMOAsyncStreamAggregate | Conve(...)00000 [23] | 1   | 2,862.4 ms |    NA |  4.17 | 38000.0000 |         - |         - |  1903096.8 KB |    1,442.75 |
|                               |                      |     |            |       |       |            |           |           |               |             |
| **ExcelReaderAggregate**          | **Conve(...)00000 [25]** | **1**   |   **703.2 ms** |    **NA** |  **1.00** |          **-** |         **-** |         **-** |     **865.59 KB** |        **1.00** |
| OfficeIMOTextOwnedAggregate   | Conve(...)00000 [25] | 1   |   577.6 ms |    NA |  0.82 |  6000.0000 | 5000.0000 | 1000.0000 |  567054.06 KB |      655.11 |
| OfficeIMOAsyncPathAggregate   | Conve(...)00000 [25] | 1   | 1,688.1 ms |    NA |  2.40 | 27000.0000 |         - |         - | 1327737.47 KB |    1,533.92 |
| OfficeIMOAsyncStreamAggregate | Conve(...)00000 [25] | 1   | 1,754.4 ms |    NA |  2.49 | 27000.0000 |         - |         - | 1327728.34 KB |    1,533.91 |
|                               |                      |     |            |       |       |            |           |           |               |             |
| **ExcelReaderAggregate**          | **NarrowInt-8000000**    | **1**   |   **618.5 ms** |    **NA** |  **1.00** |          **-** |         **-** |         **-** |    **1307.09 KB** |        **1.00** |
| OfficeIMOTextOwnedAggregate   | NarrowInt-8000000    | 1   |   987.7 ms |    NA |  1.60 |  9000.0000 | 8000.0000 | 1000.0000 |  820823.54 KB |      627.98 |
| OfficeIMOAsyncPathAggregate   | NarrowInt-8000000    | 1   | 3,069.9 ms |    NA |  4.96 | 45000.0000 |         - |         - | 2207866.61 KB |    1,689.14 |
| OfficeIMOAsyncStreamAggregate | NarrowInt-8000000    | 1   | 3,411.7 ms |    NA |  5.52 | 45000.0000 |         - |         - | 2207870.67 KB |    1,689.14 |
