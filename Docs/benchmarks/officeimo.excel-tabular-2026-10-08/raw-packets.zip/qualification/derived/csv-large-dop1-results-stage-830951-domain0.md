# Sealed large CSV DOP 1: domain 0, frozen 830951

27 successful cases across 2 native tables/3 full-scale inputs; 216 measured samples. Source/runtime=83095146282a96143b23a79a7ecca058a24a709b; benchmark source unchanged from e676775a59458d1095606386c39506ceb8a9bc33. Started 2026-10-08T17:25:09.8902429+00:00,finished 2026-10-08T17:58:32.6196702+00:00,context ended 2026-10-08T17:58:32.7315621Z.

Huge CSV recipe: 1 launch/4 warmups/8 measurements/250 ms automatic Pilot/unroll 1/DontRemove;High priority/0xFFFF,DOP 1. Actual duration 1765.5022–14071.6213 ms,all >= 100 ms. 0 short/0 distribution rows; 8 outlier hints/9 native outlier values.

- 4.3M conversion-heavy automatic class mapping: OfficeIMO CoreParallel 762.765ms/1,352,941,166B versus peer Parallel 977.759ms/704,077,504B. A scoped time improvement with more cumulative allocation; factory text and sequential controls remain distinct.
- 8M narrow class mapping: OfficeIMO CoreParallel 728.148ms/1,214,821,720B versus peer Parallel 576.967ms/257,691,296B; valid time/allocation loss retained.
- 8M narrow direct reduction: OfficeIMO AsyncPath 3182.490ms/2,260,862,556B and AsyncStream 3291.023ms/2,260,861,670B versus peer native aggregate 586.686ms/1,312,040B. Actual asynchronous IO/decode/field snapshot costs are included; bounded retained state does not mean low cumulative allocations.
- TextOwned direct reduction reads/decodes the complete input within timing and avoids mapped result arrays. Async owner reduces decoded snapshots incrementally; peer reduces UTF8 ref/struct fields. Do not invent a missing native zero-copy counterpart or rank these as identical parser/materialization work.
- All 3 complete original inputs, 27 successful children/216 matched samples retained with exact source/harness/runner/reference identities,High/FFFF. FullName carries untruncated Input/Dop; native Parameters may abbreviate strings and are preserved alongside resolved parameters.
- Only sealed DOP 1/domain 0 inspected. Active DOP 4/later/domain 1 results untouched; no global ranking. Every warning/outlier and valid slower result retained. Allocation is managed cumulative bytes per operation, not peak/retained/native memory.

3M conversion-heavy text-owned direct reduction is 499.000 ± 26.359 ms / 581,031,552 B versus peer native 582.755 ± 60.223 ms / 951,452 B. Retain this shape-dependent mean improvement with substantially higher cumulative allocation; all samples and domain 0 limits remain.

## Input identity and full result qualification

| Full input | Rows | Fields | Child occurrences | Bytes | Expected count/sum | SHA256 |
| --- | ---: | ---: | ---: | ---: | ---: | --- |
| ConversionHeavy-4300000 | 4300000 | 6 | 9 | 207563853 | 4300000/1077150000 | 86B1EE25363929A54CEA19CDA95BD63BC5F08B053B3DF7FBC83E76A0AA2634EF |
| ConversionHeavy3M-3000000 | 3000000 | 6 | 9 | 144811299 | 3000000/751500000 | FB01381C6257B7E716EF069DD14CCC19F1128DDDD3584A3409D5BA05BB240F63 |
| NarrowInt-8000000 | 8000000 | 3 | 9 | 209597884 | 8000000/31999996000000 | 23CC15B690540E2D15F6BDA51184E5B4D20EB3219447B860497CE02052EC0680 |

Each input is generated/fingerprinted before timing. Every method opens/reads the complete file inside timing. Text factory and text-owned reduction perform File.ReadAllText/UTF8 decode inside each invocation; async reductions use actual path/Stream ReadAsync and decoded-field snapshots. Twelve untimed GlobalSetup probes of the public OfficeIMO Stream aggregate show ReadAsync>0 and synchronous Read=0, one per direct-aggregate child. These counters do not cover every timed invocation or peer/TextOwned timed IO; the probe wrapper is absent from timed methods. Typed mapping consumes materialized classes; direct reduction consumes all fields into independent sum/count states without mapped result arrays. Setup validates every typed field/source order or every direct field and exact repeating-row multiplicity; checksum alone is not the integrity proof.

Native FullName preserves full Input/Dop identity; abbreviated native Parameters remain unchanged alongside the resolved input. Original4.3M/8M/3M shapes and DOP 1 are not pooled with smaller inputs, DOP 4 or other data contracts. Old caller-reduction diagnostics are not selected in this 27-case group. No output workbook or serialized mapped-record file is part of these contracts.

## CsvDirectAggregateBenchmarks

Three original full files,DOP 1. Peer CsvParallel.AggregateAsync uses UTF8 ref/struct fields and independent native states; OfficeIMO public AggregateTextRowsAsParallel reads/decodes whole file inside timing, public AggregateRowsAsParallelAsync path/stream reads incrementally with decoded UTF16 field snapshots. All6 heavy fields/all3 narrow integers consumed; states sum Units/A and count rows without mapped result arrays. Every consumed field and repeating-row multiplicity is proved in Setup. UTF8 versus decoded text/materialization pipeline remains explicit; bounded retained state is not low cumulative allocation.

| Method | Resolved full input / DOP | Mean ms | SD ms | Allocated bytes | Min actual iteration ms |
| --- | --- | ---: | ---: | ---: | ---: |
| ExcelReaderAggregate | ConversionHeavy-4300000 / 1 | 696.787706 | 139.855513 | 1258224 | 2196.2283 |
| OfficeIMOTextOwnedAggregate | ConversionHeavy-4300000 / 1 | 724.655872 | 29.201177 | 832285386 | 2739.2390 |
| OfficeIMOAsyncPathAggregate | ConversionHeavy-4300000 / 1 | 2599.968175 | 174.636155 | 1948760284 | 9090.9123 |
| OfficeIMOAsyncStreamAggregate | ConversionHeavy-4300000 / 1 | 2196.885716 | 343.248016 | 1948766446 | 7225.8375 |
| ExcelReaderAggregate | ConversionHeavy3M-3000000 / 1 | 582.754719 | 60.222567 | 951452 | 2053.5141 |
| OfficeIMOTextOwnedAggregate | ConversionHeavy3M-3000000 / 1 | 498.999906 | 26.358775 | 581031552 | 1859.2525 |
| OfficeIMOAsyncPathAggregate | ConversionHeavy3M-3000000 / 1 | 1843.204928 | 275.108922 | 1359595902 | 6202.8044 |
| OfficeIMOAsyncStreamAggregate | ConversionHeavy3M-3000000 / 1 | 2049.350334 | 368.661117 | 1359611650 | 7270.7275 |
| ExcelReaderAggregate | NarrowInt-8000000 / 1 | 586.685725 | 20.154424 | 1312040 | 2256.8470 |
| OfficeIMOTextOwnedAggregate | NarrowInt-8000000 / 1 | 894.448038 | 45.520151 | 840761312 | 3208.2791 |
| OfficeIMOAsyncPathAggregate | NarrowInt-8000000 / 1 | 3182.489878 | 188.654469 | 2260862556 | 11749.7910 |
| OfficeIMOAsyncStreamAggregate | NarrowInt-8000000 / 1 | 3291.022641 | 141.234222 | 2260861670 | 12465.4007 |

## CsvParallelTypedBenchmarks

Same4.3M/8M/3M full files,DOP 1. Same materialized heavy6-field/narrow3-integer classes across automatic peer CsvParallel/attribute sequential parser, OfficeIMO Core.RowsAsParallel, public decoded-text factory ReadTextRowsAsParallel, Sylvan GetRecords sequential. Text factory includes File.ReadAllText/UTF8 decode in each timed call. Each engine Setup checks every mapped field/source order/count before timing; result rows are consumed into same Units/A checksum. Parallel and sequential pipelines remain distinct.

| Method | Resolved full input / DOP | Mean ms | SD ms | Allocated bytes | Min actual iteration ms |
| --- | --- | ---: | ---: | ---: | ---: |
| ExcelReaderParallel | ConversionHeavy-4300000 / 1 | 977.759031 | 62.525569 | 704077504 | 3495.2412 |
| ExcelReaderSequential | ConversionHeavy-4300000 / 1 | 927.056922 | 58.303850 | 702355214 | 3343.5220 |
| OfficeIMOCoreParallel | ConversionHeavy-4300000 / 1 | 762.765097 | 14.652647 | 1352941166 | 2980.4473 |
| OfficeIMOTextParallel | ConversionHeavy-4300000 / 1 | 936.503381 | 46.401509 | 1534968376 | 3531.5813 |
| SylvanSequential | ConversionHeavy-4300000 / 1 | 1222.931944 | 110.752926 | 1354773944 | 4594.4648 |
| ExcelReaderParallel | ConversionHeavy3M-3000000 / 1 | 700.551812 | 34.231760 | 491178704 | 2565.7645 |
| ExcelReaderSequential | ConversionHeavy3M-3000000 / 1 | 702.501941 | 18.241260 | 490002016 | 2709.6346 |
| OfficeIMOCoreParallel | ConversionHeavy3M-3000000 / 1 | 531.598397 | 38.342144 | 943867768 | 1765.5022 |
| OfficeIMOTextParallel | ConversionHeavy3M-3000000 / 1 | 672.630050 | 20.723714 | 1071021116 | 2548.9270 |
| SylvanSequential | ConversionHeavy3M-3000000 / 1 | 987.268381 | 56.100991 | 945204488 | 3633.9065 |
| ExcelReaderParallel | NarrowInt-8000000 / 1 | 576.967016 | 11.397773 | 257691296 | 2234.4241 |
| ExcelReaderSequential | NarrowInt-8000000 / 1 | 547.282422 | 20.401833 | 256001784 | 2064.3884 |
| OfficeIMOCoreParallel | NarrowInt-8000000 / 1 | 728.148497 | 27.646178 | 1214821720 | 2653.2845 |
| OfficeIMOTextParallel | NarrowInt-8000000 / 1 | 818.601156 | 52.543360 | 1096532138 | 2919.2262 |
| SylvanSequential | NarrowInt-8000000 / 1 | 694.094966 | 33.270536 | 1214862504 | 2582.8954 |

## Runtime and host boundary

Outer harness 5E79575325D94AE8D09B97CD0C1C341EBB6AC0A24C3EEE6AE4817A897F97E7A4; runner C52377235F70A38C61333009FFA2CC97C0BE2B3C102041CB127587B09AB32A95;generated-project saved-reference hook CEDF3A831603914A5E024C980CCA65AAAAF25544D98538BC416E963DD8632B12. All 108 loaded-owner identities match frozen quartet. Failure/Dry stays separate; repair does not change product/outer harness.

Boundary snapshots: 111/51 entries, 47 persistent/4 new IDs, max persistent CPU delta 13.812500 s, sum 31.843750 s. No command roles/per-case timeline; no isolation or causal contamination established. No live audit.

## Native warnings and hints

Native type/method/full input/DOP/job tables remain authoritative. Warning prose omitting parameters retains ambiguity; all per-case intervals/outlier arrays/Actuals/Results/allocations remain in JSON. Retain every native warning and valid slower result.

~~~text
// * Hints *
Outliers
  CsvDirectAggregateBenchmarks.OfficeIMOAsyncPathAggregate: OutlierMode=DontRemove, Affinity=00000000000000001111111111111111, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=8, IterationTime=250 ms, LaunchCount=1, UnrollFactor=1, WarmupCount=4   -> 1 outlier  was  detected (2.39 s)
  CsvDirectAggregateBenchmarks.OfficeIMOAsyncStreamAggregate: OutlierMode=DontRemove, Affinity=00000000000000001111111111111111, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=8, IterationTime=250 ms, LaunchCount=1, UnrollFactor=1, WarmupCount=4 -> 1 outlier  was  detected (2.92 s)
  CsvDirectAggregateBenchmarks.ExcelReaderAggregate: OutlierMode=DontRemove, Affinity=00000000000000001111111111111111, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=8, IterationTime=250 ms, LaunchCount=1, UnrollFactor=1, WarmupCount=4          -> 1 outlier  was  detected (632.23 ms)
  CsvDirectAggregateBenchmarks.OfficeIMOTextOwnedAggregate: OutlierMode=DontRemove, Affinity=00000000000000001111111111111111, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=8, IterationTime=250 ms, LaunchCount=1, UnrollFactor=1, WarmupCount=4   -> 1 outlier  was  detected (802.07 ms)
// * Hints *
Outliers
  CsvParallelTypedBenchmarks.SylvanSequential: OutlierMode=DontRemove, Affinity=00000000000000001111111111111111, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=8, IterationTime=250 ms, LaunchCount=1, UnrollFactor=1, WarmupCount=4      -> 2 outliers were detected (1.36 s, 1.43 s)
  CsvParallelTypedBenchmarks.OfficeIMOCoreParallel: OutlierMode=DontRemove, Affinity=00000000000000001111111111111111, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=8, IterationTime=250 ms, LaunchCount=1, UnrollFactor=1, WarmupCount=4 -> 1 outlier  was  detected (441.38 ms)
  CsvParallelTypedBenchmarks.OfficeIMOCoreParallel: OutlierMode=DontRemove, Affinity=00000000000000001111111111111111, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=8, IterationTime=250 ms, LaunchCount=1, UnrollFactor=1, WarmupCount=4 -> 1 outlier  was  detected (663.32 ms)
  CsvParallelTypedBenchmarks.OfficeIMOTextParallel: OutlierMode=DontRemove, Affinity=00000000000000001111111111111111, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=8, IterationTime=250 ms, LaunchCount=1, UnrollFactor=1, WarmupCount=4 -> 1 outlier  was  detected (729.81 ms)
~~~

This adds 27 primary cases: 308 primary + 78 supplementary = 386 sealed/730 planned; 344 current pending. Historical 106 separate. No domain 1/DOP 4/global winner claim. Native originals unchanged; no source/build/test/timer/package/profile/fixturecopy/archive/cleanup/publication.