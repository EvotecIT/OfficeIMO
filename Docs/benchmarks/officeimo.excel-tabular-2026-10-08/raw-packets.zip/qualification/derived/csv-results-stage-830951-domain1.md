# Sealed CSV stage: domain 1, frozen 830951

37 successful cases across 11 native tables; 555 measured samples. Source/runtime=83095146282a96143b23a79a7ecca058a24a709b; benchmark source unchanged from e676775a59458d1095606386c39506ceb8a9bc33. Started 2026-10-08T20:06:21.0503545+00:00, finished 2026-10-08T20:28:19.534304+00:00, context ended 2026-10-08T20:28:19.6507105Z.

Recipe: 1 launch/12 warmups/15 measurements/1000ms automatic Pilot/unroll 1/DontRemove, High/0xFFFF0000. Actual duration 899.9026–1361.6066ms, all >= 100 ms. Warnings:0 short/5 distribution; 14 outlier hint rows/17 native outlier values.

- All 37 cases/555 samples and Actuals succeeded; every measured iteration exceeds 100 ms. All uncertainty, distributions, outlier arrays and allocations retained; no pooled or universal domain claim.
- Raw borrowed UTF8, materialized Name, full string materialization, automatic typed class mapping and async opening/enumeration remain separate native groups. OfficeIMO borrows exact normalized UTF8 from its native source buffers; conversion/text-parser fallbacks are unavailable. Whole parser/opening pipelines remain distinct.
- Matched materialized 32-column wide complete fields: OfficeIMO 14.022775 +/- 0.887951 ms / 52804360 allocated B/op versus peer 20.947360 +/- 1.935122 ms / 52800848 allocated B/op and Sylvan 11.755006 +/- 0.800918 ms / 52846584 allocated B/op. MaterializeStrings=False borrowed routes are separate full parameter identities.
- Ordinary automatic typed class OfficeIMO 5.819986 +/- 0.309526 ms / 11451284 allocated B/op versus peer 3.835464 +/- 0.203136 ms / 4051702 allocated B/op and Sylvan 10.764153 +/- 1.099302 ms / 11486688 allocated B/op. Preserve strategy-specific losses, distinct from raw/materialized work.
- Ordinary writer OfficeIMO 10.978292 +/- 1.026489 ms / 11802663 allocated B/op versus peer 3.721237 +/- 0.172340 ms / 4198248 allocated B/op and Sylvan 5.427023 +/- 0.312847 ms / 4235060 allocated B/op. Valid formatting/output lengths differ; complete fields checked, not identical bytes or format-cost equivalence.
- Public UTF8 writer OfficeIMO 8.907295 +/- 0.460400 ms / 2704 allocated B/op versus peer 3.168175 +/- 0.194072 ms / 416 allocated B/op. Same 100K x 4 input buffers and representative Setup outputs 6,900,000 B/SHA256 3A1E723702CF4E920BDC3F1D2EF1E8D173BE13A4FA7F9095B504F3504C86C20F; byte equality only for retained Setup proof, not every timed invocation.
- Generated/pinned inputs match D0 actual SHA/lengths. Source-enforced full-field/order/type/count and every normalized UTF8 byte Setup proof remains outside timing. Native public borrowed UTF8 API paths are measured; source-only text/encoding fallback costs must not be assigned to native provider lanes. Populated fixture/checksum counts do not establish general nullable/missing-cell/DBNull schema semantics or peak/retained memory.
- Pinned real CSV includes the header: 65,536 rows x 14 fields. Raw/memory/stream/native UTF8/Sylvan UTF16 and fully materialized modes are separate complete native identities. Ordinary async memory-stream opening/actual async traversal is disclosed; no disk/network async scalability claim.
- Prepared writer objects are not serialized-byte timed inputs. Ordinary/record outputs retain full field proofs and lengths, not output SHA; public UTF8 Setup proof also covers escaping/Unicode/null/empty/formula preservation. Individual timed outputs are not retained.
- Allocated bytes are cumulative managed bytes/op, not peak/retained/native memory. V1 failure/136 eligibility remains unranked; V2 reference hook changes build wiring, not product/outer-harness bytes. Only assigned sealed D1 CSV and existing D0 derived packet inspected; no large/live/incomplete/later results or source/process/session audit.

## Runtime and host boundary

Outer harness 5E79575325D94AE8D09B97CD0C1C341EBB6AC0A24C3EEE6AE4817A897F97E7A4; runner C52377235F70A38C61333009FFA2CC97C0BE2B3C102041CB127587B09AB32A95; generated-project saved-reference hook CEDF3A831603914A5E024C980CCA65AAAAF25544D98538BC416E963DD8632B12. All 148 loaded-owner identities match frozen quartet. Failure/Dry stays separate; repair does not change product/outer harness.

Host boundary:55/42 entries,40 persistent/2 new IDs,max CPU delta0.609375s,sum8.531250s. No command roles/per-case timeline; neither isolation nor causal contamination is established. No live audit.

## Input and output qualification

All 51 logged input/output byte records are retained per child; input identities match across paired children. Actual headerless 2,318,990B/headered 2,319,009B/wide 9,200,000B/pinned real8,170,842B inputs are fingerprinted. Prepared object-list writer input is source-defined; writer-record CSV identity is a representative serialization. Ordinary/record output full values/lengths validated without output SHA. Public UTF8 output exactly 6,900,000B/CRLF/headerless has identical SHA and full byte/field proof. Timed outputs are not retained or hashed.

Cross-domain comparison uses 37 unique full case identities and all 51 actual retained declarations; each nonempty 64-hex SHA/byte length matches its D0 record. Timings remain separate, and sample/row/materialization/mapping/format flags are preserved without collapsing composite parameters.

| Input identity | Child occurrences | Bytes | SHA256 |
| --- | ---: | ---: | --- |
| 32-column wide, materializeStrings=False | 3 | 9200000 | 78519F47209E388EE2782F76BAA118209542466D40301CF6B8E4F52B0ABB4ABB |
| 32-column wide, materializeStrings=True | 3 | 9200000 | 78519F47209E388EE2782F76BAA118209542466D40301CF6B8E4F52B0ABB4ABB |
| Pinned65KReal | 7 | 8170842 | AC959F43CF1077B71D310E6E49E3C168BA63A448F1855D45F44E734273EBA490 |
| raw async materialized name | 3 | 2318990 | D81A95FEC39988C63EEAAC841D0AC12CA8EC6677F9FED37D82B785897073B8FC |
| raw materialized name | 3 | 2318990 | D81A95FEC39988C63EEAAC841D0AC12CA8EC6677F9FED37D82B785897073B8FC |
| raw original headerless | 3 | 2318990 | D81A95FEC39988C63EEAAC841D0AC12CA8EC6677F9FED37D82B785897073B8FC |
| typed async headered | 3 | 2319009 | D69CFDC7ED2851B919C6EE847116338FC5F1FB8654F5439332E11062E8DB0E1E |
| typed headered | 3 | 2319009 | D69CFDC7ED2851B919C6EE847116338FC5F1FB8654F5439332E11062E8DB0E1E |
| write/Utf8/Csv/rows=100000/column=0/offsets | 2 | 400004 | 51C283816A6D2B3A47B94156554CFA9A96C308EA2689B14D4DCB4E4C9881F098 |
| write/Utf8/Csv/rows=100000/column=0/values | 2 | 1600000 | B876FFF81A04B978AABCB078941AD90C55A1247810968C47FB8137E36B9D46D2 |
| write/Utf8/Csv/rows=100000/column=1/offsets | 2 | 400004 | 51C283816A6D2B3A47B94156554CFA9A96C308EA2689B14D4DCB4E4C9881F098 |
| write/Utf8/Csv/rows=100000/column=1/values | 2 | 1600000 | 8DFFF8BEEBF466AED0144CF5BC76052AF8177E511F8171A23F9396F4DFA36A40 |
| write/Utf8/Csv/rows=100000/column=2/offsets | 2 | 400004 | 51C283816A6D2B3A47B94156554CFA9A96C308EA2689B14D4DCB4E4C9881F098 |
| write/Utf8/Csv/rows=100000/column=2/values | 2 | 1600000 | D762C2FD86A5E8DC07661DAB2CCADAB04E5074F96DFDA04D915E7B6E6169C4FD |
| write/Utf8/Csv/rows=100000/column=3/offsets | 2 | 400004 | 51C283816A6D2B3A47B94156554CFA9A96C308EA2689B14D4DCB4E4C9881F098 |
| write/Utf8/Csv/rows=100000/column=3/values | 2 | 1600000 | FC5F76E6049A5AF203BA74B582E04021459E0CFDED36E1CCD3497B3CCD1E6712 |
| writer records | 3 | 2319009 | D69CFDC7ED2851B919C6EE847116338FC5F1FB8654F5439332E11062E8DB0E1E |

## CsvMaterializedReadBenchmarks



| Method | Full parameters | Mean ms | SD ms | Allocated bytes | Min actual iteration ms |
| --- | --- | ---: | ---: | ---: | ---: |
| ExcelReaderMaterialized | RowCount=50000 | 2.406832 | 0.081247 | 1650848 | 969.5728 |
| OfficeIMOMaterialized | RowCount=50000 | 5.033706 | 0.276744 | 9049072 | 1073.9600 |
| SylvanMaterialized | RowCount=50000 | 3.160371 | 0.114637 | 1688688 | 934.7656 |

## CsvRawAsyncBenchmarks



| Method | Full parameters | Mean ms | SD ms | Allocated bytes | Min actual iteration ms |
| --- | --- | ---: | ---: | ---: | ---: |
| ExcelReaderAsync | RowCount=50000 | 2.514215 | 0.136403 | 1650920 | 1006.1020 |
| OfficeIMOAsync | RowCount=50000 | 10.800616 | 0.410970 | 14872480 | 922.3139 |
| SylvanAsync | RowCount=50000 | 3.665905 | 0.144445 | 1699128 | 1026.4744 |

## CsvRawReadBenchmarks



| Method | Full parameters | Mean ms | SD ms | Allocated bytes | Min actual iteration ms |
| --- | --- | ---: | ---: | ---: | ---: |
| ExcelReaderOriginal | RowCount=50000 | 1.949433 | 0.060788 | 848 | 981.4545 |
| OfficeIMOBorrowedUtf8 | RowCount=50000 | 4.750742 | 0.272180 | 2120 | 1041.5557 |
| SylvanOriginal | RowCount=50000 | 2.890639 | 0.095377 | 38681 | 1003.0885 |

## CsvRealDataMaterializedReadBenchmarks



| Method | Full parameters | Mean ms | SD ms | Allocated bytes | Min actual iteration ms |
| --- | --- | ---: | ---: | ---: | ---: |
| ExcelReaderMaterialized |  | 23.007694 | 0.950277 | 37443456 | 995.5653 |
| OfficeIMOMaterialized |  | 13.000780 | 0.439670 | 35871296 | 899.9026 |
| SylvanMaterialized |  | 9.352945 | 0.448297 | 37483987 | 1003.2659 |

## CsvRealDataReadBenchmarks



| Method | Full parameters | Mean ms | SD ms | Allocated bytes | Min actual iteration ms |
| --- | --- | ---: | ---: | ---: | ---: |
| ExcelReaderStream |  | 6.691141 | 0.120208 | 848 | 964.6728 |
| ExcelReaderMemory |  | 7.280589 | 0.188715 | 576 | 1028.8944 |
| OfficeIMOStreamBorrowedUtf8 |  | 4.862813 | 0.221152 | 2920 | 997.7298 |
| SylvanFieldSpan |  | 6.380294 | 0.318890 | 41225 | 978.9300 |

## CsvRecordWriterBenchmarks



| Method | Full parameters | Mean ms | SD ms | Allocated bytes | Min actual iteration ms |
| --- | --- | ---: | ---: | ---: | ---: |
| ExcelReaderRecordLayout | Mapped=False&RowCount=50000 | 3.625816 | 0.162130 | 4197443 | 974.5872 |
| OfficeIMOWriteObjects | Mapped=False&RowCount=50000 | 10.275180 | 0.218261 | 11802534 | 983.2331 |
| ExcelReaderRecordLayout | Mapped=True&RowCount=50000 | 4.320924 | 0.124829 | 4197492 | 953.7597 |
| OfficeIMOWriteObjects | Mapped=True&RowCount=50000 | 10.125927 | 0.261529 | 11802535 | 947.2334 |

## CsvTypedAsyncBenchmarks



| Method | Full parameters | Mean ms | SD ms | Allocated bytes | Min actual iteration ms |
| --- | --- | ---: | ---: | ---: | ---: |
| ExcelReaderTypedAsync | RowCount=50000 | 4.311488 | 0.396199 | 4051472 | 1012.5792 |
| OfficeIMORowsAsAsync | RowCount=50000 | 13.540905 | 0.578997 | 17272936 | 1030.4776 |
| SylvanTypedAsync | RowCount=50000 | 8.721418 | 0.463910 | 11497088 | 1034.9687 |

## CsvTypedReadBenchmarks



| Method | Full parameters | Mean ms | SD ms | Allocated bytes | Min actual iteration ms |
| --- | --- | ---: | ---: | ---: | ---: |
| ExcelReaderTyped | RowCount=50000 | 3.835464 | 0.203136 | 4051702 | 1022.5404 |
| OfficeIMORowsAs | RowCount=50000 | 5.819986 | 0.309526 | 11451284 | 957.9719 |
| SylvanTyped | RowCount=50000 | 10.764153 | 1.099302 | 11486688 | 965.5078 |

## CsvUtf8WriterBenchmarks



| Method | Full parameters | Mean ms | SD ms | Allocated bytes | Min actual iteration ms |
| --- | --- | ---: | ---: | ---: | ---: |
| OfficeIMOPublicUtf8Row |  | 8.907295 | 0.460400 | 2704 | 1067.2235 |
| ExcelReaderPublicUtf8 |  | 3.168175 | 0.194072 | 416 | 957.7082 |

## CsvWideReadBenchmarks



| Method | Full parameters | Mean ms | SD ms | Allocated bytes | Min actual iteration ms |
| --- | --- | ---: | ---: | ---: | ---: |
| ExcelReaderWide | RowCount=50000&MaterializeStrings=False | 5.487252 | 0.253474 | 848 | 1039.7709 |
| OfficeIMOWide | RowCount=50000&MaterializeStrings=False | 6.678177 | 0.422401 | 4360 | 925.5028 |
| SylvanWide | RowCount=50000&MaterializeStrings=False | 4.650317 | 0.384841 | 46377 | 1001.1663 |
| ExcelReaderWide | RowCount=50000&MaterializeStrings=True | 20.947360 | 1.935122 | 52800848 | 1006.9457 |
| OfficeIMOWide | RowCount=50000&MaterializeStrings=True | 14.022775 | 0.887951 | 52804360 | 945.6118 |
| SylvanWide | RowCount=50000&MaterializeStrings=True | 11.755006 | 0.800918 | 52846584 | 956.0439 |

## CsvWriterBenchmarks



| Method | Full parameters | Mean ms | SD ms | Allocated bytes | Min actual iteration ms |
| --- | --- | ---: | ---: | ---: | ---: |
| ExcelReaderWriter | RowCount=50000 | 3.721237 | 0.172340 | 4198248 | 1012.8184 |
| OfficeIMOWriteObjects | RowCount=50000 | 10.978292 | 1.026489 | 11802663 | 975.2340 |
| SylvanWriter | RowCount=50000 | 5.427023 | 0.312847 | 4235060 | 1055.3849 |

## Native warnings and hints

Native class/method/full parameters/job tables remain authoritative. Warning prose omitting parameters retains ambiguity. All statistics, intervals, outlier arrays, Actual/Result samples and allocations retained; normalized values/statistics/allocations match native.

~~~text
// * Hints *
Outliers
  CsvMaterializedReadBenchmarks.ExcelReaderMaterialized: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12 -> 1 outlier  was  detected (2.58 ms)
  CsvMaterializedReadBenchmarks.SylvanMaterialized: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12      -> 1 outlier  was  detected (3.44 ms)
// * Warnings *
MultimodalDistribution
  CsvRawAsyncBenchmarks.ExcelReaderAsync: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12 -> It seems that the distribution can have several modes (mValue = 2.86)
// * Hints *
Outliers
  CsvRawReadBenchmarks.OfficeIMOBorrowedUtf8: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12 -> 2 outliers were detected (5.28 ms, 5.46 ms)
// * Warnings *
MultimodalDistribution
  CsvRealDataMaterializedReadBenchmarks.ExcelReaderMaterialized: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12 -> It seems that the distribution can have several modes (mValue = 2.86)
// * Hints *
Outliers
  CsvRealDataMaterializedReadBenchmarks.OfficeIMOMaterialized: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12 -> 2 outliers were detected (12.16 ms, 14.23 ms)
// * Hints *
Outliers
  CsvRealDataReadBenchmarks.ExcelReaderMemory: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12           -> 1 outlier  was  detected (7.67 ms)
  CsvRealDataReadBenchmarks.OfficeIMOStreamBorrowedUtf8: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12 -> 1 outlier  was  detected (5.34 ms)
  CsvRealDataReadBenchmarks.SylvanFieldSpan: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12             -> 1 outlier  was  detected (7.26 ms)
// * Warnings *
MultimodalDistribution
  CsvRecordWriterBenchmarks.ExcelReaderRecordLayout: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12 -> It seems that the distribution is bimodal (mValue = 3.25)
// * Hints *
Outliers
  CsvRecordWriterBenchmarks.ExcelReaderRecordLayout: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12 -> 1 outlier  was  detected (3.97 ms)
  CsvRecordWriterBenchmarks.OfficeIMOWriteObjects: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12   -> 1 outlier  was  detected (10.83 ms)
// * Warnings *
MultimodalDistribution
  CsvTypedAsyncBenchmarks.ExcelReaderTypedAsync: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12 -> It seems that the distribution is bimodal (mValue = 3.43)
// * Hints *
Outliers
  CsvTypedAsyncBenchmarks.SylvanTypedAsync: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12 -> 1 outlier  was  detected (10.08 ms)
// * Hints *
Outliers
  CsvTypedReadBenchmarks.OfficeIMORowsAs: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12 -> 1 outlier  was  detected (6.70 ms)
// * Hints *
Outliers
  CsvUtf8WriterBenchmarks.ExcelReaderPublicUtf8: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12 -> 1 outlier  was  detected (3.65 ms)
// * Warnings *
MultimodalDistribution
  CsvWideReadBenchmarks.SylvanWide: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12 -> It seems that the distribution is bimodal (mValue = 3.67)
// * Hints *
Outliers
  CsvWideReadBenchmarks.OfficeIMOWide: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12 -> 1 outlier  was  detected (8.06 ms)
  CsvWideReadBenchmarks.OfficeIMOWide: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12 -> 2 outliers were detected (11.67 ms, 15.72 ms)
~~~

This independently qualified group contains 37 cases; the coordinator shared ledger remains 542 primary / 110 pending + 78 supplementary while assigned D1 large DOP1 qualification is held separately. If only this increment is applied, 579 primary / 73 pending + 78=657/730; after both assigned 64 cases pass, 606 primary / 46 pending + 78=684/730. Historical 106 and 136 eligibility remain outside timing counts. No pooled/global ranking; valid slower results retained.

Native originals unchanged; no source edit/build/test/timer/fixturecopy/archive/cleanup/incomplete-group inspection/publication.