# Main benchmark stage — e676

This is completed, sealed **stage evidence**, not a final frozen-candidate report. It includes all six main packets and 48 cases: domain 0 source-start → published → current, domain 1 current → published → source-start. Crypto and the remaining matrix are excluded. A bounded native XLSB refinement may change the later candidate; these captured runtime identities and values must remain unchanged.

The published 3.4.4 Original typed-read gap reproduces at about 9.74× and 9.99× the peer mean in domains 0 and 1. Source-start78 is a separate engineering baseline. Current e676 Original time advantage reverses by domain, while Original allocation is lower in both. SST does not establish a reliable speed advantage, and its current allocation is about 5.7% above the peer. The ordinary default writer is slower in both domains; configured compact writers are absent from these main packets.

All methods consume the qualified complete fields. The headline OfficeIMO typed operation constructs the class through direct typed getters; peer/Sylvan use automatic projection. Automatic model mapping has its own selected scenarios. Writer timings retain ordinary defaults, full output finalization and a new 4 MiB destination; configured output policies must not replace this default result.

## Current e676 pairs

Mean ± SD is milliseconds. Allocations are exact managed bytes per operation. Ratios below are the explicit arithmetic quotient of the two recorded means, not a pooled fastest score or a significance test.

| Domain | Contract | OfficeIMO mean ± SD (ms) | Peer mean ± SD (ms) | Office/peer mean ratio | Office bytes | Peer bytes |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| 0 | Original | 12.816 ± 0.269 | 11.883 ± 0.508 | 1.079 | 2479548 | 4054464 |
| 0 | SharedStrings | 12.955 ± 0.230 | 11.701 ± 0.595 | 1.107 | 2558824 | 2420609 |
| 0 | Ordinary writer | 17.948 ± 0.727 | 10.316 ± 0.218 | 1.740 | 4239132 | 4217745 |
| 1 | Original | 12.050 ± 0.447 | 12.941 ± 0.539 | 0.931 | 2560798 | 4069313 |
| 1 | SharedStrings | 11.834 ± 0.729 | 11.736 ± 0.410 | 1.008 | 2558904 | 2420609 |
| 1 | Ordinary writer | 18.612 ± 0.493 | 10.015 ± 0.291 | 1.858 | 4238908 | 4217508 |

Original current allocation ratios are 0.612 and 0.629, about 38.8% and 37.1% lower respectively. That is a scoped managed-allocation finding, not a peak-memory or universal library claim. CPU domains share one machine; neither averaging them nor selecting the favorable domain settles small-margin ranking.

## Original typed source/package attribution

| Domain | Runtime lane | OfficeIMO mean ± SD (ms) | Peer mean ± SD (ms) | Office/peer mean ratio | Office bytes | Peer bytes |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| 0 | before | 112.129 ± 3.723 | 14.417 ± 0.448 | 7.778 | 2540469 | 4054464 |
| 0 | published | 123.642 ± 3.655 | 12.699 ± 0.435 | 9.736 | 5969752 | 4054464 |
| 0 | current | 12.816 ± 0.269 | 11.883 ± 0.508 | 1.079 | 2479548 | 4054464 |
| 1 | before | 107.824 ± 6.915 | 12.126 ± 0.554 | 8.892 | 2621818 | 4069313 |
| 1 | published | 121.815 ± 5.729 | 12.194 ± 1.209 | 9.990 | 6051153 | 4069313 |
| 1 | current | 12.050 ± 0.447 | 12.941 ± 0.539 | 0.931 | 2560798 | 4069313 |

These are sequential rotated runtime comparisons with peers retained in each packet. They support reproduction of the published-package claim on this host and shape; they do not establish the exact timing ratio on the upstream Ryzen 7 5700X or a universal performance ranking.

## Runtime and capture identities

Capture/harness source for every packet is e676775a59458d1095606386c39506ceb8a9bc33, with clean worktree provenance. Runtime owners vary independently. The JSON retains each method, namespace/type, full parameters/full name, native job, actual owner SHA and logged primary comparison-engine identity.

| Runtime lane | Embedded OfficeIMO source | Excel SHA256 | Core SHA256 | Captured harness SHA256 |
| --- | --- | --- | --- | --- |
| before | 78bfbd96dc3967b6f3c5e2376ce4c98000213e2c | 29A145238D67CC254AD211EA26FBC887D7748F45232F9D092BE72DF7BFF80340 | B952AF0AAA5B03E6587AD32DD35DD2C83925DD01F932FAA8DC778BF22595DA99 | 6318FB8B3978D74B05BB5B404E672589B8A96AB85541B363CE98DBFFE65954A2 |
| published | 7ea881d08359b4fddddef8e2aa7782d1ee2265b8 | BEB5A238B4802DAA4B43244E9E3D69E7349FBA8483D2EF4884D90CC81AAD72D3 | 44B3C7657F79296D2F52488328BB14CB7363DDF1784F12E4E8527FD20D4F8745 | 5127D9718E40B9D6D131644A23DB0583CB8A3C88A40DFBA29207C98F82DE30B3 |
| current | e676775a59458d1095606386c39506ceb8a9bc33 | 8158D5FDA5B840BD7B8FCD8F84B261F0C7E88C569E7F2927AE86EDE6FF5284E3 | 7CCC87462A55571045520EDF7A4680A5B4BBBC9DDD794016E3E888C2A7D0182F | 842D0A5B3007B2867DB4424F9CC6A1A3A2769C94D3B41BEE1289B4EE09034156 |

ExcelReader.Core is 6.0.0+ca5b50f99e8ef57ab476f0a2bc8043558d58b28d, SHA256 C6738EF3015B153084D4C0DBB018A48600E841E34FC9689B0773A905A726E8B8. Sylvan.Data.Excel is 0.5.8+d32fb74, SHA256 304B2A317653243720CB8D60C017E6689C228B19A3BBB43ADD57062FBD13CFC7; projection dependency Sylvan.Data is pinned 0.2.17. Every logged owner identity matches sealed metadata within each packet.

## Measurement and input limits

The common job uses 32 invocations, 12 warmups, 15 measurements, one launch, unroll one and DontRemove outliers. All 48 cases retain 15 measured samples. The minimum measured workload iteration is 300.878 ms; none is below the recommended 100 ms boundary, and no MinIterationTime warning occurs. There are 6 distribution-warning rows across the packets; exact native warnings and all detected outlier values remain in the JSON and original logs. Longer iterations do not remove distribution uncertainty.

| Packet | Native cases / successful children | Verified artifacts | Distribution-warning rows | Native artifact bytes |
| --- | ---: | ---: | ---: | ---: |
| qualified-e676-v1-domain0-main-before | 8 / 8 | 9 | 2 | 296361 |
| qualified-e676-v1-domain0-main-published | 8 / 8 | 9 | 1 | 291539 |
| qualified-e676-v1-domain0-main-current | 8 / 8 | 9 | 0 | 309685 |
| qualified-e676-v1-domain1-main-current | 8 / 8 | 9 | 3 | 307527 |
| qualified-e676-v1-domain1-main-published | 8 / 8 | 9 | 0 | 293109 |
| qualified-e676-v1-domain1-main-before | 8 / 8 | 9 | 0 | 296187 |

Every sidecar-listed artifact SHA/length matches, and all 48 native full names are preserved in normalized summaries. Each typed shape has 18 independently generated instances. Original ZIPs are 773,409 bytes and SST ZIPs 777,338 bytes; each shape has 18 distinct package hashes but one identical inflated-part manifest. Logged timestamps differ. That is consistent with metadata variation; this preparation does not claim a byte-diff proof that every differing ZIP byte is a timestamp. Actual per-case package and part hashes remain in the JSON. Validated writer outputs are labelled as outputs, not read inputs.

## All 48 native cases

Tables below retain complete parameters and class/method identity. They do not compute a fastest ranking across class or work boundaries; the original native grouped tables remain authoritative.

### qualified-e676-v1-domain0-main-before

| Class.Method | Full parameters | Mean ± SD (ms) | Median (ms) | Allocated bytes | N | Retained detected outliers |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| TypedReadBenchmarks.ExcelReaderTyped | RowCount=50000&Shape=Original | 14.417 ± 0.448 | 14.403 | 4054464 | 15 | 1 |
| TypedReadBenchmarks.OfficeIMOTyped | RowCount=50000&Shape=Original | 112.129 ± 3.723 | 111.786 | 2540469 | 15 | 0 |
| TypedReadBenchmarks.SylvanTyped | RowCount=50000&Shape=Original | 65.992 ± 1.726 | 66.346 | 10983849 | 15 | 0 |
| TypedReadBenchmarks.ExcelReaderTyped | RowCount=50000&Shape=SharedStrings | 11.664 ± 0.435 | 11.608 | 2405760 | 15 | 1 |
| TypedReadBenchmarks.OfficeIMOTyped | RowCount=50000&Shape=SharedStrings | 71.971 ± 2.274 | 71.643 | 3796995 | 15 | 2 |
| TypedReadBenchmarks.SylvanTyped | RowCount=50000&Shape=SharedStrings | 62.376 ± 3.506 | 62.188 | 9342346 | 15 | 0 |
| WriterBenchmarks.OfficeIMO | RowCount=50000 | 20.206 ± 0.586 | 20.198 | 4235053 | 15 | 0 |
| WriterBenchmarks.ExcelReaderWriter | RowCount=50000 | 10.978 ± 0.634 | 11.179 | 4216744 | 15 | 0 |

### qualified-e676-v1-domain0-main-published

| Class.Method | Full parameters | Mean ± SD (ms) | Median (ms) | Allocated bytes | N | Retained detected outliers |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| TypedReadBenchmarks.ExcelReaderTyped | RowCount=50000&Shape=Original | 12.699 ± 0.435 | 12.693 | 4054464 | 15 | 3 |
| TypedReadBenchmarks.OfficeIMOTyped | RowCount=50000&Shape=Original | 123.642 ± 3.655 | 123.327 | 5969752 | 15 | 0 |
| TypedReadBenchmarks.SylvanTyped | RowCount=50000&Shape=Original | 66.356 ± 2.297 | 66.821 | 10984234 | 15 | 1 |
| TypedReadBenchmarks.ExcelReaderTyped | RowCount=50000&Shape=SharedStrings | 10.966 ± 0.286 | 10.862 | 2420609 | 15 | 3 |
| TypedReadBenchmarks.OfficeIMOTyped | RowCount=50000&Shape=SharedStrings | 80.216 ± 2.335 | 79.597 | 6533345 | 15 | 0 |
| TypedReadBenchmarks.SylvanTyped | RowCount=50000&Shape=SharedStrings | 61.147 ± 5.191 | 60.584 | 9342346 | 15 | 0 |
| WriterBenchmarks.OfficeIMO | RowCount=50000 | 19.940 ± 0.379 | 20.042 | 4220047 | 15 | 0 |
| WriterBenchmarks.ExcelReaderWriter | RowCount=50000 | 10.950 ± 0.371 | 11.034 | 4216386 | 15 | 0 |

### qualified-e676-v1-domain0-main-current

| Class.Method | Full parameters | Mean ± SD (ms) | Median (ms) | Allocated bytes | N | Retained detected outliers |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| TypedReadBenchmarks.ExcelReaderTyped | RowCount=50000&Shape=Original | 11.883 ± 0.508 | 11.811 | 4054464 | 15 | 1 |
| TypedReadBenchmarks.OfficeIMOTyped | RowCount=50000&Shape=Original | 12.816 ± 0.269 | 12.803 | 2479548 | 15 | 0 |
| TypedReadBenchmarks.SylvanTyped | RowCount=50000&Shape=Original | 65.103 ± 2.460 | 65.356 | 10983849 | 15 | 0 |
| TypedReadBenchmarks.ExcelReaderTyped | RowCount=50000&Shape=SharedStrings | 11.701 ± 0.595 | 11.557 | 2420609 | 15 | 4 |
| TypedReadBenchmarks.OfficeIMOTyped | RowCount=50000&Shape=SharedStrings | 12.955 ± 0.230 | 13.021 | 2558824 | 15 | 2 |
| TypedReadBenchmarks.SylvanTyped | RowCount=50000&Shape=SharedStrings | 61.295 ± 2.017 | 61.052 | 9342731 | 15 | 0 |
| WriterBenchmarks.OfficeIMO | RowCount=50000 | 17.948 ± 0.727 | 17.816 | 4239132 | 15 | 0 |
| WriterBenchmarks.ExcelReaderWriter | RowCount=50000 | 10.316 ± 0.218 | 10.300 | 4217745 | 15 | 2 |

### qualified-e676-v1-domain1-main-current

| Class.Method | Full parameters | Mean ± SD (ms) | Median (ms) | Allocated bytes | N | Retained detected outliers |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| TypedReadBenchmarks.ExcelReaderTyped | RowCount=50000&Shape=Original | 12.941 ± 0.539 | 12.997 | 4069313 | 15 | 0 |
| TypedReadBenchmarks.OfficeIMOTyped | RowCount=50000&Shape=Original | 12.050 ± 0.447 | 11.963 | 2560798 | 15 | 0 |
| TypedReadBenchmarks.SylvanTyped | RowCount=50000&Shape=Original | 71.121 ± 1.948 | 71.630 | 10984234 | 15 | 0 |
| TypedReadBenchmarks.ExcelReaderTyped | RowCount=50000&Shape=SharedStrings | 11.736 ± 0.410 | 11.768 | 2420609 | 15 | 0 |
| TypedReadBenchmarks.OfficeIMOTyped | RowCount=50000&Shape=SharedStrings | 11.834 ± 0.729 | 12.016 | 2558904 | 15 | 0 |
| TypedReadBenchmarks.SylvanTyped | RowCount=50000&Shape=SharedStrings | 58.705 ± 2.629 | 59.070 | 9342736 | 15 | 2 |
| WriterBenchmarks.OfficeIMO | RowCount=50000 | 18.612 ± 0.493 | 18.544 | 4238908 | 15 | 0 |
| WriterBenchmarks.ExcelReaderWriter | RowCount=50000 | 10.015 ± 0.291 | 10.031 | 4217508 | 15 | 0 |

### qualified-e676-v1-domain1-main-published

| Class.Method | Full parameters | Mean ± SD (ms) | Median (ms) | Allocated bytes | N | Retained detected outliers |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| TypedReadBenchmarks.ExcelReaderTyped | RowCount=50000&Shape=Original | 12.194 ± 1.209 | 12.714 | 4069313 | 15 | 1 |
| TypedReadBenchmarks.OfficeIMOTyped | RowCount=50000&Shape=Original | 121.815 ± 5.729 | 120.757 | 6051153 | 15 | 1 |
| TypedReadBenchmarks.SylvanTyped | RowCount=50000&Shape=Original | 66.770 ± 2.792 | 66.604 | 10984234 | 15 | 1 |
| TypedReadBenchmarks.ExcelReaderTyped | RowCount=50000&Shape=SharedStrings | 10.998 ± 0.617 | 10.917 | 2420609 | 15 | 0 |
| TypedReadBenchmarks.OfficeIMOTyped | RowCount=50000&Shape=SharedStrings | 83.639 ± 4.319 | 82.850 | 6533632 | 15 | 0 |
| TypedReadBenchmarks.SylvanTyped | RowCount=50000&Shape=SharedStrings | 60.741 ± 2.351 | 61.464 | 9342726 | 15 | 1 |
| WriterBenchmarks.OfficeIMO | RowCount=50000 | 18.748 ± 0.631 | 18.747 | 4223438 | 15 | 1 |
| WriterBenchmarks.ExcelReaderWriter | RowCount=50000 | 10.040 ± 0.348 | 9.992 | 4217132 | 15 | 0 |

### qualified-e676-v1-domain1-main-before

| Class.Method | Full parameters | Mean ± SD (ms) | Median (ms) | Allocated bytes | N | Retained detected outliers |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| TypedReadBenchmarks.ExcelReaderTyped | RowCount=50000&Shape=Original | 12.126 ± 0.554 | 12.245 | 4069313 | 15 | 0 |
| TypedReadBenchmarks.OfficeIMOTyped | RowCount=50000&Shape=Original | 107.824 ± 6.915 | 108.794 | 2621818 | 15 | 1 |
| TypedReadBenchmarks.SylvanTyped | RowCount=50000&Shape=Original | 67.626 ± 2.479 | 67.992 | 10984234 | 15 | 0 |
| TypedReadBenchmarks.ExcelReaderTyped | RowCount=50000&Shape=SharedStrings | 10.793 ± 0.391 | 10.689 | 2420609 | 15 | 0 |
| TypedReadBenchmarks.OfficeIMOTyped | RowCount=50000&Shape=SharedStrings | 69.566 ± 3.359 | 69.634 | 3878382 | 15 | 0 |
| TypedReadBenchmarks.SylvanTyped | RowCount=50000&Shape=SharedStrings | 60.608 ± 2.098 | 60.138 | 9342736 | 15 | 1 |
| WriterBenchmarks.OfficeIMO | RowCount=50000 | 18.477 ± 0.544 | 18.697 | 4238838 | 15 | 0 |
| WriterBenchmarks.ExcelReaderWriter | RowCount=50000 | 9.918 ± 0.241 | 9.867 | 4217510 | 15 | 0 |

## Handoff

Use main-results-stage-e676.json for exact numbers and source paths. Keep this stage separate from historical36df and any later native-refined candidate. It does not fill the final 652-case report automatically. Crypto and remaining families need their own completed captures and identity reconciliation. No source edits, builds, tests, benchmarks, fixture copies, archive assembly or public actions were performed for this extraction.
