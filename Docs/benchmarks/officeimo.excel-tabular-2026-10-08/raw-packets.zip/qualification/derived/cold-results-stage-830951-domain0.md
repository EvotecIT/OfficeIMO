# Sealed cold results: 830951, domain 0

Qualified 6 cases, 96 successful fresh children and 96 native actual samples. Every normalized summary/sample/statistic/allocation metric reconciles with native data. All 9 native sidecar artifacts match retained lengths and SHA-256.

Six target first-use cases: four read mapping strategies and two object-layout writer strategies on 200 records with Name/Id/Date/Value.

Sixteen fresh child processes per case; zero warmups, one actual iteration and one invocation per child. No Pilot, adaptive repetition or explicit Jitting stages occur in the native measurement list.

GlobalSetup and assembly description run before timing. Read setup creates the workbook using peer writer APIs and checks ZIP shape without target ColdStartRecord mapping. Write setup constructs source ColdStartRecord instances. Related APIs and constructors may be initialized or JIT compiled before timing.

Timed scope includes the first target mapping-plan/layout use and reachable JIT/code initialization still deferred after setup, plus complete workbook open/read or write/save/disposal. This is not process startup or first-ever usage of every library API.

Cold reads enforce the Id checksum; timed writers return length. Complete four-field read mapping and parsed writer output are validated in a separate frozen-harness process. No timed writer per-invocation output hash or full-field validation is invented.

Allocated bytes come from BenchmarkDotNet 0.15.8 MemoryDiagnoser's subsequent extra-statistics invocation: second-use allocation, distinct from the first target mapping/layout latency. The boundary is source-derived from the pinned Engine.Run/GetExtraStats behavior established in the earlier bounded review. Native Memory records and GC descriptors report one diagnostic operation and the allocation value; they do not establish first-use or mapping/layout initialization allocation. No separate second-use latency was measured.

Short individual cold operations and minimum-duration warnings are expected for this contract. Repeating work to force a >=100ms iteration would replace first use with warm throughput. Cold results are not ranked with warm cases.

| Native class / method | Complete inputs | First-use mean ms | First-use SD ms | Second-use diagnostic allocated bytes/op |
| --- | --- | ---: | ---: | ---: |
| ColdStartReadBenchmarks.ExcelReaderAttributes | 200 records × Name/Id/Date/Value | 29.209350 | 4.337818 | 21600 |
| ColdStartReadBenchmarks.OfficeIMOAutomaticMapping | 200 records × Name/Id/Date/Value | 78.425519 | 49.660167 | 96048 |
| ColdStartReadBenchmarks.ExcelReaderFluentMapping | 200 records × Name/Id/Date/Value | 24.894212 | 2.295675 | 24608 |
| ColdStartReadBenchmarks.ExcelReaderAttributeFallback | 200 records × Name/Id/Date/Value | 30.040363 | 1.823483 | 26784 |
| ColdStartWriteBenchmarks.ExcelReaderAutomaticLayout | 200 records × Name/Id/Date/Value | 33.942550 | 0.565489 | 86272 |
| ColdStartWriteBenchmarks.OfficeIMOAutomaticLayout | 200 records × Name/Id/Date/Value | 125.108156 | 2.088265 | 680816 |

Native detected outlier values retained: 10. Warning rows: 5 minimum-duration, 0 distribution; 5 outlier hints. No outliers were removed. Full warnings, native confidence intervals/percentiles/statistics and all actuals are in the JSON and immutable source packet.

Raw measured iteration range: 23.403200–264.621400 ms. The warm >=100ms gate does not apply to this first-use contract.

Captured 2026-10-08T18:31:19.2205343+00:00 to 2026-10-08T18:31:53.1664909+00:00; sealed elapsed 33.945957 s. Host: AMD Ryzen 9 9950X3D2, .NET 10.0.12 (10.0.12, 10.0.1226.42308). Each measured child reports High priority and affinity 0xFFFF. Pre/post snapshots do not identify process roles, CPU during individual cases, or activity of processes absent at either endpoint. They do not prove an idle host or establish causal contamination. Fresh benchmark children and generated builds occur within the capture; original snapshots are retained. No live host audit or later-group inspection.

Frozen source/runtime 83095146282a96143b23a79a7ecca058a24a709b and harness 5E79575325D94AE8D09B97CD0C1C341EBB6AC0A24C3EEE6AE4817A897F97E7A4. Resume runner C52377235F70A38C61333009FFA2CC97C0BE2B3C102041CB127587B09AB32A95 matches the v2 sidecar; the separately preserved v1 runner is not substituted. Generated-project reference import CEDF3A831603914A5E024C980CCA65AAAAF25544D98538BC416E963DD8632B12 affects compilation references only; measured owner assemblies retain their recorded hashes.

Complete output proof: original --validate-cold endpoint passed 2026-10-08T16:39:00.3089551Z in a separate process with the identical frozen harness/runtime. Read mapping checks all four fields and count; writer output is parsed and validated independently. Timed child setup and first-operation scope are preserved above.

Only this sealed domain 0 family was qualified. No domain 1/incomplete/later run was inspected, and no source/build/test/package/timing/fixture copy/archive/cleanup or shared report update occurred. Normalized duplicate samples remain in immutable source references; this packet adds no pooled or cross-contract ratio.
