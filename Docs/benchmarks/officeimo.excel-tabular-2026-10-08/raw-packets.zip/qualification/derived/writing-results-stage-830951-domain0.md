# Sealed writing stage: domain 0, frozen 830951

This primary stage contains 26 successful cases across nine native tables and 312 measured samples. Capture/runtime source: 83095146282a96143b23a79a7ecca058a24a709b; benchmark source unchanged from e676775a59458d1095606386c39506ceb8a9bc33. Started 2026-10-08T16:45:44.1934617+00:00, finished 2026-10-08T17:02:32.4584707+00:00, sealed context 2026-10-08T17:02:32.7174355Z.

Job: one launch, eight warmups, twelve measurements, 1000 ms automatic Pilot, unroll 1, DontRemove, High priority/0xFFFF. Measured iteration durations 273.9237–4375.1216 ms; all >= 100 ms. Native diagnostics preserve 0 short-iteration warnings, 0 distribution warning rows, 5 outlier hint rows and 10 native outlier values.

- All 26 cases/312 measured samples succeeded and every actual iteration exceeds100ms. Distribution/outlier warnings and variance remain limits; no domain1/global winner claim.
- Retain the large native XLSB loss: ordinary OfficeIMO model + Save 857.7908ms/461083288B versus peer row streaming 8.8285ms/4218488B. Configured/attributed/mapped XLSB routes incur the same model costs. Same valid output fields do not imply matching model versus streaming intermediate work.
- Compact XLSX Office 10.3711ms versus peer ordinary9.6104ms and PrefetchWrite6.7392ms here. SST compact9.1260ms versus peer SST10.1300ms is a narrower favorable result; ordinary Office SST 18.5675ms is slower. Do not turn configured results into ordinary/global claims.
- Public Arrow orchestration 56.6357ms versus peer RecordBatch 25.0299ms; public UTF8Office 35.3468ms versus peer 16.2456ms; styled Office11.4070ms versus peer6.2273ms. Caller callback/enumeration, native validation/style coordinates and dedicated writer differences remain visible.
- Setup output byte/ZIP-part identities and complete field/style/storage checks are representative qualification outside timing; individual measured output hashes are not retained. Prepared object-list inputs have source/definition/semantic proof rather than a serialized-byte fingerprint; native input buffers have actual per-buffer SHA.
- The v1 compiler failure and Dry/reference eligibility remain separate unranked captures. V2 uses the explicit hook with identical product and outer harness binaries. No source/timed-method change or replacement pooling.
- Only sealed writing domain0 is inspected; no live/incomplete CSV, later/domain1 result or other process audit.

## Runtime, build configuration and host boundary

Outer harness SHA256 5E79575325D94AE8D09B97CD0C1C341EBB6AC0A24C3EEE6AE4817A897F97E7A4; runner SHA256 C52377235F70A38C61333009FFA2CC97C0BE2B3C102041CB127587B09AB32A95. Explicit generated-project saved-reference hook SHA256 CEDF3A831603914A5E024C980CCA65AAAAF25544D98538BC416E963DD8632B12, verified from actual file and capture metadata. All 104 loaded-owner hashes match the captured quartet. The v1 compiler failure has zero measured rows and the 136-case Dry/Cold eligibility stays outside measured counts. V2 timing is separate and does not relabel or pool those attempts.

Host snapshots: 77 before/86 after entries; 44 persistent IDs; 42 new IDs; max persistent CPU delta 0.265625 s, sum 3.671875 s. Boundary snapshots have no command roles/per-case timeline; they establish neither full isolation nor causal contamination. No live process audit performed.

## Input and representative generated-output identities

All 141 logged byte records and 725 ZIP-part records are preserved per child in JSON. Representative generated packages have SHA/length plus each part name, inflated/compressed length, timestamp and SHA. All UTF8/Arrow buffer IDs have the same bytes/hash across paired children. Typed 50K prepared objects and styled Enumerable.Range inputs are source-defined deterministic values rather than serialized input blobs; no object-list byte SHA is invented. Complete field/type/order/style/string-storage proof is in Setup; timed calls return output length and their individual packages are not retained.

Observed XLSB storage policies (exact declarations):

~~~text
XLSB storage=ExcelReader shared strings; configured=True; inlineCells=0; sharedStringCells=50004; hasSstPart=True; sstReferences=50004; sstUnique=12.
XLSB storage=ExcelReader typed records; configured=default; inlineCells=50004; sharedStringCells=0; hasSstPart=True; sstReferences=0; sstUnique=0.
XLSB storage=ExcelReader write prefetch; configured=False; inlineCells=50004; sharedStringCells=0; hasSstPart=True; sstReferences=0; sstUnique=0.
XLSB storage=ExcelReader; configured=default; inlineCells=50004; sharedStringCells=0; hasSstPart=True; sstReferences=0; sstUnique=0.
XLSB storage=OfficeIMO inline strings; configured=False; inlineCells=50004; sharedStringCells=0; hasSstPart=False; sstReferences=absent; sstUnique=0.
XLSB storage=OfficeIMO shared strings; configured=True; inlineCells=0; sharedStringCells=50004; hasSstPart=True; sstReferences=50004; sstUnique=12.
XLSB storage=OfficeIMO; configured=default; inlineCells=50004; sharedStringCells=0; hasSstPart=False; sstReferences=absent; sstUnique=0.
~~~

## ArrowStringWriterBenchmarks

100K four required Arrow string columns, prepared Arrow buffers outside timing; header c0..c3. Both reuse32MiB output, reset/finalize and return length. ExcelReader public WriteRecordBatch versus OfficeIMO public WriteRows/WriteUtf8 caller orchestration with ordinary Enumerable.Range/callback/column-access costs; no dedicated OfficeIMO RecordBatch writer is claimed. Complete fields/schema/output parts checked in Setup.

| Method | Complete parameters | Mean ms | SD ms | Allocated bytes | Min actual iteration ms |
| --- | --- | ---: | ---: | ---: | ---: |
| ExcelReaderRecordBatch |  | 25.029856 | 1.632980 | 18754 | 1039.9748 |
| OfficeIMOPublicRowOrchestration |  | 56.635732 | 3.496322 | 1148427 | 865.0886 |

## CompactWriterBenchmarks

50K prepared Name/Id/Date/Value objects plus header; new4MiB MemoryStream per operation, complete XLSX finalization, return length. OfficeIMO public IncludeCellReferences=false is configured compact output: header references and dimension remain; peer normal writer omits references/dimension. ExcelReader PrefetchWrite=true separate. Full fields/date styles/package integrity/independent readers checked; does not replace ordinary writer results.

| Method | Complete parameters | Mean ms | SD ms | Allocated bytes | Min actual iteration ms |
| --- | --- | ---: | ---: | ---: | ---: |
| OfficeIMOWithoutReferences | RowCount=50000 | 10.371096 | 0.268346 | 4235560 | 1032.2751 |
| ExcelReaderWriter | RowCount=50000 | 9.610373 | 0.510173 | 4216296 | 847.8408 |
| ExcelReaderWriterPrefetch | RowCount=50000 | 6.739178 | 0.313611 | 4261965 | 981.0312 |

## ConfiguredXlsbWriterBenchmarks

50K prepared records plus header. OfficeIMO builds native spreadsheet model then Save, explicitly inline or SST. Peer public XLSB streaming writer with SST=true versus inline PrefetchWrite=true. Full fields/date styles/storage records/package parts validated. Same logical records do not make model and streaming allocation work equal, and inline/prefetch versus SST remain distinct policies.

| Method | Complete parameters | Mean ms | SD ms | Allocated bytes | Min actual iteration ms |
| --- | --- | ---: | ---: | ---: | ---: |
| OfficeIMOModelAndSaveInlineStrings | RowCount=50000 | 864.295235 | 86.169015 | 461361754 | 2856.5579 |
| OfficeIMOModelAndSaveSharedStrings | RowCount=50000 | 894.027263 | 134.849530 | 451014222 | 2949.1760 |
| ExcelReaderXlsbWriterSharedStrings | RowCount=50000 | 7.246943 | 0.675686 | 4254703 | 761.6012 |
| ExcelReaderXlsbWriterPrefetch | RowCount=50000 | 4.681036 | 0.120771 | 4228261 | 913.0125 |

## MappedRecordWriterBenchmarks

50K prebuilt mapped objects, XLSX/XLSB plus header, new4MiB destination and full finalization. Peer generated record layout writes the mapped model; OfficeIMO ordinary public XLSX callback or XLSB model+Save writes the same fields. This is caller-output equivalence, not an automatic mapped writer API equivalence. Object/layout preparation outside timing; correct output validated.

| Method | Complete parameters | Mean ms | SD ms | Allocated bytes | Min actual iteration ms |
| --- | --- | ---: | ---: | ---: | ---: |
| OfficeIMOPublicTypedWrite | Format=Xlsx&RowCount=50000 | 16.992000 | 0.951679 | 4234975 | 1012.1436 |
| ExcelReaderMappedRecords | Format=Xlsx&RowCount=50000 | 10.616357 | 1.224187 | 4215874 | 902.5598 |
| OfficeIMOPublicTypedWrite | Format=Xlsb&RowCount=50000 | 910.490546 | 99.641569 | 461362338 | 3000.7479 |
| ExcelReaderMappedRecords | Format=Xlsb&RowCount=50000 | 7.385121 | 0.370204 | 4216121 | 762.9477 |

## NativeWriterBenchmarks

50K Name/Id/Date/Value records plus header, native XLSB default writing. OfficeIMO builds workbook model then Save versus peer public row-streaming writer. Both current defaults use inline cells; peer carries an empty SST part, OfficeIMO omits it. Same fields/types/order/date styles and independent readability validated. Native XLS diagnostics are unselected and remain unranked separately.

| Method | Complete parameters | Mean ms | SD ms | Allocated bytes | Min actual iteration ms |
| --- | --- | ---: | ---: | ---: | ---: |
| OfficeIMOModelAndSave | Format=Xlsb&RowCount=50000 | 857.790758 | 48.627475 | 461083288 | 3150.5196 |
| ExcelReaderWriter | Format=Xlsb&RowCount=50000 | 8.828459 | 0.304274 | 4218488 | 957.4664 |

## RecordWriterBenchmarks

50K prepared attributed records, XLSX/XLSB plus header, new4MiB destination and complete finalization. Peer WriteRecordsAsync with attribute layout versus OfficeIMO normal XLSX row callback/XLSB model+Save. No automatic OfficeIMO attributed-record writer is implied. Full output values/styles/metadata and independent readability proved outside timing.

| Method | Complete parameters | Mean ms | SD ms | Allocated bytes | Min actual iteration ms |
| --- | --- | ---: | ---: | ---: | ---: |
| OfficeIMOPublicTypedWrite | Format=Xlsx&RowCount=50000 | 22.134299 | 0.341805 | 4237347 | 979.7907 |
| ExcelReaderWriteRecords | Format=Xlsx&RowCount=50000 | 12.838290 | 0.297999 | 4217024 | 961.4956 |
| OfficeIMOPublicTypedWrite | Format=Xlsb&RowCount=50000 | 869.725783 | 87.678743 | 461360400 | 2787.1670 |
| ExcelReaderWriteRecords | Format=Xlsb&RowCount=50000 | 6.732154 | 0.670666 | 4218696 | 815.7433 |

## SharedStringWriterBenchmarks

50K prepared records plus header, new4MiB MemoryStream and finalization. Both select SST. OfficeIMO ordinary coordinates and configured coordinate omission are separate methods; peer omits coordinates/dimension. Header references/dimension remain in Office compact output. Complete fields/order/date-style/SST/package proof outside timing; ordinary and compact results stay separate.

| Method | Complete parameters | Mean ms | SD ms | Allocated bytes | Min actual iteration ms |
| --- | --- | ---: | ---: | ---: | ---: |
| OfficeIMOSharedStrings | RowCount=50000 | 18.567501 | 0.485641 | 4239683 | 1078.5415 |
| OfficeIMOSharedStringsWithoutReferences | RowCount=50000 | 9.125979 | 0.455925 | 4239513 | 926.7414 |
| ExcelReaderWriterSharedStrings | RowCount=50000 | 10.129952 | 0.384047 | 4257674 | 273.9237 |

## StyledRowWriterBenchmarks

100K numeric rows0..99999, no header, same retained32MiB destination/reset/finalization. Public true bold row defaults and authored bold values qualified through actual row/cell/style references, every value and earlier independent Excel evidence. OfficeIMO authored resolved cell XFs/coordinates and peer row defaults/no coordinates differ structurally but produce qualified bold values. Style pipeline cost remains visible.

| Method | Complete parameters | Mean ms | SD ms | Allocated bytes | Min actual iteration ms |
| --- | --- | ---: | ---: | ---: | ---: |
| OfficeIMODefaultRowStyle |  | 11.407035 | 0.517935 | 2624416 | 921.5873 |
| ExcelReaderOriginalStyledRows |  | 6.227280 | 0.520919 | 18632 | 336.4528 |

## Utf8WriterBenchmarks

100K four prepared unmanaged UTF8 value buffers/offsets, no header, retained32MiB destination/reset/finalization. Both public UTF8 APIs consume exact inputs; OfficeIMO normal WriteRows callback/enumeration is included. No private native WriteApi adapter. Every field/UTF8 value/escaping proof and produced package parts are checked outside timing.

| Method | Complete parameters | Mean ms | SD ms | Allocated bytes | Min actual iteration ms |
| --- | --- | ---: | ---: | ---: | ---: |
| OfficeIMOUtf8 |  | 35.346782 | 2.353232 | 42963 | 890.9063 |
| ExcelReaderPublicUtf8 |  | 16.245603 | 0.699992 | 18448 | 967.3476 |

## Native warnings and hints

Native class/method/full parameters/job tables remain authoritative. Diagnostic prose omitting parameters retains ambiguity. Statistics, intervals, outlier arrays, Actuals, Results and allocations are preserved; all normalized sample values/statistics/allocations match native.

~~~text
// * Hints *
Outliers
  NativeWriterBenchmarks.ExcelReaderWriter: OutlierMode=DontRemove, Affinity=00000000000000001111111111111111, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=12, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=8 -> 2 outliers were detected (8.11 ms, 9.35 ms)
// * Hints *
Outliers
  RecordWriterBenchmarks.OfficeIMOPublicTypedWrite: OutlierMode=DontRemove, Affinity=00000000000000001111111111111111, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=12, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=8 -> 1 outlier  was  detected (22.91 ms)
  RecordWriterBenchmarks.ExcelReaderWriteRecords: OutlierMode=DontRemove, Affinity=00000000000000001111111111111111, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=12, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=8   -> 2 outliers were detected (12.33 ms, 13.61 ms)
// * Hints *
Outliers
  SharedStringWriterBenchmarks.OfficeIMOSharedStrings: OutlierMode=DontRemove, Affinity=00000000000000001111111111111111, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=12, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=8 -> 3 outliers were detected (17.68 ms, 19.36 ms, 19.40 ms)
// * Hints *
Outliers
  StyledRowWriterBenchmarks.ExcelReaderOriginalStyledRows: OutlierMode=DontRemove, Affinity=00000000000000001111111111111111, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=12, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=8 -> 2 outliers were detected (5.18 ms, 5.35 ms)
~~~

This qualified group adds 26 primary cases: 244 primary + 78 supplementary = 322 sealed of 730 planned, 408 current cases pending. Historical 36df 106 remains outside both categories. No domain1/global ranking claim and no excluded valid slower result.

Native originals unchanged; no source edits, builds, tests, timing, fixture copies, archives, cleanup, incomplete-group inspection or publication.