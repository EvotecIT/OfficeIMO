# Sealed large CSV DOP 4: domain 0, frozen 830951

21 successful cases across 2 native tables/3 full-scale inputs; 168 measured samples. Source/runtime=83095146282a96143b23a79a7ecca058a24a709b; benchmark source unchanged from e676775a59458d1095606386c39506ceb8a9bc33. Started 2026-10-08T17:58:33.0186425+00:00,finished 2026-10-08T18:22:10.5703073+00:00,context ended 2026-10-08T18:22:10.6602177Z.

Huge CSV recipe: 1 launch/4 warmups/8 measurements/250 ms automatic Pilot/unroll 1/DontRemove;High priority/0xFFFF,DOP 4. Actual duration421.4114–12211.2615ms,all >= 100 ms. 0 short/0 distribution rows; 4 outlier hints/5 native outlier values.

- DOP 4 automatic class mapping retains valid throughput/allocation losses. On 4.3M conversion-heavy input OfficeIMO CoreParallel 1256.495ms/1,920,274,754B versus peer Parallel 325.836ms/713,241,318B; the decoded-text factory is 562.469ms/1,537,859,510B. These are distinct strategies with identical qualified class fields/order.
- 8M narrow class mapping: OfficeIMO CoreParallel 1951.675ms/1,950,392,250B and text factory 570.764ms/1,097,690,672B versus peer Parallel 223.157ms/267,190,958B. Preserve these valid losses; DOP1 results remain separate.
- 8M narrow direct reduction: OfficeIMO AsyncPath 2521.225ms/2,273,364,216B and AsyncStream 2634.036ms/2,273,374,356B versus peer native aggregate 117.027ms/1,557,756B. Full asynchronous IO/decode/decoded-field snapshot costs are included; cumulative allocation is not peak/retained memory.
- TextOwned reduction includes whole-file read/UTF8 decode inside timing; async owner reduces decoded snapshots incrementally; peer reduces UTF8 ref/struct fields. Do not describe their parsing/materialization work as identical or invent a missing pure native zero-copy scenario.
- All 3 original full inputs, 21 successful children/168 matched samples retain exact source/harness/runner/reference identities and High/FFFF. FullName carries untruncated Input/Dop; abbreviated native Parameters stay unchanged beside resolved parameters.
- Only requested sealed DOP 4/domain 0 inspected. No domain 1 or global ranking. All warnings/outliers and slower results are retained.
- The 12 asyncReads>0/syncReads0 records are untimed Setup public OfficeIMO Stream probes, one per direct-aggregate child; they do not characterize peer/TextOwned timed operations or collect counters for each measured invocation.

- Within the same automatic Core class workflow, DOP4 has a higher mean and cumulative allocation than the earlier separate domain0/DOP1 capture: 4.3M1256.495ms/1,920,274,754B versus762.765ms/1,352,941,166B;3M871.284ms/1,339,748,386B versus531.598ms/943,867,768B;8M1951.675ms/1,950,392,250B versus728.148ms/1,214,821,720B. Retain this within-shape scaling weakness; separate sequential captures do not establish causal CPU effects or a universal parallel-speed claim.

## Input identity and full result qualification

| Full input | Rows | Fields | Child occurrences | Bytes | Expected count/sum | SHA256 |
| --- | ---: | ---: | ---: | ---: | ---: | --- |
| ConversionHeavy-4300000 | 4300000 | 6 | 7 | 207563853 | 4300000/1077150000 | 86B1EE25363929A54CEA19CDA95BD63BC5F08B053B3DF7FBC83E76A0AA2634EF |
| ConversionHeavy3M-3000000 | 3000000 | 6 | 7 | 144811299 | 3000000/751500000 | FB01381C6257B7E716EF069DD14CCC19F1128DDDD3584A3409D5BA05BB240F63 |
| NarrowInt-8000000 | 8000000 | 3 | 7 | 209597884 | 8000000/31999996000000 | 23CC15B690540E2D15F6BDA51184E5B4D20EB3219447B860497CE02052EC0680 |

Each input is generated/fingerprinted before timing. Every method opens/reads the complete file inside timing. Text factory and text-owned reduction perform File.ReadAllText/UTF8 decode inside each invocation; async reductions use actual path/Stream ReadAsync and decoded-field snapshots. Twelve untimed Setup probes of the actual public OfficeIMO Stream aggregate show asynchronous reads>0/synchronous reads0, one per direct-aggregate child. The probes do not describe the peer/TextOwned timed operations and do not collect counters per measured invocation. Typed mapping consumes materialized classes; direct reduction consumes all fields into independent sum/count states without mapped result arrays. Setup validates every typed field/source order or every direct field and exact repeating-row multiplicity; checksum alone is not the integrity proof.

Native FullName preserves full Input/Dop identity; abbreviated native Parameters remain unchanged alongside the resolved input. Original4.3M/8M/3M shapes and DOP 4 are not pooled with smaller inputs, DOP1 or other data contracts. Old caller-reduction diagnostics are not selected in this21-case group. No output workbook or serialized mapped-record file is part of these contracts.

## CsvDirectAggregateBenchmarks

Three original full files,DOP 4. Peer CsvParallel.AggregateAsync uses UTF8 ref/struct fields and independent native states; OfficeIMO public AggregateTextRowsAsParallel reads/decodes whole file inside timing, public AggregateRowsAsParallelAsync path/stream reads incrementally with decoded UTF16 field snapshots. All6 heavy fields/all3 narrow integers consumed; states sum Units/A and count rows without mapped result arrays. Every consumed field and repeating-row multiplicity is proved in Setup. UTF8 versus decoded text/materialization pipeline remains explicit; bounded retained state is not low cumulative allocation.

| Method | Resolved full input / DOP | Mean ms | SD ms | Allocated bytes | Min actual iteration ms |
| --- | --- | ---: | ---: | ---: | ---: |
| ExcelReaderAggregate | ConversionHeavy-4300000 / 4 | 214.135172 | 4.678511 | 1521414 | 829.1117 |
| OfficeIMOTextOwnedAggregate | ConversionHeavy-4300000 / 4 | 622.782163 | 46.262102 | 832881376 | 2238.3364 |
| OfficeIMOAsyncPathAggregate | ConversionHeavy-4300000 / 4 | 2501.232619 | 330.638335 | 1955478974 | 8023.1432 |
| OfficeIMOAsyncStreamAggregate | ConversionHeavy-4300000 / 4 | 2662.850394 | 261.615020 | 1955468396 | 9059.7065 |
| ExcelReaderAggregate | ConversionHeavy3M-3000000 / 4 | 137.864284 | 9.880138 | 1133128 | 509.7205 |
| OfficeIMOTextOwnedAggregate | ConversionHeavy3M-3000000 / 4 | 351.114753 | 15.470720 | 582020656 | 1295.3321 |
| OfficeIMOAsyncPathAggregate | ConversionHeavy3M-3000000 / 4 | 1606.172184 | 358.282050 | 1364298130 | 5069.6894 |
| OfficeIMOAsyncStreamAggregate | ConversionHeavy3M-3000000 / 4 | 1626.694209 | 126.897861 | 1364299718 | 6023.5706 |
| ExcelReaderAggregate | NarrowInt-8000000 / 4 | 117.026997 | 8.241936 | 1557756 | 421.4114 |
| OfficeIMOTextOwnedAggregate | NarrowInt-8000000 / 4 | 608.608884 | 24.944381 | 841142644 | 2293.2618 |
| OfficeIMOAsyncPathAggregate | NarrowInt-8000000 / 4 | 2521.224875 | 337.911841 | 2273364216 | 8424.9587 |
| OfficeIMOAsyncStreamAggregate | NarrowInt-8000000 / 4 | 2634.036475 | 226.144975 | 2273374356 | 8875.9888 |

## CsvParallelTypedBenchmarks

Same4.3M/8M/3M full files,DOP 4. Same materialized heavy6-field/narrow3-integer classes across automatic peer CsvParallel/attribute sequential parser, OfficeIMO Core.RowsAsParallel, public decoded-text factory ReadTextRowsAsParallel, Sylvan GetRecords sequential. Text factory includes File.ReadAllText/UTF8 decode in each timed call. Each engine Setup checks every mapped field/source order/count before timing; result rows are consumed into same Units/A checksum. Parallel and sequential pipelines remain distinct.

| Method | Resolved full input / DOP | Mean ms | SD ms | Allocated bytes | Min actual iteration ms |
| --- | --- | ---: | ---: | ---: | ---: |
| ExcelReaderParallel | ConversionHeavy-4300000 / 4 | 325.836031 | 18.213207 | 713241318 | 1191.1871 |
| OfficeIMOCoreParallel | ConversionHeavy-4300000 / 4 | 1256.494553 | 118.402529 | 1920274754 | 4405.7691 |
| OfficeIMOTextParallel | ConversionHeavy-4300000 / 4 | 562.468806 | 65.934525 | 1537859510 | 1895.1048 |
| ExcelReaderParallel | ConversionHeavy3M-3000000 / 4 | 240.231753 | 15.051926 | 497787094 | 878.9806 |
| OfficeIMOCoreParallel | ConversionHeavy3M-3000000 / 4 | 871.284016 | 75.411376 | 1339748386 | 3202.4086 |
| OfficeIMOTextParallel | ConversionHeavy3M-3000000 / 4 | 437.377050 | 22.736573 | 1072116748 | 1630.4544 |
| ExcelReaderParallel | NarrowInt-8000000 / 4 | 223.156978 | 4.233855 | 267190958 | 871.8466 |
| OfficeIMOCoreParallel | NarrowInt-8000000 / 4 | 1951.674928 | 114.074215 | 1950392250 | 7207.6506 |
| OfficeIMOTextParallel | NarrowInt-8000000 / 4 | 570.764328 | 26.086120 | 1097690672 | 2106.7979 |

## Runtime and host boundary

Outer harness5E79575325D94AE8D09B97CD0C1C341EBB6AC0A24C3EEE6AE4817A897F97E7A4;runnerC52377235F70A38C61333009FFA2CC97C0BE2B3C102041CB127587B09AB32A95;generated-project saved-reference hookCEDF3A831603914A5E024C980CCA65AAAAF25544D98538BC416E963DD8632B12. All 84 loaded-owner identities match frozen quartet. Failure/Dry stays separate; repair does not change product/outer harness.

Boundary snapshots:51/95 entries,47 persistent/48 new IDs,max persistent CPU delta1.656250s,sum9.937500s. No command roles/per-case timeline; no isolation or causal contamination established. No live audit.

## Native warnings and hints

Native type/method/full input/DOP/job tables remain authoritative. Warning prose omitting parameters retains ambiguity; all per-case intervals/outlier arrays/Actuals/Results/allocations remain in JSON. Retain every native warning and valid slower result.

~~~text
// * Hints *
Outliers
  CsvDirectAggregateBenchmarks.ExcelReaderAggregate: OutlierMode=DontRemove, Affinity=00000000000000001111111111111111, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=8, IterationTime=250ms, LaunchCount=1, UnrollFactor=1, WarmupCount=4        -> 1 outlier  was  detected (158.13 ms)
  CsvDirectAggregateBenchmarks.OfficeIMOAsyncPathAggregate: OutlierMode=DontRemove, Affinity=00000000000000001111111111111111, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=8, IterationTime=250ms, LaunchCount=1, UnrollFactor=1, WarmupCount=4 -> 1 outlier  was  detected (2.36 s)
// * Hints *
Outliers
  CsvParallelTypedBenchmarks.ExcelReaderParallel: OutlierMode=DontRemove, Affinity=00000000000000001111111111111111, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=8, IterationTime=250ms, LaunchCount=1, UnrollFactor=1, WarmupCount=4   -> 1 outlier  was  detected (231.68 ms)
  CsvParallelTypedBenchmarks.OfficeIMOTextParallel: OutlierMode=DontRemove, Affinity=00000000000000001111111111111111, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=8, IterationTime=250ms, LaunchCount=1, UnrollFactor=1, WarmupCount=4 -> 2 outliers were detected (526.70 ms, 534.42 ms)
~~~

This qualifies21 additional primary cases; shared counters wait for Arrow and separately assigned encryption/cold packet reconciliation. Historical106 remains separate. No domain1/global winner claim. Native originals unchanged; no source/build/test/timer/package/profile/fixturecopy/archive/cleanup/publication.