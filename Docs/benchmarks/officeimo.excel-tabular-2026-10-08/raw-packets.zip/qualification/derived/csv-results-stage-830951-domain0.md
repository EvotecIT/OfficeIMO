# Sealed CSV stage: domain 0, frozen 830951

37 successful cases across 11 native tables; 555 measured samples. Source/runtime=83095146282a96143b23a79a7ecca058a24a709b; benchmark source unchanged from e676775a59458d1095606386c39506ceb8a9bc33. Started 2026-10-08T17:02:32.9950324+00:00, finished 2026-10-08T17:25:09.3771494+00:00, context ended 2026-10-08T17:25:09.5965030Z.

Recipe: 1 launch/12 warmups/15 measurements/1000 ms automatic Pilot/unroll 1/DontRemove, High/0xFFFF. Actual duration 661.4125–1767.6399 ms, all >= 100 ms. Warnings: 0 short/7 distribution; 13 outlier hint rows/18 native outlier values.

- All 37 cases/555 measured samples succeeded, all Actual iterations above 100 ms. Native distribution warnings/outliers retained; no domain 1 or universal speed claim.
- Raw borrowed UTF8, materialized Name, full string materialization, automatic typed class mapping and async opening/enumeration remain separate native groups. OfficeIMO borrows exact normalized UTF8 from its native source buffers; conversion/text-parser fallbacks are unavailable. Whole parser/opening pipelines remain distinct.
- Ordinary CSV output has valid formatting/length differences: peer and OfficeIMO 2,369,010B versus Sylvan 1,919,009B. Every logical header/name/ID/date/value/order checked independently; not an identical-byte/format cost contract.
- Public UTF8 CSV writers consume the same 100Kx4 unmanaged buffers and produce identical 6,900,000B SHA3A1E723702CF4E920BDC3F1D2EF1E8D173BE13A4FA7F9095B504F3504C86C20F; all bytes/fields plus escaping/Unicode/null/empty/formula cases proved outside timing.
- Pinned real CSV includes the header in 65,536x14 rows. Every field/type/order/span/UTF8 byte checked against independent Sylvan oracle; memory-vs-stream and UTF8-vs-UTF16 borrowed representation costs disclosed.
- Generated/pinned input SHA retained; ordinary/record writer inputs are prepared object lists with source semantic proof, not serialized input blobs. Ordinary/record Setup outputs log lengths/full field proof without output SHA; individual timed outputs not retained.
- V1 compiler failure/136-case eligibility remain unranked. V2 uses the verified hook with identical product/outer harness binaries. Only sealed CSV domain 0 inspected; no later/large/domain 1 result or live process audit.



- Scoped domain 0 materialized-wide result: OfficeIMO 12.973ms/52,807,564B, peer 25.899ms/52,802,406B, Sylvan 15.417ms/52,846,584B. Raw/MaterializeStrings=False has different allocations/strategies and is not pooled with this result. Full parameter identity is retained even where normalized RowCount contains the composite parameter text.
- Scoped pinned materialized result: OfficeIMO 20.183ms/35,876,551B versus peer 30.621ms/37,445,794B and Sylvan 16.158ms/37,483,994B. Borrowed stream result is OfficeIMO 6.415ms versus peer 11.049ms and Sylvan 10.612ms; representation/opening strategy remains explicit. No global win.
- Retain typed/writer losses: OfficeIMO typed 8.014ms/11,449,760B versus peer 3.800ms/4,051,779B and Sylvan 11.577ms/11,486,693B; ordinary writer 14.167ms versus peer 4.057ms/Sylvan 6.674ms with valid formatting differences. Byte-identical publicUTF8 writer OfficeIMO 8.442ms/6,134B versus peer 3.407ms/416B. Distribution/outlier evidence limits small-margin claims.

## Runtime and host boundary

Outer harness 5E79575325D94AE8D09B97CD0C1C341EBB6AC0A24C3EEE6AE4817A897F97E7A4; runner C52377235F70A38C61333009FFA2CC97C0BE2B3C102041CB127587B09AB32A95; generated-project saved-reference hook CEDF3A831603914A5E024C980CCA65AAAAF25544D98538BC416E963DD8632B12. All 148 loaded-owner identities match frozen quartet. Failure/Dry stays separate; repair does not change product/outer harness.

Host boundary: 86/111 entries, 45 persistent/66 new IDs, max CPU delta 3.093750 s, sum 8.750000 s. No command roles/per-case timeline; neither isolation nor causal contamination is established. No live audit.

## Input and output qualification

All 51 logged input/output byte records are retained per child; input identities match across paired children. Actual headerless 2,318,990B/headered 2,319,009B/wide 9,200,000B/pinned real 8,170,842B inputs are fingerprinted. Prepared object-list writer input is source-defined; writer-record CSV identity is a representative serialization. Ordinary/record output full values/lengths validated without output SHA. Public UTF8 output exactly 6,900,000B/CRLF/headerless has identical SHA and full byte/field proof. Timed outputs are not retained or hashed.

| Input identity | Child occurrences | Bytes | SHA256 |
| --- | ---: | ---: | --- |
| 32-column wide, materializeStrings=False | 3 | 9200000 | 78519F47209E388EE2782F76BAA118209542466D40301CF6B8E4F52B0ABB4ABB |
| 32-column wide, materializeStrings=True | 3 | 9200000 | 78519F47209E388EE2782F76BAA118209542466D40301CF6B8E4F52B0ABB4ABB |
| Pinned65KReal | 7 | 8170842 | AC959F43CF1077B71D310E6E49E3C168BA63A448F1855D45F44E734273EBA490 |
| raw async materialized name | 3 | 2318990 | D81A95FEC39988C63EEAAC841D0AC12CA8EC6677F9FED37D82B785897073B8FC |
| raw materialized name | 3 | 2318990 | D81A95FEC39988C63EEAAC841D0AC12CA8EC6677F9FED37D82B785897073B8FC |
| raw original headerless | 3 | 2318990 | D81A95FEC39988C63EEAAC841D0AC12CA8EC6677F9FED37D82B785897073B8FC |
| typed async headered | 3 | 2319009 | D69CFDC7ED2851B919C6EE847116338FC5F1FB8654F5439332E11062E8DB0E1E |
| typed headered | 3 | 2319009 | D69CFDC7ED2851B919C6EE847116338FC5F1FB8654F5439332E11062E8DB0E1E |
| write/Utf8/Csv/rows=100000/column=0/offsets | 2 | 400004 | 51C283816A6D2B3A47B94156554CFA9A96C308EA2689B14D4DCB4E4C9881F098 |
| write/Utf8/Csv/rows=100000/column=0/values | 2 | 1600000 | B876FFF81A04B978AABCB078941AD90C55A1247810968C47FB8137E36B9D46D2 |
| write/Utf8/Csv/rows=100000/column=1/offsets | 2 | 400004 | 51C283816A6D2B3A47B94156554CFA9A96C308EA2689B14D4DCB4E4C9881F098 |
| write/Utf8/Csv/rows=100000/column=1/values | 2 | 1600000 | 8DFFF8BEEBF466AED0144CF5BC76052AF8177E511F8171A23F9396F4DFA36A40 |
| write/Utf8/Csv/rows=100000/column=2/offsets | 2 | 400004 | 51C283816A6D2B3A47B94156554CFA9A96C308EA2689B14D4DCB4E4C9881F098 |
| write/Utf8/Csv/rows=100000/column=2/values | 2 | 1600000 | D762C2FD86A5E8DC07661DAB2CCADAB04E5074F96DFDA04D915E7B6E6169C4FD |
| write/Utf8/Csv/rows=100000/column=3/offsets | 2 | 400004 | 51C283816A6D2B3A47B94156554CFA9A96C308EA2689B14D4DCB4E4C9881F098 |
| write/Utf8/Csv/rows=100000/column=3/values | 2 | 1600000 | FC5F76E6049A5AF203BA74B582E04021459E0CFDED36E1CCD3497B3CCD1E6712 |
| writer records | 3 | 2319009 | D69CFDC7ED2851B919C6EE847116338FC5F1FB8654F5439332E11062E8DB0E1E |

## CsvMaterializedReadBenchmarks

50K headerless four fields. Every engine materializes Name and parses int/DateTime/double. OfficeIMO/Sylvan typed getters versus peer cell conversion; every field/order/count checked in Setup.

| Method | Full parameters | Mean ms | SD ms | Allocated bytes | Min actual iteration ms |
| --- | --- | ---: | ---: | ---: | ---: |
| ExcelReaderMaterialized | RowCount=50000 | 2.931878 | 0.204076 | 1650848 | 758.3636 |
| OfficeIMOMaterialized | RowCount=50000 | 6.412252 | 0.774607 | 9050627 | 762.7641 |
| SylvanMaterialized | RowCount=50000 | 3.154209 | 0.314552 | 1688688 | 801.6092 |

## CsvRawAsyncBenchmarks

50K headerless, materialized Name and three typed scalars. Timed memory-stream opening/async traversal/disposal. OfficeIMO/Sylvan async open versus peer synchronous FromCsv open then async enumeration. Actual methods validate each row in Setup; no disk/network async latency claim.

| Method | Full parameters | Mean ms | SD ms | Allocated bytes | Min actual iteration ms |
| --- | --- | ---: | ---: | ---: | ---: |
| ExcelReaderAsync | RowCount=50000 | 3.178769 | 0.557594 | 1651103 | 1000.9803 |
| OfficeIMOAsync | RowCount=50000 | 12.623518 | 1.896261 | 14872486 | 874.5437 |
| SylvanAsync | RowCount=50000 | 4.168068 | 0.702230 | 1699128 | 954.5027 |

## CsvRawReadBenchmarks

50K headerless original fields. Peer borrowed UTF8 Name/cell parsing, OfficeIMO normalized borrowed UTF8 all fields/scalar parsing, Sylvan borrowed UTF16 Name/native typed getters. Public provider borrows exact normalized UTF8 already held by native stream source; conversion/text-parser fallbacks unavailable. Whole parser/opening pipelines remain distinct. ASCII byte/char lengths coincide. Every ordinary scalar/text value validated, borrowed methods count/checksum checked.

| Method | Full parameters | Mean ms | SD ms | Allocated bytes | Min actual iteration ms |
| --- | --- | ---: | ---: | ---: | ---: |
| ExcelReaderOriginal | RowCount=50000 | 2.128650 | 0.317020 | 997 | 967.3957 |
| OfficeIMOBorrowedUtf8 | RowCount=50000 | 6.640970 | 0.349861 | 3849 | 930.3610 |
| SylvanOriginal | RowCount=50000 | 4.114940 | 0.350998 | 38681 | 796.9695 |

## CsvRealDataMaterializedReadBenchmarks

Pinned real CSV65,536 rows including header/14 string fields. All engines materialize every field. Every field/type/order/span/UTF8 byte checked against independent Sylvan oracle; opening pipelines differ.

| Method | Full parameters | Mean ms | SD ms | Allocated bytes | Min actual iteration ms |
| --- | --- | ---: | ---: | ---: | ---: |
| ExcelReaderMaterialized |  | 30.621438 | 1.593214 | 37445794 | 923.5399 |
| OfficeIMOMaterialized |  | 20.183163 | 2.078183 | 35876551 | 829.3596 |
| SylvanMaterialized |  | 16.157857 | 0.411573 | 37483994 | 957.8219 |

## CsvRealDataReadBenchmarks

Same pinned real14-column input/header included. Peer ReadOnlyMemory or stream borrowed UTF8; OfficeIMO stream normalized borrowed UTF8; Sylvan StreamReader borrowed UTF16 spans. Every field/type/order/span checked; ASCII7,253,335 byte/character sums coincide. Representation/opening costs remain distinct.

| Method | Full parameters | Mean ms | SD ms | Allocated bytes | Min actual iteration ms |
| --- | --- | ---: | ---: | ---: | ---: |
| ExcelReaderStream |  | 11.049407 | 0.832273 | 1712 | 870.6823 |
| ExcelReaderMemory |  | 11.308608 | 0.836851 | 738 | 797.9849 |
| OfficeIMOStreamBorrowedUtf8 |  | 6.414902 | 0.445053 | 2920 | 938.0036 |
| SylvanFieldSpan |  | 10.612265 | 0.263668 | 41226 | 1037.9017 |

## CsvRecordWriterBenchmarks

50K prepared objects+header,new4MiB destination/finalization. Mapped=false/true: peer attribute/generated WriteRecordsAsync versus OfficeIMO WriteObjects ordinary object mapping. Invariant O dates for OfficeIMO; every header/value/type/date/order checked by OfficeIMO/Sylvan. Automatic writer strategies and async/sync contract disclosed.

| Method | Full parameters | Mean ms | SD ms | Allocated bytes | Min actual iteration ms |
| --- | --- | ---: | ---: | ---: | ---: |
| ExcelReaderRecordLayout | Mapped=False&RowCount=50000 | 5.097549 | 0.278353 | 4197566 | 867.1462 |
| OfficeIMOWriteObjects | Mapped=False&RowCount=50000 | 12.566803 | 1.170256 | 11802535 | 1010.4823 |
| ExcelReaderRecordLayout | Mapped=True&RowCount=50000 | 5.410688 | 0.292554 | 4197517 | 849.0304 |
| OfficeIMOWriteObjects | Mapped=True&RowCount=50000 | 12.820091 | 0.698819 | 11802533 | 863.1783 |

## CsvTypedAsyncBenchmarks

50K headered identical TypedRecord class. OfficeIMO RowsAsAsync/async opener, peer attribute parser async enumeration/sync FromCsv opener, Sylvan GetRecordsAsync/async opener. Setup validates every field through actual methods; memory stream does not measure external async IO latency.

| Method | Full parameters | Mean ms | SD ms | Allocated bytes | Min actual iteration ms |
| --- | --- | ---: | ---: | ---: | ---: |
| ExcelReaderTypedAsync | RowCount=50000 | 5.522784 | 0.150337 | 4051472 | 1505.5202 |
| OfficeIMORowsAsAsync | RowCount=50000 | 13.342001 | 0.626115 | 17272936 | 726.5128 |
| SylvanTypedAsync | RowCount=50000 | 10.099359 | 2.269749 | 11497088 | 990.1692 |

## CsvTypedReadBenchmarks

50K headered complete Name/Id/Date/Value class. Automatic OfficeIMO RowsAs, peer attribute parser, Sylvan GetRecords. Every mapped field/order/count validated in Setup; distinct from raw/manual construction.

| Method | Full parameters | Mean ms | SD ms | Allocated bytes | Min actual iteration ms |
| --- | --- | ---: | ---: | ---: | ---: |
| ExcelReaderTyped | RowCount=50000 | 3.799762 | 0.798101 | 4051779 | 728.0320 |
| OfficeIMORowsAs | RowCount=50000 | 8.014368 | 0.614347 | 11449760 | 842.0334 |
| SylvanTyped | RowCount=50000 | 11.576903 | 0.857342 | 11486693 | 884.8195 |

## CsvUtf8WriterBenchmarks

100Kx4 unmanaged offsets/value buffers,no header,reused32MiB destination/reset/finalization. Public CsvRowWriter.WriteUtf8Row versus peer row.WriteUtf8. Same CRLF6,900,000B output/all bytes and fields checked, plus escaping/Unicode/null/empty/formula proof. No private NativeWriteApi adapter.

| Method | Full parameters | Mean ms | SD ms | Allocated bytes | Min actual iteration ms |
| --- | --- | ---: | ---: | ---: | ---: |
| OfficeIMOPublicUtf8Row |  | 8.442231 | 1.261077 | 6134 | 661.4125 |
| ExcelReaderPublicUtf8 |  | 3.406654 | 0.473524 | 416 | 999.8628 |

## CsvWideReadBenchmarks

50Kx32 ASCII fields/headerless. MaterializeStrings=false: peer borrowed UTF8, OfficeIMO normalized borrowed UTF8, Sylvan UTF16 spans; true materializes every field. Every1.6M-field value/order/width/count checked. ASCII length equivalence does not remove representation/parser allocation differences.

| Method | Full parameters | Mean ms | SD ms | Allocated bytes | Min actual iteration ms |
| --- | --- | ---: | ---: | ---: | ---: |
| ExcelReaderWide | RowCount=50000&MaterializeStrings=False | 6.071381 | 1.499885 | 1243 | 984.4814 |
| OfficeIMOWide | RowCount=50000&MaterializeStrings=False | 6.348169 | 0.926616 | 4360 | 937.9675 |
| SylvanWide | RowCount=50000&MaterializeStrings=False | 4.364473 | 0.415429 | 46377 | 969.6313 |
| ExcelReaderWide | RowCount=50000&MaterializeStrings=True | 25.899157 | 3.747403 | 52802406 | 1005.4314 |
| OfficeIMOWide | RowCount=50000&MaterializeStrings=True | 12.973471 | 1.177180 | 52807564 | 969.1967 |
| SylvanWide | RowCount=50000&MaterializeStrings=True | 15.416722 | 1.232105 | 52846584 | 1196.8822 |

## CsvWriterBenchmarks

50K prepared typed objects+header,new4MiB destination/full finalization. Peer row writer, OfficeIMO WriteObjects invariant O dates/default newline, Sylvan ObjectDataReader/CsvDataWriter default format. Every logical field/type/date/order checked independently. Valid formatting/output-length differences prohibit an identical-byte/format cost claim.

| Method | Full parameters | Mean ms | SD ms | Allocated bytes | Min actual iteration ms |
| --- | --- | ---: | ---: | ---: | ---: |
| ExcelReaderWriter | RowCount=50000 | 4.056575 | 0.315013 | 4198070 | 882.5931 |
| OfficeIMOWriteObjects | RowCount=50000 | 14.167028 | 0.878640 | 11802673 | 949.8028 |
| SylvanWriter | RowCount=50000 | 6.673600 | 0.830823 | 4234777 | 715.4673 |

## Native warnings and hints

Native class/method/full parameters/job tables remain authoritative. Warning prose omitting parameters retains ambiguity. All statistics, intervals, outlier arrays, Actual/Result samples and allocations retained; normalized values/statistics/allocations match native.

~~~text
// * Warnings *
MultimodalDistribution
  CsvMaterializedReadBenchmarks.OfficeIMOMaterialized: OutlierMode=DontRemove, Affinity=00000000000000001111111111111111, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12 -> It seems that the distribution can have several modes (mValue = 3.14)
// * Hints *
Outliers
  CsvMaterializedReadBenchmarks.OfficeIMOMaterialized: OutlierMode=DontRemove, Affinity=00000000000000001111111111111111, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12 -> 2 outliers were detected (4.51 ms, 4.79 ms)
  CsvMaterializedReadBenchmarks.SylvanMaterialized: OutlierMode=DontRemove, Affinity=00000000000000001111111111111111, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12    -> 3 outliers were detected (3.36 ms..4.05 ms)
// * Warnings *
MultimodalDistribution
  CsvRawAsyncBenchmarks.ExcelReaderAsync: OutlierMode=DontRemove, Affinity=00000000000000001111111111111111, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12 -> It seems that the distribution can have several modes (mValue = 3)
// * Hints *
Outliers
  CsvRawReadBenchmarks.ExcelReaderOriginal: OutlierMode=DontRemove, Affinity=00000000000000001111111111111111, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12 -> 1 outlier  was  detected (2.79 ms)
  CsvRawReadBenchmarks.SylvanOriginal: OutlierMode=DontRemove, Affinity=00000000000000001111111111111111, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12      -> 1 outlier  was  detected (3.24 ms)
// * Hints *
Outliers
  CsvRealDataReadBenchmarks.OfficeIMOStreamBorrowedUtf8: OutlierMode=DontRemove, Affinity=00000000000000001111111111111111, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12 -> 1 outlier  was  detected (7.52 ms)
  CsvRealDataReadBenchmarks.SylvanFieldSpan: OutlierMode=DontRemove, Affinity=00000000000000001111111111111111, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12             -> 1 outlier  was  detected (11.43 ms)
// * Warnings *
MultimodalDistribution
  CsvRecordWriterBenchmarks.ExcelReaderRecordLayout: OutlierMode=DontRemove, Affinity=00000000000000001111111111111111, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12 -> It seems that the distribution can have several modes (mValue = 3.14)
// * Hints *
Outliers
  CsvRecordWriterBenchmarks.OfficeIMOWriteObjects: OutlierMode=DontRemove, Affinity=00000000000000001111111111111111, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12 -> 1 outlier  was  detected (14.43 ms)
// * Warnings *
MultimodalDistribution
  CsvTypedAsyncBenchmarks.OfficeIMORowsAsAsync: OutlierMode=DontRemove, Affinity=00000000000000001111111111111111, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12 -> It seems that the distribution is bimodal (mValue = 4)
  CsvTypedAsyncBenchmarks.SylvanTypedAsync: OutlierMode=DontRemove, Affinity=00000000000000001111111111111111, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12     -> It seems that the distribution can have several modes (mValue = 3)
// * Hints *
Outliers
  CsvTypedAsyncBenchmarks.OfficeIMORowsAsAsync: OutlierMode=DontRemove, Affinity=00000000000000001111111111111111, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12 -> 1 outlier  was  detected (15.08 ms)
// * Hints *
Outliers
  CsvTypedReadBenchmarks.ExcelReaderTyped: OutlierMode=DontRemove, Affinity=00000000000000001111111111111111, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12 -> 1 outlier  was  detected (5.75 ms)
  CsvTypedReadBenchmarks.SylvanTyped: OutlierMode=DontRemove, Affinity=00000000000000001111111111111111, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12      -> 1 outlier  was  detected (9.72 ms)
// * Hints *
Outliers
  CsvUtf8WriterBenchmarks.OfficeIMOPublicUtf8Row: OutlierMode=DontRemove, Affinity=00000000000000001111111111111111, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12 -> 1 outlier  was  detected (12.67 ms)
// * Warnings *
MultimodalDistribution
  CsvWideReadBenchmarks.SylvanWide: OutlierMode=DontRemove, Affinity=00000000000000001111111111111111, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12 -> It seems that the distribution can have several modes (mValue = 3.11)
// * Hints *
Outliers
  CsvWideReadBenchmarks.OfficeIMOWide: OutlierMode=DontRemove, Affinity=00000000000000001111111111111111, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12 -> 3 outliers were detected (6.97 ms..8.99 ms)
  CsvWideReadBenchmarks.OfficeIMOWide: OutlierMode=DontRemove, Affinity=00000000000000001111111111111111, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12 -> 1 outlier  was  detected (16.12 ms)
// * Warnings *
MultimodalDistribution
  CsvWriterBenchmarks.SylvanWriter: OutlierMode=DontRemove, Affinity=00000000000000001111111111111111, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12 -> It seems that the distribution is bimodal (mValue = 3.25)
~~~

This qualified group adds 37 primary cases: 281 primary + 78 supplementary = 359 sealed/730 planned; 371 current cases pending. Historical 106 outside both counts. No domain 1/global ranking; valid slower results retained.

Native originals unchanged; no source edit/build/test/timer/fixturecopy/archive/cleanup/incomplete-group inspection/publication.