# Qualified cold capture, domain1

Qualified 6 cases, 96 successful fresh children and 96 native actual samples. Every normalized summary/sample/statistic/allocation and native GC descriptor reconciles with native data. All nine native sidecar artifacts match SHA-256 and length. Frozen830951 owners, harness, v2 runner/reference hook and High/0xFFFF0000 match. Run qualified-830951-long-v2-domain1-cold. Capture identity derives from sealed context/sidecar, not importer IDs/timestamps.

Six target first-use cases: four read mapping strategies and two object-layout writer strategies on 200 records with Name/Id/Date/Value.

Sixteen fresh child processes per case; zero warmups, one actual iteration and one invocation per child. No Pilot, adaptive repetition or explicit Jitting stages occur in the native measurement list.

GlobalSetup and assembly description run before timing. Read setup creates the workbook using peer writer APIs and checks ZIP shape without target ColdStartRecord mapping. Write setup constructs source ColdStartRecord instances. Related APIs and constructors may be initialized or JIT compiled before timing.

Timed scope includes the first target mapping-plan/layout use and reachable JIT/code initialization still deferred after setup, plus complete workbook open/read or write/save/disposal. This is not process startup or first-ever usage of every library API.

Cold reads enforce the Id checksum; timed writers return length. Complete four-field read mapping and parsed writer output are validated in a separate frozen-harness process. No timed writer per-invocation output hash or full-field validation is invented.

Short individual cold operations and minimum-duration warnings are expected for this contract. Repeating work to force a >=100ms iteration would replace first use with warm throughput. Cold results are not ranked with warm cases.

Allocated bytes report the subsequent BenchmarkDotNet 0.15.8 MemoryDiagnoser diagnostic invocation (second use). The first target mapping/layout latency remains separate. The allocation boundary is source-derived from the prior pinned Engine.Run/GetExtraStats review, not a separately timed second-use operation or first-use initialization allocation measurement.

| Native class / method | Complete input | First target mean ms, after Setup | First target SD ms | Second-use MemoryDiagnoser diagnostic bytes/op |
|---|---|---:|---:|---:|
| ColdStartReadBenchmarks.ExcelReaderAttributes | 200 records × Name/Id/Date/Value; first target mapping use | 41.253931 | 8.752626 | 136216 |
| ColdStartReadBenchmarks.OfficeIMOAutomaticMapping | 200 records × Name/Id/Date/Value; first target mapping use | 104.121988 | 59.559748 | 115696 |
| ColdStartReadBenchmarks.ExcelReaderFluentMapping | 200 records × Name/Id/Date/Value; first target mapping use | 28.773619 | 4.022655 | 139312 |
| ColdStartReadBenchmarks.ExcelReaderAttributeFallback | 200 records × Name/Id/Date/Value; first target mapping use | 32.214894 | 1.778896 | 141400 |
| ColdStartWriteBenchmarks.ExcelReaderAutomaticLayout | 200 records × Name/Id/Date/Value; first target object-layout write | 36.871256 | 1.633752 | 98144 |
| ColdStartWriteBenchmarks.OfficeIMOAutomaticLayout | 200 records × Name/Id/Date/Value; first target object-layout write | 134.485562 | 9.313261 | 923600 |

Raw WorkloadActual range 23.7544–325.0031 ms. Native diagnostic rows: 5 minimum-duration warnings, 2 distribution warnings and 2 outlier hints; 3 native outlier values retained. DontRemove preserves all samples and per-case native arrays. Method-level hints can omit parameters; they are not assigned to specific input cases.

This is first TARGET mapping/layout use after GlobalSetup in 16 fresh processes per case, not first-ever library/API use or process startup. Related APIs, constructors and JIT can run in Setup. Native measurements contain no Pilot, warmup, adaptive repeated work or explicit Jitting stages; each launch has one actual invocation. Short operations and five minimum-duration warnings are part of the contract, and the warm 100 ms duration gate is inapplicable.

Allocated bytes are the subsequent MemoryDiagnoser extra-statistics invocation (SECOND USE), distinct from first-target latency. This boundary is source-derived from the earlier pinned BDN0.15.8 Engine.Run/GetExtraStats review. Native Memory/GC descriptors report one diagnostic operation; they do not measure initial mapping/layout allocation or a separately timed second-use latency.

Complete output proof comes from the earlier identical frozen-harness --validate-cold process, ended 2026-10-08T16:39:00.3089551Z. It checks every Name/Id/Date/Value and count for four read strategies and parsed/independently validated output for two writers. Timed cold reads enforce Id checksum; timed writers return length. No per-invocation output hash or complete field proof is invented for the timing children.

Domain0 comparison establishes matching owning-source/input/lifecycle contracts only; elapsed and allocation observations stay separate. Valid losses and variance are retained without cross-domain pooling, cache/isolation attribution or ranking cold latency with warm throughput.

Capture 2026-10-08T21:26:06.8549975+00:00 to 2026-10-08T21:27:00.6239217+00:00, elapsed 53.7689242 seconds, sealed 2026-10-08T21:27:00.7516928Z. Native total: Global total time: 00:00:50 (50.95 sec), executed benchmarks: 6

Host endpoints: 65/94 entries; 64 persistent matches; maximum observed CPU delta 46.578125 seconds, sum 63.796875 seconds. Pre/post snapshots do not identify process roles, CPU during individual cases, or activity of processes absent at either endpoint. They do not prove an idle host or establish causal contamination. Fresh benchmark children and generated builds occur within the capture; original snapshots are retained. No live host audit or later-group inspection.

Observed persistent endpoint entry: process 87244 named testhost accrued 46.578125 CPU seconds over this capture. Its role, placement and per-case activity are not established; no causal effect is assigned.

Source/runtime 83095146282a96143b23a79a7ecca058a24a709b; unchanged benchmark source e676775a59458d1095606386c39506ceb8a9bc33. Harness 5E79575325D94AE8D09B97CD0C1C341EBB6AC0A24C3EEE6AE4817A897F97E7A4; v2 resume runner C52377235F70A38C61333009FFA2CC97C0BE2B3C102041CB127587B09AB32A95; generated-project reference import CEDF3A831603914A5E024C980CCA65AAAAF25544D98538BC416E963DD8632B12. Saved owners remain unchanged; hook affects generated compile references only. All native artifacts, frozen output-proof/input refs and case measurements remain in JSON/manifest.

Only the assigned sealed encrypted/cold domain1 packets were derived. No source/build/test/package/timing run, fixture copy, archive, cleanup or shared report mutation. Native/import evidence remains in place; no current topology change or package qualification against830951.
