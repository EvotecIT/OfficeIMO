# Native XLSB attribution stage — 2026-10-08

The discovery change reduces measured OfficeIMO allocations in both CPU cache domains. Timing varies with domain and peer controls, so this packet supports an allocation improvement and does not establish a stable causal throughput win.

This is additional 16-case attribution evidence outside the primary 652-case report. All four contexts are sealed, each with four successful child processes and 15 retained measurements per case. The JSON retains native statistics, confidence intervals, samples, actual iteration operation counts/durations, exact warnings, complete input identities and original artifact hashes. Native grouped reports remain authoritative.

## Runtime and harness attribution

Capture source: 83095146282a96143b23a79a7ecca058a24a709b. Before runtime: e676775a59458d1095606386c39506ceb8a9bc33. Current runtime: 83095146282a96143b23a79a7ecca058a24a709b. Git confirms zero changed benchmark files between those sources; only the Excel discovery helper/calls and 14 regression cases differ. Whole-owner rebuilds have distinct version/hash identities, which must stay explicit.

| Runtime | Excel SHA256 | Core SHA256 | Harness SHA256 |
|---|---|---|---|
| before-e676 | 8158D5FDA5B840BD7B8FCD8F84B261F0C7E88C569E7F2927AE86EDE6FF5284E3 | 7CCC87462A55571045520EDF7A4680A5B4BBBC9DDD794016E3E888C2A7D0182F | 842D0A5B3007B2867DB4424F9CC6A1A3A2769C94D3B41BEE1289B4EE09034156 |
| current-830951 | F2853A4C62D5C03C5E3F0CBB7CCBB5776FB63CE58CE8933BE4EBAA4F5887502F | B5565DE58D83BFC91F4FFB69A797CE02DFCB10A5A6409323845D05A5732E1A84 | 5E79575325D94AE8D09B97CD0C1C341EBB6AC0A24C3EEE6AE4817A897F97E7A4 |

The intervention replaces three discovery string materializations with Unicode validation/advance using the ordinary fallback policy. Ordinary delivery is unchanged. Raw OfficeIMO still gets string/object values and boxes the three scalar fields. The raw peer uses borrowed UTF8 cells; its raw allocation figure is a control, not an equivalent-output allocation ranking.

Typed cases consume the same Name/Id/Date/Value record contract. OfficeIMO constructs records with public typed getters; ExcelReader uses its attribute parser. Complete field/type/order/count validation runs in GlobalSetup, and each timed method checks count/checksum. Preserve the different mapping strategies when discussing these numbers.

## Before/current results and peer controls

Means and SD are milliseconds; allocation is exact bytes per operation. Changes below are arithmetic across two separate contexts, not native paired ratios or a significance test.

| Domain | Method | Before mean ± SD | Current mean ± SD | Mean change | Allocated before → current | Allocation reduction |
|---|---|---:|---:|---:|---:|---:|
| 0 | RawReadBenchmarks.OfficeIMOOriginal | 11.158 ± 0.927 | 10.568 ± 1.331 | -5.29% | 7022510 → 5973009 | 14.94% |
| 0 | TypedXlsbReadBenchmarks.OfficeIMOTypedXlsb | 12.027 ± 1.611 | 8.934 ± 0.366 | -25.72% | 6757498 → 4400553 | 34.88% |
| 0 | RawReadBenchmarks.ExcelReaderOriginal | 4.749 ± 0.495 | 5.118 ± 0.137 | 7.77% | 4232 → 12292 | -190.45% |
| 0 | TypedXlsbReadBenchmarks.ExcelReaderTypedXlsb | 9.018 ± 0.540 | 6.239 ± 0.297 | -30.81% | 4122719 → 4122719 | 0.00% |
| 1 | RawReadBenchmarks.OfficeIMOOriginal | 12.040 ± 0.887 | 9.274 ± 0.636 | -22.98% | 7864142 → 6020060 | 23.45% |
| 1 | TypedXlsbReadBenchmarks.OfficeIMOTypedXlsb | 8.628 ± 0.947 | 8.874 ± 0.821 | 2.85% | 6425329 → 4820799 | 24.97% |
| 1 | RawReadBenchmarks.ExcelReaderOriginal | 4.772 ± 0.564 | 5.037 ± 0.619 | 5.56% | 12158 → 57070 | -369.40% |
| 1 | TypedXlsbReadBenchmarks.ExcelReaderTypedXlsb | 6.831 ± 0.733 | 6.199 ± 0.331 | -9.24% | 4122719 → 4122855 | -0.00% |

Domain 0 ran before→current; domain 1 current→before. The typed Office mean improves in domain 0 but moves slightly upward in domain 1; both peer typed controls improve. Retained variation and shorter iterations limit close throughput claims.

## Actual input identity

| Input | Instances | Package bytes | Distinct package SHA256 | Distinct inflated manifests | Worksheet SHA256 |
|---|---:|---:|---:|---:|---|
| read/raw/Xlsb/dataRows=50000 | 8 | 870431 | 8 | 1 | EFFBE6186E05BE1F4C65CAA7238DBF53B6896630DC30433D089E9844727DEF5C |
| read/typed/Xlsb/dataRows=50000 | 8 | 871166 | 8 | 1 | FCB404C49DE3ED1515C95C2055B4319E0FA10C6A3A072DF365FACFCECB4431DD |

Every child logs its actual bytes before timing: eight parts per input. Inflated part names, lengths and SHA256 are identical across before/current and both domains for each shape. The raw fixture has no header; the typed fixture has Name/Id/Date/Value headers. Packages are regenerated in each child and ZIP timestamps differ. The detailed JSON keeps each actual package hash and timestamp instead of assigning an unrelated retained archive hash.

## Measured iteration limits

All 240 measurements and all outliers are retained. Eight of 16 cases have an actual measured iteration below 100 ms; minimum 37.792 ms. Pilot 250 ms can size operations while initial code is slower, then measured execution accelerates after warmup. Native warnings are preserved below. Do not describe this attribution packet as uniformly stable.

| Domain | Runtime | Method | Actual operations/iteration | Minimum → maximum duration (ms) |
|---|---|---|---:|---:|
| 0 | before-e676 | RawReadBenchmarks.ExcelReaderOriginal | 10 | 40.676 → 53.476 |
| 0 | before-e676 | RawReadBenchmarks.OfficeIMOOriginal | 13 | 127.268 → 164.683 |
| 0 | before-e676 | TypedXlsbReadBenchmarks.ExcelReaderTypedXlsb | 7 | 57.259 → 71.380 |
| 0 | before-e676 | TypedXlsbReadBenchmarks.OfficeIMOTypedXlsb | 9 | 96.491 → 148.537 |
| 0 | current-830951 | RawReadBenchmarks.ExcelReaderOriginal | 59 | 293.149 → 323.328 |
| 0 | current-830951 | RawReadBenchmarks.OfficeIMOOriginal | 14 | 102.487 → 175.034 |
| 0 | current-830951 | TypedXlsbReadBenchmarks.ExcelReaderTypedXlsb | 7 | 40.681 → 47.831 |
| 0 | current-830951 | TypedXlsbReadBenchmarks.OfficeIMOTypedXlsb | 37 | 311.501 → 367.036 |
| 1 | current-830951 | RawReadBenchmarks.ExcelReaderOriginal | 9 | 37.792 → 56.427 |
| 1 | current-830951 | RawReadBenchmarks.OfficeIMOOriginal | 13 | 106.576 → 134.815 |
| 1 | current-830951 | TypedXlsbReadBenchmarks.ExcelReaderTypedXlsb | 7 | 41.177 → 49.090 |
| 1 | current-830951 | TypedXlsbReadBenchmarks.OfficeIMOTypedXlsb | 13 | 93.778 → 136.411 |
| 1 | before-e676 | RawReadBenchmarks.ExcelReaderOriginal | 60 | 255.706 → 366.152 |
| 1 | before-e676 | RawReadBenchmarks.OfficeIMOOriginal | 10 | 104.613 → 131.811 |
| 1 | before-e676 | TypedXlsbReadBenchmarks.ExcelReaderTypedXlsb | 7 | 42.902 → 59.131 |
| 1 | before-e676 | TypedXlsbReadBenchmarks.OfficeIMOTypedXlsb | 14 | 103.924 → 141.079 |

### qualified-830951-v1-domain0-native-attribution-before

- Finished: 10/08/2026 15:13:59. Expected/completed/successful children: 4/4/4. Capture clean: True.
- Native grouped table: [OfficeIMO.Excel.ReaderComparison.Benchmarks.RawReadBenchmarks-report-github.md](D:\Dev\Scratch\officeimo-excelreader-performance\final-runs\qualified-830951-v1-domain0-native-attribution-before\20261008-151332\OfficeIMO.Excel.ReaderComparison.Benchmarks.RawReadBenchmarks-report-github.md).
- Native grouped table: [OfficeIMO.Excel.ReaderComparison.Benchmarks.TypedXlsbReadBenchmarks-report-github.md](D:\Dev\Scratch\officeimo-excelreader-performance\final-runs\qualified-830951-v1-domain0-native-attribution-before\20261008-151332\OfficeIMO.Excel.ReaderComparison.Benchmarks.TypedXlsbReadBenchmarks-report-github.md).

> MultimodalDistribution
>   RawReadBenchmarks.ExcelReaderOriginal: OutlierMode=DontRemove, Affinity=00000000000000001111111111111111, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-e67677",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=250ms, LaunchCount=1, UnrollFactor=1, WarmupCount=12 -> It seems that the distribution is bimodal (mValue = 3.25)
>   RawReadBenchmarks.OfficeIMOOriginal: OutlierMode=DontRemove, Affinity=00000000000000001111111111111111, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-e67677",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=250ms, LaunchCount=1, UnrollFactor=1, WarmupCount=12   -> It seems that the distribution is bimodal (mValue = 3.67)
> MinIterationTime
>   RawReadBenchmarks.ExcelReaderOriginal: OutlierMode=DontRemove, Affinity=00000000000000001111111111111111, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-e67677",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=250ms, LaunchCount=1, UnrollFactor=1, WarmupCount=12 -> The minimum observed iteration time is 40.676ms which is very small. It's recommended to increase it to at least 100ms using more operations.
> MultimodalDistribution
>   TypedXlsbReadBenchmarks.ExcelReaderTypedXlsb: OutlierMode=DontRemove, Affinity=00000000000000001111111111111111, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-e67677",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=250ms, LaunchCount=1, UnrollFactor=1, WarmupCount=12 -> It seems that the distribution is bimodal (mValue = 3.25)
> MinIterationTime
>   TypedXlsbReadBenchmarks.ExcelReaderTypedXlsb: OutlierMode=DontRemove, Affinity=00000000000000001111111111111111, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-e67677",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=250ms, LaunchCount=1, UnrollFactor=1, WarmupCount=12 -> The minimum observed iteration time is 57.259ms which is very small. It's recommended to increase it to at least 100ms using more operations.
>   TypedXlsbReadBenchmarks.OfficeIMOTypedXlsb: OutlierMode=DontRemove, Affinity=00000000000000001111111111111111, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-e67677",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=250ms, LaunchCount=1, UnrollFactor=1, WarmupCount=12   -> The minimum observed iteration time is 96.491ms which is very small. It's recommended to increase it to at least 100ms using more operations.

### qualified-830951-v1-domain0-native-attribution-current

- Finished: 10/08/2026 15:14:38. Expected/completed/successful children: 4/4/4. Capture clean: True.
- Native grouped table: [OfficeIMO.Excel.ReaderComparison.Benchmarks.RawReadBenchmarks-report-github.md](D:\Dev\Scratch\officeimo-excelreader-performance\final-runs\qualified-830951-v1-domain0-native-attribution-current\20261008-151400\OfficeIMO.Excel.ReaderComparison.Benchmarks.RawReadBenchmarks-report-github.md).
- Native grouped table: [OfficeIMO.Excel.ReaderComparison.Benchmarks.TypedXlsbReadBenchmarks-report-github.md](D:\Dev\Scratch\officeimo-excelreader-performance\final-runs\qualified-830951-v1-domain0-native-attribution-current\20261008-151400\OfficeIMO.Excel.ReaderComparison.Benchmarks.TypedXlsbReadBenchmarks-report-github.md).

> MinIterationTime
>   TypedXlsbReadBenchmarks.ExcelReaderTypedXlsb: OutlierMode=DontRemove, Affinity=00000000000000001111111111111111, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=250ms, LaunchCount=1, UnrollFactor=1, WarmupCount=12 -> The minimum observed iteration time is 40.681ms which is very small. It's recommended to increase it to at least 100ms using more operations.

### qualified-830951-v1-domain1-native-attribution-current

- Finished: 10/08/2026 15:15:08. Expected/completed/successful children: 4/4/4. Capture clean: True.
- Native grouped table: [OfficeIMO.Excel.ReaderComparison.Benchmarks.RawReadBenchmarks-report-github.md](D:\Dev\Scratch\officeimo-excelreader-performance\final-runs\qualified-830951-v1-domain1-native-attribution-current\20261008-151440\OfficeIMO.Excel.ReaderComparison.Benchmarks.RawReadBenchmarks-report-github.md).
- Native grouped table: [OfficeIMO.Excel.ReaderComparison.Benchmarks.TypedXlsbReadBenchmarks-report-github.md](D:\Dev\Scratch\officeimo-excelreader-performance\final-runs\qualified-830951-v1-domain1-native-attribution-current\20261008-151440\OfficeIMO.Excel.ReaderComparison.Benchmarks.TypedXlsbReadBenchmarks-report-github.md).

> MinIterationTime
>   RawReadBenchmarks.ExcelReaderOriginal: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=250ms, LaunchCount=1, UnrollFactor=1, WarmupCount=12 -> The minimum observed iteration time is 37.792ms which is very small. It's recommended to increase it to at least 100ms using more operations.
> MinIterationTime
>   TypedXlsbReadBenchmarks.ExcelReaderTypedXlsb: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=250ms, LaunchCount=1, UnrollFactor=1, WarmupCount=12 -> The minimum observed iteration time is 41.177ms which is very small. It's recommended to increase it to at least 100ms using more operations.
>   TypedXlsbReadBenchmarks.OfficeIMOTypedXlsb: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=250ms, LaunchCount=1, UnrollFactor=1, WarmupCount=12   -> The minimum observed iteration time is 93.779ms which is very small. It's recommended to increase it to at least 100ms using more operations.

### qualified-830951-v1-domain1-native-attribution-before

- Finished: 10/08/2026 15:15:46. Expected/completed/successful children: 4/4/4. Capture clean: True.
- Native grouped table: [OfficeIMO.Excel.ReaderComparison.Benchmarks.RawReadBenchmarks-report-github.md](D:\Dev\Scratch\officeimo-excelreader-performance\final-runs\qualified-830951-v1-domain1-native-attribution-before\20261008-151509\OfficeIMO.Excel.ReaderComparison.Benchmarks.RawReadBenchmarks-report-github.md).
- Native grouped table: [OfficeIMO.Excel.ReaderComparison.Benchmarks.TypedXlsbReadBenchmarks-report-github.md](D:\Dev\Scratch\officeimo-excelreader-performance\final-runs\qualified-830951-v1-domain1-native-attribution-before\20261008-151509\OfficeIMO.Excel.ReaderComparison.Benchmarks.TypedXlsbReadBenchmarks-report-github.md).

> MultimodalDistribution
>   TypedXlsbReadBenchmarks.OfficeIMOTypedXlsb: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-e67677",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=250ms, LaunchCount=1, UnrollFactor=1, WarmupCount=12 -> It seems that the distribution is bimodal (mValue = 3.25)
> MinIterationTime
>   TypedXlsbReadBenchmarks.ExcelReaderTypedXlsb: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-e67677",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=250ms, LaunchCount=1, UnrollFactor=1, WarmupCount=12 -> The minimum observed iteration time is 42.902ms which is very small. It's recommended to increase it to at least 100ms using more operations.

No source, test, benchmark, fixture or archive mutation was performed for this extraction. Original sealed packet files remain in place; the derived manifest describes these three task-scratch deliverables.
