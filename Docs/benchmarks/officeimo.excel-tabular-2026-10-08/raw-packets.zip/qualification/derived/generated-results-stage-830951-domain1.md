# Sealed generated readers: domain 1, frozen 830951

54 successful cases across10 native class tables;810 matching normalized measured samples and810 retained WorkloadActual measurements. Capture/runtime 83095146282a96143b23a79a7ecca058a24a709b; benchmark source unchanged from e676775a59458d1095606386c39506ceb8a9bc33. Started 2026-10-08T18:31:53.4427565+00:00; native sidecar completed 2026-10-08T18:58:48.3387884+00:00; context ended 2026-10-08T18:58:48.4612922Z.

Recipe: one launch /12 warmups /15 measurements /1000ms automatic Pilot /unroll1 /DontRemove; High priority, affinity0xFFFF0000. Measured actual durations 136.8291–1417.4426ms; all>=100ms. 0 short /5 distribution warning rows; 35 outlier hint rows /49 native outlier values, retained.

- All54 cases across10 native class tables pass; all810 normalized samples/statistics/allocations reconcile with native OriginalValues/Results and810 actual iteration measurements. All54 child exits0 atHigh/0xFFFF0000;216 owner hash/version observations match the frozen quartet.
- Domain1 preserves valid losses. Ordinary automatic50K class mapping OfficeIMO9.978ms/2,479,717B versus peer7.528ms/4,054,600B; struct10.144ms/79,621B versus7.408ms/1,654,600B. Lower managed allocation does not establish a throughput win.
- Typed XLSB synchronous manual-class OfficeIMO6.954ms/4,173,060B versus automatic peer6.156ms/4,054,784B and Sylvan19.545ms/10,907,980B. Async automatic OfficeIMO11.090ms/8,973,770B versus peer6.162ms/4,054,896B; routes remain separate.
- Materialized raw XLSX OfficeIMO9.958ms/3,678,278B versus peer5.972ms/1,653,912B and Sylvan25.989ms/1,985,697B. Original raw borrowed peer and GetValue/boxing OfficeIMO rows have different allocation work and remain separate, with no borrowed/raw matched-materialization ranking.
- Public async Stream opening plus automatic XLSX mapping OfficeIMO11.045ms/3,254,681B versus peer7.544ms/4,054,576B and Sylvan43.647ms/10,984,841B. Prepared MemoryStream measures included buffering/parsing/discovery and traversal, not blockedI/O scalability.
- Public RowsAsBorrowed factory ref-struct8.938ms/79,155B versus peer automatic ref-struct7.661ms/4,464B; full values/order match, factory orchestration remains explicit and arbitrary automatic OfficeIMO ref-struct mapping remains an API gap.
- All five actual generated shapes match qualified domain0 inflated payloads and compressed lengths; BIFF8 bytes match exactly. ZIP package hashes and observed timestamps vary and are preserved without exclusive causal attribution. Domains are distinct sequential captures; no pooling or universal winner claim.
- Allocated is cumulative managed bytes per operation, not peak/retained/native memory. Every native confidence interval, outlier array, warning and measured duration is preserved. Boundary snapshots lack per-case roles/timeline and do not establish isolation or contamination.

## Native class/parameter work and measurements

### BorrowedRefStructReadBenchmarks

Same original 50K XLSX span-bearing model values and complete checksum/count. Peer automatic ref-struct mapping versus OfficeIMO public RowsAsBorrowed factory calling borrowed UTF8/name and native numeric/date getters. Factory orchestration timed. No automatic OfficeIMO ref-struct mapper claimed; manual-loop method not selected.

| Method | Full native parameters | D1 mean ms | D1 SD ms | Allocated managed bytes/op | Min actual iteration ms |
| --- | --- | ---: | ---: | ---: | ---: |
| ExcelReaderMappedRefStruct | RowCount=50000 | 7.661197 | 0.426753 | 4464 | 933.8476 |
| OfficeIMOFactoryRefStruct | RowCount=50000 | 8.938377 | 0.407632 | 79155 | 953.9539 |

### MaterializedRawAsyncReadBenchmarks

Same raw async lifecycle differences, with strings materialized in all engines. Complete fields/count/checksum matched; original borrowed raw rows remain separate.

| Method | Full native parameters | D1 mean ms | D1 SD ms | Allocated managed bytes/op | Min actual iteration ms |
| --- | --- | ---: | ---: | ---: | ---: |
| ExcelReaderStringsMaterializedAsync | RowCount=50000&Format=Xlsx | 6.839998 | 0.383650 | 1653984 | 945.2650 |
| OfficeIMOAsync | RowCount=50000&Format=Xlsx | 11.799581 | 1.136101 | 3678393 | 866.1756 |
| SylvanAsync | RowCount=50000&Format=Xlsx | 28.504115 | 1.952127 | 1986624 | 755.2300 |
| ExcelReaderStringsMaterializedAsync | RowCount=50000&Format=Xlsb | 4.459443 | 0.039257 | 1656408 | 1001.3755 |
| OfficeIMOAsync | RowCount=50000&Format=Xlsb | 7.156962 | 0.315581 | 5372438 | 987.2237 |
| SylvanAsync | RowCount=50000&Format=Xlsb | 5.815941 | 0.070859 | 1911216 | 880.9480 |
| ExcelReaderStringsMaterializedAsync | RowCount=50000&Format=Xls | 2.820248 | 0.015922 | 1652976 | 1000.4251 |
| OfficeIMOAsync | RowCount=50000&Format=Xls | 5.454352 | 0.095110 | 10751205 | 979.0954 |
| SylvanAsync | RowCount=50000&Format=Xls | 4.812681 | 0.120936 | 1760296 | 953.1201 |

### MaterializedRawReadBenchmarks

Same headerless raw inputs, all strings materialized in each engine. Every field/type/order/count is validated outside timing; full raw checksum/count in timing. Ordinary scalar API and boxing costs remain. Public opening/traversal/disposal included.

| Method | Full native parameters | D1 mean ms | D1 SD ms | Allocated managed bytes/op | Min actual iteration ms |
| --- | --- | ---: | ---: | ---: | ---: |
| ExcelReaderStringsMaterialized | RowCount=50000&Format=Xlsx | 5.971665 | 0.085552 | 1653912 | 986.2036 |
| OfficeIMOOriginal | RowCount=50000&Format=Xlsx | 9.957901 | 0.823929 | 3678278 | 181.7318 |
| Sylvan | RowCount=50000&Format=Xlsx | 25.989272 | 0.179106 | 1985697 | 953.8302 |
| ExcelReaderStringsMaterialized | RowCount=50000&Format=Xlsb | 4.372455 | 0.024340 | 1654232 | 990.8513 |
| OfficeIMOOriginal | RowCount=50000&Format=Xlsb | 6.554814 | 0.105411 | 5372355 | 905.0686 |
| Sylvan | RowCount=50000&Format=Xlsb | 5.448824 | 0.097042 | 1910288 | 989.3853 |
| ExcelReaderStringsMaterialized | RowCount=50000&Format=Xls | 2.960104 | 0.107358 | 1652904 | 988.1139 |
| OfficeIMOOriginal | RowCount=50000&Format=Xls | 4.803279 | 0.055101 | 10751134 | 987.5433 |
| Sylvan | RowCount=50000&Format=Xls | 4.268475 | 0.027882 | 1758984 | 989.2620 |

### RawAsyncReadBenchmarks

Same original raw semantic work through public async APIs: peer async Stream opening, OfficeIMO synchronous byte[] opening plus ReadAsync, Sylvan synchronous create plus ReadAsync. Opening/I/O strategies differ; prepared MemoryStream is not blocked-I/O scalability evidence.

| Method | Full native parameters | D1 mean ms | D1 SD ms | Allocated managed bytes/op | Min actual iteration ms |
| --- | --- | ---: | ---: | ---: | ---: |
| ExcelReaderAsync | RowCount=50000&Format=Xlsx | 5.501425 | 0.097953 | 3984 | 989.4963 |
| OfficeIMOAsync | RowCount=50000&Format=Xlsx | 9.962291 | 0.074260 | 3678350 | 187.8512 |
| SylvanAsync | RowCount=50000&Format=Xlsx | 29.912404 | 2.515022 | 1986625 | 997.8872 |
| ExcelReaderAsync | RowCount=50000&Format=Xlsb | 4.745047 | 0.406919 | 4304 | 1003.2482 |
| OfficeIMOAsync | RowCount=50000&Format=Xlsb | 6.938982 | 0.059954 | 5372438 | 982.4622 |
| SylvanAsync | RowCount=50000&Format=Xlsb | 6.201189 | 0.270457 | 1911217 | 259.7429 |
| ExcelReaderAsync | RowCount=50000&Format=Xls | 2.794264 | 0.365935 | 2976 | 999.8596 |
| OfficeIMOAsync | RowCount=50000&Format=Xls | 5.265990 | 0.070490 | 10751205 | 972.5655 |
| SylvanAsync | RowCount=50000&Format=Xls | 5.405705 | 0.486027 | 1760296 | 902.1680 |

### RawReadBenchmarks

Original headerless 50K four-field raw reads. Peer borrowed UTF8/date/double parsing versus OfficeIMO GetValue strings and scalar boxing versus Sylvan native GetValue. Same semantic count/checksum; string production differs, so no raw cross-library matched-materialization claim.

| Method | Full native parameters | D1 mean ms | D1 SD ms | Allocated managed bytes/op | Min actual iteration ms |
| --- | --- | ---: | ---: | ---: | ---: |
| ExcelReaderOriginal | RowCount=50000&Format=Xlsx | 5.322051 | 0.045184 | 3912 | 990.8124 |
| OfficeIMOOriginal | RowCount=50000&Format=Xlsx | 16.714102 | 0.310878 | 3808385 | 325.9807 |
| Sylvan | RowCount=50000&Format=Xlsx | 26.888213 | 0.509129 | 1985697 | 791.0319 |
| ExcelReaderOriginal | RowCount=50000&Format=Xlsb | 4.009978 | 0.156914 | 4232 | 982.8927 |
| OfficeIMOOriginal | RowCount=50000&Format=Xlsb | 7.777727 | 0.746559 | 5372367 | 941.0500 |
| Sylvan | RowCount=50000&Format=Xlsb | 5.571314 | 0.155134 | 1910358 | 986.2195 |
| ExcelReaderOriginal | RowCount=50000&Format=Xls | 2.533229 | 0.018137 | 3185 | 1001.4734 |
| OfficeIMOOriginal | RowCount=50000&Format=Xls | 4.877664 | 0.134371 | 10772666 | 982.2995 |
| Sylvan | RowCount=50000&Format=Xls | 4.436722 | 0.265911 | 1758983 | 966.9593 |

### TypedAsyncReadBenchmarks

Original 50K XLSX automatic class projection and full checksum/count. OfficeIMO sync byte[] opener plus RowsAsAsync, peer async Stream opener/parser, Sylvan create plus GetRecordsAsync. Synchronous CPU parsing and prepared memory input remain explicit.

| Method | Full native parameters | D1 mean ms | D1 SD ms | Allocated managed bytes/op | Min actual iteration ms |
| --- | --- | ---: | ---: | ---: | ---: |
| OfficeIMOTypedAsync | RowCount=50000&Shape=Original | 11.037746 | 0.992304 | 2479830 | 136.8291 |
| ExcelReaderTypedAsync | RowCount=50000&Shape=Original | 7.680031 | 0.141064 | 4054576 | 995.9679 |
| SylvanTypedAsync | RowCount=50000&Shape=Original | 43.821895 | 1.040636 | 10984840 | 853.9052 |

### TypedModelReadBenchmarks

Same original 50K XLSX ordinary automatic class/struct model contract. OfficeIMO RowsAs versus peer attribute parser, both consume Name/Id/Date/Value. Full record validation outside timing; scalar/string representation and model strategy visible.

| Method | Full native parameters | D1 mean ms | D1 SD ms | Allocated managed bytes/op | Min actual iteration ms |
| --- | --- | ---: | ---: | ---: | ---: |
| ExcelReaderAutomatic | RowCount=50000&Model=Class | 7.528323 | 0.162826 | 4054600 | 985.4772 |
| OfficeIMOAutomatic | RowCount=50000&Model=Class | 9.978034 | 0.299626 | 2479717 | 962.7845 |
| ExcelReaderAutomatic | RowCount=50000&Model=Struct | 7.408372 | 0.171581 | 1654600 | 993.9953 |
| OfficeIMOAutomatic | RowCount=50000&Model=Struct | 10.144059 | 0.261236 | 79621 | 936.9355 |

### TypedStreamAsyncReadBenchmarks

Original 50K XLSX through public async Stream openers and automatic class projection; create/dispose prepared MemoryStream per invocation. OfficeIMO bounded buffering/decode/discovery included. MemoryStream does not model blocked I/O.

| Method | Full native parameters | D1 mean ms | D1 SD ms | Allocated managed bytes/op | Min actual iteration ms |
| --- | --- | ---: | ---: | ---: | ---: |
| OfficeIMOStreamOpenTypedAsync | RowCount=50000&Shape=Original | 11.045118 | 0.225907 | 3254681 | 162.9100 |
| ExcelReaderStreamOpenTypedAsync | RowCount=50000&Shape=Original | 7.544433 | 0.040940 | 4054576 | 994.9012 |
| SylvanStreamOpenTypedAsync | RowCount=50000&Shape=Original | 43.647298 | 0.667482 | 10984841 | 942.5059 |

### TypedXlsbAsyncReadBenchmarks

Header-bearing 50K XLSB automatic class projection. OfficeIMO sync byte[] opener plus RowsAsAsync, peer async Stream opener/parser and Sylvan GetRecordsAsync; full field/count/order proof and checksum preserved.

| Method | Full native parameters | D1 mean ms | D1 SD ms | Allocated managed bytes/op | Min actual iteration ms |
| --- | --- | ---: | ---: | ---: | ---: |
| ExcelReaderTypedXlsbAsync | RowCount=50000 | 6.162183 | 0.276169 | 4054896 | 964.2689 |
| OfficeIMOTypedXlsbAsync | RowCount=50000 | 11.090054 | 0.958702 | 8973770 | 633.3494 |
| SylvanTypedXlsbAsync | RowCount=50000 | 23.806699 | 2.945756 | 10908970 | 427.8937 |

### TypedXlsbReadBenchmarks

Header-bearing 50K XLSB Name/Id/Date/Value. OfficeIMO direct native getters plus manual class construction; peer/Sylvan automatic projection. Complete record fields/order/count outside timing; full checksum/count timed.

| Method | Full native parameters | D1 mean ms | D1 SD ms | Allocated managed bytes/op | Min actual iteration ms |
| --- | --- | ---: | ---: | ---: | ---: |
| ExcelReaderTypedXlsb | RowCount=50000 | 6.156217 | 0.176457 | 4054784 | 911.3112 |
| OfficeIMOTypedXlsb | RowCount=50000 | 6.953646 | 0.167414 | 4173060 | 951.5698 |
| SylvanTypedXlsb | RowCount=50000 | 19.544629 | 1.381441 | 10907980 | 430.2654 |

Every identity retains namespace, class, method, complete parameters, native FullName and job. Original raw borrowed spans and materialized reads are separate; automatic models, manual typed XLSB class construction, and public ref-struct factory mapping remain distinct. Async byte-opening enumeration differs from public Stream opening; prepared MemoryStream is not a blockedI/O experiment. Native grouped tables and all samples are authoritative.

## Actual inputs and same payload qualification

| Input shape | Instances | Bytes | Distinct container/file SHA256 | Inflated parts |
| --- | ---: | ---: | ---: | ---: |
| read/raw/Xls/dataRows=50000 | 12 | 3617792 | 1 | 0 |
| read/raw/Xlsb/dataRows=50000 | 12 | 870431 | 12 | 8 |
| read/raw/Xlsx/dataRows=50000 | 12 | 773466 | 12 | 6 |
| read/typed/Xlsb/dataRows=50000 | 6 | 871166 | 6 | 8 |
| read/typed/Xlsx/Original/dataRows=50000 | 12 | 773409 | 12 | 6 |

All54 actual input byte fingerprints and288 inflated part records are retained per child in JSON. All5 shape payloads and compressed lengths match the previously qualified domain0 derived stage. Headerless BIFF8/OLE3,617,792-byte input has the same whole-file SHA256; ZIP containers retain every distinct observed hash and entry timestamp. Identical inflated names/lengths/hashes establish input payload equivalence; no bytewise container analysis or exclusive metadata causal attribution is claimed. Each child consumes its own prepared unchanged bytes and validates every field/order/count before timing.

### read/raw/Xls/dataRows=50000

Whole-file SHA256: 800A59EF69588F1F44F13DCE93CF01F018C5792D2D5C91CEFF3F5B4B7CA705E1

### read/raw/Xlsb/dataRows=50000

| Inflated entry | Bytes | Compressed bytes | SHA256 |
| --- | ---: | ---: | --- |
| [Content_Types].xml | 899 | 403 | FC62B911F2BFE6482E812242BBE93E8AB727D4453C9CA8D3C09D0A43C58DF22C |
| _rels/.rels | 438 | 248 | 93EBC98ECD0A158942C51A10F12DDC2B849917154EFC2328F6AD20D6BC47F6D2 |
| docProps/app.xml | 231 | 193 | 215F432F2989969565FC2DDB8BF4F6E0B8958EFA7E752C2BB373B3129699E1C2 |
| xl/_rels/workbook.bin.rels | 557 | 246 | 7F57FC54E0C74E705DAAF71856E9C7854EA19A7BFA4CEFF24AEE5C18D7C8A7B2 |
| xl/sharedStrings.bin | 14 | 10 | A598F2C2704EF01CBC4F9DFB4888054023C0B6A1E19C7E4DA7F0C06A6EE0266B |
| xl/styles.bin | 390 | 184 | 7B252C122048E3899F452448E1C33B1AE159B7DAF8FD4296B4314CAE766DC5A9 |
| xl/workbook.bin | 54 | 41 | 1E3461BD8B29F0FE94FB6F4B41915D6A1600BF3EAF7E4C8ECA8EA95F9A09ED5E |
| xl/worksheets/sheet1.bin | 4925166 | 868188 | EFFBE6186E05BE1F4C65CAA7238DBF53B6896630DC30433D089E9844727DEF5C |

### read/raw/Xlsx/dataRows=50000

| Inflated entry | Bytes | Compressed bytes | SHA256 |
| --- | ---: | ---: | --- |
| [Content_Types].xml | 679 | 324 | 38EF511C77D41512E20181A2FD53DC223E8B2E0B406ACB16319BAF234C18C3FD |
| _rels/.rels | 295 | 204 | F2F3948A1B6F661F2A5169A86B7029166ACD4B79D7ABFD37FA2B646FE302BFD6 |
| xl/_rels/workbook.xml.rels | 423 | 223 | 41469A71751EBF1183C540B5FFC9BBBA3A7009511271C1B540AB7FCC018654D8 |
| xl/styles.xml | 678 | 377 | F72F8C91B43E33BAB6356D8B9058B7AFBDA2E691843994944CAC2052811F115E |
| xl/workbook.xml | 279 | 220 | 9A4C68DE5B9BBB96D36674F27B22AD76FFD4AE1FEDC67B0DDD8B4D9E8D3A339B |
| xl/worksheets/sheet1.xml | 5969157 | 771424 | 598C042F6840BC82CC576962512A796CE0FFCCC074A3CCA0685E41E090B8A5A9 |

### read/typed/Xlsb/dataRows=50000

| Inflated entry | Bytes | Compressed bytes | SHA256 |
| --- | ---: | ---: | --- |
| [Content_Types].xml | 899 | 403 | FC62B911F2BFE6482E812242BBE93E8AB727D4453C9CA8D3C09D0A43C58DF22C |
| _rels/.rels | 438 | 248 | 93EBC98ECD0A158942C51A10F12DDC2B849917154EFC2328F6AD20D6BC47F6D2 |
| docProps/app.xml | 231 | 193 | 215F432F2989969565FC2DDB8BF4F6E0B8958EFA7E752C2BB373B3129699E1C2 |
| xl/_rels/workbook.bin.rels | 557 | 246 | 7F57FC54E0C74E705DAAF71856E9C7854EA19A7BFA4CEFF24AEE5C18D7C8A7B2 |
| xl/sharedStrings.bin | 14 | 10 | A598F2C2704EF01CBC4F9DFB4888054023C0B6A1E19C7E4DA7F0C06A6EE0266B |
| xl/styles.bin | 390 | 184 | 7B252C122048E3899F452448E1C33B1AE159B7DAF8FD4296B4314CAE766DC5A9 |
| xl/workbook.bin | 54 | 41 | 1E3461BD8B29F0FE94FB6F4B41915D6A1600BF3EAF7E4C8ECA8EA95F9A09ED5E |
| xl/worksheets/sheet1.bin | 4925279 | 868923 | FCB404C49DE3ED1515C95C2055B4319E0FA10C6A3A072DF365FACFCECB4431DD |

### read/typed/Xlsx/Original/dataRows=50000

| Inflated entry | Bytes | Compressed bytes | SHA256 |
| --- | ---: | ---: | --- |
| [Content_Types].xml | 679 | 324 | 38EF511C77D41512E20181A2FD53DC223E8B2E0B406ACB16319BAF234C18C3FD |
| _rels/.rels | 295 | 204 | F2F3948A1B6F661F2A5169A86B7029166ACD4B79D7ABFD37FA2B646FE302BFD6 |
| xl/_rels/workbook.xml.rels | 423 | 223 | 41469A71751EBF1183C540B5FFC9BBBA3A7009511271C1B540AB7FCC018654D8 |
| xl/styles.xml | 678 | 377 | F72F8C91B43E33BAB6356D8B9058B7AFBDA2E691843994944CAC2052811F115E |
| xl/workbook.xml | 279 | 220 | 9A4C68DE5B9BBB96D36674F27B22AD76FFD4AE1FEDC67B0DDD8B4D9E8D3A339B |
| xl/worksheets/sheet1.xml | 5969331 | 771367 | 436EF0BE5835F7320D2F0D9C2C4023F151A15ED90337A7DEDD1B03A32485628C |

## Separate domain observations

Domain0 and domain1 are separately identified sequential captures, with different run timestamps/affinities and original runner metadata preserved. JSON includes the already qualified domain0 mean/SD/allocation for each full identity as an observation reference; values are neither pooled nor portrayed as physical interleaving. Domain1 valid losses and variation remain visible, including the original raw XLSX OfficeIMO16.714ms versus its separately captured materialized class9.958ms. No causal explanation is inferred from that difference.

## Provenance, host boundary and native diagnostics

All41 native artifact SHA256/length pairs and810 normalized sample values/statistics/managed allocation values reconcile. Outer frozen harness 5E79575325D94AE8D09B97CD0C1C341EBB6AC0A24C3EEE6AE4817A897F97E7A4; resumed runner C52377235F70A38C61333009FFA2CC97C0BE2B3C102041CB127587B09AB32A95; generated-project-only saved-reference hook CEDF3A831603914A5E024C980CCA65AAAAF25544D98538BC416E963DD8632B12. All216 owner hash/version observations match frozen quartet3.4.4+83095146282a96143b23a79a7ecca058a24a709b. The hook supplies compiler references only; the frozen runtime and benchmark methods remain unchanged.

Boundary snapshots 82/57 entries; 45 persistent IDs /12 new afterIDs. Maximum observed persistent CPU delta 0.625000s; sum 10.093750s. These snapshots lack command roles/per-case timeline; neither full isolation nor causal contamination is established. No live process audit was performed.

All native warnings/hints are preserved below. Warning prose that omits parameter identity is ambiguous across parameterized siblings; use native class/method/full parameters/job and distributions rather than a generic scenario grouping.

~~~text
// * Warnings *
MultimodalDistribution
  MaterializedRawAsyncReadBenchmarks.ExcelReaderStringsMaterializedAsync: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12 -> It seems that the distribution is bimodal (mValue = 3.71)
// * Hints *
Outliers
  MaterializedRawAsyncReadBenchmarks.OfficeIMOAsync: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12                      -> 1 outlier  was  detected (14.77 ms)
  MaterializedRawAsyncReadBenchmarks.SylvanAsync: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12                         -> 2 outliers were detected (32.27 ms, 32.90 ms)
  MaterializedRawAsyncReadBenchmarks.ExcelReaderStringsMaterializedAsync: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12 -> 1 outlier  was  detected (4.60 ms)
  MaterializedRawAsyncReadBenchmarks.OfficeIMOAsync: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12                      -> 1 outlier  was  detected (8.10 ms)
  MaterializedRawAsyncReadBenchmarks.SylvanAsync: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12                         -> 1 outlier  was  detected (6.04 ms)
  MaterializedRawAsyncReadBenchmarks.OfficeIMOAsync: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12                      -> 1 outlier  was  detected (5.71 ms)
  MaterializedRawAsyncReadBenchmarks.SylvanAsync: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12                         -> 2 outliers were detected (5.05 ms, 5.11 ms)
// * Hints *
Outliers
  MaterializedRawReadBenchmarks.ExcelReaderStringsMaterialized: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12 -> 2 outliers were detected (6.13 ms, 6.21 ms)
  MaterializedRawReadBenchmarks.OfficeIMOOriginal: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12              -> 2 outliers were detected (10.31 ms, 12.83 ms)
  MaterializedRawReadBenchmarks.OfficeIMOOriginal: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12              -> 1 outlier  was  detected (6.84 ms)
  MaterializedRawReadBenchmarks.Sylvan: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12                         -> 1 outlier  was  detected (5.76 ms)
  MaterializedRawReadBenchmarks.ExcelReaderStringsMaterialized: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12 -> 2 outliers were detected (3.01 ms, 3.33 ms)
  MaterializedRawReadBenchmarks.OfficeIMOOriginal: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12              -> 1 outlier  was  detected (4.97 ms)
// * Warnings *
MultimodalDistribution
  RawAsyncReadBenchmarks.ExcelReaderAsync: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12 -> It seems that the distribution is bimodal (mValue = 3.71)
  RawAsyncReadBenchmarks.SylvanAsync: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12      -> It seems that the distribution can have several modes (mValue = 3)
// * Hints *
Outliers
  RawAsyncReadBenchmarks.ExcelReaderAsync: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12 -> 2 outliers were detected (5.60 ms, 5.82 ms)
  RawAsyncReadBenchmarks.OfficeIMOAsync: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12   -> 1 outlier  was  detected (10.20 ms)
  RawAsyncReadBenchmarks.SylvanAsync: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12      -> 1 outlier  was  detected (36.48 ms)
  RawAsyncReadBenchmarks.OfficeIMOAsync: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12   -> 1 outlier  was  detected (7.06 ms)
  RawAsyncReadBenchmarks.OfficeIMOAsync: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12   -> 1 outlier  was  detected (5.50 ms)
  RawAsyncReadBenchmarks.SylvanAsync: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12      -> 1 outlier  was  detected (6.96 ms)
// * Hints *
Outliers
  RawReadBenchmarks.ExcelReaderOriginal: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12 -> 1 outlier  was  detected (5.44 ms)
  RawReadBenchmarks.Sylvan: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12              -> 1 outlier  was  detected (28.38 ms)
  RawReadBenchmarks.ExcelReaderOriginal: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12 -> 1 outlier  was  detected (4.54 ms)
  RawReadBenchmarks.OfficeIMOOriginal: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12   -> 2 outliers were detected (7.76 ms, 10.47 ms)
  RawReadBenchmarks.OfficeIMOOriginal: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12   -> 1 outlier  was  detected (5.29 ms)
  RawReadBenchmarks.Sylvan: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12              -> 2 outliers were detected (4.80 ms, 5.28 ms)
// * Hints *
Outliers
  TypedAsyncReadBenchmarks.OfficeIMOTypedAsync: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12   -> 1 outlier  was  detected (14.46 ms)
  TypedAsyncReadBenchmarks.ExcelReaderTypedAsync: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12 -> 1 outlier  was  detected (8.09 ms)
  TypedAsyncReadBenchmarks.SylvanTypedAsync: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12      -> 2 outliers were detected (45.92 ms, 46.07 ms)
// * Hints *
Outliers
  TypedModelReadBenchmarks.ExcelReaderAutomatic: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12 -> 1 outlier  was  detected (8.08 ms)
  TypedModelReadBenchmarks.OfficeIMOAutomatic: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12   -> 1 outlier  was  detected (10.88 ms)
  TypedModelReadBenchmarks.ExcelReaderAutomatic: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12 -> 2 outliers were detected (7.63 ms, 7.94 ms)
  TypedModelReadBenchmarks.OfficeIMOAutomatic: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12   -> 2 outliers were detected (10.51 ms, 10.96 ms)
// * Hints *
Outliers
  TypedStreamAsyncReadBenchmarks.OfficeIMOStreamOpenTypedAsync: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12 -> 2 outliers were detected (11.51 ms, 11.66 ms)
// * Warnings *
MultimodalDistribution
  TypedXlsbAsyncReadBenchmarks.SylvanTypedXlsbAsync: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12 -> It seems that the distribution can have several modes (mValue = 3.14)
// * Hints *
Outliers
  TypedXlsbAsyncReadBenchmarks.SylvanTypedXlsbAsync: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12 -> 3 outliers were detected (27.91 ms..30.09 ms)
// * Warnings *
MultimodalDistribution
  TypedXlsbReadBenchmarks.SylvanTypedXlsb: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12 -> It seems that the distribution is bimodal (mValue = 3.25)
// * Hints *
Outliers
  TypedXlsbReadBenchmarks.ExcelReaderTypedXlsb: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12 -> 1 outlier  was  detected (6.56 ms)
~~~

This qualifies54 additional primary cases:408 primary sealed /244 pending plus78 supplementary =486/730. Historical106 exploratory cases remain outside this ledger. Only requested sealed domain1-generated was inspected; no real/later/incomplete groups, source/build/test/timer/fixturecopy/archive/cleanup/public actions. Native originals unchanged.