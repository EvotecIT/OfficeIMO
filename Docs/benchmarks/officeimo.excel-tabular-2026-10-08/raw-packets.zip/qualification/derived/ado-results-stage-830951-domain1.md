# Qualified ADO capture, domain1

All nine cases and successful children, with 135 actual samples, match native BDN and normalized statistics/GC/allocation metrics. All five native artifacts match sidecar SHA-256 and byte length. Measured children load frozen830951 owners at High/0xFFFF0000. Capture identity comes from the sealed context/sidecar; normalized importer IDs/timestamps are retained as import metadata.

Recipe: 1 launch, 12 warmups, 15 actual iterations, 1-second target, unroll 1, DontRemove. Raw actuals 854.6389–1048.8762 ms, all at least 100 ms. Retained native diagnostics: 0 short-iteration warnings, 0 distribution warnings, 4 outlier hint rows, 5 native outlier values. Capture elapsed 298.3643937 seconds; 2026-10-08T19:47:17.2724566+00:00 to 2026-10-08T19:52:15.6368503+00:00, sealed 2026-10-08T19:52:15.6710163Z. Native total: Global total time: 00:04:57 (297.46 sec), executed benchmarks: 9

Per operation: prepared in-memory input, public opening, IDataReader traversal and disposal. Fixture generation, package/shape validation, full-field checks and reused byte-buffer allocation are outside timing.

## GetValue

All four fields through IDataReader.GetValue interface dispatch; counts non-null object references and verifies 50,000 rows. The all-populated fixture yields 200,000. This accumulator does not establish DBNull-versus-null behavior for missing cells. Complete header, typed fields, GetValue conversions, order and count are checked outside timing.

| Library | Mean ms | SD ms | Managed bytes/op, native diagnostic |
|---|---:|---:|---:|
| ExcelReader | 6.784472 | 0.094492 | 5254664 |
| OfficeIMO | 9.782414 | 0.121813 | 4453217 |
| Sylvan | 33.417685 | 0.296560 | 8583409 |

## TypedGetters

IDataReader.GetString(Name), GetInt32(Id), GetDateTime(Date), GetDouble(Value) on every row. The timed accumulator uses name length + id + Date.Day + truncated numeric value; all full fields and count/order are validated outside timing. Separate from GetValue and text copying.

| Library | Mean ms | SD ms | Managed bytes/op, native diagnostic |
|---|---:|---:|---:|
| ExcelReader | 6.904163 | 0.055132 | 1654664 |
| OfficeIMO | 8.397873 | 0.065084 | 1035503 |
| Sylvan | 25.106074 | 0.227207 | 1986477 |

## Utf8TextCopy

Name copied into a reused caller-owned 256-byte buffer; returned byte counts accumulated and 50,000 rows checked. Peer text GetBytes is matched by explicit public OfficeIMO.Data.GetUtf8Bytes for OfficeIMO and Sylvan. Full copied bytes/count match Encoding.UTF8 outside timing, alongside all four scalar fields. Provider binary GetBytes semantics remain unchanged. Only Name is copied in timing; this is distinct from borrowed-span scanning.

| Library | Mean ms | SD ms | Managed bytes/op, native diagnostic |
|---|---:|---:|---:|
| ExcelReader | 5.141342 | 0.043304 | 7101 |
| OfficeIMO | 6.227202 | 0.102230 | 852886 |
| Sylvan | 21.799381 | 0.181749 | 4386168 |

## Qualification boundaries

All successful GlobalSetup calls execute the frozen source-enforced header/field/type/order/count validators for all three providers, GetValue conversions and selected accessor accumulator checks. The Utf8TextCopy setup additionally compares every copied Name byte and returned length with Encoding.UTF8. No separate ADO success declaration is emitted. Success is supported by the frozen source hashes and completed child setup/exit, not an invented output hash or validation-success log line.

The all-populated fixture and non-null GetValue reference count do not establish missing-cell or DBNull semantics. UTF8 copy validates complete short Name values into a reused 256-byte caller buffer; this workload does not exercise segmented offsets, arbitrary Unicode names or borrowed-span lifetime. Those remain separate correctness contracts.

All nine inputs are 773,409-byte XLSX archives with 50,000 populated data rows, four columns and the same six complete nonempty XML-part identities. Each matching domain0 case has equal inflated part names/lengths/SHA, compressed lengths and package length. Actual package SHA matches 0 of 9; actual hashes/timestamps remain separate, without an exclusive explanation of differences. No fixture re-open or copy.

Source-enforced: one S1 worksheet; Name/Id/Date/Value headers; 50,000 data rows + header; 200,004 cells; implicit row/cell coordinates; no dimension; 50,004 inline text cells; numeric styled dates. Names alpha,beta,gamma,delta,epsilon,zeta,eta,theta by index modulo8; Id=index; Date=FromOADate(45292+index%3650+0.25); Value=index*1.5.

Domain1 elapsed and allocation observations remain separate from domain0. The three access strategies have different timed outputs; no unlike ratio or allocation pooling is used. MemoryDiagnoser managed bytes/op are from the diagnostic invocation, separate from actual elapsed samples. Sample allocatedBytes is null; native memory appears in summary/sample metric projections. Native warning labels may omit Access; method-level hints are not assigned to a parameter case. DontRemove preserves all values and native outlier arrays.

Host endpoints: 48/48 entries; 48 persistent matches; maximum observed CPU delta 0.203125 seconds, sum 2.093750 seconds. Pre/post snapshots do not identify process roles, CPU during individual cases, or activity of processes absent at either endpoint. They do not prove an idle host or establish causal contamination. Fresh benchmark children and generated builds occur within the capture; original snapshots are retained. No live host audit or later-group inspection.

Source 83095146282a96143b23a79a7ecca058a24a709b; unchanged benchmark source e676775a59458d1095606386c39506ceb8a9bc33. Harness 5E79575325D94AE8D09B97CD0C1C341EBB6AC0A24C3EEE6AE4817A897F97E7A4; v2 resume runner C52377235F70A38C61333009FFA2CC97C0BE2B3C102041CB127587B09AB32A95; generated-reference hook CEDF3A831603914A5E024C980CCA65AAAAF25544D98538BC416E963DD8632B12. Reference import affects generated compile references only; saved measured owners are unchanged.

Only this three-file ADO packet is written. No source/build/test/package/timing/session/later-group activity, fixture copy, archive or cleanup. Logical bytes removed 0; compact derivations retained and immutable native/import evidence referenced in place. Shared report and coverage ledger remain coordinator-owned.
