# Longer native XLSB attribution — 2026-10-08

The longer runs confirm lower OfficeIMO allocations in both CPU cache domains, with approximately 23% less allocated memory for raw XLSB and 28% less for typed XLSB. Raw mean times decrease in both domains. Typed timing is nearly unchanged in domain 0 and lower in domain 1, with peer movement and retained variation still visible. This supports a scoped allocation improvement, not a universal throughput win.

All four contexts are sealed: 16 successful cases, 36 verified native artifacts and 240 retained measurements. Every actual measured iteration passes the 100 ms guard; minimum 638.912 ms, maximum 1498.962 ms. No MinIterationTime warning remains. Two distribution-warning rows are preserved.

This is supplementary 16-case attribution evidence outside the primary 652. Capture source: 83095146282a96143b23a79a7ecca058a24a709b. Before runtime: e676775a59458d1095606386c39506ceb8a9bc33; after runtime: 83095146282a96143b23a79a7ecca058a24a709b. Benchmark source is unchanged from e676. The Excel discovery helper validates strings using the same Unicode decoder/fallback policy without creating discarded strings. Three discovery branches change; ordinary delivery remains unchanged.

## Recipe and identity boundaries

The coordinator changes only the iteration target from 250 ms to 1000 ms: 1 launch, 12 warmups, 15 measurements, unroll 1, DontRemove, High priority. Domain 0 runs before→current; domain 1 current→before. Runtime and harness hashes match the short stage for each lane. Whole quartet rebuilds have distinct informational-version hashes; the recorded Git diff limits source behavior changes to Excel discovery and its regression tests.

| Runtime | Excel SHA256 | Core SHA256 | Harness SHA256 |
|---|---|---|---|
| before-e676 | 8158D5FDA5B840BD7B8FCD8F84B261F0C7E88C569E7F2927AE86EDE6FF5284E3 | 7CCC87462A55571045520EDF7A4680A5B4BBBC9DDD794016E3E888C2A7D0182F | 842D0A5B3007B2867DB4424F9CC6A1A3A2769C94D3B41BEE1289B4EE09034156 |
| current-830951 | F2853A4C62D5C03C5E3F0CBB7CCBB5776FB63CE58CE8933BE4EBAA4F5887502F | B5565DE58D83BFC91F4FFB69A797CE02DFCB10A5A6409323845D05A5732E1A84 | 5E79575325D94AE8D09B97CD0C1C341EBB6AC0A24C3EEE6AE4817A897F97E7A4 |

## Within-Office results with unchanged peer controls

Means/SD are milliseconds; allocated bytes are exact per-operation values. Before/current changes are arithmetic across separate contexts, not a native paired ratio or significance test.

| Domain | Type.Method | Before mean ± SD | Current mean ± SD | Mean change | Bytes before → current | Allocation reduction |
|---|---|---:|---:|---:|---:|---:|
| 0 | RawReadBenchmarks.OfficeIMOOriginal | 11.561 ± 0.356 | 10.354 ± 1.296 | -10.44% | 7119192 → 5455706 | 23.37% |
| 0 | TypedXlsbReadBenchmarks.OfficeIMOTypedXlsb | 10.613 ± 0.394 | 10.689 ± 0.471 | 0.71% | 5910164 → 4254168 | 28.02% |
| 0 | RawReadBenchmarks.ExcelReaderOriginal | 5.593 ± 0.086 | 5.411 ± 0.134 | -3.24% | 6981 → 6803 | 2.55% |
| 0 | TypedXlsbReadBenchmarks.ExcelReaderTypedXlsb | 8.642 ± 0.252 | 8.573 ± 0.786 | -0.80% | 4054784 → 4059270 | -0.11% |
| 1 | RawReadBenchmarks.OfficeIMOOriginal | 8.269 ± 1.100 | 7.368 ± 0.280 | -10.90% | 7082270 → 5441360 | 23.17% |
| 1 | TypedXlsbReadBenchmarks.OfficeIMOTypedXlsb | 10.281 ± 1.273 | 7.142 ± 0.488 | -30.52% | 5921222 → 4231700 | 28.53% |
| 1 | RawReadBenchmarks.ExcelReaderOriginal | 4.056 ± 0.133 | 4.469 ± 0.398 | 10.17% | 6181 → 6157 | 0.39% |
| 1 | TypedXlsbReadBenchmarks.ExcelReaderTypedXlsb | 7.975 ± 1.029 | 7.151 ± 1.378 | -10.33% | 4058109 → 4057738 | 0.01% |

Raw OfficeIMO consumes GetValue strings/objects and still boxes three scalar fields per row; the peer consumes borrowed UTF8. Raw cross-library allocation and throughput figures therefore remain controls over different API work. Typed methods consume the same complete Name/Id/Date/Value records: Office uses ordinary typed getters/manual construction and the peer uses its attribute parser. Setup validates every field, type, order and row count; timed loops validate checksum/count. Preserve these strategies.

## Reconciliation with the short stage

The original 250 ms stage is retained unchanged, including its eight short-iteration warnings and four distribution warnings. These follow-ups use identical owners, harnesses, method parameters and inflated input parts. Increasing iteration work improves measured duration; it does not authorize pooling old/new samples or removing the earlier evidence. The longer typed Office mean changes +0.71% in domain 0 and −30.52% in domain 1; the earlier short direction differed. Keep the old speed attribution limited.

| Domain | Runtime | Method | Short mean (ms) | Long mean (ms) | Short bytes | Long bytes | Short min iteration (ms) | Long min iteration (ms) |
|---|---|---|---:|---:|---:|---:|---:|---:|
| 0 | before-e676 | RawReadBenchmarks.ExcelReaderOriginal | 4.749 | 5.593 | 4232 | 6981 | 40.676 | 933.623 |
| 0 | before-e676 | RawReadBenchmarks.OfficeIMOOriginal | 11.158 | 11.561 | 7022510 | 7119192 | 127.268 | 955.139 |
| 0 | before-e676 | TypedXlsbReadBenchmarks.ExcelReaderTypedXlsb | 9.018 | 8.642 | 4122719 | 4054784 | 57.259 | 971.989 |
| 0 | before-e676 | TypedXlsbReadBenchmarks.OfficeIMOTypedXlsb | 12.027 | 10.613 | 6757498 | 5910164 | 96.491 | 983.942 |
| 0 | current-830951 | RawReadBenchmarks.ExcelReaderOriginal | 5.118 | 5.411 | 12292 | 6803 | 293.149 | 966.733 |
| 0 | current-830951 | RawReadBenchmarks.OfficeIMOOriginal | 10.568 | 10.354 | 5973009 | 5455706 | 102.487 | 787.588 |
| 0 | current-830951 | TypedXlsbReadBenchmarks.ExcelReaderTypedXlsb | 6.239 | 8.573 | 4122719 | 4059270 | 40.681 | 727.441 |
| 0 | current-830951 | TypedXlsbReadBenchmarks.OfficeIMOTypedXlsb | 8.934 | 10.689 | 4400553 | 4254168 | 311.501 | 1031.954 |
| 1 | current-830951 | RawReadBenchmarks.ExcelReaderOriginal | 5.037 | 4.469 | 57070 | 6157 | 37.792 | 997.527 |
| 1 | current-830951 | RawReadBenchmarks.OfficeIMOOriginal | 9.274 | 7.368 | 6020060 | 5441360 | 106.576 | 859.823 |
| 1 | current-830951 | TypedXlsbReadBenchmarks.ExcelReaderTypedXlsb | 6.199 | 7.151 | 4122855 | 4057738 | 41.177 | 965.603 |
| 1 | current-830951 | TypedXlsbReadBenchmarks.OfficeIMOTypedXlsb | 8.874 | 7.142 | 4820799 | 4231700 | 93.778 | 931.432 |
| 1 | before-e676 | RawReadBenchmarks.ExcelReaderOriginal | 4.772 | 4.056 | 12158 | 6181 | 255.706 | 963.590 |
| 1 | before-e676 | RawReadBenchmarks.OfficeIMOOriginal | 12.040 | 8.269 | 7864142 | 7082270 | 104.613 | 1022.870 |
| 1 | before-e676 | TypedXlsbReadBenchmarks.ExcelReaderTypedXlsb | 6.831 | 7.975 | 4122719 | 4058109 | 42.902 | 898.012 |
| 1 | before-e676 | TypedXlsbReadBenchmarks.OfficeIMOTypedXlsb | 8.628 | 10.281 | 6425329 | 5921222 | 103.924 | 638.912 |

## Actual input identities

| Input | Long instances | Short instances | Package bytes | Long package hash count | Combined inflated manifest count | Worksheet SHA256 |
|---|---:|---:|---:|---:|---:|---|
| read/raw/Xlsb/dataRows=50000 | 8 | 8 | 870431 | 8 | 1 | EFFBE6186E05BE1F4C65CAA7238DBF53B6896630DC30433D089E9844727DEF5C |
| read/typed/Xlsb/dataRows=50000 | 8 | 8 | 871166 | 8 | 1 | FCB404C49DE3ED1515C95C2055B4319E0FA10C6A3A072DF365FACFCECB4431DD |

Every child logs its actual input bytes before timing. Raw inputs have 50,000 rows/no header; typed inputs add Name/Id/Date/Value headers. All eight inflated part names, lengths and SHA256 are identical per shape across both recipes, runtimes and domains. Actual package hashes and timestamps vary and remain individually recorded; this does not prove every differing ZIP byte is metadata. No fixture copies were made.

## Actual measured iteration work and warnings

| Domain | Runtime | Method | Operations/iteration | Min → max actual duration (ms) |
|---|---|---|---:|---:|
| 0 | before-e676 | RawReadBenchmarks.ExcelReaderOriginal | 173 | 933.623 → 997.691 |
| 0 | before-e676 | RawReadBenchmarks.OfficeIMOOriginal | 87 | 955.139 → 1076.891 |
| 0 | before-e676 | TypedXlsbReadBenchmarks.ExcelReaderTypedXlsb | 119 | 971.989 → 1077.505 |
| 0 | before-e676 | TypedXlsbReadBenchmarks.OfficeIMOTypedXlsb | 97 | 983.942 → 1115.926 |
| 0 | current-830951 | RawReadBenchmarks.ExcelReaderOriginal | 185 | 966.733 → 1047.794 |
| 0 | current-830951 | RawReadBenchmarks.OfficeIMOOriginal | 101 | 787.588 → 1175.847 |
| 0 | current-830951 | TypedXlsbReadBenchmarks.ExcelReaderTypedXlsb | 106 | 727.441 → 1023.606 |
| 0 | current-830951 | TypedXlsbReadBenchmarks.OfficeIMOTypedXlsb | 104 | 1031.954 → 1196.298 |
| 1 | current-830951 | RawReadBenchmarks.ExcelReaderOriginal | 247 | 997.527 → 1342.513 |
| 1 | current-830951 | RawReadBenchmarks.OfficeIMOOriginal | 122 | 859.823 → 974.827 |
| 1 | current-830951 | TypedXlsbReadBenchmarks.ExcelReaderTypedXlsb | 161 | 965.603 → 1485.926 |
| 1 | current-830951 | TypedXlsbReadBenchmarks.OfficeIMOTypedXlsb | 144 | 931.432 → 1181.563 |
| 1 | before-e676 | RawReadBenchmarks.ExcelReaderOriginal | 244 | 963.590 → 1094.105 |
| 1 | before-e676 | RawReadBenchmarks.OfficeIMOOriginal | 141 | 1022.870 → 1498.962 |
| 1 | before-e676 | TypedXlsbReadBenchmarks.ExcelReaderTypedXlsb | 143 | 898.012 → 1318.629 |
| 1 | before-e676 | TypedXlsbReadBenchmarks.OfficeIMOTypedXlsb | 86 | 638.912 → 988.370 |

All 15 measured values and detected outliers per case are retained, along with native confidence intervals and exact actual measurements. The ≥100 ms guard is satisfied; one launch, distribution warnings and domain-sensitive results still bound the claims.

### qualified-830951-long-v1-domain 0-native-attribution-before

- Finished:10/08/2026 15:28:34; expected/completed/successful: 4/4/4; capture clean: True.
- Native grouped table: [OfficeIMO.Excel.ReaderComparison.Benchmarks.RawReadBenchmarks-report-github.md](D:\Dev\Scratch\officeimo-excelreader-performance\final-runs\qualified-830951-long-v1-domain 0-native-attribution-before\20261008-152559\OfficeIMO.Excel.ReaderComparison.Benchmarks.RawReadBenchmarks-report-github.md).
- Native grouped table: [OfficeIMO.Excel.ReaderComparison.Benchmarks.TypedXlsbReadBenchmarks-report-github.md](D:\Dev\Scratch\officeimo-excelreader-performance\final-runs\qualified-830951-long-v1-domain 0-native-attribution-before\20261008-152559\OfficeIMO.Excel.ReaderComparison.Benchmarks.TypedXlsbReadBenchmarks-report-github.md).

No native warning rows.

### qualified-830951-long-v1-domain 0-native-attribution-current

- Finished:10/08/2026 15:31:16; expected/completed/successful: 4/4/4; capture clean: True.
- Native grouped table: [OfficeIMO.Excel.ReaderComparison.Benchmarks.RawReadBenchmarks-report-github.md](D:\Dev\Scratch\officeimo-excelreader-performance\final-runs\qualified-830951-long-v1-domain 0-native-attribution-current\20261008-152836\OfficeIMO.Excel.ReaderComparison.Benchmarks.RawReadBenchmarks-report-github.md).
- Native grouped table: [OfficeIMO.Excel.ReaderComparison.Benchmarks.TypedXlsbReadBenchmarks-report-github.md](D:\Dev\Scratch\officeimo-excelreader-performance\final-runs\qualified-830951-long-v1-domain 0-native-attribution-current\20261008-152836\OfficeIMO.Excel.ReaderComparison.Benchmarks.TypedXlsbReadBenchmarks-report-github.md).

No native warning rows.

### qualified-830951-long-v1-domain 1-native-attribution-current

- Finished:10/08/2026 15:33:50; expected/completed/successful: 4/4/4; capture clean: True.
- Native grouped table: [OfficeIMO.Excel.ReaderComparison.Benchmarks.RawReadBenchmarks-report-github.md](D:\Dev\Scratch\officeimo-excelreader-performance\final-runs\qualified-830951-long-v1-domain 1-native-attribution-current\20261008-153121\OfficeIMO.Excel.ReaderComparison.Benchmarks.RawReadBenchmarks-report-github.md).
- Native grouped table: [OfficeIMO.Excel.ReaderComparison.Benchmarks.TypedXlsbReadBenchmarks-report-github.md](D:\Dev\Scratch\officeimo-excelreader-performance\final-runs\qualified-830951-long-v1-domain 1-native-attribution-current\20261008-153121\OfficeIMO.Excel.ReaderComparison.Benchmarks.TypedXlsbReadBenchmarks-report-github.md).

> MultimodalDistribution
>   TypedXlsbReadBenchmarks.ExcelReaderTypedXlsb: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12 -> It seems that the distribution can have several modes (mValue = 3)

### qualified-830951-long-v1-domain 1-native-attribution-before

- Finished:10/08/2026 15:36:42; expected/completed/successful: 4/4/4; capture clean: True.
- Native grouped table: [OfficeIMO.Excel.ReaderComparison.Benchmarks.RawReadBenchmarks-report-github.md](D:\Dev\Scratch\officeimo-excelreader-performance\final-runs\qualified-830951-long-v1-domain 1-native-attribution-before\20261008-153353\OfficeIMO.Excel.ReaderComparison.Benchmarks.RawReadBenchmarks-report-github.md).
- Native grouped table: [OfficeIMO.Excel.ReaderComparison.Benchmarks.TypedXlsbReadBenchmarks-report-github.md](D:\Dev\Scratch\officeimo-excelreader-performance\final-runs\qualified-830951-long-v1-domain 1-native-attribution-before\20261008-153353\OfficeIMO.Excel.ReaderComparison.Benchmarks.TypedXlsbReadBenchmarks-report-github.md).

> MultimodalDistribution
>   TypedXlsbReadBenchmarks.ExcelReaderTypedXlsb: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-e67677",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12 -> It seems that the distribution can have several modes (mValue = 3)

Original packets and the short derived stage remain unchanged. This extraction writes only the three compact task-scratch deliverables; source/build/test/timing/archive actions remain zero. Native grouped tables remain authoritative.
