# Sealed ADO reader results — domain 0, 2026-10-08

The packet contains nine successful cases, nine normalized summaries and 135 retained actual measurements. Every actual measured iteration passes the ≥100 ms guard; the range is **161.006–1,395.604 ms**. One distribution warning and seven outlier hint rows remain visible, with all 11 detected native outlier values retained. The duration guard does not establish stable distributions or a portable ranking.

This is the selected primary ADO domain0 capture at source/runtime **83095146282a96143b23a79a7ecca058a24a709b**, separate from the earlier supplementary recipe probes. It covers ExcelReader.NET 6.0.0, OfficeIMO 3.4.4+830951 and Sylvan.Data.Excel 0.5.8 through IDataReader interface dispatch, with **50,000 data rows and four fields**. Native reports and the immutable normalized import remain unchanged; no measurements are pooled.

The job uses one launch, 12 warmups, 15 measurements, 1000 ms Pilot, unroll 1 and DontRemove, with High process priority and affinity **0xFFFF**. BDN 0.15.8 reports Windows 11 (10.0.26300.9457), AMD Ryzen 9 9950X3D2, 16 physical/32 logical cores and .NET 10.0.12 with SDK 10.0.112. The setup log records High performance power plan. Full metadata, native confidence intervals/statistics, original samples, outliers, child identities, assemblies and actual input declarations are retained in JSON.

## Accessor contracts

- **GetValue** calls all four fields and counts non-null object references. This fully populated fixture yields 200,000. Header, typed values, GetValue conversions, order and count are checked outside timing. The counter alone does not test DBNull-versus-null behavior for missing cells.
- **TypedGetters** calls GetString(Name), GetInt32(Id), GetDateTime(Date), GetDouble(Value) on every row. The timed accumulator uses name length, id, Date.Day and truncated numeric value; complete fields are validated outside timing.
- **Utf8TextCopy** copies Name into a reused caller-owned 256-byte buffer and accumulates returned lengths. Full byte equality and length are checked against UTF8 encoding outside timing, alongside all four scalar fields. The peer defines textual copying on GetBytes; OfficeIMO and Sylvan use the public Core GetUtf8Bytes extension, preserving their binary GetBytes behavior. This is owned text copying, separate from a borrowed-span read.

Each operation includes public opening, traversal and disposal over prepared in-memory input. Fixture generation, input/shape validation, full-field checks and the reused copy-buffer allocation are outside timing. GlobalSetup validates all three providers and each selected accumulator; successful native child execution is the retained proof. This setup emits no separate ADO validation-success message.

Compare only within the same Access contract. The native grouped table is preserved below; its ratios do not compare GetValue with typed getters or text copying. Native provider representations and conversion costs remain visible.

## Original grouped native table

```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host]     : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Job-KJRLRQ : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

OutlierMode=DontRemove  Affinity=00000000000000001111111111111111  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=15  IterationTime=1s  LaunchCount=1  
UnrollFactor=1  WarmupCount=12  

```
| Method      | RowCount | Access       | Mean      | Error     | StdDev    | Ratio | RatioSD | Gen0     | Gen1    | Gen2    | Allocated  | Alloc Ratio |
|------------ |--------- |------------- |----------:|----------:|----------:|------:|--------:|---------:|--------:|--------:|-----------:|------------:|
| **ExcelReader** | **50000**    | **GetValue**     | **10.359 ms** | **0.6254 ms** | **0.5850 ms** |  **1.00** |    **0.08** | **108.6957** |       **-** |       **-** | **5136.55 KB** |        **1.00** |
| OfficeIMO   | 50000    | GetValue     | 14.931 ms | 0.7828 ms | 0.7322 ms |  1.45 |    0.10 |  52.6316 |       - |       - | 4482.33 KB |        0.87 |
| Sylvan      | 50000    | GetValue     | 37.024 ms | 3.6508 ms | 3.4150 ms |  3.58 |    0.37 | 157.8947 |       - |       - | 8382.87 KB |        1.63 |
|             |          |              |           |           |           |       |         |          |         |         |            |             |
| **ExcelReader** | **50000**    | **TypedGetters** |  **8.511 ms** | **1.1360 ms** | **1.0626 ms** |  **1.02** |    **0.18** |  **36.2319** |       **-** |       **-** | **1619.25 KB** |        **1.00** |
| OfficeIMO   | 50000    | TypedGetters | 12.573 ms | 0.4880 ms | 0.4565 ms |  1.50 |    0.19 |        - |       - |       - |  833.01 KB |        0.51 |
| Sylvan      | 50000    | TypedGetters | 36.204 ms | 7.1431 ms | 6.6817 ms |  4.32 |    0.95 |        - |       - |       - | 1939.62 KB |        1.20 |
|             |          |              |           |           |           |       |         |          |         |         |            |             |
| **ExcelReader** | **50000**    | **Utf8TextCopy** |  **8.130 ms** | **0.5258 ms** | **0.4918 ms** |  **1.00** |    **0.08** |        **-** |       **-** |       **-** |    **4.55 KB** |        **1.00** |
| OfficeIMO   | 50000    | Utf8TextCopy |  9.597 ms | 0.4454 ms | 0.4166 ms |  1.18 |    0.08 |  31.5789 | 31.5789 | 31.5789 |  832.98 KB |      182.88 |
| Sylvan      | 50000    | Utf8TextCopy | 38.674 ms | 1.4343 ms | 1.3417 ms |  4.77 |    0.31 |  76.9231 |       - |       - | 4283.37 KB |      940.43 |

## Actual iteration durations

- ExcelReader; RowCount=50000&Access=GetValue: 92 operations/iteration; actual duration 862.867–1069.918 ms; 1 detected outlier values retained.
- OfficeIMO; RowCount=50000&Access=GetValue: 19 operations/iteration; actual duration 251.770–306.598 ms; 1 detected outlier values retained.
- Sylvan; RowCount=50000&Access=GetValue: 19 operations/iteration; actual duration 627.671–858.423 ms; 1 detected outlier values retained.
- ExcelReader; RowCount=50000&Access=TypedGetters: 138 operations/iteration; actual duration 964.939–1395.604 ms; 0 detected outlier values retained.
- OfficeIMO; RowCount=50000&Access=TypedGetters: 14 operations/iteration; actual duration 161.006–188.357 ms; 4 detected outlier values retained.
- Sylvan; RowCount=50000&Access=TypedGetters: 24 operations/iteration; actual duration 656.893–1179.195 ms; 0 detected outlier values retained.
- ExcelReader; RowCount=50000&Access=Utf8TextCopy: 119 operations/iteration; actual duration 882.429–1122.609 ms; 1 detected outlier values retained.
- OfficeIMO; RowCount=50000&Access=Utf8TextCopy: 95 operations/iteration; actual duration 825.352–977.191 ms; 2 detected outlier values retained.
- Sylvan; RowCount=50000&Access=Utf8TextCopy: 26 operations/iteration; actual duration 923.921–1060.455 ms; 1 detected outlier values retained.

## Input and provenance

All nine children generated a 773,409-byte Original XLSX with one S1 worksheet, Name/Id/Date/Value headers and 50,000 data rows. Source-enforced shape validation checks 50,001 total rows, 200,004 cells, implicit coordinates, no dimension and 50,004 inline text cells. Id=index; Date=FromOADate(45292+index%3650+0.25); Value=index*1.5. The names repeat alpha, beta, gamma, delta, epsilon, zeta, eta, theta by index modulo 8.

The nine timestamped archives have nine actual package hashes. Their six inflated XML-part lengths and hashes are identical across all children, including the 5,969,331-byte worksheet. Per-child archive SHA, ZIP timestamps/compressed sizes and the full part ledger remain in JSON. No fixture bytes were read or copied for this derivation.

The five native artifacts were verified against the sidecar's exact SHA256 and length. All nine child processes exited 0 and recorded High priority/0xFFFF. Every normalized summary and sample matches native original values/statistics and allocation counts. The current 437,248-byte harness hash also matches its captured metadata.

- [Native full JSON](D:\Dev\Scratch\officeimo-excelreader-performance\final-runs\qualified-830951-long-v1-domain0-ado\20261008-171741\OfficeIMO.Excel.ReaderComparison.Benchmarks.AdoReadBenchmarks-report-full.json)
- [Native grouped Markdown](D:\Dev\Scratch\officeimo-excelreader-performance\final-runs\qualified-830951-long-v1-domain0-ado\20261008-171741\OfficeIMO.Excel.ReaderComparison.Benchmarks.AdoReadBenchmarks-report-github.md)
- [Immutable normalized import](D:\Dev\Scratch\officeimo-excelreader-performance\final-runs\qualified-830951-long-v1-domain0-ado-normalized.json)
- [Run context](D:\Dev\Scratch\officeimo-excelreader-performance\final-runs\qualified-830951-long-v1-domain0-ado-context.json)
- [Provenance sidecar](D:\Dev\Scratch\officeimo-excelreader-performance\final-runs\qualified-830951-long-v1-domain0-ado\.powerforge-benchmark-provenance.json)

## Warnings, outliers and host limits

### Native Warnings

> MultimodalDistribution
>   AdoReadBenchmarks.ExcelReader: OutlierMode=DontRemove, Affinity=00000000000000001111111111111111, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12 -> It seems that the distribution can have several modes (mValue = 3.14)

### Native Hints

> Outliers
>   AdoReadBenchmarks.ExcelReader: OutlierMode=DontRemove, Affinity=00000000000000001111111111111111, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12 -> 1 outlier  was  detected (11.63 ms)
>   AdoReadBenchmarks.OfficeIMO: OutlierMode=DontRemove, Affinity=00000000000000001111111111111111, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12   -> 1 outlier  was  detected (13.25 ms)
>   AdoReadBenchmarks.Sylvan: OutlierMode=DontRemove, Affinity=00000000000000001111111111111111, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12      -> 1 outlier  was  detected (45.18 ms)
>   AdoReadBenchmarks.OfficeIMO: OutlierMode=DontRemove, Affinity=00000000000000001111111111111111, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12   -> 4 outliers were detected (11.50 ms, 11.96 ms, 13.16 ms, 13.45 ms)
>   AdoReadBenchmarks.ExcelReader: OutlierMode=DontRemove, Affinity=00000000000000001111111111111111, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12 -> 1 outlier  was  detected (9.43 ms)
>   AdoReadBenchmarks.OfficeIMO: OutlierMode=DontRemove, Affinity=00000000000000001111111111111111, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12   -> 2 outliers were detected (8.69 ms, 8.89 ms)
>   AdoReadBenchmarks.Sylvan: OutlierMode=DontRemove, Affinity=00000000000000001111111111111111, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12      -> 1 outlier  was  detected (35.54 ms)

Native warning/hint display omits the Access parameters. These method-level lines remain in their original sections; exact per-case outlier arrays are retained in JSON. The normalized summary's outlierCount is not substituted for BDN's detected outliers. DontRemove retains the samples.

The source sidecar spans 15:17:41.5151971Z–15:22:08.9906084Z; context seals at 15:22:09.037922Z. Native global total is 266.22 seconds. Pre/post process snapshots contain 94/83 entries, 66 persistent matches and 17 new after-snapshot IDs. Maximum persistent CPU delta is 0.125 seconds; their total is 1.3125 seconds. A testhost appears before and is absent after. Without process roles or per-case timelines, these snapshots prove neither full isolation nor causal contamination. The original snapshots are retained unchanged. Firmware, chipset-driver, VBS and per-case frequency data are not established by this packet.

Only this sealed ADO packet was derived. Source, builds, tests, timing, fixtures, archives, cleanup and shared publication files were untouched.
