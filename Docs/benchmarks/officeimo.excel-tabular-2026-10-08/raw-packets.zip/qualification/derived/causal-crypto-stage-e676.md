# Authenticated workbook Core-only intervention — e676 capture stage

Four sealed packets contain eight successful OfficeIMO cases: two CPU domains × file/byte-array input × before/Core-only intervention. This is a causal attribution stage with fixed caller/work/input, not a whole final-candidate or library-peer comparison. Older316/36df timings remain separate and are not relabelled.

Replacing Core ba9 with Core4ee reduces mean time by an arithmetic factor of 6.24–6.76 for the selected small authenticated workbook, and reduces managed allocations by about 99.60–99.62%. This scope includes password derivation, complete authenticated decryption/buffering, field scanning and disposal. The tiny two-row fixture is dominated by crypto/opening; these values do not establish the effect on a 300K workbook, other encryption parameters, async paths or the complete later candidate.

## Controlled before/after results

Times are native means ± SD in milliseconds. Ratios are explicit quotients of recorded means, not a significance test. Allocations are exact managed bytes per operation.

| Domain | Actual input route | Before mean ± SD (ms) | Core-only mean ± SD (ms) | Before/after mean ratio | Before bytes | After bytes |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| 0 | FileStream opener | 189.878 ± 7.930 | 28.100 ± 2.276 | 6.757 | 144583008 | 572239 |
| 0 | byte[] opener | 182.793 ± 7.420 | 27.533 ± 1.549 | 6.639 | 144562916 | 552553 |
| 1 | FileStream opener | 176.548 ± 6.445 | 27.664 ± 1.202 | 6.382 | 144578908 | 570732 |
| 1 | byte[] opener | 170.381 ± 7.039 | 27.295 ± 1.405 | 6.242 | 144559036 | 550878 |

## Owner and harness attribution

Canonical provenance capture source is e676775a59458d1095606386c39506ceb8a9bc33 with a clean worktree. It is not the runtime or private harness source. The private harness snapshot is ba9f21651d204ba1171735d26cc48c6d0a99f765 plus unchanged authenticated workload 4be388b9f1 and native-width affinity wiring. Its source-identity SHA256 is FFD5C7C94B3BC0B53AC4591AD3F7EAC3AF83ECA0AEFAB34EBD71BDFC32350694. Program and all three authenticated workload source-file hashes match that manifest. The Program wiring donor 316 reference is source ancestry only, not a 316 timing capture.

| Component | Before | Core-only intervention |
| --- | --- | --- |
| Core embedded source | ba9f21651d204ba1171735d26cc48c6d0a99f765 | 4ee00bfa851b7b9d14b30058c67e036e53578c95 |
| Core SHA256 | 4222C2E8DDCD62B6CC253D1B43D8519FF0D7C9EC5AF1110491ABC07F5A9C1D97 | 0336BCBF8D00E6519401CB79795F85B0C6753E2E8839B8370D3A246637D1A824 |
| Excel SHA256, unchanged ba9 | BD540DD1F7BEF8D8C5BD51147D9F5180FE30EB9CBCFF7AF699097E810A7E0403 | Same |
| Harness DLL SHA256 | CC38E56446699E12172F19E6EE9BD14F7A2A53292B9E5A8A2BC8DC4F805074E2 | 9D4A1CED39F1EE2FD34930B5C1FC9FD8C8FF6D5D1F26B4C2A74489D9F6D48A77 |

Harness binaries differ by reference/build selector; the source snapshot and authenticated operation remain fixed. All measured child Excel/Core identities match sealed metadata. The saved bundle manifests retain identical Excel/CSV/Arrow bytes and identify a Core delta confined to OfficeEncryption.cs and OfficeEncryption.PasswordDerivation.cs; CSV/Arrow are not used by this timed route. Full metadata and both bundle-manifest identities remain in the JSON.

## Input and authenticated work

All eight cases use OriginalSmallXlsx: exactly two rows, two columns, full-field checksum 12, password hunter2 and Agile AES-256-CBC/SHA-512/spin100000/dataIntegrity. The pinned ca5b50f99e8ef57ab476f0a2bc8043558d58b28d upstream corpus identifies the fixture bytes; the original small encryption producer is unpinned. Independent msoffcrypto-tool 6.0.0 authenticated decryption provides the plaintext oracle. Each setup records every value/type/order, sheet and row-count equivalence against the plaintext reader and both integrity-verifying readers; successful native qualification lines are retained per case.

| Input artifact | Bytes | SHA256 |
| --- | ---: | --- |
| Encrypted small XLSX | 15,360 | 13F9532B916634CB112D3593E7AB859F67B2DA35A3A47E574F1C1E26C5DA370D |
| Independently authenticated plaintext | 8,915 | 85FBDE3D5CC6C936BE8D9C8A5F9658E4CDED25145A2E6449C5D1FCD54F64E602 |

MemoryInput=false creates, reads and disposes a FileStream inside the measured operation. MemoryInput=true passes the byte array prepared in setup to the public byte[] opener; it is not a MemoryStream route. Both include complete decryption and integrity verification, field accumulation and reader disposal. The fixture descriptor stream=FileStream describes its available file path, while the actual measured route is controlled by MemoryInput. File timings follow warmups and do not measure cold physical-disk throughput. No integrity-disabled, open-only, row-width-only or peer timed method belongs in this causal table.

## Native job, warnings and complete case ledger

The policy is native Pilot at 250 ms, 12 warmups, 15 measured iterations, one launch, unroll 1 and DontRemove outliers. Pilot selects four operations per before iteration and ten per Core-only iteration; results are per operation. All eight cases retain 15 samples. Minimum actual workload duration is 246.046 ms, above 100 ms, and no MinIterationTime warning appears. One native warning reports a bimodal distribution in domain 0 Core-only; its exact text, per-case intervals and detected outlier values remain in the JSON. CPU domains share one host and are reported separately.

| Domain | Core lane | Full parameters | Mean ± SD (ms) | Median (ms) | Allocated bytes | Actual operations | Retained detected outliers | Min iteration (ms) |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| 0 | before | Input=OriginalSmallXlsx&MemoryInput=False | 189.878 ± 7.930 | 191.356 | 144583008 | 4 | 1 | 686.717 |
| 0 | before | Input=OriginalSmallXlsx&MemoryInput=True | 182.793 ± 7.420 | 181.524 | 144562916 | 4 | 2 | 670.186 |
| 0 | core-only | Input=OriginalSmallXlsx&MemoryInput=False | 28.100 ± 2.276 | 28.234 | 572239 | 10 | 1 | 249.717 |
| 0 | core-only | Input=OriginalSmallXlsx&MemoryInput=True | 27.533 ± 1.549 | 27.953 | 552553 | 10 | 0 | 251.432 |
| 1 | before | Input=OriginalSmallXlsx&MemoryInput=False | 176.548 ± 6.445 | 175.478 | 144578908 | 4 | 0 | 665.448 |
| 1 | before | Input=OriginalSmallXlsx&MemoryInput=True | 170.381 ± 7.039 | 169.298 | 144559036 | 4 | 0 | 646.901 |
| 1 | core-only | Input=OriginalSmallXlsx&MemoryInput=False | 27.664 ± 1.202 | 27.217 | 570732 | 10 | 0 | 255.247 |
| 1 | core-only | Input=OriginalSmallXlsx&MemoryInput=True | 27.295 ± 1.405 | 27.258 | 550878 | 10 | 0 | 246.046 |

The sole measured method is OfficeIMO.Excel.ReaderComparison.Benchmarks.EncryptedVerifiedReadBenchmarks.OfficeIMOVerifiedFullFields. Every full name/job/domain/Core owner and runtime hash is retained in JSON. All eight native full names survive normalized summaries. The four completed sidecars list 20 native artifacts; every SHA/length matches and all eight child processes exit successfully.

## Handoff

Use causal-crypto-stage-e676.json for exact samples, intervals, identities and canonical artifact paths. This stage is not pooled with older 316/36df observations or final whole-candidate/peer comparisons. No new timing, build, test, source edit, input copying, archive assembly or publication occurred.
