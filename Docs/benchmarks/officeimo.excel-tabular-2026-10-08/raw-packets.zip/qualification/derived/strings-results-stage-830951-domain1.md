# Qualified shared-string capture, domain1

All 47 cases/47 successful children and 564 samples match native and normalized statistics/diagnostic allocation; all 25 native artifacts match SHA-256 and byte length. Frozen 830951, High/0xFFFF0000; domain0 timing/allocation is not pooled.

Recipe: 1 launch, 8 warmups, 12 actual iterations, 1-second target, unroll 1, DontRemove. Raw actuals 473.9745–1928.5801 ms, all at least 100 ms. Native rows: 0 short-iteration warnings, 0 distribution warnings, 21 outlier hints; 26 outlier values retained. Elapsed 1264.9352731 s; 2026-10-08T19:26:11.9898963+00:00 to 2026-10-08T19:47:16.9251694+00:00, sealed 2026-10-08T19:47:17.0027570Z.

All 47 cases and 564 native corrected/normalized actual samples match. Six native class tables, all 25 native artifacts and loaded runtime identities are retained. Native statistics, diagnostic allocation, per-case outlier arrays and all warning/hint lines remain separate.

Domain1 is an independent capture at High/0xFFFF0000. Input content/length identities agree with domain0 for each matching case. Timings and allocation are not pooled, and differences are not assigned to cache placement or host isolation.

First-row values measure public caller latency with different initialization/validation lifecycles. The completed source assessment records OfficeIMO selected-worksheet qualification and complete selected shared-string table materialization, including later unreferenced items. This remains a valid measured cost, not a full-scan or cold-process ratio.

Raw borrowed APIs, materialized strings, stream/byte input, prefetch/interning and public UTF8 cache contracts remain separately labelled. Peer-only borrowed 65,536 scans have no paired OfficeIMO method in that class; OfficeIMO public UTF8 coverage is the separate 100K class.

OfficeIMO losses on materialized/shared-string UTF8/first-row workloads are retained. Public UTF8 borrows provider-owned normalized cache; fresh reader/cache initialization, full validation, decoding and encoding misses remain inside measured calls. No zero-allocation or retained-cache claim.

Pre/post host snapshots are bounded endpoint evidence. They do not prove an idle host, identify process roles, capture all transient activity or establish causes of timing variation.

Seven input shapes; all 47 matched domain0 cases have equal inflated part names/lengths/SHA, compressed lengths and package lengths. Exact package SHA matches 0/47; timestamps/hashes retained without exclusive causal explanation. Stored/Deflated inflated identity checked per format/row count; no fixture copy or re-open.

## MaterializedStringHeavyReadBenchmarks (10 cases)

Same complete eleven-field input, all strings materialized. Peer default versus InternStrings=true are separate policies. Numeric/date APIs and scalar boxing remain visible; full count/checksum consumed and fields/types/order checked. Fresh reader opening/scan/disposal included; byte/Stream variants separate.

| Method | Input parameters | Mean ms | SD ms | Managed bytes/op, native diagnostic |
|---|---|---:|---:|---:|
| ExcelReaderStringsMaterialized | Format: Xlsx, RowCount: 65536 | 46.947611 | 2.235940 | 15989611 |
| ExcelReaderStringsInterned | Format: Xlsx, RowCount: 65536 | 45.928708 | 1.250876 | 15997726 |
| OfficeIMOBytes | Format: Xlsx, RowCount: 65536 | 77.030638 | 5.454442 | 20036567 |
| OfficeIMOStream | Format: Xlsx, RowCount: 65536 | 75.285284 | 5.313317 | 26688699 |
| Sylvan | Format: Xlsx, RowCount: 65536 | 135.309860 | 8.399310 | 18253408 |
| ExcelReaderStringsMaterialized | Format: Xlsb, RowCount: 65536 | 46.713649 | 2.264195 | 15988916 |
| ExcelReaderStringsInterned | Format: Xlsb, RowCount: 65536 | 47.278681 | 2.050839 | 15997156 |
| OfficeIMOBytes | Format: Xlsb, RowCount: 65536 | 49.552930 | 2.549850 | 33078986 |
| OfficeIMOStream | Format: Xlsb, RowCount: 65536 | 47.820299 | 2.152371 | 41205431 |
| Sylvan | Format: Xlsb, RowCount: 65536 | 57.859573 | 4.080870 | 18226043 |

## SharedStringBorrowedScanBenchmarks (4 cases)

Peer-only full borrowed UTF8 scan on Deflated/Stored XLSX at 65,536 data rows, default versus PrefetchDecompression=true. Complete semantic proof/checksum/count. No paired OfficeIMO method in this class; the separate 100K public UTF8 class provides OfficeIMO coverage.

| Method | Input parameters | Mean ms | SD ms | Managed bytes/op, native diagnostic |
|---|---|---:|---:|---:|
| ExcelReaderBorrowed | RowCount: 65536, Storage: Deflated | 35.726438 | 1.399768 | 2286056 |
| ExcelReaderBorrowedPrefetch | RowCount: 65536, Storage: Deflated | 28.284931 | 0.802559 | 2373773 |
| ExcelReaderBorrowed | RowCount: 65536, Storage: Stored | 14.927225 | 0.931030 | 2284976 |
| ExcelReaderBorrowedPrefetch | RowCount: 65536, Storage: Stored | 16.682587 | 0.661319 | 2299996 |

## SharedStringFirstRowBenchmarks (6 cases)

Public open through first Read/MoveNext, then disposal. Timed result is header-row availability; complete fields/input proved outside timing. Deflated/Stored XLSX separate. OfficeIMO qualifies the selected worksheet and materializes the complete selected shared-string table, including later unreferenced items, before delivery; peer public initialization/validation lifecycles differ. First-row caller latency is separate from full-sheet validation work and process-cold first-use.

| Method | Input parameters | Mean ms | SD ms | Managed bytes/op, native diagnostic |
|---|---|---:|---:|---:|
| ExcelReaderOpenThroughFirstRow | RowCount: 65536, Storage: Deflated | 13.267986 | 0.388487 | 765240 |
| OfficeIMOOpenThroughFirstRow | RowCount: 65536, Storage: Deflated | 68.120311 | 5.528496 | 15317486 |
| SylvanOpenThroughFirstRow | RowCount: 65536, Storage: Deflated | 0.060791 | 0.004143 | 328624 |
| ExcelReaderOpenThroughFirstRow | RowCount: 65536, Storage: Stored | 3.228990 | 0.032401 | 764160 |
| OfficeIMOOpenThroughFirstRow | RowCount: 65536, Storage: Stored | 42.783717 | 3.043396 | 15315543 |
| SylvanOpenThroughFirstRow | RowCount: 65536, Storage: Stored | 0.057844 | 0.004750 | 327769 |

## SharedStringFullScanBenchmarks (3 cases)

Complete materialized eleven-field scan at 65,536 data rows plus header, Stored XLSX. Stored rewrite preserves inflated parts. Full count/checksum consumed; expected fields/types/order checked. Opening/scan/disposal included; separate from first-row/borrowed/cache policies.

| Method | Input parameters | Mean ms | SD ms | Managed bytes/op, native diagnostic |
|---|---|---:|---:|---:|
| ExcelReaderStringsMaterialized | RowCount: 65536, Storage: Stored | 39.788428 | 5.642107 | 16354935 |
| OfficeIMOStringsMaterialized | RowCount: 65536, Storage: Stored | 63.889946 | 3.718558 | 20034658 |
| SylvanStringsMaterialized | RowCount: 65536, Storage: Stored | 122.703118 | 7.654549 | 18252176 |

## SharedStringUtf8ReadBenchmarks (12 cases)

100,000 data rows plus header, eight text and three typed columns, XLSX/XLSB and Deflated/Stored. Every normalized UTF8 byte and scalar field checked individually. Full byte-length/checksum/count consumed through public borrowing: OfficeIMO TryGetUtf8Text with normal GetValue for three scalars versus peer public borrowed row parsing. Each invocation opens a fresh reader and includes OfficeIMO complete validation/normalized SST loading, encoding/cache misses. Default/prefetch separate; no retained-cache or zero-allocation claim.

| Method | Input parameters | Mean ms | SD ms | Managed bytes/op, native diagnostic |
|---|---|---:|---:|---:|
| ExcelReaderBorrowed | Format: Xlsx, RowCount: 100000, Storage: Deflated | 49.950932 | 1.649157 | 3036552 |
| ExcelReaderBorrowedPrefetch | Format: Xlsx, RowCount: 100000, Storage: Deflated | 40.318143 | 1.255043 | 3141396 |
| OfficeIMOBorrowedSharedUtf8 | Format: Xlsx, RowCount: 100000, Storage: Deflated | 159.411421 | 9.033566 | 93053085 |
| ExcelReaderBorrowed | Format: Xlsx, RowCount: 100000, Storage: Stored | 24.252998 | 1.336271 | 3035472 |
| ExcelReaderBorrowedPrefetch | Format: Xlsx, RowCount: 100000, Storage: Stored | 24.850459 | 0.766944 | 3055437 |
| OfficeIMOBorrowedSharedUtf8 | Format: Xlsx, RowCount: 100000, Storage: Stored | 204.632979 | 14.416147 | 93595932 |
| ExcelReaderBorrowed | Format: Xlsb, RowCount: 100000, Storage: Deflated | 52.851786 | 4.396592 | 3036044 |
| ExcelReaderBorrowedPrefetch | Format: Xlsb, RowCount: 100000, Storage: Deflated | 32.966574 | 0.309478 | 3138217 |
| OfficeIMOBorrowedSharedUtf8 | Format: Xlsb, RowCount: 100000, Storage: Deflated | 103.383570 | 2.829146 | 108465862 |
| ExcelReaderBorrowed | Format: Xlsb, RowCount: 100000, Storage: Stored | 20.418722 | 0.496002 | 3034960 |
| ExcelReaderBorrowedPrefetch | Format: Xlsb, RowCount: 100000, Storage: Stored | 22.935588 | 0.892906 | 3052644 |
| OfficeIMOBorrowedSharedUtf8 | Format: Xlsb, RowCount: 100000, Storage: Stored | 78.479705 | 3.082344 | 108463748 |

## StringHeavyReadBenchmarks (12 cases)

65,536 data rows plus header: eight text and three typed columns from the pinned upstream generator. Full expected fields/types/order/count checked outside timing; checksum/count inside. Peer borrowed raw text, default/prefetch and ReadOnlyMemory routes differ from ordinary GetValue strings/scalar objects in OfficeIMO/Sylvan. Byte/Stream routes are separate; no matched-materialization allocation claim for raw APIs.

| Method | Input parameters | Mean ms | SD ms | Managed bytes/op, native diagnostic |
|---|---|---:|---:|---:|
| ExcelReaderOriginal | Format: Xlsx, RowCount: 65536 | 35.428252 | 0.807816 | 2286056 |
| ExcelReaderPrefetch | Format: Xlsx, RowCount: 65536 | 28.048848 | 0.350467 | 2374543 |
| ExcelReaderMemory | Format: Xlsx, RowCount: 65536 | 34.911424 | 1.369872 | 2285800 |
| OfficeIMOBytes | Format: Xlsx, RowCount: 65536 | 91.321795 | 9.973769 | 20036205 |
| OfficeIMOStream | Format: Xlsx, RowCount: 65536 | 72.765619 | 1.652047 | 26688453 |
| Sylvan | Format: Xlsx, RowCount: 65536 | 134.169932 | 7.870026 | 18253408 |
| ExcelReaderOriginal | Format: Xlsb, RowCount: 65536 | 31.986203 | 0.423939 | 2285544 |
| ExcelReaderPrefetch | Format: Xlsb, RowCount: 65536 | 20.101313 | 0.779795 | 2383745 |
| ExcelReaderMemory | Format: Xlsb, RowCount: 65536 | 30.183436 | 0.148793 | 6779360 |
| OfficeIMOBytes | Format: Xlsb, RowCount: 65536 | 44.367208 | 0.396738 | 33078925 |
| OfficeIMOStream | Format: Xlsb, RowCount: 65536 | 46.120288 | 0.985789 | 41205457 |
| Sylvan | Format: Xlsb, RowCount: 65536 | 46.124985 | 1.495079 | 18226560 |

Allocation is native BDN MemoryDiagnoser managed bytes per operation from its diagnostic invocation, separate from elapsed samples and domain0 observations. Native statistics/GC descriptors/original/result/actual values and all warnings/hints remain in JSON/native reports. Method-level hints can omit parameters; no parameter assignment is invented. DontRemove retains outlier samples.

Host endpoints: 46/48 entries; 40 persistent matches; maximum CPU delta 0.343750s, sum 4.718750s. Pre/post snapshots do not identify process roles, CPU during individual cases, or activity of processes absent at either endpoint. They do not prove an idle host or establish causal contamination. Fresh benchmark children and generated builds occur within the capture; original snapshots are retained. No live host audit or later-group inspection.

Source 83095146282a96143b23a79a7ecca058a24a709b; unchanged benchmark e676775a59458d1095606386c39506ceb8a9bc33; harness 5E79575325D94AE8D09B97CD0C1C341EBB6AC0A24C3EEE6AE4817A897F97E7A4; v2 runner C52377235F70A38C61333009FFA2CC97C0BE2B3C102041CB127587B09AB32A95; generated-reference hook CEDF3A831603914A5E024C980CCA65AAAAF25544D98538BC416E963DD8632B12. Saved runtime unchanged.

Completed assessment: [shared-string-first-row-source-note.md](D:/Dev/Scratch/officeimo-xlsb-string-discovery-20261008/shared-string-first-row-source-note.md).
Completed assessment: [shared-string-validation-metadata-assessment.md](D:/Dev/Scratch/officeimo-xlsb-string-discovery-20261008/shared-string-validation-metadata-assessment.md).

Only this three-file packet is written. No source/build/test/package/timing/session/later-group activity, fixture copy, archive or cleanup. Removed 0 bytes; native/import inputs referenced in place. Shared ledger coordinator-owned.
