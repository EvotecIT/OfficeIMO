# Sealed recipe-duration probes — 2026-10-08

Both domains are sealed: 30 successful cases, 450 retained measurements and 26 original artifacts verified. All actual measured iterations pass the ≥100 ms guard; minimum 115.698 ms, maximum 1652.031 ms. The guard removes the observed short-iteration issue; it does not establish stable distributions or a global ranking.

These are supplementary 30 cases, separate from the primary 652. Each domain covers nine ADO accessors, three raw CSV readers and three stored-SST first-row readers. The source/runtime is 83095146282a96143b23a79a7ecca058a24a709b; benchmark source remains byte-identical to e676775a59458d1095606386c39506ceb8a9bc33. All owners/harness/actual inputs, native statistics/intervals, original samples/outliers and warnings are retained in JSON.

The job uses 1 launch, 12 warmups, 15 measurements, 1000 ms Pilot, unroll 1, DontRemove, High process priority and domain masks 65535/4294901760. Native grouped tables are authoritative. These probe cases do not substitute for a later selected Remaining capture.

## Access and lifecycle contracts

- ADO GetValue consumes all four fields through IDataReader interface dispatch and counts non-null values. Typed getters consume Name/Id/Date/Value, with Date.Day in the timed accumulator. UTF8 copy writes Name into a reused 256-byte buffer and times returned counts. Full fields/header/order/count and copied-byte equality are validated outside timing. Peer textual GetBytes is matched by public GetUtf8Bytes; the binary GetBytes contract is preserved.
- Raw CSV parses every scalar field and consumes the name span, with complete checksum/count checks. The source is headerless UTF8/LF with round-trip dates and ASCII names. Office/peer borrowed UTF8 and Sylvan borrowed UTF16 remain distinct representation/provider strategies.
- Stored-SST first-row measures open through first header row and disposal on a 65,536-data-row, 11-field corpus. Full values/types/order/count and ZIP/relationship checks happen in setup. Eager/lazy initialization work differs; first-row results do not measure full traversal.

## Every selected probe measurement

Means/SD are milliseconds; allocations are exact bytes per operation. Keep each class/method/complete parameters/domain/job identity.

| Domain | Type.Method | Full parameters | Mean ± SD (ms) | Allocated bytes | Operations/iteration | Minimum actual duration (ms) |
|---|---|---|---:|---:|---:|---:|
| 0 | AdoReadBenchmarks.ExcelReader | RowCount=50000&Access=GetValue | 11.961 ± 0.238 | 5260321 | 84 | 974.944 |
| 0 | AdoReadBenchmarks.OfficeIMO | RowCount=50000&Access=GetValue | 18.177 ± 0.360 | 4594956 | 55 | 965.085 |
| 0 | AdoReadBenchmarks.Sylvan | RowCount=50000&Access=GetValue | 61.266 ± 2.148 | 8584181 | 16 | 943.268 |
| 0 | AdoReadBenchmarks.ExcelReader | RowCount=50000&Access=TypedGetters | 12.381 ± 0.477 | 1660459 | 82 | 958.889 |
| 0 | AdoReadBenchmarks.OfficeIMO | RowCount=50000&Access=TypedGetters | 13.956 ± 0.513 | 1038959 | 14 | 183.047 |
| 0 | AdoReadBenchmarks.Sylvan | RowCount=50000&Access=TypedGetters | 45.093 ± 2.356 | 1986757 | 21 | 832.934 |
| 0 | AdoReadBenchmarks.ExcelReader | RowCount=50000&Access=Utf8TextCopy | 8.444 ± 0.217 | 8984 | 110 | 871.002 |
| 0 | AdoReadBenchmarks.OfficeIMO | RowCount=50000&Access=Utf8TextCopy | 10.706 ± 0.361 | 982945 | 20 | 204.308 |
| 0 | AdoReadBenchmarks.Sylvan | RowCount=50000&Access=Utf8TextCopy | 40.231 ± 1.756 | 4386168 | 27 | 989.839 |
| 0 | CsvRawReadBenchmarks.ExcelReaderOriginal | RowCount=50000 | 2.760 ± 0.066 | 848 | 365 | 961.081 |
| 0 | CsvRawReadBenchmarks.OfficeIMOBorrowedUtf8 | RowCount=50000 | 7.777 ± 0.230 | 3970 | 142 | 1038.484 |
| 0 | CsvRawReadBenchmarks.SylvanOriginal | RowCount=50000 | 4.460 ± 0.101 | 38681 | 222 | 940.577 |
| 0 | SharedStringFirstRowBenchmarks.ExcelReaderOpenThroughFirstRow | RowCount=65536&Storage=Stored | 4.313 ± 0.066 | 764160 | 221 | 923.696 |
| 0 | SharedStringFirstRowBenchmarks.OfficeIMOOpenThroughFirstRow | RowCount=65536&Storage=Stored | 60.558 ± 1.850 | 15315563 | 17 | 983.728 |
| 0 | SharedStringFirstRowBenchmarks.SylvanOpenThroughFirstRow | RowCount=65536&Storage=Stored | 0.055 ± 0.005 | 327763 | 18269 | 891.635 |
| 1 | AdoReadBenchmarks.ExcelReader | RowCount=50000&Access=GetValue | 7.713 ± 0.361 | 5254664 | 130 | 964.081 |
| 1 | AdoReadBenchmarks.OfficeIMO | RowCount=50000&Access=GetValue | 10.877 ± 1.458 | 4452860 | 12 | 115.698 |
| 1 | AdoReadBenchmarks.Sylvan | RowCount=50000&Access=GetValue | 40.767 ± 6.297 | 8583409 | 29 | 1034.734 |
| 1 | AdoReadBenchmarks.ExcelReader | RowCount=50000&Access=TypedGetters | 11.934 ± 0.268 | 1660389 | 83 | 937.172 |
| 1 | AdoReadBenchmarks.OfficeIMO | RowCount=50000&Access=TypedGetters | 11.698 ± 0.719 | 1026556 | 15 | 152.751 |
| 1 | AdoReadBenchmarks.Sylvan | RowCount=50000&Access=TypedGetters | 37.534 ± 6.428 | 1986610 | 28 | 822.407 |
| 1 | AdoReadBenchmarks.ExcelReader | RowCount=50000&Access=Utf8TextCopy | 6.397 ± 0.885 | 8657 | 119 | 648.914 |
| 1 | AdoReadBenchmarks.OfficeIMO | RowCount=50000&Access=Utf8TextCopy | 9.256 ± 1.393 | 997415 | 18 | 122.761 |
| 1 | AdoReadBenchmarks.Sylvan | RowCount=50000&Access=Utf8TextCopy | 41.735 ± 1.989 | 4386493 | 38 | 1355.432 |
| 1 | CsvRawReadBenchmarks.ExcelReaderOriginal | RowCount=50000 | 2.930 ± 0.089 | 1047 | 399 | 1079.263 |
| 1 | CsvRawReadBenchmarks.OfficeIMOBorrowedUtf8 | RowCount=50000 | 6.752 ± 0.652 | 2120 | 133 | 760.230 |
| 1 | CsvRawReadBenchmarks.SylvanOriginal | RowCount=50000 | 4.054 ± 0.157 | 38681 | 263 | 982.167 |
| 1 | SharedStringFirstRowBenchmarks.ExcelReaderOpenThroughFirstRow | RowCount=65536&Storage=Stored | 4.122 ± 0.343 | 803518 | 225 | 773.611 |
| 1 | SharedStringFirstRowBenchmarks.OfficeIMOOpenThroughFirstRow | RowCount=65536&Storage=Stored | 70.872 ± 2.206 | 18504015 | 13 | 875.467 |
| 1 | SharedStringFirstRowBenchmarks.SylvanOpenThroughFirstRow | RowCount=65536&Storage=Stored | 0.073 ± 0.003 | 327777 | 17225 | 1181.226 |

## Actual inputs

| Input | Instances | Bytes | Actual package/plain hash count | Inflated manifest or plain CSV hash count |
|---|---:|---:|---:|---:|
| read/raw/Csv/dataRows=50000 | 6 | 2318990 | 1 | 1 |
| read/typed/Xlsx/Original/dataRows=50000 | 18 | 773409 | 18 | 1 |
| validated-scan/Xlsx/rows=65537/columns=11 | 6 | 25686810 | 6 | 1 |

Every CSV instance has the same exact 2,318,990-byte input hash. Each ZIP shape has one identical inflated-part manifest across methods/domains, with actual generated package hashes/timestamps separately retained. No fixture copying or reassignment of unrelated archive hashes occurred.

## Native warnings and original grouped reports

### qualified-830951-long-v1-domain0-recipe-probe

- Started:10/08/2026 15:36:45; sealed:10/08/2026 15:45:08; expected/completed/successful 15/15/15.
- Native table: [OfficeIMO.Excel.ReaderComparison.Benchmarks.AdoReadBenchmarks-report-github.md](D:\Dev\Scratch\officeimo-excelreader-performance\final-runs\qualified-830951-long-v1-domain0-recipe-probe\20261008-153646\OfficeIMO.Excel.ReaderComparison.Benchmarks.AdoReadBenchmarks-report-github.md).
- Native table: [OfficeIMO.Excel.ReaderComparison.Benchmarks.CsvRawReadBenchmarks-report-github.md](D:\Dev\Scratch\officeimo-excelreader-performance\final-runs\qualified-830951-long-v1-domain0-recipe-probe\20261008-153646\OfficeIMO.Excel.ReaderComparison.Benchmarks.CsvRawReadBenchmarks-report-github.md).
- Native table: [OfficeIMO.Excel.ReaderComparison.Benchmarks.SharedStringFirstRowBenchmarks-report-github.md](D:\Dev\Scratch\officeimo-excelreader-performance\final-runs\qualified-830951-long-v1-domain0-recipe-probe\20261008-153646\OfficeIMO.Excel.ReaderComparison.Benchmarks.SharedStringFirstRowBenchmarks-report-github.md).

> MultimodalDistribution
>   SharedStringFirstRowBenchmarks.OfficeIMOOpenThroughFirstRow: OutlierMode=DontRemove, Affinity=00000000000000001111111111111111, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12 -> It seems that the distribution is bimodal (mValue = 3.5)

### qualified-830951-long-v1-domain1-recipe-probe

- Started:10/08/2026 15:45:10; sealed:10/08/2026 15:53:16; expected/completed/successful 15/15/15.
- Native table: [OfficeIMO.Excel.ReaderComparison.Benchmarks.AdoReadBenchmarks-report-github.md](D:\Dev\Scratch\officeimo-excelreader-performance\final-runs\qualified-830951-long-v1-domain1-recipe-probe\20261008-154511\OfficeIMO.Excel.ReaderComparison.Benchmarks.AdoReadBenchmarks-report-github.md).
- Native table: [OfficeIMO.Excel.ReaderComparison.Benchmarks.CsvRawReadBenchmarks-report-github.md](D:\Dev\Scratch\officeimo-excelreader-performance\final-runs\qualified-830951-long-v1-domain1-recipe-probe\20261008-154511\OfficeIMO.Excel.ReaderComparison.Benchmarks.CsvRawReadBenchmarks-report-github.md).
- Native table: [OfficeIMO.Excel.ReaderComparison.Benchmarks.SharedStringFirstRowBenchmarks-report-github.md](D:\Dev\Scratch\officeimo-excelreader-performance\final-runs\qualified-830951-long-v1-domain1-recipe-probe\20261008-154511\OfficeIMO.Excel.ReaderComparison.Benchmarks.SharedStringFirstRowBenchmarks-report-github.md).

> MultimodalDistribution
>   AdoReadBenchmarks.Sylvan: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12 -> It seems that the distribution can have several modes (mValue = 3)
>   AdoReadBenchmarks.Sylvan: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12 -> It seems that the distribution can have several modes (mValue = 3.14)
> MultimodalDistribution
>   CsvRawReadBenchmarks.OfficeIMOBorrowedUtf8: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12 -> It seems that the distribution is bimodal (mValue = 3.71)
> MultimodalDistribution
>   SharedStringFirstRowBenchmarks.OfficeIMOOpenThroughFirstRow: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12 -> It seems that the distribution can have several modes (mValue = 2.89)

The final bounded capability inventory is retained separately; it distinguishes supported public routes, caller strategies, two remaining product API gaps and missing comparison-engine columns. This packet is a read-only extraction and contains no new exhaustive-upstream-audit claim. Original packets remain unchanged.
