# Sealed writing stage: domain 1, frozen 830951

This primary stage contains 26 successful cases across nine native tables and 312 measured samples. Capture/runtime source: 83095146282a96143b23a79a7ecca058a24a709b; benchmark source unchanged from e676775a59458d1095606386c39506ceb8a9bc33. Started 2026-10-08T19:52:15.9367041+00:00, finished 2026-10-08T20:06:20.6911046+00:00, sealed context 2026-10-08T20:06:20.7992674Z.

Job: one launch, eight warmups, twelve measurements, 1000 ms automatic Pilot, unroll 1, DontRemove, High priority/0xFFFF0000. Measured iteration durations 192.6613–2828.3605 ms; all >= 100 ms. Native diagnostics preserve 0 short-iteration warnings, 0 distribution warning rows, 10 outlier hint rows and 14 native outlier values.

- All 26 cases/312 measured samples succeeded and every actual iteration exceeds 100 ms. All variance, intervals, warnings and outlier values remain retained; domains are separate observations, not pooled or a universal winner claim.
- Native XLSB default supported model + Save: OfficeIMO 619.231837 +/- 22.332344 ms / 461084110 allocated B/op versus peer streaming 5.742896 +/- 0.225284 ms / 4216155 allocated B/op. Keep architecture/throughput/allocation weakness; valid output is not excluded.
- Configured XLSB inline OfficeIMO 545.751900 +/- 13.281230 ms / 461085654 allocated B/op; SST 543.015352 +/- 10.776130 ms / 451016714 allocated B/op versus peer inline/prefetch 4.345141 +/- 0.045714 ms / 4226760 allocated B/op and peer SST 5.570238 +/- 0.129181 ms / 4254941 allocated B/op. Inline/SST/prefetch are distinct configurations.
- Configured compact XLSX OfficeIMO 7.308677 +/- 0.109654 ms / 4235672 allocated B/op versus peer ordinary 7.893369 +/- 0.163412 ms / 4216413 allocated B/op and peer PrefetchWrite 4.441402 +/- 0.185408 ms / 4220284 allocated B/op. Ordinary and configured strategies remain separate.
- SST XLSX ordinary OfficeIMO 15.575432 +/- 0.422837 ms / 4239609 allocated B/op; configured coordinate omission 8.629870 +/- 0.583592 ms / 4239772 allocated B/op versus peer SST 8.016763 +/- 0.145253 ms / 4257962 allocated B/op. Header references/dimension and complete finalization remain disclosed.
- Public Arrow caller row orchestration OfficeIMO 41.455239 +/- 0.408351 ms / 1142155 allocated B/op versus peer public RecordBatch 18.241385 +/- 0.170850 ms / 18496 allocated B/op. No dedicated OfficeIMO RecordBatch writer is claimed.
- Public UTF8 OfficeIMO 28.793820 +/- 3.673322 ms / 39288 allocated B/op versus peer 14.691608 +/- 0.436638 ms / 18613 allocated B/op; styled row defaults OfficeIMO 8.762936 +/- 0.426082 ms / 2624628 allocated B/op versus peer 5.171391 +/- 0.307940 ms / 18632 allocated B/op. Callback/iteration, UTF8 validation, authored resolved XFs and coordinates are ordinary strategy costs.
- Allocated bytes are cumulative managed bytes/op, not peak/retained/native memory. All attributed and mapped caller fallbacks remain visible; no automatic OfficeIMO record-writer API equivalence is invented.
- Representative Setup output byte/ZIP-part identities and source-enforced complete field/style/storage proof remain outside timing; individual measured output hashes are not retained. Prepared object lists/ranges have definitions and semantic validation, not an invented serialized-byte input hash.
- The v1 compiler failure and Dry/reference eligibility remain separate unranked evidence. V2 uses the explicit hook with identical frozen product/outer harness binaries; no source/timed-method change or replacement pooling.
- Only sealed domain1 writing and the existing sealed domain0 derived packet are inspected. No live/incomplete CSV/later results or process audit.

## Runtime, build configuration and host boundary

Outer harness SHA256 5E79575325D94AE8D09B97CD0C1C341EBB6AC0A24C3EEE6AE4817A897F97E7A4; runner SHA256 C52377235F70A38C61333009FFA2CC97C0BE2B3C102041CB127587B09AB32A95. Explicit generated-project saved-reference hook SHA256 CEDF3A831603914A5E024C980CCA65AAAAF25544D98538BC416E963DD8632B12, verified from actual file and capture metadata. All 104 loaded-owner hashes match the captured quartet. The v1 compiler failure has zero measured rows and the 136-case Dry/Cold eligibility stays outside measured counts. V2 timing is separate and does not relabel or pool those attempts.

Host snapshots: 48 before/55 after entries; 42 persistent IDs; 13 new IDs; max persistent CPU delta 0.234375 s, sum 3.328125 s. Boundary snapshots have no command roles/per-case timeline; they establish neither full isolation nor causal contamination. No live process audit performed.

## Input and representative generated-output identities

All 141 logged byte records and 725 ZIP-part records are preserved per child in JSON. Representative generated packages have SHA/length plus each part name, inflated/compressed length, timestamp and SHA. All UTF8/Arrow buffer IDs have the same bytes/hash across paired children. Typed 50K prepared objects and styled Enumerable.Range inputs are source-defined deterministic values rather than serialized input blobs; no object-list byte SHA is invented. Complete field/type/order/style/string-storage proof is in Setup; timed calls return output length and their individual packages are not retained.

Cross-domain input comparison: all 40 prepared buffer declarations exactly match D0 lengths/SHA; all 26 full case identities match. 101 representative Setup outputs retain D0/D1 package SHA/length and complete entry metadata; 18 whole package identities match, 101 have all inflated parts equal. Recorded timestamps/container changes are observations, without exclusive causal attribution. Timings are not pooled or asserted interleaved.

Observed XLSB storage policies (exact declarations):

~~~text
XLSB storage=ExcelReader shared strings; configured=True; inlineCells=0; sharedStringCells=50004; hasSstPart=True; sstReferences=50004; sstUnique=12.
XLSB storage=ExcelReader typed records; configured=default; inlineCells=50004; sharedStringCells=0; hasSstPart=True; sstReferences=0; sstUnique=0.
XLSB storage=ExcelReader write prefetch; configured=False; inlineCells=50004; sharedStringCells=0; hasSstPart=True; sstReferences=0; sstUnique=0.
XLSB storage=ExcelReader; configured=default; inlineCells=50004; sharedStringCells=0; hasSstPart=True; sstReferences=0; sstUnique=0.
XLSB storage=OfficeIMO inline strings; configured=False; inlineCells=50004; sharedStringCells=0; hasSstPart=False; sstReferences=absent; sstUnique=0.
XLSB storage=OfficeIMO shared strings; configured=True; inlineCells=0; sharedStringCells=50004; hasSstPart=True; sstReferences=50004; sstUnique=12.
XLSB storage=OfficeIMO; configured=default; inlineCells=50004; sharedStringCells=0; hasSstPart=False; sstReferences=absent; sstUnique=0.
~~~

## ArrowStringWriterBenchmarks

100K four required Arrow string columns, prepared Arrow buffers outside timing; header c0..c3. Both reuse32MiB output, reset/finalize and return length. ExcelReader public WriteRecordBatch versus OfficeIMO public WriteRows/WriteUtf8 caller orchestration with ordinary Enumerable.Range/callback/column-access costs; no dedicated OfficeIMO RecordBatch writer is claimed. Complete fields/schema/output parts checked in Setup.

| Method | Complete parameters | Mean ms | SD ms | Allocated bytes | Min actual iteration ms |
| --- | --- | ---: | ---: | ---: | ---: |
| ExcelReaderRecordBatch |  | 18.241385 | 0.170850 | 18496 | 973.5928 |
| OfficeIMOPublicRowOrchestration |  | 41.455239 | 0.408351 | 1142155 | 941.8209 |

## CompactWriterBenchmarks

50K prepared Name/Id/Date/Value objects plus header; new4MiB MemoryStream per operation, complete XLSX finalization, return length. OfficeIMO public IncludeCellReferences=false is configured compact output: header references and dimension remain; peer normal writer omits references/dimension. ExcelReader PrefetchWrite=true separate. Full fields/date styles/package integrity/independent readers checked; does not replace ordinary writer results.

| Method | Complete parameters | Mean ms | SD ms | Allocated bytes | Min actual iteration ms |
| --- | --- | ---: | ---: | ---: | ---: |
| OfficeIMOWithoutReferences | RowCount=50000 | 7.308677 | 0.109654 | 4235672 | 897.2095 |
| ExcelReaderWriter | RowCount=50000 | 7.893369 | 0.163412 | 4216413 | 1006.9965 |
| ExcelReaderWriterPrefetch | RowCount=50000 | 4.441402 | 0.185408 | 4220284 | 977.9557 |

## ConfiguredXlsbWriterBenchmarks

50K prepared records plus header. OfficeIMO builds native spreadsheet model then Save, explicitly inline or SST. Peer public XLSB streaming writer with SST=true versus inline PrefetchWrite=true. Full fields/date styles/storage records/package parts validated. Same logical records do not make model and streaming allocation work equal, and inline/prefetch versus SST remain distinct policies.

| Method | Complete parameters | Mean ms | SD ms | Allocated bytes | Min actual iteration ms |
| --- | --- | ---: | ---: | ---: | ---: |
| OfficeIMOModelAndSaveInlineStrings | RowCount=50000 | 545.751900 | 13.281230 | 461085654 | 2116.2507 |
| OfficeIMOModelAndSaveSharedStrings | RowCount=50000 | 543.015352 | 10.776130 | 451016714 | 2081.7705 |
| ExcelReaderXlsbWriterSharedStrings | RowCount=50000 | 5.570238 | 0.129181 | 4254941 | 892.2853 |
| ExcelReaderXlsbWriterPrefetch | RowCount=50000 | 4.345141 | 0.045714 | 4226760 | 996.0204 |

## MappedRecordWriterBenchmarks

50K prebuilt mapped objects, XLSX/XLSB plus header, new4MiB destination and full finalization. Peer generated record layout writes the mapped model; OfficeIMO ordinary public XLSX callback or XLSB model+Save writes the same fields. This is caller-output equivalence, not an automatic mapped writer API equivalence. Object/layout preparation outside timing; correct output validated.

| Method | Complete parameters | Mean ms | SD ms | Allocated bytes | Min actual iteration ms |
| --- | --- | ---: | ---: | ---: | ---: |
| OfficeIMOPublicTypedWrite | Format=Xlsx&RowCount=50000 | 15.021231 | 0.433500 | 4234862 | 929.7414 |
| ExcelReaderMappedRecords | Format=Xlsx&RowCount=50000 | 9.940764 | 0.944346 | 4215885 | 192.6613 |
| OfficeIMOPublicTypedWrite | Format=Xlsb&RowCount=50000 | 620.725646 | 43.232968 | 461083322 | 2262.9798 |
| ExcelReaderMappedRecords | Format=Xlsb&RowCount=50000 | 6.617091 | 0.247771 | 4216085 | 305.4989 |

## NativeWriterBenchmarks

50K Name/Id/Date/Value records plus header, native XLSB default writing. OfficeIMO builds workbook model then Save versus peer public row-streaming writer. Both current defaults use inline cells; peer carries an empty SST part, OfficeIMO omits it. Same fields/types/order/date styles and independent readability validated. Native XLS diagnostics are unselected and remain unranked separately.

| Method | Complete parameters | Mean ms | SD ms | Allocated bytes | Min actual iteration ms |
| --- | --- | ---: | ---: | ---: | ---: |
| OfficeIMOModelAndSave | Format=Xlsb&RowCount=50000 | 619.231837 | 22.332344 | 461084110 | 2304.9565 |
| ExcelReaderWriter | Format=Xlsb&RowCount=50000 | 5.742896 | 0.225284 | 4216155 | 917.0920 |

## RecordWriterBenchmarks

50K prepared attributed records, XLSX/XLSB plus header, new4MiB destination and complete finalization. Peer WriteRecordsAsync with attribute layout versus OfficeIMO normal XLSX row callback/XLSB model+Save. No automatic OfficeIMO attributed-record writer is implied. Full output values/styles/metadata and independent readability proved outside timing.

| Method | Complete parameters | Mean ms | SD ms | Allocated bytes | Min actual iteration ms |
| --- | --- | ---: | ---: | ---: | ---: |
| OfficeIMOPublicTypedWrite | Format=Xlsx&RowCount=50000 | 14.742676 | 0.464383 | 4235158 | 896.2488 |
| ExcelReaderWriteRecords | Format=Xlsx&RowCount=50000 | 8.908701 | 0.405325 | 4215966 | 944.5723 |
| OfficeIMOPublicTypedWrite | Format=Xlsb&RowCount=50000 | 603.283533 | 20.257321 | 461084020 | 2304.1718 |
| ExcelReaderWriteRecords | Format=Xlsb&RowCount=50000 | 5.673703 | 0.173405 | 4216180 | 443.0447 |

## SharedStringWriterBenchmarks

50K prepared records plus header, new4MiB MemoryStream and finalization. Both select SST. OfficeIMO ordinary coordinates and configured coordinate omission are separate methods; peer omits coordinates/dimension. Header references/dimension remain in Office compact output. Complete fields/order/date-style/SST/package proof outside timing; ordinary and compact results stay separate.

| Method | Complete parameters | Mean ms | SD ms | Allocated bytes | Min actual iteration ms |
| --- | --- | ---: | ---: | ---: | ---: |
| OfficeIMOSharedStrings | RowCount=50000 | 15.575432 | 0.422837 | 4239609 | 988.4006 |
| OfficeIMOSharedStringsWithoutReferences | RowCount=50000 | 8.629870 | 0.583592 | 4239772 | 981.6480 |
| ExcelReaderWriterSharedStrings | RowCount=50000 | 8.016763 | 0.145253 | 4257962 | 964.0188 |

## StyledRowWriterBenchmarks

100K numeric rows0..99999, no header, same retained32MiB destination/reset/finalization. Public true bold row defaults and authored bold values qualified through actual row/cell/style references, every value and earlier independent Excel evidence. OfficeIMO authored resolved cell XFs/coordinates and peer row defaults/no coordinates differ structurally but produce qualified bold values. Style pipeline cost remains visible.

| Method | Complete parameters | Mean ms | SD ms | Allocated bytes | Min actual iteration ms |
| --- | --- | ---: | ---: | ---: | ---: |
| OfficeIMODefaultRowStyle |  | 8.762936 | 0.426082 | 2624628 | 954.4831 |
| ExcelReaderOriginalStyledRows |  | 5.171391 | 0.307940 | 18632 | 983.8732 |

## Utf8WriterBenchmarks

100K four prepared unmanaged UTF8 value buffers/offsets, no header, retained32MiB destination/reset/finalization. Both public UTF8 APIs consume exact inputs; OfficeIMO normal WriteRows callback/enumeration is included. No private native WriteApi adapter. Every field/UTF8 value/escaping proof and produced package parts are checked outside timing.

| Method | Complete parameters | Mean ms | SD ms | Allocated bytes | Min actual iteration ms |
| --- | --- | ---: | ---: | ---: | ---: |
| OfficeIMOUtf8 |  | 28.793820 | 3.673322 | 39288 | 772.1170 |
| ExcelReaderPublicUtf8 |  | 14.691608 | 0.436638 | 18613 | 1014.1291 |

## Native warnings and hints

Native class/method/full parameters/job tables remain authoritative. Diagnostic prose omitting parameters retains ambiguity. Statistics, intervals, outlier arrays, Actuals, Results and allocations are preserved; all normalized sample values/statistics/allocations match native.

~~~text
// * Hints *
Outliers
  ArrowStringWriterBenchmarks.OfficeIMOPublicRowOrchestration: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=12, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=8 -> 1 outlier  was  detected (42.44 ms)
// * Hints *
Outliers
  CompactWriterBenchmarks.OfficeIMOWithoutReferences: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=12, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=8 -> 1 outlier  was  detected (7.57 ms)
// * Hints *
Outliers
  ConfiguredXlsbWriterBenchmarks.OfficeIMOModelAndSaveInlineStrings: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=12, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=8 -> 1 outlier  was  detected (579.61 ms)
  ConfiguredXlsbWriterBenchmarks.ExcelReaderXlsbWriterSharedStrings: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=12, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=8 -> 2 outliers were detected (5.82 ms, 5.83 ms)
// * Hints *
Outliers
  MappedRecordWriterBenchmarks.ExcelReaderMappedRecords: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=12, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=8 -> 2 outliers were detected (11.37 ms, 12.10 ms)
// * Hints *
Outliers
  NativeWriterBenchmarks.OfficeIMOModelAndSave: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=12, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=8 -> 2 outliers were detected (576.24 ms, 669.07 ms)
  NativeWriterBenchmarks.ExcelReaderWriter: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=12, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=8     -> 1 outlier  was  detected (6.30 ms)
// * Hints *
Outliers
  RecordWriterBenchmarks.ExcelReaderWriteRecords: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=12, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=8 -> 2 outliers were detected (9.66 ms, 9.69 ms)
// * Hints *
Outliers
  SharedStringWriterBenchmarks.OfficeIMOSharedStrings: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=12, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=8 -> 1 outlier  was  detected (16.59 ms)
// * Hints *
Outliers
  StyledRowWriterBenchmarks.OfficeIMODefaultRowStyle: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=12, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=8 -> 1 outlier  was  detected (9.71 ms)
~~~

This qualified group adds 26 primary cases: 542 primary + 78 supplementary = 620 sealed of 730 planned, 110 current cases pending. The immutable 434-case v2 resume plan has 324 fresh qualified cases. Historical 36df 106 remains outside both categories. Domains remain separate observations; no pooled or global ranking and no excluded valid slower result.

Native originals unchanged; no source edits, builds, tests, timing, fixture copies, archives, cleanup, incomplete-group inspection or publication.