# Sealed real-data readers: domain1, frozen830951

52 successful cases across4 native tables;780 matching normalized samples and780 native Actual iterations. Capture/runtime 83095146282a96143b23a79a7ecca058a24a709b; unchanged benchmark source e676775a59458d1095606386c39506ceb8a9bc33. Started 2026-10-08T18:58:48.7101444+00:00; native sidecar completed 2026-10-08T19:26:11.6425595+00:00; context ended 2026-10-08T19:26:11.7424157Z.

High/0xFFFF0000; one launch/12warmups/15measurements/1000ms automatic Pilot/unroll1/DontRemove. Actual duration 220.7697–1358.2417ms; all>=100ms. Zero short warnings; 4 distribution rows/22 outlier hints/33 native outlier values, retained with all confidence intervals and distributions.

- All52 cases across4 native class tables pass;780 normalized samples/statistics/allocations reconcile with native OriginalValues/Results and780 Actual iterations. All52 exits0/High/FFFF0000;208 frozen-owner hash/version observations match. Long1000ms recipe duration minimum passes100ms without eliminating distribution/host uncertainty.
- Real fourteen-field automatic XLSX OfficeIMO61.434±3.594ms/8,511,104B versus peer47.451±2.397ms/8,406,944B; XLSB35.611±1.209ms/25,859,178B versus29.898±1.882ms/8,406,488B. These valid throughput/allocation losses remain, separate from manual four-field headline projection.
- Materialized real XLSX OfficeIMOBytes67.227±6.031ms/14,274,442B and OfficeIMOStream64.926±5.441ms/20,995,842B versus peer42.635±2.513ms/17,504B and Sylvan155.750±7.374ms/660,029B. Source strings are cache-backed/materialized where that API contract requires; allocation is cumulative managed bytes/op rather than peak or retained memory.
- Original borrowed raw text versus GetValue/boxing remains different API work. Configured peer prefetch/ReadOnlyMemory and ordinary OfficeIMO byte/Stream openers are separately grouped, not claimed as equivalent prefetch strategies. MemoryStream work does not establish blockedI/O scalability.
- All4 exact pinned input file lengths/SHA256 and complete ZIP payload/compressed lengths/timestamps match the qualified domain0 derived packet. Raw scans include65,536 rows/header×14fields; automatic models consume65,535data records×14properties with independent every-property/type/order validation in Setup and complete checksum/count timed.
- Domains retain distinct timestamps, affinity and original runner identities; no pooling, physical interleave, causal cache/isolation effect or universal win is inferred. Boundary snapshots have no per-case timeline or command roles; no live audit is performed.
- Only requested sealed domain1 real-data is inspected. Shared counters remain408primary/244pending+78 until separately assigned strings47 packet reconciliation. Original failed generated build and136 eligibility cases stay unranked.

## API work and full native parameters

### MaterializedRealDataReadBenchmarks

Same pinned complete sheet, all string fields materialized in all engines. Every field/type/order/count is validated outside timing; full count/checksum consumed in timing. Scalar representation and normal API boxing remain visible. Byte/Stream input variants are separate; compare within format and this materialization contract.

| Method | Complete parameters | Mean ms | SD ms | Allocated managed bytes/op | Min actual iteration ms |
| --- | --- | ---: | ---: | ---: | ---: |
| ExcelReaderStringsMaterialized | Format=Xlsx | 42.634794 | 2.512719 | 17504 | 978.2460 |
| OfficeIMOBytes | Format=Xlsx | 67.227033 | 6.031048 | 14274442 | 238.6809 |
| OfficeIMOStream | Format=Xlsx | 64.925957 | 5.441464 | 20995842 | 231.6284 |
| Sylvan | Format=Xlsx | 155.749882 | 7.373790 | 660029 | 1024.9361 |
| ExcelReaderStringsMaterialized | Format=Xlsm | 41.228586 | 1.293463 | 17504 | 912.9051 |
| OfficeIMOBytes | Format=Xlsm | 61.140279 | 3.290092 | 14274460 | 860.1983 |
| OfficeIMOStream | Format=Xlsm | 63.579012 | 3.517289 | 20995819 | 805.1998 |
| Sylvan | Format=Xlsm | 151.189906 | 4.580264 | 660109 | 1022.0143 |
| ExcelReaderStringsMaterialized | Format=Xlsb | 25.153769 | 0.758231 | 17048 | 1017.7381 |
| OfficeIMOBytes | Format=Xlsb | 25.200062 | 0.721128 | 14321879 | 969.0031 |
| OfficeIMOStream | Format=Xlsb | 26.360247 | 1.239882 | 18197390 | 956.7437 |
| Sylvan | Format=Xlsb | 26.147388 | 1.026790 | 346998 | 901.4071 |
| ExcelReaderStringsMaterialized | Format=Xls | 10.735640 | 0.674591 | 22000 | 996.3226 |
| OfficeIMOBytes | Format=Xls | 14.724276 | 1.087282 | 14325847 | 1053.3720 |
| OfficeIMOStream | Format=Xls | 15.836232 | 0.771617 | 26150933 | 906.3501 |
| Sylvan | Format=Xls | 18.227016 | 0.677975 | 190764 | 1066.9246 |

### PrefetchedRealDataReadBenchmarks

Same complete pinned XLSX/XLSM/XLSB sheet contract. Peer PrefetchDecompression=true Stream/ReadOnlyMemory cases are explicit configured pipelines. OfficeIMOBytes and Sylvan use ordinary defaults. Public opening/scan/disposal included, prepared in-memory input; no blocked-I/O scalability or equivalent-prefetch implementation claim.

| Method | Complete parameters | Mean ms | SD ms | Allocated managed bytes/op | Min actual iteration ms |
| --- | --- | ---: | ---: | ---: | ---: |
| ExcelReaderPrefetch | Format=Xlsx | 28.123930 | 0.837307 | 23183 | 968.6200 |
| ExcelReaderMemoryPrefetch | Format=Xlsx | 28.127918 | 0.970671 | 25116 | 930.1588 |
| OfficeIMOBytes | Format=Xlsx | 60.818044 | 1.821385 | 14274501 | 871.3524 |
| Sylvan | Format=Xlsx | 156.399728 | 4.646065 | 660029 | 1045.4478 |
| ExcelReaderPrefetch | Format=Xlsm | 28.027800 | 0.801350 | 25354 | 953.4713 |
| ExcelReaderMemoryPrefetch | Format=Xlsm | 29.148464 | 0.961859 | 23756 | 915.3864 |
| OfficeIMOBytes | Format=Xlsm | 63.067090 | 3.042512 | 14274531 | 819.2473 |
| Sylvan | Format=Xlsm | 149.782330 | 8.406899 | 660074 | 993.3781 |
| ExcelReaderPrefetch | Format=Xlsb | 15.481700 | 0.276523 | 16615 | 957.4520 |
| ExcelReaderMemoryPrefetch | Format=Xlsb | 15.597552 | 0.242064 | 19695 | 976.6416 |
| OfficeIMOBytes | Format=Xlsb | 24.758022 | 1.165975 | 14321572 | 915.7743 |
| Sylvan | Format=Xlsb | 26.095905 | 0.997252 | 346997 | 927.9144 |

### RealDataReadBenchmarks

Pinned first-sheet65,536 rows including header,14columns. Peer original exposes borrowedUTF8 text with double/date parsing; OfficeIMO and Sylvan consume ordinary GetValue and materialized strings/scalar objects. Full fields/types/order checked outside timing; count/checksum in timing. ExcelReaderOriginal uses prepared MemoryStream; ExcelReaderMemory uses ReadOnlyMemory<byte>; OfficeIMOBytes versus prepared MemoryStream explicitly separate. No cross-library matched-materialization allocation ranking for raw APIs.

| Method | Complete parameters | Mean ms | SD ms | Allocated managed bytes/op | Min actual iteration ms |
| --- | --- | ---: | ---: | ---: | ---: |
| ExcelReaderOriginal | Format=Xlsx | 39.013666 | 0.995323 | 7808 | 951.6426 |
| ExcelReaderMemory | Format=Xlsx | 39.694833 | 1.013389 | 7552 | 965.6898 |
| OfficeIMOBytes | Format=Xlsx | 63.331777 | 2.899151 | 14274496 | 932.2263 |
| OfficeIMOStream | Format=Xlsx | 60.637177 | 7.081829 | 20995842 | 225.6326 |
| Sylvan | Format=Xlsx | 154.145041 | 9.641275 | 660029 | 990.3120 |
| ExcelReaderOriginal | Format=Xlsm | 40.534509 | 1.667244 | 7808 | 1010.2649 |
| ExcelReaderMemory | Format=Xlsm | 40.126773 | 1.232948 | 7552 | 985.7952 |
| OfficeIMOBytes | Format=Xlsm | 62.898120 | 4.343908 | 14274450 | 235.9662 |
| OfficeIMOStream | Format=Xlsm | 61.788034 | 3.870998 | 20995982 | 910.8369 |
| Sylvan | Format=Xlsm | 155.175297 | 9.069919 | 660074 | 1017.6027 |
| ExcelReaderOriginal | Format=Xlsb | 24.147209 | 0.644776 | 7352 | 1005.1782 |
| ExcelReaderMemory | Format=Xlsb | 24.437305 | 0.706591 | 9096 | 968.2624 |
| OfficeIMOBytes | Format=Xlsb | 26.161660 | 1.424958 | 14321574 | 936.9337 |
| OfficeIMOStream | Format=Xlsb | 26.536636 | 1.147054 | 18197786 | 888.3264 |
| Sylvan | Format=Xlsb | 30.173968 | 1.771499 | 346998 | 1022.4454 |
| ExcelReaderOriginal | Format=Xls | 9.089035 | 0.368640 | 12304 | 871.1497 |
| ExcelReaderMemory | Format=Xls | 9.664125 | 0.683106 | 12168 | 1042.1199 |
| OfficeIMOBytes | Format=Xls | 13.401305 | 0.610856 | 14325848 | 855.0877 |
| OfficeIMOStream | Format=Xls | 15.065435 | 1.566775 | 26150970 | 805.1729 |
| Sylvan | Format=Xls | 17.304934 | 1.222047 | 190764 | 1050.9161 |

### RealDataTypedReadBenchmarks

Pinned header-bearing XLSX/XLSB65,535 data records with14mapped properties. Ordinary automatic mapping in both engines, complete property/type/order proof against fixture-derived expected values outside timing, full count/checksum consumed in timing. OfficeIMO byte opener plus RowsAs versus peer prepared MemoryStream opener/parser; include all opening/traversal/disposal and retain input API differences.

| Method | Complete parameters | Mean ms | SD ms | Allocated managed bytes/op | Min actual iteration ms |
| --- | --- | ---: | ---: | ---: | ---: |
| ExcelReaderAutomatic | Format=Xlsx | 47.450518 | 2.397263 | 8406944 | 949.3473 |
| OfficeIMOAutomatic | Format=Xlsx | 61.434153 | 3.593676 | 8511104 | 220.7697 |
| ExcelReaderAutomatic | Format=Xlsb | 29.898445 | 1.882407 | 8406488 | 1021.3021 |
| OfficeIMOAutomatic | Format=Xlsb | 35.611463 | 1.209087 | 25859178 | 990.3975 |

Original borrowed rows, fully materialized strings, prefetch configuration and automatic fourteen-property projection are separate contracts. Full input opening/traversal/count/checksum/disposal remains timed. Prepared memory byte/Stream routes are explicit; complete field/type/order proof is Setup work, not a weak sum-only correctness assertion. Cache-backed strings can satisfy materialization without per-cell fresh string allocation. Allocated is cumulative managed bytes/op, not peak/retained/native memory.

## Exact pinned inputs

| File | Case instances | Bytes | SHA256 | ZIP parts |
| --- | ---: | ---: | --- | ---: |
| 65K_Records_Data.xls | 9 | 11824128 | 294102433C1527E5FCF48B6E4F1A707852633E623B8A20D184F5BAC926843DD6 | 0 |
| 65K_Records_Data.xlsb | 15 | 3875407 | 9F03F160D32272CBE57D6023C73748D6C450783738FCD84CC552B03C00E23CC8 | 12 |
| 65K_Records_Data.xlsm | 13 | 6721342 | 6E4B3A60D3C59C075BC53E4AF6DAE482DEC8532A0AF0309DA4EFB6AD59F39ABE | 10 |
| 65K_Records_Data.xlsx | 15 | 6721305 | 0F44D3E06454508DBD2CDBAF701B04160637162AB71471616D8ADC59D2EDD3A8 | 10 |

All48 raw children log actual byte identities and416 complete inflated part records. Four typed children independently log exact file SHA256; their lengths/parts resolve from sealed raw children with identical hash. Every pinned file SHA/length and entry name/inflated length/compressed length/SHA/timestamp matches the qualified domain0 derived packet. No fixture byte reading/copy/decompression was performed for this report. Source URLs are retained per case. Raw65,536rows/header×14fields and typed65,535data records×14properties remain distinct.

### 65K_Records_Data.xlsb

| Inflated entry | Bytes | Compressed bytes | SHA256 |
| --- | ---: | ---: | --- |
| [Content_Types].xml | 1123 | 385 | 4C5EE50642C79F66CC6BDA47F84707AD1B0B285550552F19CF2C7ACC6B2E2606 |
| _rels/.rels | 588 | 247 | 9741BF9066C5AF654DC221E71608E58F57EAB5C050F83491D079F3152836A0F1 |
| docProps/app.xml | 780 | 393 | 335BAF763506C1508848A4032E09DF882CA4FF52E98EBA9CC812A2FC2CD980C4 |
| docProps/core.xml | 614 | 337 | 95218235B2050431E63FC2459101264FC2CDC32B1A30323727E86F85DAEC6839 |
| xl/_rels/workbook.bin.rels | 698 | 248 | F9ED407985A792514F5D1A26A3E419B65EF2FBD7318F92C53E6DD0D6D367B82D |
| xl/sharedStrings.bin | 5642 | 2286 | 01EC456B783902AF13A203B6CC9BE149B7A1C7AC09894FB5E17E66FFC3F914FE |
| xl/styles.bin | 7329 | 1543 | BE96C9FFD0A3153CDDCB4806BCAE10AE0291C6D54E8A152C72E9246E44852A63 |
| xl/theme/theme1.xml | 6520 | 1544 | 079D27C89AE224FC34C36A676B7FEF69DF0E32BA249841AAEF8816D9BF307006 |
| xl/workbook.bin | 503 | 315 | AB5A0F89DD8B583D542066157931FBB998BBA03BDAFA8EE2EA252E1E196A3D44 |
| xl/worksheets/_rels/sheet1.bin.rels | 284 | 193 | B3549AED1DB89C155318A37E20C90A7C28421A592FA788722627F95085C30CBC |
| xl/worksheets/binaryIndex1.bin | 477187 | 120974 | 3BD7F63C0ED48C7ADBE50568749618C4892ED1524D0485E78CE021FB4C3B0DA3 |
| xl/worksheets/sheet1.bin | 15896224 | 3743686 | D88403A0728E8B2A3A845DEC7729D5D667598117079E2A6CF48F510BFE4EE7F7 |

### 65K_Records_Data.xlsm

| Inflated entry | Bytes | Compressed bytes | SHA256 |
| --- | ---: | ---: | --- |
| [Content_Types].xml | 1146 | 367 | 1201CE9D35181763181E983A4FC7A947695E8C8659EFF83E0D47D39AEF2F2D49 |
| _rels/.rels | 588 | 244 | 73E5A29F48D5AB979EEDA062493BC7E679265C1344EF936978B8BECEC5549497 |
| docProps/app.xml | 780 | 393 | 335BAF763506C1508848A4032E09DF882CA4FF52E98EBA9CC812A2FC2CD980C4 |
| docProps/core.xml | 614 | 338 | 9EA3C7053664B20C479628DA167007A614F9F1E0C4497EF1A67FC4EC25E8772B |
| xl/_rels/workbook.xml.rels | 698 | 243 | 353383FBE90F202BE596BDF0A86439C704D7024F4F8C19EBC9D06B42A341DBA1 |
| xl/sharedStrings.xml | 5928 | 1700 | B040A77523F6D83CF30D91CA022C5AB283B831DBF50E6051DB0C5351F44FA152 |
| xl/styles.xml | 16730 | 2137 | 1340B34BB9C030450EE192EDADB6CB3E51B0027C9809741A7976DB8D848A7AF6 |
| xl/theme/theme1.xml | 6520 | 1507 | 079D27C89AE224FC34C36A676B7FEF69DF0E32BA249841AAEF8816D9BF307006 |
| xl/workbook.xml | 1435 | 638 | ED0FEB3085DA2A3A728B5FAA5F77CCEF29D6880EC97DFE0C5A0E8F39DC725B58 |
| xl/worksheets/sheet1.xml | 34402657 | 6710801 | B17367138F599558F674AA06709CA4B74A5A93B6763AFDF75E2430B005FB51AF |

### 65K_Records_Data.xlsx

| Inflated entry | Bytes | Compressed bytes | SHA256 |
| --- | ---: | ---: | --- |
| [Content_Types].xml | 1168 | 350 | BFA02EA1994B73DCA866EA3B6596340FE00063D19EAB5957C7D8E6A5FA10599A |
| _rels/.rels | 588 | 244 | 73E5A29F48D5AB979EEDA062493BC7E679265C1344EF936978B8BECEC5549497 |
| docProps/app.xml | 780 | 393 | 335BAF763506C1508848A4032E09DF882CA4FF52E98EBA9CC812A2FC2CD980C4 |
| docProps/core.xml | 614 | 337 | C84A81DBA7D1E8050ED58DA6E43FA2EE30510ED3565D3E696F0710F3701BDA9A |
| xl/_rels/workbook.xml.rels | 698 | 243 | 353383FBE90F202BE596BDF0A86439C704D7024F4F8C19EBC9D06B42A341DBA1 |
| xl/sharedStrings.xml | 5928 | 1700 | B040A77523F6D83CF30D91CA022C5AB283B831DBF50E6051DB0C5351F44FA152 |
| xl/styles.xml | 16730 | 2137 | 1340B34BB9C030450EE192EDADB6CB3E51B0027C9809741A7976DB8D848A7AF6 |
| xl/theme/theme1.xml | 6520 | 1507 | 079D27C89AE224FC34C36A676B7FEF69DF0E32BA249841AAEF8816D9BF307006 |
| xl/workbook.xml | 1394 | 619 | B0E7B3A4923260B0DF79CD30B1964C678CB017D653F9F5811040B5290AE00A50 |
| xl/worksheets/sheet1.xml | 34402657 | 6710801 | B17367138F599558F674AA06709CA4B74A5A93B6763AFDF75E2430B005FB51AF |

## Provenance and host limits

All17 native artifacts SHA256/lengths verify. Frozen harness 5E79575325D94AE8D09B97CD0C1C341EBB6AC0A24C3EEE6AE4817A897F97E7A4; resumed runner C52377235F70A38C61333009FFA2CC97C0BE2B3C102041CB127587B09AB32A95; generated-project-only saved-reference hook CEDF3A831603914A5E024C980CCA65AAAAF25544D98538BC416E963DD8632B12. All208 loaded-owner version/hash observations match frozen quartet3.4.4+83095146282a96143b23a79a7ecca058a24a709b. Domains retain original sequential timestamps/metadata; JSON includes previously qualified D0 observations per complete native identity, without pooling or implying physical interleave.

Boundary snapshots 57/46 entries; 44 persistent IDs/2 new afterIDs; max observed persistent CPU delta 0.656250s,sum 10.406250s. No command roles/per-case timeline exist in these snapshots; they prove neither full isolation nor causal contamination. No live audit.

## Native diagnostics

Native warning prose may omit Format and therefore remains ambiguous across parameterized siblings. Native class/method/complete parameters/job and full per-case statistics/outliers are authoritative. All diagnostics are preserved below.

~~~text
// * Warnings *
MultimodalDistribution
  MaterializedRealDataReadBenchmarks.ExcelReaderStringsMaterialized: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12 -> It seems that the distribution is bimodal (mValue = 3.33)
  MaterializedRealDataReadBenchmarks.OfficeIMOStream: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12                -> It seems that the distribution is bimodal (mValue = 3.5)
// * Hints *
Outliers
  MaterializedRealDataReadBenchmarks.OfficeIMOBytes: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12  -> 1 outlier  was  detected (68.82 ms)
  MaterializedRealDataReadBenchmarks.Sylvan: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12          -> 1 outlier  was  detected (163.60 ms)
  MaterializedRealDataReadBenchmarks.OfficeIMOBytes: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12  -> 1 outlier  was  detected (27.38 ms)
  MaterializedRealDataReadBenchmarks.Sylvan: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12          -> 1 outlier  was  detected (28.51 ms)
  MaterializedRealDataReadBenchmarks.OfficeIMOStream: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12 -> 3 outliers were detected (14.39 ms, 17.17 ms, 17.24 ms)
// * Hints *
Outliers
  PrefetchedRealDataReadBenchmarks.ExcelReaderMemoryPrefetch: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12 -> 1 outlier  was  detected (30.15 ms)
  PrefetchedRealDataReadBenchmarks.ExcelReaderMemoryPrefetch: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12 -> 1 outlier  was  detected (26.92 ms)
  PrefetchedRealDataReadBenchmarks.Sylvan: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12                    -> 2 outliers were detected (168.32 ms, 169.87 ms)
  PrefetchedRealDataReadBenchmarks.ExcelReaderMemoryPrefetch: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12 -> 1 outlier  was  detected (15.03 ms)
  PrefetchedRealDataReadBenchmarks.OfficeIMOBytes: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12            -> 1 outlier  was  detected (27.78 ms)
// * Warnings *
MultimodalDistribution
  RealDataReadBenchmarks.Sylvan: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12            -> It seems that the distribution is bimodal (mValue = 3.43)
  RealDataReadBenchmarks.ExcelReaderMemory: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12 -> It seems that the distribution can have several modes (mValue = 3)
// * Hints *
Outliers
  RealDataReadBenchmarks.ExcelReaderOriginal: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12 -> 1 outlier  was  detected (42.02 ms)
  RealDataReadBenchmarks.ExcelReaderMemory: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12   -> 1 outlier  was  detected (41.79 ms)
  RealDataReadBenchmarks.OfficeIMOBytes: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12      -> 4 outliers were detected (58.26 ms, 59.03 ms, 68.03 ms, 68.25 ms)
  RealDataReadBenchmarks.OfficeIMOStream: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12     -> 3 outliers were detected (64.31 ms..82.60 ms)
  RealDataReadBenchmarks.Sylvan: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12              -> 1 outlier  was  detected (178.46 ms)
  RealDataReadBenchmarks.OfficeIMOBytes: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12      -> 2 outliers were detected (71.25 ms, 72.23 ms)
  RealDataReadBenchmarks.Sylvan: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12              -> 1 outlier  was  detected (176.96 ms)
  RealDataReadBenchmarks.ExcelReaderMemory: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12   -> 2 outliers were detected (25.74 ms, 26.12 ms)
  RealDataReadBenchmarks.OfficeIMOBytes: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12      -> 1 outlier  was  detected (29.15 ms)
  RealDataReadBenchmarks.Sylvan: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12              -> 1 outlier  was  detected (20.90 ms)
// * Hints *
Outliers
  RealDataTypedReadBenchmarks.ExcelReaderAutomatic: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12 -> 1 outlier  was  detected (55.06 ms)
  RealDataTypedReadBenchmarks.ExcelReaderAutomatic: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12 -> 2 outliers were detected (33.44 ms, 34.26 ms)
~~~

This packet qualifies52 additional primary cases; shared counters remain408primary/244pending+78supplementary until the separately assigned domain1 strings47 packet is reconciled. Original failure and136 eligibility observations remain unranked. Only requested sealed domain1 real-data inspected; no liveADO/incomplete/later groups, source/build/test/package/profile/fixturecopy/archive/cleanup/public actions. Native originals unchanged.