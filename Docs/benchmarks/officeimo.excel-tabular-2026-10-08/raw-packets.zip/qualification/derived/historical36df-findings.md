# Historical generated and real-data review

This read-only inventory covers two completed exploratory packets from source `36df28c4abc6a4c4371e09e26a5e40e0c07d30d2`, CPU domain 0. It does not supply final-source values. The original main/crypto draft remains a historical preparation artifact; interrupted string measurements and missing domain 1 counterparts are not completion evidence.

| Packet | Native cases | Successful child exits | Retained measured samples per case | Verified sidecar artifacts | Artifact bytes | MinIterationTime rows |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| stable36df-domain0-generated | 54 | 54 | 10 | 41 | 1,637,120 | 47 |
| stable36df-domain0-real | 52 | 52 | 10 | 17 | 1,527,641 | 15 |

Every artifact listed by both completed provenance sidecars matches its recorded SHA-256 and length. Native full names survive the PowerForge import in both samples and summaries; the summaries contain 54 and 52 distinct cases. All cases have statistics and ten original measured values. No child failure, missing workload result, unhandled exception, or field-validation failure was found. The native `Exceptions` diagnostic counter is not, by itself, a failed benchmark or a correctness failure.

The exact source/runtime identities are retained in `historical36df-generated-real-packets.json`; every case's class, method, complete parameter string, native job, statistics, allocation, measured-iteration duration, and source artifact are retained in the JSON/CSV case ledger. No original artifact was copied or changed.

## Measurement limits needing a fresh capture

Both jobs fixed four invocations, six warmups, ten measurements, one launch, unroll factor one, and retained outliers. Actual minimum workload iterations were below 100 ms for 47 generated and 15 real cases, exactly matching the 62 native short-iteration warning rows. The minimum was 10.4652 ms for generated work and 36.3283 ms for real work. Fifteen of the 106 cases have SD/mean above 20%; the highest is about 79.8%. These are descriptive warning thresholds, not automatic invalidation rules or significance tests. No explicit multimodal/bimodal warning appears in these two packets; warnings from the earlier main packets remain separate.

Use the coordinator's adopted 250 ms native pilot recipes for the next capture and inspect actual measured iteration durations after it finishes. Preserve all native warnings and samples even if a follow-up is needed. A longer iteration does not remove host noise or establish a universal ranking. Valid slower results remain visible.

## Historical behavior affected by later owner fixes

| Historical case | Mean ± SD | Allocated bytes | Correct interpretation |
| --- | ---: | ---: | --- |
| TypedStreamAsyncRead / OfficeIMOStreamOpenTypedAsync, 50K Original | 622.551 ± 30.738 ms | 430,978,584 | Correct old36 output with the old invariant-culture clone path. It is not a final-source result; the qualified culture fix needs its own fresh identity and capture. |
| TypedModelRead / OfficeIMOAutomatic, Class | 25.514 ± 7.309 ms | 7,279,952 | Ordinary automatic mapping cost in old36; preserve it while measuring the later guarded getter participation under a new identity. |
| TypedModelRead / OfficeIMOAutomatic, Struct | 23.037 ± 1.152 ms | 4,880,056 | Distinct model/storage cost; do not substitute the manual-getter headline method or ref-struct factory result. |
| RealDataTypedRead / OfficeIMOAutomatic, XLSX | 73.122 ± 6.480 ms | 25,812,456 | Qualified fourteen-field old36 automatic projection; raw/typed and source/package costs remain separate. |
| RealDataTypedRead / OfficeIMOAutomatic, XLSB | 38.677 ± 5.370 ms | 25,859,028 | Preserve the valid old36 result even if later automatic mapping improves it. |

The authoritative exact numeric values are in the machine-readable ledger. This table is historical investigation context, not a before/after attribution experiment: runtime changes, harness changes, fixtures, job and order must all be controlled before quantifying the new improvements.

The coordinator reports a separate inferred-schema parallel CSV capture conversion defect under repair. These two packets do not exercise that owner path. Final qualification must use the combined repaired owner and preserve its schema/conversion proof before timing; this inventory adds no new product defect.

## Work boundaries that must stay explicit

- Original raw scans expose different text/value APIs: peer borrowed UTF-8 versus OfficeIMO/Sylvan materialized native values. Their values/count/order are validated, but their allocations are not a matched string-copy contract. Retain the companion materialized tables. Native numeric boxing remains part of each public operation.
- The upstream Sylvan default header behavior drops the first row on headerless generated raw input. The measured qualified lane uses its ordinary no-header option and validates all 50,000 rows; the 49,999-row default observation remains a separate diagnostic. Do not resurrect that default as a paired result.
- Original OfficeIMO typed parsing constructs a class through direct getters, while the peer and Sylvan use their public automatic projections. Identical materialized fields permit an output comparison, but automatic class/struct methods have their own tables.
- Ref-struct peer automatic mapping and OfficeIMO `RowsAsBorrowed<T>` factory mapping are distinct strategies. The factory is a real public route, not an automatic ref-struct mapper. Both preserve the borrowed lifetime boundary.
- Async enumeration over byte/memory input and async stream opening are separate operations. MemoryStream runs exercise async APIs, not blocked disk/network scalability. Full input/decode work stays inside genuine parallel CSV async measurements.
- Real-data memory/stream and peer prefetch methods remain labelled pipelines. An OfficeIMO ordinary byte route does not become a prefetch API because it is displayed next to a peer prefetch method.

## Identity limits

The four real workbook input hashes are recorded in the sealed logs and compact inventory. Historical generated cases did not record their actual per-child input-byte SHA. Their generator, storage shape, lengths and complete semantic proof are retained; a later hash from the same generator cannot retrospectively identify the old bytes. ZIP creation timestamps vary between independently generated packages. The newly committed setup logging solves this for fresh captures without rewriting input; retain actual package and entry hashes and never replace them with a checksum or an unrelated archive hash.

Source-start `78bfbd96dc3967b6f3c5e2376ce4c98000213e2c` is not the published OfficeIMO 3.4.4 binary. See `published344-attribution.md`. Losses in the source-start or historical packets are not grounds to exclude them; valid source-start and actual published-package comparisons need distinct labels.

## Bounded disposition

- [x] Verify both sealed packets, complete counts, child exits, native samples and import identities.
- [x] Retain all 106 historical cases and exact warning lines in compact derived inventories.
- [x] Identify short-iteration/noise limits and source/package attribution boundaries.
- [ ] Coordinator: finish the inferred-schema CSV owner repair and final combined qualification.
- [ ] Coordinator: freeze new runtime/harness/input identities and capture the selected matrix with adopted jobs.
- [ ] Coordinator: include a separate actual published 3.4.4 headline lane if auditing the upstream package claim.
- [ ] Coordinator: reconcile native cases, warnings, exclusions and each domain before final public findings.

## Additional publication boundary

The current tracked comparison catalog check found no group spanning multiple recorded BDN classes among its 28 referenced packets (16 marked publish=true). The proposed expanded generated54 input would nevertheless pool raw/materialized sync/async XLSX classes in the current display grouping and compute an invalid shared fastest ratio. This is a future-input presentation limitation, not evidence invalidating an existing current packet or the historical native timings. Keep the new matrix in report/native archives. The bounded proof and precise potential canonical renderer improvement are recorded in dashboard-grouping-boundary.md and existing-dashboard-grouping-check.json.