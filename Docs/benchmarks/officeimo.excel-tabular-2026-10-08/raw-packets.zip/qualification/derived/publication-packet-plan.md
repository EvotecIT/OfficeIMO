# Bounded publication packet plan

Preparation is scoped to completed `stable36df-*-main-current`, `*-crypto-before`, and `*-crypto-core-only` roots. No active remaining-case output was read, copied, altered, imported, or published. `completed-packets-inventory.json` records exact completed sidecar metadata, proposed archive member names, original paths, byte lengths and SHA256. Every native artifact hash/length named by the six completed sidecars was verified. `completed-results.json` and `.csv` are small derived review tables, not replacements for native/PowerForge results.

## Proposed committed deliverable

- Human-authored `Docs/benchmarks/officeimo.excel-tabular-2026-10-08.md`, finalized from the draft only after all selected coverage is reconciled.
- Compact sibling `Docs/benchmarks/excel-tabular-2026-10-08/` with a selected-case coverage ledger, input/runtime identity manifests, qualification summary, archive SHA/member manifests, and extraction README.
- One bounded native packet ZIP per domain if necessary, plus a small separate attribution packet. Keep completed sealed normalized results and provenance beside their native artifacts. Existing evidence convention permits compressed native samples with a manifest.
- Links in existing benchmark navigation and opt-in suite README. Product README can link evidence without reproducing a large table. Existing generated 25K Excel/CSV README highlights retain their own source datasets.
- Catalog entries produced by canonical `Update-BenchmarkEvidenceCatalog` using the existing capture-bound workload IDs, after the coordinator finishes and applies publication. The generic comparison partial already reads that catalog.

## Archive member conventions

Use relative POSIX member paths; retain packet roots and the original inner timestamp folder. Keep every artifact named by a completed provenance sidecar byte-for-byte, including original logs, CSV, full JSON, Markdown and HTML. This avoids breaking the sealed sidecar's artifact inventory. Do not edit or redact a sealed file and then reuse its hash or publication provenance.

```text
packets/<original-run-id>/.powerforge-benchmark-provenance.json
packets/<original-run-id>/<original-native-timestamp>/<Type>-report-full.json
packets/<original-run-id>/<original-native-timestamp>/<Type>-report.csv
packets/<original-run-id>/<original-native-timestamp>/<Type>-report-github.md
packets/<original-run-id>/<original-native-timestamp>/<Type>-report.html
packets/<original-run-id>/<original-original-log-name>.log
imports/<original-run-id>-normalized.json
contexts/<original-run-id>-context.json
manifests/selected-coverage.json
manifests/runtime-identities.json
manifests/input-identities.json
manifests/qualification-summary.json
manifests/archive-members.json
```

The outer archive-members inventory maps each member to original source path, bytes, SHA256, purpose, and completed run. The public manifest should use portable source-relative provenance where available; the original sealed packets retain their actual recorded machine paths. Publish the archive's own SHA256 in a sidecar and extraction README. An archive cannot inventory its own final hash internally without recursion, so keep that hash outside it.

Exclude compiled binaries, copied repositories, BDN-generated build directories, obj/bin, traces, process dumps, lock files, package caches, encrypted/generated input caches, unpublished fixture copies and duplicate top-level redirected logs that are not part of the sidecar. Keep requested independent qualification evidence only when compact and necessary; otherwise preserve its hashes and durable source link. Do not redistribute unknown-license upstream corpus files merely to make an archive self-contained.

Target a small committed packet (roughly 10 MiB compressed where practical). Inventory first; if native logs/full samples exceed that scale, split by domain/measurement family and obtain the coordinator's final size decision. Do not discard warnings, samples or sidecar-listed members to reach a cosmetic size threshold. No archives or raw copies were made during this timing window.

## Coverage and grouping rules

Maintain two distinct ledgers:

1. The selected managed recipe: exactly 306 successful native cases per domain, with main eight plus remaining 298. Record actual run IDs, filters/environment selectors, owner bundle, type/method/native parameters, native job, domain, success, statistics/sample count, warnings, and qualification boundary. Reconcile against an explicit expected-case inventory; retain failures and exclusions rather than claiming a larger declaration universe was measured.
2. Core attribution: four cases per domain (before/candidate times file/memory), outside the 306 main count. Pair identical input, Excel assembly, workload snapshot, job recipe and domain; Core alone varies. Current full 36df runtime results are not the Core-only intervention bundle.

Use the native complete parameter string and FullName when grouping. BDN method names repeat across classes. Current import's combined ampersand parameters must not collapse storage shape, format, DOP, memory input or row count. Preserve declared native baselines; diagnostics with no equivalent output/schema/verification contract do not acquire a comparison ratio. Do not global-rank unrelated classes or average all workload ratios into a claimed product win.

The main longer jobs and the remaining shorter jobs retain their own run recipes. Record MinIterationTime/distribution warnings verbatim in native logs and in a compact per-case warning index. The remaining fixed4/fixed1, six/four-warmup matrix supports broad exploratory measurement coverage; a small-margin ranking requires a focused sufficiently warm longer-iteration comparison. Dry establishes eligibility and qualification setup, not performance. Include all native measured samples/outliers.

## Coordinator completion checklist

- [x] Inspect six completed main/attribution packets and verify sidecar-listed artifact bytes/hashes.
- [x] Preserve exact current/attribution identities and complete main/crypto values in a lightweight scratch draft.
- [x] Reserve placeholders for remaining groups, source baseline, published package lane and exact input manifests.
- [ ] Finish remaining domain0/domain1 jobs, check every expected case and native warning, and reconcile 306/domain independently of 477 declared parameter cases.
- [ ] Attach exact source78 and published3.4.4 package/DLL identities; retain their separately qualified available contracts.
- [ ] Attach main generated input byte hashes if retained, or disclose the retained generator/semantic proof boundary without substituting checksums for SHA256.
- [ ] Add existing full-field/native-format/style/crypto/scale qualification summaries and exact commands; preserve failure diagnostics.
- [ ] Finalize scoped findings with means/medians/dispersion/allocation and per-domain limits; configured compact writing remains separate from ordinary writing.
- [ ] Inventory and assemble bounded native archives after timing, then validate hashes/extraction and canonical import/catalog readiness.
- [ ] Apply dated report/navigation/current-contract doc links and existing catalog generation; do not feed heterogeneous native data into the older Excel summary generator unchanged.
- [ ] Put real remaining automatic ref-struct mapper and dedicated RecordBatch writer work in existing ROADMAP when applied; Sep/SpreadCheetah remain comparison coverage limits.
- [ ] Perform existing benchmark website checks and rendered inspection if website artifacts change, then complete task-owned output cleanup and report retained paths/sizes.

Completed sidecars have canonical production provenance and imported results already. No retrofit is requested. Reuse the existing workload IDs; catalog ComparisonId must match the capture-bound workload ID. Do not fan out one sealed result by relabeling comparison metadata. Catalog publication remains coordinator-owned after timing.
