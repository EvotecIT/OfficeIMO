# Tabular reading, writing, and authenticated workbook evidence — 2026-10-08

Coordinator draft. This file is publication preparation in task scratch. It is not a completed report, a published catalog entry, or a claim that every declared benchmark has stable comparative results. Apply the final report to the existing dated evidence route only after the remaining packets finish and their coverage is reconciled.

The frozen current runtime and harness source is `36df28c4abc6a4c4371e09e26a5e40e0c07d30d2`. The selected managed measurement recipe contains 306 cases per CPU domain. This draft inspects the completed eight-case main packet in each domain and four additional Core attribution cases in each domain. The remaining 298 main cases per domain are pending here. The full declarations check found 59 types, 170 methods, and 477 parameter cases; that declaration universe is different from the selected 306-case measurement recipe. Publish the selected-case ledger and explicit exclusions before claiming coverage complete.

## Results available now

The main packets use one launch, 12 warmups, 15 measurements, 32 invocations per iteration, unroll factor 1, and `DontRemove` outlier handling. Values below are native BDN means with standard deviations in milliseconds. Managed allocation is reported per operation; it is not peak or retained memory. The exact allocated byte counts, medians, native identities, and source artifact locations are in `completed-results.json` and its CSV companion.

| Typed input and method | Domain 0 mean ± SD (ms) | Domain 1 mean ± SD (ms) | BDN allocation display |
|---|---:|---:|---:|
| Original / ExcelReaderTyped | 8.150 ± 0.442 | 9.555 ± 1.718 | 3.87–3.88 MiB |
| Original / OfficeIMOTyped | 10.429 ± 1.846 | 8.393 ± 0.865 | 2.36 MiB |
| Original / SylvanTyped | 51.899 ± 7.472 | 40.082 ± 0.296 | 10.48 MiB |
| SharedStrings / ExcelReaderTyped | 10.451 ± 1.537 | 8.131 ± 0.966 | 2.29 MiB |
| SharedStrings / OfficeIMOTyped | 9.907 ± 1.385 | 8.330 ± 0.972 | 2.36 MiB |
| SharedStrings / SylvanTyped | 46.708 ± 7.691 | 41.065 ± 1.389 | 8.91 MiB |

The ordering of OfficeIMO and ExcelReader changes by CPU domain and storage shape. These packets support a lower allocation finding for OfficeIMO on the original inline-string fixture, but do not support a general typed parsing speed win. The shared-string allocation result differs from the inline-string result and remains visible. Domain 0 OfficeIMOTyped and domain 1 SylvanTyped have native multimodal distribution warnings; retain those warnings alongside the data.

| Ordinary writer method | Domain 0 mean ± SD (ms) | Domain 1 mean ± SD (ms) | BDN allocation display |
|---|---:|---:|---:|
| OfficeIMO | 15.511 ± 0.934 | 14.485 ± 0.354 | 4.04 MiB |
| ExcelReaderWriter | 9.373 ± 1.298 | 8.229 ± 0.330 | 4.02 MiB |

These are ordinary public writers over the same prepared 50,000 records, a four-column header, a newly allocated 4 MiB-capacity destination, and complete package finalization. OfficeIMO's ordinary output includes row references, cell references, and a dimension; the peer's ordinary output omits those structures. Both packages pass complete field and independent-reader qualification. The ordinary OfficeIMO package is 1,941,389 bytes, compared with 773,409 bytes for the peer. Explain the storage and interoperability contracts beside the timing rather than replacing this operation with configured compact output. Domain 0 ExcelReaderWriter has a multimodal distribution warning.

Configured compact writer results belong in a separate table: **[PENDING remaining packets: exact options, coordinates and dimension policy, output byte count, independent readability, samples and warnings]**. Preserve the ordinary writer row above even if a configured route is faster.

## Core-only authenticated opening attribution

These packets measure the same full-field authenticated opening operation with the same original small encrypted XLSX, using the old Excel assembly and replacing only Core. They are attribution comparisons between OfficeIMO bundles; they are not an ExcelReader ranking. Each job uses one launch, eight warmups, ten measurements, four invocations, unroll factor 1, and retained outliers.

| Domain / input | Before mean ± SD (ms) | Core-only mean ± SD (ms) | Before allocated bytes | Core-only allocated bytes |
|---|---:|---:|---:|---:|
| 0 / file stream | 135.930 ± 4.705 | 29.603 ± 4.296 | 144,578,584 | 572,882 |
| 0 / memory | 150.960 ± 6.680 | 25.240 ± 1.464 | 144,558,636 | 553,538 |
| 1 / file stream | 141.919 ± 12.701 | 24.058 ± 1.808 | 144,578,892 | 573,418 |
| 1 / memory | 140.452 ± 6.110 | 23.229 ± 1.407 | 144,558,696 | 553,082 |

All four attribution pairs reduce mean time and allocated bytes on this fixture. The output is still eagerly decrypted and fully authenticated. This result is limited to the qualified small workbook and the recorded operation. Large inputs and the final current-owner peer comparisons have separate pending rows.

The exact input is `OriginalSmallXlsx`: 15,360 encrypted bytes, SHA256 `13F9532B916634CB112D3593E7AB859F67B2DA35A3A47E574F1C1E26C5DA370D`; 8,915 authenticated plaintext bytes, SHA256 `85FBDE3D5CC6C936BE8D9C8A5F9658E4CDED25145A2E6449C5D1FCD54F64E602`; two rows and two columns. The pinned upstream file is at commit `ca5b50f99e8ef57ab476f0a2bc8043558d58b28d`. The encryption producer itself is unpinned; the plaintext oracle is independently authenticated with msoffcrypto-tool. Password `hunter2`; the harness records Agile AES-256-CBC, SHA-512, spin count 100,000, and data integrity. Keep these actual small input bytes distinct from supplementary or independently generated fixtures.

## Runtime, harness, and input identities

The host is Windows 11 build 10.0.26300.9457, AMD Ryzen 9 9950X3D2 with 16 physical and 32 logical cores, SDK 10.0.112, .NET 10.0.12, BenchmarkDotNet 0.15.8. Domain 0 uses mask `0xFFFF` / decimal 65535; domain 1 uses `0xFFFF0000` / decimal 4294901760. Child processes report High priority and the matching native-width affinity. Preserve the coordinator's physical cache-domain topology proof. Run order and timestamps are in the completed provenance and context files; do not pool domains as though they were independent repeated machines.

| Bundle | Assembly/harness identity |
|---|---|
| Current main harness | SHA256 `04895AF9FF1FCF2492537A4ABD091088FC857CD496D30AAD6639D13CA9AB541D`; root `36df28c4abc6a4c4371e09e26a5e40e0c07d30d2` |
| Current Excel | `3.4.4+36df28c4abc6a4c4371e09e26a5e40e0c07d30d2`; SHA256 `A1F0BE7B8009B53FF2995867E0A98F58D093D6BE7734BB5D038A5CD67BBC9122` |
| Current Core | Same root; SHA256 `120ED0E03AAB955707610B90625DF19282DB1FE4DDF2922729BC1C45A1C9926E` |
| Current CSV | Same root; SHA256 `F189322DCA36DBEEB7A79E7EF0F9D73FC6B986613043A97DDEB3CD756A22427E` |
| Current Arrow owner | Same root; SHA256 `062D2D66DCFD8F0137B11902D8E9F1BF649AA31D5F74BE16CBFD3E5D996CB8FF` |
| Attribution Excel, unchanged | `3.4.4+ba9f21651d204ba1171735d26cc48c6d0a99f765`; SHA256 `BD540DD1F7BEF8D8C5BD51147D9F5180FE30EB9CBCFF7AF699097E810A7E0403` |
| Attribution Core before | Same ba9 source; SHA256 `4222C2E8DDCD62B6CC253D1B43D8519FF0D7C9EC5AF1110491ABC07F5A9C1D97` |
| Attribution Core candidate | `3.4.4+4ee00bfa851b7b9d14b30058c67e036e53578c95`; SHA256 `0336BCBF8D00E6519401CB79795F85B0C6753E2E8839B8370D3A246637D1A824` |
| Attribution harnesses | Before SHA256 `CC38E56446699E12172F19E6EE9BD14F7A2A53292B9E5A8A2BC8DC4F805074E2`; Core-only SHA256 `9D4A1CED39F1EE2FD34930B5C1FC9FD8C8FF6D5D1F26B4C2A74489D9F6D48A77` |
| Attribution source snapshot | ba9 source plus the unchanged authenticated workload and native-width affinity wiring; SHA256 `FFD5C7C94B3BC0B53AC4591AD3F7EAC3AF83ECA0AEFAB34EBD71BDFC32350694` |
| Source baseline | `78bfbd96dc3967b6f3c5e2376ce4c98000213e2c`; **[PENDING completed lane's actual DLL, harness and fixture identities]** |
| Published package lane | OfficeIMO.Excel / OfficeIMO.CSV 3.4.4 from NuGet, with new-API flag disabled; **[PENDING package and actual DLL SHA, available-case ledger and known-defect qualification references]** |

The source baseline and the published package lane are different evidence. A current DLL reporting assembly version 3.4.4 is not proof that it is the published NuGet artifact. Do not attribute source improvements to the published package or fill unavailable older APIs with adapters.

Comparison dependencies: ExcelReader.NET 6.0.0 at `ca5b50f99e8ef57ab476f0a2bc8043558d58b28d`; Sylvan.Data.Excel 0.5.8; Sylvan.Data 0.2.17; optional Sylvan.Data.Csv 1.4.4; optional ExcelReader.Arrow 6.0.0 and Apache.Arrow 23.0.0. Their assembly identities are preserved in packet logs and the scratch inventory. They remain opt-in comparison dependencies outside shipped product projects. Keep existing third-party notices and corpus attribution.

Main typed fixture: 50,000 data rows plus header, four fields Name/Id/Date/Value, checksum `-7649324682946766260`; no row references, cell references, or worksheet dimension. Original has 50,004 inline string cells, package 773,409 bytes, worksheet 5,969,331 bytes. SharedStrings has 50,004 shared string cells, package 777,338 bytes, worksheet 4,944,252 bytes. **[PENDING coordinator attachment: generator source hash and input-byte SHA from retained qualification/input manifest, or an explicit statement that per-launch generated ZIP bytes were not retained; do not substitute checksum for a byte hash.]**

## Remaining managed coverage

Reconcile these groups against actual native case identities after the sequential jobs complete. This is a report outline, not another product backlog.

| Group | Output equivalence and presentation | Completion placeholder |
|---|---|---|
| Raw XLSX/XLSB/XLS and real CSV/Excel corpus | Preserve raw borrowed, materialized, typed getter and asynchronous work separately; exact same fields/order | [PENDING packets, counts, warnings] |
| Real typed data, class/struct/ref-struct models | Automatic mapper, public borrowed factory, and manual construction are distinct strategies | [PENDING packets, counts, warnings] |
| Shared-string lifecycle and string-heavy reads | XLSX/XLSB, stored/deflated ZIP, cache policy, first encoding, copied strings and borrowed UTF8 remain explicit | [PENDING packets, counts, warnings] |
| CSV typed, parallel maps and direct reduction | Full original 8M/4.3M/3M shapes and DOP1/4 proof; direct state and caller reduction separate; async includes input I/O/decode | [PENDING packets, counts, warnings] |
| ADO getters/copies and cold first use | Complete copied-byte validation; DataTable schema diagnostics unpaired; cold allocation is second-use | [PENDING packets, counts, warnings] |
| Ordinary/configured/record/native-format/UTF8/Arrow/styles writes | Prepared input and destination contracts explicit; authored package/style proof retained | [PENDING packets, counts, warnings] |
| Arrow conversion | Explicit schemas/one-batch comparisons; bounded batches and differing inference schemas separate | [PENDING packets, counts, warnings] |
| Encrypted original/full-auth/async/plain/open-only | Pair equally authenticated full scans; eager-buffering costs visible; original unverified/open-only peer rows diagnostic | [PENDING packets, counts, warnings] |
| Source baseline / published 3.4.4 | Compare only available qualified original contracts, using actual frozen bundle identity | [PENDING packets, counts, warnings] |

The remaining matrix uses fixed four invocations for ordinary work or one for large/huge work, with six/four warmups. Many fast cases can have short iteration durations. Preserve every `MinIterationTime`, multimodal, and other BDN warning in the native packets and the report's per-group warning index. Completion of 306 selected cases per domain establishes measurement coverage; it does not make every small-margin ratio statistically stable. Classify these shorter jobs as exploratory coverage evidence. Use a sufficiently warm, longer-iteration focused comparison before treating a small difference as a ranking. Do not silently replace successful slow or noisy rows with earlier favorable measurements.

## Public API and comparison coverage disposition

| Topic | Current implemented route | Remaining gap / correct claim |
|---|---|---|
| Ref-struct records | .NET 10 `RowsAsBorrowed<T>` caller factory, with ordinals resolved once and borrowed lifetime enforced by reader advancement | Automatic property/attribute mapping into arbitrary ref-struct models remains an API gap. Factory mapping is implemented and is not an automatic mapper. |
| Ordinary automatic class mapping | Existing Core typed mapping over the public reader is functional and measured in the frozen suite | Its fast-value marker participation and resulting boxing cost are under separate owner analysis. This is an optimization disposition, distinct from the automatic ref-struct API gap. Preserve 36df's actual mapping strategy/costs; any later improvement needs a new runtime identity and separate measurement. |
| Arrow strings to XLSX | Public `WriteRows` / `WriteUtf8` orchestration over an already prepared RecordBatch; optional dependencies only in benchmark project | A dedicated public RecordBatch writer remains an API gap. Do not advertise caller orchestration as that API or add Arrow to Excel runtime dependencies. |
| CSV parallel aggregation | Public text reduction and genuine asynchronous Stream/path reduction with independent worker states and source-order merge | Existing caller reduction stays diagnostic; disclose decoded UTF16 parser materialization versus peer UTF8. |
| Shared strings and styles | Native public XLSX/XLSB UTF8 borrowing; public streamed row defaults and resolved authored styles | Preserve cache and first-encoding costs, and actual Excel style qualification. No artificial replacement operation. |
| Sep and SpreadCheetah columns | Engines not added to this completed comparison set | Missing comparison columns are coverage limits, not demonstrated OfficeIMO product/API defects or evidence of superiority. |

When the coordinator applies documentation, real open API work belongs in the existing `Docs/ROADMAP.md`; this dated evidence report must not become a second backlog. Link current API contracts in package READMEs and Core borrowed mapping documentation.

## Interpretation and reproducibility

Keep native BDN baseline grouping by benchmark type, complete parameter set, job, and CPU domain. `TypedReadBenchmarks` uses ExcelReaderTyped; `WriterBenchmarks` uses ExcelReaderWriter. Attribution pairs have their own explicit before/candidate identity, without a competitor ratio. The PowerForge import retains native FullName and source artifacts, but currently parses the BDN parameter string `RowCount=50000&Shape=Original` into a single RowCount variable. Use the complete native parameter string and FullName for the ledger; do not collapse shapes or rewrite sealed imported metadata. Native ratio columns are preserved as produced and need not equal a hand-divided pair of means.

Keep invalid-output XLS diagnostics, differing DataTable schemas, differing Arrow inference, and verification/eagerness mismatches unpaired. Preserve independent readers, native Excel observations, validation commands and fixture provenance. Historical tuning runs, overlapped warmups, incomplete or failed jobs, profiles and Dry results remain explicitly diagnostic and outside the final ranking packets.

Reproduction commands and selectors are recorded verbatim in sealed packet metadata. **[PENDING coordinator: append portable source/saved-assembly/package commands, selected filter/env recipes, fixture hashes and retained output manifest once remaining groups are complete.]** Public install examples continue to use the version actually published; this report identifies current source behavior separately.

Publication follows the existing dated report and evidence catalog conventions described in `publication-packet-plan.md`. No catalog entry or main-tree documentation has been changed by this preparation.
