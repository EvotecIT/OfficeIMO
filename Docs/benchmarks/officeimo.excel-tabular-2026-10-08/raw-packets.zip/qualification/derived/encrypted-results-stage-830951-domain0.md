# Sealed encrypted results: 830951, domain 0

Qualified 12 cases, 12 successful fresh children and 144 native actual samples. Every normalized summary/sample/statistic/allocation metric reconciles with native data. All 9 native sidecar artifacts match retained lengths and SHA-256.

Authenticated complete field scans: two-row/two-column original ciphertext and 300K-row/four-column generated ciphertext remain separate inputs.

Memory true uses peer Open(ReadOnlyMemory) and OfficeIMO byte-array opening. Memory false and async use public stream APIs; original small uses FileStream, generated large uses MemoryStream. Labels do not imply generated-large disk I/O.

Timing includes stream creation where applicable, password derivation, decryption/full integrity verification, workbook opening, all native field scans, checksum/count checks and disposal. Immutable input loading, plaintext oracle comparison and setup checks occur outside timing.

Setup compares every field value/type/order and exact sheet/row counts against an independent Sylvan plaintext reader, across memory/stream and async routes. Each timed call enforces expected checksum and row count.

Both peer VerifyEncryptedIntegrity=true and OfficeIMO authenticated reader paths retain full integrity checks. This packet does not inject wrong-password/tamper/cancellation cases or replace the separate security correctness gates.

| Native class / method | Complete inputs | Mean ms | SD ms | Allocated bytes/op |
| --- | --- | ---: | ---: | ---: |
| EncryptedVerifiedAsyncReadBenchmarks.ExcelReaderVerifiedStreamAsync | Input: OriginalSmallXlsx | 23.182315 | 1.543077 | 64866 |
| EncryptedVerifiedAsyncReadBenchmarks.OfficeIMOVerifiedStreamAsync | Input: OriginalSmallXlsx | 22.739025 | 0.764888 | 269044 |
| EncryptedVerifiedAsyncReadBenchmarks.ExcelReaderVerifiedStreamAsync | Input: GeneratedLargeXlsx | 72.799183 | 5.148859 | 10294252 |
| EncryptedVerifiedAsyncReadBenchmarks.OfficeIMOVerifiedStreamAsync | Input: GeneratedLargeXlsx | 157.320787 | 11.963928 | 68264531 |
| EncryptedVerifiedReadBenchmarks.ExcelReaderVerifiedFullFields | Input: OriginalSmallXlsx, MemoryInput: False | 21.921355 | 1.467315 | 41564 |
| EncryptedVerifiedReadBenchmarks.OfficeIMOVerifiedFullFields | Input: OriginalSmallXlsx, MemoryInput: False | 24.061754 | 0.947613 | 267713 |
| EncryptedVerifiedReadBenchmarks.ExcelReaderVerifiedFullFields | Input: OriginalSmallXlsx, MemoryInput: True | 23.220130 | 1.239066 | 54858 |
| EncryptedVerifiedReadBenchmarks.OfficeIMOVerifiedFullFields | Input: OriginalSmallXlsx, MemoryInput: True | 23.865897 | 1.715298 | 247948 |
| EncryptedVerifiedReadBenchmarks.ExcelReaderVerifiedFullFields | Input: GeneratedLargeXlsx, MemoryInput: False | 71.674288 | 5.240247 | 9932730 |
| EncryptedVerifiedReadBenchmarks.OfficeIMOVerifiedFullFields | Input: GeneratedLargeXlsx, MemoryInput: False | 135.530542 | 13.731636 | 68263793 |
| EncryptedVerifiedReadBenchmarks.ExcelReaderVerifiedFullFields | Input: GeneratedLargeXlsx, MemoryInput: True | 74.232038 | 7.048682 | 19191434 |
| EncryptedVerifiedReadBenchmarks.OfficeIMOVerifiedFullFields | Input: GeneratedLargeXlsx, MemoryInput: True | 139.846048 | 14.515418 | 63594265 |

Native detected outlier values retained: 5. Warning rows: 0 minimum-duration, 0 distribution; 4 outlier hints. No outliers were removed. Full warnings, native confidence intervals/percentiles/statistics and all actuals are in the JSON and immutable source packet.

Raw measured iteration range: 604.430200–1263.032600 ms. Every raw measured iteration exceeds the warm >=100ms eligibility threshold.

Captured 2026-10-08T18:26:16.8091087+00:00 to 2026-10-08T18:31:18.8910402+00:00; sealed elapsed 302.081931 s. Host: AMD Ryzen 9 9950X3D2, .NET 10.0.12 (10.0.12, 10.0.1226.42308). Each measured child reports High priority and affinity 0xFFFF. Pre/post snapshots do not identify process roles, CPU during individual cases, or activity of processes absent at either endpoint. They do not prove an idle host or establish causal contamination. Fresh benchmark children and generated builds occur within the capture; original snapshots are retained. No live host audit or later-group inspection.

Frozen source/runtime 83095146282a96143b23a79a7ecca058a24a709b and harness 5E79575325D94AE8D09B97CD0C1C341EBB6AC0A24C3EEE6AE4817A897F97E7A4. Resume runner C52377235F70A38C61333009FFA2CC97C0BE2B3C102041CB127587B09AB32A95 matches the v2 sidecar; the separately preserved v1 runner is not substituted. Generated-project reference import CEDF3A831603914A5E024C980CCA65AAAAF25544D98538BC416E963DD8632B12 affects compilation references only; measured owner assemblies retain their recorded hashes.

OriginalSmallXlsx: 2 rows × 2 columns; plaintext 8915 bytes/SHA256 85FBDE3D5CC6C936BE8D9C8A5F9658E4CDED25145A2E6449C5D1FCD54F64E602; ciphertext 15360 bytes/SHA256 13F9532B916634CB112D3593E7AB859F67B2DA35A3A47E574F1C1E26C5DA370D. FileStream for stream APIs; direct memory for memory APIs. Small encryption producer unpinned; authenticated plaintext independently decrypted with msoffcrypto-tool.

GeneratedLargeXlsx: 300000 rows × 4 columns; plaintext 4629421 bytes/SHA256 D87EA1ED357D29AF19A0ABA99245C939A3BF60701BB52AFE1144F2ED9B9740C8; ciphertext 4669440 bytes/SHA256 F5323073EA9D347AEDF420284BB967E4933699AC40B6D539D94ABEEF0DBACA54. MemoryStream for stream APIs; direct memory for memory APIs. ExcelReader.NET 6.0.0 / WorkbookGenerator.BuildAsync / Excel.EncryptPackage.

Only this sealed domain 0 family was qualified. No domain 1/incomplete/later run was inspected, and no source/build/test/package/timing/fixture copy/archive/cleanup or shared report update occurred. Normalized duplicate samples remain in immutable source references; this packet adds no pooled or cross-contract ratio.
