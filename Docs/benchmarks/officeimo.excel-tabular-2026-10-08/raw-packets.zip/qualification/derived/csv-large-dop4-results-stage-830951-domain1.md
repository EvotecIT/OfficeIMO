# Sealed large CSV DOP 4: domain 1, frozen 830951

21 successful cases across 2 native tables/3 full-scale inputs; 168 measured samples. Source/runtime=83095146282a96143b23a79a7ecca058a24a709b; benchmark source unchanged from e676775a59458d1095606386c39506ceb8a9bc33. Started 2026-10-08T20:55:30.6642543+00:00,finished 2026-10-08T21:16:56.012155+00:00,context ended 2026-10-08T21:16:56.0902108Z.

Huge CSV recipe: 1 launch/4 warmups/8 measurements/250 ms automatic Pilot/unroll 1/DontRemove;High priority/0xFFFF0000,DOP 4. Actual duration478.4654–12325.4866ms,all >= 100 ms. 0 short/0 distribution rows; 6 outlier hints/6 native outlier values.

- 21 successful domain 1 cases retain all native/normalized measurements, allocations, outliers and actual input identities. Input content is compared with domain 0; timings and allocations remain separate observations.
- Typed automatic classes, decoded-text factories, public text and async direct reduction retain different materialization and ownership strategies. All original 4.3M/8M/3M inputs and full Input/Dop identities are preserved. Allocated bytes are cumulative managed allocation, not retained/peak memory.
- Twelve ReadAsync>0/Read=0 observations are untimed Setup probes of the public OfficeIMO Stream aggregate, including child instances timing peer/TextOwned methods. They are not timed invocation counters or peer IO claims.
- No global speed or parallel-scaling claim. Valid slower results are included in full tables and samples; endpoint process snapshots establish neither isolation nor causal contamination.

## Input identity and full result qualification

| Full input | Rows | Fields | Child occurrences | Bytes | Expected count/sum | SHA256 |
| --- | ---: | ---: | ---: | ---: | ---: | --- |
| ConversionHeavy-4300000 | 4300000 | 6 | 7 | 207563853 | 4300000/1077150000 | 86B1EE25363929A54CEA19CDA95BD63BC5F08B053B3DF7FBC83E76A0AA2634EF |
| ConversionHeavy3M-3000000 | 3000000 | 6 | 7 | 144811299 | 3000000/751500000 | FB01381C6257B7E716EF069DD14CCC19F1128DDDD3584A3409D5BA05BB240F63 |
| NarrowInt-8000000 | 8000000 | 3 | 7 | 209597884 | 8000000/31999996000000 | 23CC15B690540E2D15F6BDA51184E5B4D20EB3219447B860497CE02052EC0680 |

Each input is generated/fingerprinted before timing. Every method opens/reads the complete file inside timing. Text factory and text-owned reduction perform File.ReadAllText/UTF8 decode inside each invocation; async reductions use actual path/Stream ReadAsync and decoded-field snapshots. Twelve untimed Setup probes of the actual public OfficeIMO Stream aggregate show asynchronous reads>0/synchronous reads0, one per direct-aggregate child. The probes do not describe the peer/TextOwned timed operations and do not collect counters per measured invocation. Typed mapping consumes materialized classes; direct reduction consumes all fields into independent sum/count states without mapped result arrays. Setup validates every typed field/source order or every direct field and exact repeating-row multiplicity; checksum alone is not the integrity proof.

Native FullName preserves full Input/Dop identity; abbreviated native Parameters remain unchanged alongside the resolved input. Original4.3M/8M/3M shapes and DOP 4 are not pooled with smaller inputs, DOP1 or other data contracts. Old caller-reduction diagnostics are not selected in this21-case group. No output workbook or serialized mapped-record file is part of these contracts.

## CsvDirectAggregateBenchmarks

Three original full files,DOP 4. Peer CsvParallel.AggregateAsync uses UTF8 ref/struct fields and independent native states; OfficeIMO public AggregateTextRowsAsParallel reads/decodes whole file inside timing, public AggregateRowsAsParallelAsync path/stream reads incrementally with decoded UTF16 field snapshots. All6 heavy fields/all3 narrow integers consumed; states sum Units/A and count rows without mapped result arrays. Every consumed field and repeating-row multiplicity is proved in Setup. UTF8 versus decoded text/materialization pipeline remains explicit; bounded retained state is not low cumulative allocation.

| Method | Resolved full input / DOP | Mean ms | SD ms | Allocated bytes | Min actual iteration ms |
| --- | --- | ---: | ---: | ---: | ---: |
| ExcelReaderAggregate | ConversionHeavy-4300000 / 4 | 157.829791 | 18.389461 | 1521780 | 557.5744 |
| OfficeIMOTextOwnedAggregate | ConversionHeavy-4300000 / 4 | 525.687537 | 20.863627 | 832883414 | 1981.3001 |
| OfficeIMOAsyncPathAggregate | ConversionHeavy-4300000 / 4 | 2154.473562 | 445.117849 | 1955513270 | 6297.6107 |
| OfficeIMOAsyncStreamAggregate | ConversionHeavy-4300000 / 4 | 1706.705200 | 136.572891 | 1955510178 | 6202.9058 |
| ExcelReaderAggregate | ConversionHeavy3M-3000000 / 4 | 128.442166 | 6.402401 | 1070718 | 480.3993 |
| OfficeIMOTextOwnedAggregate | ConversionHeavy3M-3000000 / 4 | 409.449841 | 63.460071 | 582023410 | 1364.5605 |
| OfficeIMOAsyncPathAggregate | ConversionHeavy3M-3000000 / 4 | 1261.226319 | 167.136402 | 1364310624 | 4276.5000 |
| OfficeIMOAsyncStreamAggregate | ConversionHeavy3M-3000000 / 4 | 1169.391353 | 107.968823 | 1364315096 | 4245.9498 |
| ExcelReaderAggregate | NarrowInt-8000000 / 4 | 134.143900 | 13.189097 | 1689448 | 478.4654 |
| OfficeIMOTextOwnedAggregate | NarrowInt-8000000 / 4 | 824.981844 | 57.400061 | 841363596 | 2900.5698 |
| OfficeIMOAsyncPathAggregate | NarrowInt-8000000 / 4 | 2456.013537 | 398.429464 | 2273397568 | 7715.4587 |
| OfficeIMOAsyncStreamAggregate | NarrowInt-8000000 / 4 | 2780.618716 | 230.922051 | 2273378276 | 9691.3142 |

## CsvParallelTypedBenchmarks

Same4.3M/8M/3M full files,DOP 4. Same materialized heavy6-field/narrow3-integer classes across automatic peer CsvParallel/attribute sequential parser, OfficeIMO Core.RowsAsParallel, public decoded-text factory ReadTextRowsAsParallel, Sylvan GetRecords sequential. Text factory includes File.ReadAllText/UTF8 decode in each timed call. Each engine Setup checks every mapped field/source order/count before timing; result rows are consumed into same Units/A checksum. Parallel and sequential pipelines remain distinct.

| Method | Resolved full input / DOP | Mean ms | SD ms | Allocated bytes | Min actual iteration ms |
| --- | --- | ---: | ---: | ---: | ---: |
| ExcelReaderParallel | ConversionHeavy-4300000 / 4 | 231.044075 | 23.474612 | 713223128 | 840.3218 |
| OfficeIMOCoreParallel | ConversionHeavy-4300000 / 4 | 1242.649528 | 202.422934 | 1920274868 | 4348.2952 |
| OfficeIMOTextParallel | ConversionHeavy-4300000 / 4 | 385.013331 | 42.415618 | 1535517516 | 1414.0621 |
| ExcelReaderParallel | ConversionHeavy3M-3000000 / 4 | 151.876113 | 8.324893 | 497622966 | 573.0354 |
| OfficeIMOCoreParallel | ConversionHeavy3M-3000000 / 4 | 756.633462 | 18.198575 | 1339681480 | 2967.1985 |
| OfficeIMOTextParallel | ConversionHeavy3M-3000000 / 4 | 372.734141 | 26.868164 | 1071926296 | 1348.9619 |
| ExcelReaderParallel | NarrowInt-8000000 / 4 | 153.599259 | 16.726447 | 266943718 | 540.2699 |
| OfficeIMOCoreParallel | NarrowInt-8000000 / 4 | 1427.008041 | 75.478148 | 1950323488 | 5216.1609 |
| OfficeIMOTextParallel | NarrowInt-8000000 / 4 | 446.100569 | 49.128403 | 1098722924 | 1554.6716 |

## Runtime and host boundary

Outer harness5E79575325D94AE8D09B97CD0C1C341EBB6AC0A24C3EEE6AE4817A897F97E7A4;runnerC52377235F70A38C61333009FFA2CC97C0BE2B3C102041CB127587B09AB32A95;generated-project saved-reference hookCEDF3A831603914A5E024C980CCA65AAAAF25544D98538BC416E963DD8632B12. All 84 loaded-owner identities match frozen quartet. Failure/Dry stays separate; repair does not change product/outer harness.

Boundary snapshots:40/50 entries,34 persistent/16 new IDs,max persistent CPUdelta0.359375s,sum3.921875s. No command roles/per-case timeline; no isolation or causal contamination established. No live audit.

## Native warnings and hints

Native type/method/full input/DOP/job tables remain authoritative. Warning prose omitting parameters retains ambiguity; all per-case intervals/outlier arrays/Actuals/Results/allocations remain in JSON. Retain every native warning and valid slower result.

~~~text
// * Hints *
Outliers
  CsvParallelTypedBenchmarks.ExcelReaderParallel: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=8, IterationTime=250 ms, LaunchCount=1, UnrollFactor=1, WarmupCount=4   -> 1 outlier  was  detected (274.72 ms)
  CsvParallelTypedBenchmarks.OfficeIMOCoreParallel: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=8, IterationTime=250 ms, LaunchCount=1, UnrollFactor=1, WarmupCount=4 -> 1 outlier  was  detected (1.72 s)
  CsvParallelTypedBenchmarks.OfficeIMOTextParallel: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=8, IterationTime=250 ms, LaunchCount=1, UnrollFactor=1, WarmupCount=4 -> 1 outlier  was  detected (475.72 ms)
  CsvParallelTypedBenchmarks.ExcelReaderParallel: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=8, IterationTime=250 ms, LaunchCount=1, UnrollFactor=1, WarmupCount=4   -> 1 outlier  was  detected (168.31 ms)
  CsvParallelTypedBenchmarks.OfficeIMOCoreParallel: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=8, IterationTime=250 ms, LaunchCount=1, UnrollFactor=1, WarmupCount=4 -> 1 outlier  was  detected (797.77 ms)
  CsvParallelTypedBenchmarks.ExcelReaderParallel: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=8, IterationTime=250 ms, LaunchCount=1, UnrollFactor=1, WarmupCount=4   -> 1 outlier  was  detected (189.50 ms)
~~~

This qualifies 21 domain 1 primary cases. Shared counters wait for all four final packets. Domain observations and historical evidence remain separate; no global winner claim. Native originals unchanged; no source/build/test/timer/package/profile/fixturecopy/archive/cleanup/publication.