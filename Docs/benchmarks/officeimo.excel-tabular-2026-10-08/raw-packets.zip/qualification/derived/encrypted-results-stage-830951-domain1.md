# Qualified encrypted capture, domain1

Qualified 12 cases, 12 successful fresh children and 144 native actual samples. Every normalized summary/sample/statistic/allocation and native GC descriptor reconciles with native data. All nine native sidecar artifacts match SHA-256 and length. Frozen830951 owners, harness, v2 runner/reference hook and High/0xFFFF0000 match. Run qualified-830951-long-v2-domain1-encrypted. Capture identity derives from sealed context/sidecar, not importer IDs/timestamps.

Authenticated complete field scans: two-row/two-column original ciphertext and 300K-row/four-column generated ciphertext remain separate inputs.

Memory true uses peer Open(ReadOnlyMemory) and OfficeIMO byte-array opening. Memory false and async use public stream APIs; original small uses FileStream, generated large uses MemoryStream. Labels do not imply generated-large disk I/O.

Timing includes stream creation where applicable, password derivation, decryption/full integrity verification, workbook opening, all native field scans, checksum/count checks and disposal. Immutable input loading, plaintext oracle comparison and setup checks occur outside timing.

Setup compares every field value/type/order and exact sheet/row counts against an independent Sylvan plaintext reader, across memory/stream and async routes. Each timed call enforces expected checksum and row count.

Both peer VerifyEncryptedIntegrity=true and OfficeIMO authenticated reader paths retain full integrity checks. This packet does not inject wrong-password/tamper/cancellation cases or replace the separate security correctness gates.

| Native class / method | Complete input and caller | Mean ms | SD ms | Managed diagnostic bytes/op |
|---|---|---:|---:|---:|
| EncryptedVerifiedAsyncReadBenchmarks.ExcelReaderVerifiedStreamAsync | Input: OriginalSmallXlsx; async stream/FileStream | 20.807485 | 0.120567 | 61075 |
| EncryptedVerifiedAsyncReadBenchmarks.OfficeIMOVerifiedStreamAsync | Input: OriginalSmallXlsx; async stream/FileStream | 22.274829 | 1.080673 | 269402 |
| EncryptedVerifiedAsyncReadBenchmarks.ExcelReaderVerifiedStreamAsync | Input: GeneratedLargeXlsx; async stream/MemoryStream | 78.911263 | 12.520886 | 10512056 |
| EncryptedVerifiedAsyncReadBenchmarks.OfficeIMOVerifiedStreamAsync | Input: GeneratedLargeXlsx; async stream/MemoryStream | 136.265775 | 6.864899 | 69321524 |
| EncryptedVerifiedReadBenchmarks.ExcelReaderVerifiedFullFields | Input: OriginalSmallXlsx, MemoryInput: False; sync stream/FileStream | 22.626199 | 0.604528 | 46274 |
| EncryptedVerifiedReadBenchmarks.OfficeIMOVerifiedFullFields | Input: OriginalSmallXlsx, MemoryInput: False; sync stream/FileStream | 21.622982 | 1.398283 | 267699 |
| EncryptedVerifiedReadBenchmarks.ExcelReaderVerifiedFullFields | Input: OriginalSmallXlsx, MemoryInput: True; direct memory | 25.149872 | 2.401771 | 54895 |
| EncryptedVerifiedReadBenchmarks.OfficeIMOVerifiedFullFields | Input: OriginalSmallXlsx, MemoryInput: True; direct memory | 21.289332 | 2.534642 | 247954 |
| EncryptedVerifiedReadBenchmarks.ExcelReaderVerifiedFullFields | Input: GeneratedLargeXlsx, MemoryInput: False; sync stream/MemoryStream | 86.086372 | 7.121718 | 9983411 |
| EncryptedVerifiedReadBenchmarks.OfficeIMOVerifiedFullFields | Input: GeneratedLargeXlsx, MemoryInput: False; sync stream/MemoryStream | 140.362149 | 18.673292 | 69673404 |
| EncryptedVerifiedReadBenchmarks.ExcelReaderVerifiedFullFields | Input: GeneratedLargeXlsx, MemoryInput: True; direct memory | 62.244352 | 0.723270 | 19224242 |
| EncryptedVerifiedReadBenchmarks.OfficeIMOVerifiedFullFields | Input: GeneratedLargeXlsx, MemoryInput: True; direct memory | 134.101479 | 8.024900 | 63596021 |

Raw WorkloadActual range 501.5387–1462.1692 ms. Native diagnostic rows: 0 minimum-duration warnings, 0 distribution warnings and 5 outlier hints; 8 native outlier values retained. DontRemove preserves all samples and per-case native arrays. Method-level hints can omit parameters; they are not assigned to specific input cases.

Recipe: 1 launch, 8 warmups, 12 actual iterations, 1-second target, unroll1, DontRemove. Every raw actual exceeds100 ms. Setup validates every field/type/order/count against independent decrypted-plaintext reading; timed calls enforce checksum/count with authenticated integrity verification. Small original and generated300K inputs remain separate; direct memory, FileStream and MemoryStream caller strategies remain explicit.

OriginalSmallXlsx: 2 rows, 2 columns; plaintext 8915 bytes/SHA256 85FBDE3D5CC6C936BE8D9C8A5F9658E4CDED25145A2E6449C5D1FCD54F64E602; ciphertext 15360 bytes/SHA256 13F9532B916634CB112D3593E7AB859F67B2DA35A3A47E574F1C1E26C5DA370D. FileStream for stream APIs; direct memory for memory APIs. Agile AES256/SHA512 corpus fixture. Small encryption producer unpinned; authenticated plaintext independently decrypted with msoffcrypto-tool.

GeneratedLargeXlsx: 300000 rows, 4 columns; plaintext 4629421 bytes/SHA256 D87EA1ED357D29AF19A0ABA99245C939A3BF60701BB52AFE1144F2ED9B9740C8; ciphertext 4669440 bytes/SHA256 F5323073EA9D347AEDF420284BB967E4933699AC40B6D539D94ABEEF0DBACA54. MemoryStream for stream APIs; direct memory for memory APIs. Agile AES-256-CBC/SHA-512/spin100000/dataIntegrity. ExcelReader.NET 6.0.0 / WorkbookGenerator.BuildAsync / Excel.EncryptPackage.

Encrypted warm allocation is native diagnostic managed bytes/op, separate from actual elapsed samples and retained/peak memory. Password derivation/decryption/full integrity/workbook opening/full native scans/disposal remain inside the timed operation; fixture loading and full plaintext oracle comparison are outside timing. No new tamper/wrong-password/cancellation probe is claimed.

Domain0 comparison establishes matching owning-source/input/lifecycle contracts only; elapsed and allocation observations stay separate. Valid losses and variance are retained without cross-domain pooling, cache/isolation attribution or ranking cold latency with warm throughput.

Capture 2026-10-08T21:20:51.6134789+00:00 to 2026-10-08T21:26:05.4553275+00:00, elapsed 313.8418486 seconds, sealed 2026-10-08T21:26:05.5272970Z. Native total: Global total time: 00:05:11 (311.3 sec), executed benchmarks: 12

Host endpoints: 50/65 entries; 47 persistent matches; maximum observed CPU delta 1.609375 seconds, sum 9.843750 seconds. Pre/post snapshots do not identify process roles, CPU during individual cases, or activity of processes absent at either endpoint. They do not prove an idle host or establish causal contamination. Fresh benchmark children and generated builds occur within the capture; original snapshots are retained. No live host audit or later-group inspection.

Source/runtime 83095146282a96143b23a79a7ecca058a24a709b; unchanged benchmark source e676775a59458d1095606386c39506ceb8a9bc33. Harness 5E79575325D94AE8D09B97CD0C1C341EBB6AC0A24C3EEE6AE4817A897F97E7A4; v2 resume runner C52377235F70A38C61333009FFA2CC97C0BE2B3C102041CB127587B09AB32A95; generated-project reference import CEDF3A831603914A5E024C980CCA65AAAAF25544D98538BC416E963DD8632B12. Saved owners remain unchanged; hook affects generated compile references only. All native artifacts, frozen output-proof/input refs and case measurements remain in JSON/manifest.

Only the assigned sealed encrypted/cold domain1 packets were derived. No source/build/test/package/timing run, fixture copy, archive, cleanup or shared report mutation. Native/import evidence remains in place; no current topology change or package qualification against830951.
