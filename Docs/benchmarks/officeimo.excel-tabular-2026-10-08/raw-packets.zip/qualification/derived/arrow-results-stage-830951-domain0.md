# Sealed Arrow conversion: domain 0, frozen 830951

Seven successful cases across two native tables; 105 measured samples. Source/runtime 83095146282a96143b23a79a7ecca058a24a709b; benchmark source unchanged from e676775a59458d1095606386c39506ceb8a9bc33. Started 2026-10-08T18:22:10.9507805+00:00; finished 2026-10-08T18:26:16.3132345+00:00; context ended 2026-10-08T18:26:16.3841965Z.

Ordinary recipe: one launch / 12 warmups / 15 measurements / 1000 ms automatic Pilot / unroll 1 / DontRemove, High priority and 0xFFFF. All actual durations 726.5266–1264.1386ms; all >= 100 ms. 0 short/1 distribution rows; 3 outlier hints/7 native outlier values.

- All 7 conversion cases succeed with 105 matching measured samples and exact native statistics/managed allocations. Explicit one-batch output schemas/nullability/values/order match. All sources/readers/owned batches are disposed in ordinary timed methods.
- OfficeIMO explicit conversion is slower and allocates more in all three selected domain 0 scenarios: wide CSV 42.747ms/51,803,353B versus peer 14.611ms/17,058,621B; typed CSV 26.870ms/22,597,304B versus 9.691ms/8,528,877B; typed XLSB 24.170ms/9,529,745B versus 15.154ms/8,532,085B. Preserve these valid losses and distribution/outlier evidence.
- The peer-only inference row 10.949ms/15,610,025B has four required string fields. OfficeIMO inferred string/int32/microsecond timestamp/decimal128(29,10) output is qualified in Setup but unpaired; no ratio between unequal inferred schemas.
- Three input fingerprints are logged per child. Timed source selection is recorded explicitly. CSV bytes match across all seven children; generated XLSB package hashes and logged ZIP entry timestamps differ, while all eight inflated entry names/lengths/SHA256 values match. This is actual input identity evidence, not unrelated output archive identity.
- This group measures optional Arrow conversion ownership, not RecordBatch-to-XLSX writing, bounded 8192 batches or native interchange exports. The separately captured Arrow string writer remains ordinary public row orchestration; no dedicated production RecordBatch writer claim.
- Only requested sealed Arrow/domain0 inspected. Allocated is cumulative managed bytes per operation, not total/native Arrow or peak/retained memory. No domain1 or universal winner claim.

## Validated output and API ownership

100,000 rows delivered in one owned RecordBatch with required fields. Explicit CSV typed and XLSB typed schemas are string/int64/timestamp(microsecond,no timezone)/float64; eight-string CSV schema is c0..c7 strings. Both public conversion routes open identical byte-backed inputs inside timing, publish the full batch, consume its length and dispose all batches/readers. Schema, nullability, null counts, every field and source order are validated outside timing.

| Native class / method | Full selected scenario | Mean ms | SD ms | Allocated managed bytes | Min actual iteration ms |
| --- | --- | ---: | ---: | ---: | ---: |
| ArrowConversionBenchmarks.ExcelReader | CsvAllString / 100000 rows | 14.610975 | 1.127037 | 17058621 | 878.8831 |
| ArrowConversionBenchmarks.OfficeIMO | CsvAllString / 100000 rows | 42.747244 | 3.614946 | 51803353 | 906.1808 |
| ArrowConversionBenchmarks.ExcelReader | CsvTyped / 100000 rows | 9.690893 | 0.941737 | 8528877 | 785.8063 |
| ArrowConversionBenchmarks.OfficeIMO | CsvTyped / 100000 rows | 26.870489 | 1.480780 | 22597304 | 970.6542 |
| ArrowConversionBenchmarks.ExcelReader | XlsbTyped / 100000 rows | 15.154069 | 0.965026 | 8532085 | 898.0488 |
| ArrowConversionBenchmarks.OfficeIMO | XlsbTyped / 100000 rows | 24.169845 | 2.351029 | 9529745 | 726.5266 |

Unpaired upstream peer inference diagnostic: 100,000 typed CSV rows delivered as four required string fields. Setup also validates ordinary OfficeIMO inference as string/int32/microsecond timestamp/decimal128(29,10); these schemas differ and no paired ratio is published.

| Native class / method | Full selected scenario | Mean ms | SD ms | Allocated managed bytes | Min actual iteration ms |
| --- | --- | ---: | ---: | ---: | ---: |
| ArrowInferredConversionBenchmarks.ExcelReader_CsvTypedWithInference | CsvTypedInference / 100000 rows | 10.948997 | 0.551513 | 15610025 | 866.5309 |

The optional OfficeIMO.Data.Arrow provider converts ordinary Excel/CSV DbDataReaders through ReadArrowBatches. Required nullability, field names/types, null counts, microsecond timestamp unit/timezone, every value and source order are qualified in child Setup. BatchSize100000 emits one complete owned batch just as the peer explicit ToArrowRecordBatch route. Input opening, full reading/parsing, conversion, count consumption and reader/batch disposal are inside timing; validation occurs before timing. Managed allocation is not total unmanaged Arrow memory.

The peer inference row is separate: parseText=false defaults produce four required strings. OfficeIMO ordinary inference produces string/int32/microsecond timestamp/decimal128(29,10), all checked outside timing. There is no paired inference ranking. This packet contains neither bounded 8192 conversion, Arrow export nor Arrow string writing; the separately measured caller row.WriteUtf8 orchestration does not establish a dedicated RecordBatch writer API.

## Actual input identities

| Prepared input (all three logged per child) | Occurrences | Bytes | Distinct package hashes | SHA256 identity |
| --- | ---: | ---: | ---: | --- |
| read/arrow/CsvAllString/rows=100000/columns=8 | 7 | 4600000 | 1 | 3E5EA7EA00C63E66CFA5DCD6CA75B2DDAB78533F249A6660CE6994E4A86B40F5 |
| read/arrow/CsvTyped/dataRows=100000/columns=4 | 7 | 4689844 | 1 | 27329B5DEC85816F43EF9DDFF983B5CED3DF900C8F89FA3275D021A57364A6D8 |
| read/typed/Xlsb/dataRows=100000 | 7 | 1748715 | 7 | All actual package hashes retained per child in JSON; inflated parts match |

Every case records its selected timed input separately from the other two prepared inputs. All seven XLSB instances have identical eight inflated entry names/lengths/SHA256 values; package hashes and logged ZIP timestamps differ, and both are retained. No source bytes are recopied or regenerated by this report task.

| XLSB inflated part | Occurrences | Inflated bytes | SHA256 |
| --- | ---: | ---: | --- |
| _rels/.rels | 7 | 438 | 93EBC98ECD0A158942C51A10F12DDC2B849917154EFC2328F6AD20D6BC47F6D2 |
| [Content_Types].xml | 7 | 899 | FC62B911F2BFE6482E812242BBE93E8AB727D4453C9CA8D3C09D0A43C58DF22C |
| docProps/app.xml | 7 | 231 | 215F432F2989969565FC2DDB8BF4F6E0B8958EFA7E752C2BB373B3129699E1C2 |
| xl/_rels/workbook.bin.rels | 7 | 557 | 7F57FC54E0C74E705DAAF71856E9C7854EA19A7BFA4CEFF24AEE5C18D7C8A7B2 |
| xl/sharedStrings.bin | 7 | 14 | A598F2C2704EF01CBC4F9DFB4888054023C0B6A1E19C7E4DA7F0C06A6EE0266B |
| xl/styles.bin | 7 | 390 | 7B252C122048E3899F452448E1C33B1AE159B7DAF8FD4296B4314CAE766DC5A9 |
| xl/workbook.bin | 7 | 54 | 1E3461BD8B29F0FE94FB6F4B41915D6A1600BF3EAF7E4C8ECA8EA95F9A09ED5E |
| xl/worksheets/sheet1.bin | 7 | 9850279 | 558D0D1243BE283CD8C0D26087113CB5BE55E4BD1EF2EE8687E9EDE2FEDA557D |

## Runtime, host boundary and native diagnostics

Outer harness 5E79575325D94AE8D09B97CD0C1C341EBB6AC0A24C3EEE6AE4817A897F97E7A4; runner C52377235F70A38C61333009FFA2CC97C0BE2B3C102041CB127587B09AB32A95; generated-project-only saved-reference hook CEDF3A831603914A5E024C980CCA65AAAAF25544D98538BC416E963DD8632B12. All 28 loaded-owner hashes/versions match the frozen quartet. Context and provenance artifacts are preserved and SHA/length verified.

Boundary snapshots 95/81 entries; 75 persistent/6 new IDs; max persistent CPU delta 3.484375s,sum 37.281250s. Boundary data lacks command roles/per-case timelines and does not establish isolation or causal contamination. No live audit.

Warning prose omitting parameters retains ambiguity; native grouped class/parameter/job tables and all sample distributions remain authoritative. Every native interval, outlier array, Actual/Result, statistic and allocation is retained.

~~~text
// * Warnings *
MultimodalDistribution
  ArrowConversionBenchmarks.OfficeIMO: OutlierMode=DontRemove, Affinity=00000000000000001111111111111111, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12 -> It seems that the distribution can have several modes (mValue = 3)
// * Hints *
Outliers
  ArrowConversionBenchmarks.OfficeIMO: OutlierMode=DontRemove, Affinity=00000000000000001111111111111111, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12   -> 1 outlier  was  detected (34.85 ms)
  ArrowConversionBenchmarks.OfficeIMO: OutlierMode=DontRemove, Affinity=00000000000000001111111111111111, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12   -> 4 outliers were detected (24.27 ms..24.81 ms, 30.18 ms)
  ArrowConversionBenchmarks.ExcelReader: OutlierMode=DontRemove, Affinity=00000000000000001111111111111111, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12 -> 2 outliers were detected (16.99 ms, 17.04 ms)
~~~

This qualifies seven additional primary cases; shared counters wait for reconciliation with DOP4 and separately assigned encryption/cold packets. Native originals unchanged; no incomplete/domain1 results inspected and no source/build/test/timer/package/profile/fixturecopy/archive/cleanup/public action.