# Generated workbook results — sealed domain 0 at 830951

Only the sealed group qualified-830951-long-v1-domain0-generated is included. Capture/runtime source is 83095146282a96143b23a79a7ecca058a24a709b; benchmark source is unchanged from e676775a59458d1095606386c39506ceb8a9bc33. Domain 1 and Remaining families are pending. No incomplete real result was inspected. Native grouped reports, full statistics and warnings remain authoritative.

The packet reconciles 54 successful children, 54 native/normalized case identities and 810 retained measurements (15 per case). Every WorkloadActual exceeds 100 ms: minimum 157.814ms, maximum 1644.017ms. There are 0 short-iteration warnings and 9 distribution-warning rows. DontRemove retains all outliers; warnings that omit parameters remain ambiguous.

Capture started 2026-10-08T13:56:36.8577632+00:00; sidecar finished 2026-10-08T14:27:48.8889543+00:00; context ended 2026-10-08T14:27:49.2616887Z. Job: one launch, 12 warmups, 15 measurements, 1,000 ms Pilot, unroll 1, High priority, affinity 65535. This is one cache/affinity domain on one host, not an independent second machine.

Host snapshots contain 62 before / 95 after processes, with 41 new IDs; maximum observed persistent CPU delta 3.390625 s. Pre/post snapshots lack command roles and per-case timelines. They establish neither full isolation nor causal contamination. Task-owned build/test/profile/archive work was excluded during timing by coordinator; no live process audit or rerun performed for count changes.

## Scoped findings

- Domain 0 only. Automatic OfficeIMO class and struct mapping are slower than peer here but allocate fewer managed bytes. These are genuine ordinary automatic APIs, distinct from main manual construction.
- Matched materialized raw OfficeIMO is slower and allocates more than peer for XLSX/XLSB/XLS sync and async here. Losses remain valid evidence, not correctness exclusions.
- Borrowed ref-struct peer automatic mapping is faster and allocates less than OfficeIMO public factory here. Factory work is timed caller orchestration; automatic arbitrary ref-struct mapping remains a separate gap.
- Typed XLSB sync OfficeIMO 10.096ms versus peer 9.340ms with 4,268,988 versus 4,058,814B. Typed XLSB async OfficeIMO 17.561ms versus peer 9.191ms with 9,123,891 versus 4,059,104B. Opening/projection strategies differ; no global winner claim.
- All 810 measured actuals exceed 100 ms. Native distribution warnings and every outlier/sample remain; adequate duration does not establish a small-margin statistical ranking.
- Every case has actual input identity. ZIP inflated manifests/compressed lengths match within each shape while timestamps vary; legacy XLS bytes are identical. No incomplete real or domain 1 result inspected.
- Native pre/post host process counts differ. Without command-role/per-case evidence this neither proves an isolated machine nor causally establishes contamination; preserve native context without a live audit.

Automatic class: OfficeIMO 17.674 ± 0.335 ms / 2,519,646 B versus peer 10.860 ± 1.548 ms / 4,054,600 B. Automatic struct: OfficeIMO 15.934 ± 0.842 ms / 176,065 B versus peer 11.787 ± 0.893 ms / 1,660,540 B. Ref-struct factory: OfficeIMO 13.280 ± 0.344 ms / 79,159 B versus peer automatic 9.733 ± 0.486 ms / 4,464 B. All are domain 0 results; no global ranking is inferred.

## Every selected native case

Managed allocation is per operation, not retained cache/native memory or peak working set. Tables use native mean ± SD. JSON preserves complete identity/job, confidence intervals, all samples/outliers and actual operation counts. Do not pool ratios across classes. Method warning matches do not identify parameters omitted by native warnings.

### BorrowedRefStructReadBenchmarks

Same original 50K XLSX span-bearing model values and complete checksum/count. Peer automatic ref-struct mapping versus OfficeIMO public RowsAsBorrowed factory calling borrowed UTF8/name and native numeric/date getters. Factory orchestration timed. No automatic OfficeIMO ref-struct mapper claimed; manual-loop method not selected.

| Method | Full parameters | Mean ± SD (ms/op) | Allocated B/op | Actual iteration min–max (ms) | N |
| --- | --- | ---: | ---: | ---: | ---: |
| ExcelReaderMappedRefStruct | RowCount=50000 | 9.733 ± 0.486 | 4464 | 1015.819–1182.027 | 15 |
| OfficeIMOFactoryRefStruct | RowCount=50000 | 13.280 ± 0.344 | 79159 | 998.354–1100.108 | 15 |

Native full report: D:\Dev\Scratch\officeimo-excelreader-performance\final-runs\qualified-830951-long-v1-domain0-generated\20261008-155637\OfficeIMO.Excel.ReaderComparison.Benchmarks.BorrowedRefStructReadBenchmarks-report-full.json

### MaterializedRawAsyncReadBenchmarks

Same raw async lifecycle differences, with strings materialized in all engines. Complete fields/count/checksum matched; original borrowed raw rows remain separate.

| Method | Full parameters | Mean ± SD (ms/op) | Allocated B/op | Actual iteration min–max (ms) | N |
| --- | --- | ---: | ---: | ---: | ---: |
| ExcelReaderStringsMaterializedAsync | RowCount=50000&Format=Xlsx | 9.980 ± 0.318 | 1658933 | 905.369–1011.912 | 15 |
| OfficeIMOAsync | RowCount=50000&Format=Xlsx | 15.774 ± 0.727 | 3678327 | 878.175–1032.311 | 15 |
| SylvanAsync | RowCount=50000&Format=Xlsx | 41.083 ± 4.387 | 1986624 | 767.603–1124.768 | 15 |
| ExcelReaderStringsMaterializedAsync | RowCount=50000&Format=Xlsb | 4.710 ± 0.504 | 1654304 | 854.847–1243.160 | 15 |
| OfficeIMOAsync | RowCount=50000&Format=Xlsb | 8.950 ± 1.418 | 5372428 | 1003.517–1644.017 | 15 |
| SylvanAsync | RowCount=50000&Format=Xlsb | 8.760 ± 0.304 | 1911217 | 985.733–1116.543 | 15 |
| ExcelReaderStringsMaterializedAsync | RowCount=50000&Format=Xls | 5.236 ± 0.137 | 1653516 | 1036.803–1130.556 | 15 |
| OfficeIMOAsync | RowCount=50000&Format=Xls | 7.390 ± 0.924 | 10751207 | 643.668–986.468 | 15 |
| SylvanAsync | RowCount=50000&Format=Xls | 6.004 ± 0.313 | 1760296 | 1035.067–1258.404 | 15 |

Native full report: D:\Dev\Scratch\officeimo-excelreader-performance\final-runs\qualified-830951-long-v1-domain0-generated\20261008-155637\OfficeIMO.Excel.ReaderComparison.Benchmarks.MaterializedRawAsyncReadBenchmarks-report-full.json

### MaterializedRawReadBenchmarks

Same headerless raw inputs, all strings materialized in each engine. Every field/type/order/count is validated outside timing; full raw checksum/count in timing. Ordinary scalar API and boxing costs remain. Public opening/traversal/disposal included.

| Method | Full parameters | Mean ± SD (ms/op) | Allocated B/op | Actual iteration min–max (ms) | N |
| --- | --- | ---: | ---: | ---: | ---: |
| ExcelReaderStringsMaterialized | RowCount=50000&Format=Xlsx | 8.701 ± 0.374 | 1653912 | 917.570–1091.208 | 15 |
| OfficeIMOOriginal | RowCount=50000&Format=Xlsx | 15.467 ± 0.541 | 3678257 | 1013.091–1158.704 | 15 |
| Sylvan | RowCount=50000&Format=Xlsx | 44.067 ± 2.224 | 1985697 | 916.789–1072.134 | 15 |
| ExcelReaderStringsMaterialized | RowCount=50000&Format=Xlsb | 5.933 ± 0.180 | 1654232 | 945.780–1047.161 | 15 |
| OfficeIMOOriginal | RowCount=50000&Format=Xlsb | 10.318 ± 0.410 | 5372506 | 1295.275–1488.731 | 15 |
| Sylvan | RowCount=50000&Format=Xlsb | 9.194 ± 0.177 | 1910394 | 1058.432–1140.151 | 15 |
| ExcelReaderStringsMaterialized | RowCount=50000&Format=Xls | 4.763 ± 0.151 | 1652904 | 1060.157–1204.112 | 15 |
| OfficeIMOOriginal | RowCount=50000&Format=Xls | 8.068 ± 0.170 | 10751134 | 962.932–1041.628 | 15 |
| Sylvan | RowCount=50000&Format=Xls | 6.753 ± 0.337 | 1758984 | 875.671–1043.086 | 15 |

Native full report: D:\Dev\Scratch\officeimo-excelreader-performance\final-runs\qualified-830951-long-v1-domain0-generated\20261008-155637\OfficeIMO.Excel.ReaderComparison.Benchmarks.MaterializedRawReadBenchmarks-report-full.json

### RawAsyncReadBenchmarks

Same original raw semantic work through public async APIs: peer async Stream opening, OfficeIMO synchronous byte[] opening plus ReadAsync, Sylvan synchronous create plus ReadAsync. Opening/I/O strategies differ; prepared MemoryStream is not blocked-I/O scalability evidence.

| Method | Full parameters | Mean ± SD (ms/op) | Allocated B/op | Actual iteration min–max (ms) | N |
| --- | --- | ---: | ---: | ---: | ---: |
| ExcelReaderAsync | RowCount=50000&Format=Xlsx | 8.900 ± 0.149 | 8596 | 889.749–942.441 | 15 |
| OfficeIMOAsync | RowCount=50000&Format=Xlsx | 13.111 ± 1.654 | 3708893 | 920.531–1375.807 | 15 |
| SylvanAsync | RowCount=50000&Format=Xlsx | 40.077 ± 4.509 | 1986624 | 1108.319–1610.075 | 15 |
| ExcelReaderAsync | RowCount=50000&Format=Xlsb | 5.687 ± 0.197 | 6536 | 1159.471–1283.120 | 15 |
| OfficeIMOAsync | RowCount=50000&Format=Xlsb | 8.370 ± 0.872 | 5372582 | 515.750–707.944 | 15 |
| SylvanAsync | RowCount=50000&Format=Xlsb | 8.156 ± 1.063 | 1911214 | 935.990–1343.931 | 15 |
| ExcelReaderAsync | RowCount=50000&Format=Xls | 4.291 ± 0.288 | 2976 | 979.883–1273.019 | 15 |
| OfficeIMOAsync | RowCount=50000&Format=Xls | 8.265 ± 0.373 | 10751205 | 891.867–1024.686 | 15 |
| SylvanAsync | RowCount=50000&Format=Xls | 7.953 ± 0.417 | 1760991 | 1005.810–1203.974 | 15 |

Native full report: D:\Dev\Scratch\officeimo-excelreader-performance\final-runs\qualified-830951-long-v1-domain0-generated\20261008-155637\OfficeIMO.Excel.ReaderComparison.Benchmarks.RawAsyncReadBenchmarks-report-full.json

### RawReadBenchmarks

Original headerless 50K four-field raw reads. Peer borrowed UTF8/date/double parsing versus OfficeIMO GetValue strings and scalar boxing versus Sylvan native GetValue. Same semantic count/checksum; string production differs, so no raw cross-library matched-materialization claim.

| Method | Full parameters | Mean ± SD (ms/op) | Allocated B/op | Actual iteration min–max (ms) | N |
| --- | --- | ---: | ---: | ---: | ---: |
| ExcelReaderOriginal | RowCount=50000&Format=Xlsx | 7.793 ± 0.462 | 3912 | 1258.512–1564.995 | 15 |
| OfficeIMOOriginal | RowCount=50000&Format=Xlsx | 16.744 ± 0.362 | 3717730 | 1077.818–1161.566 | 15 |
| Sylvan | RowCount=50000&Format=Xlsx | 46.974 ± 2.390 | 1986285 | 935.194–1113.174 | 15 |
| ExcelReaderOriginal | RowCount=50000&Format=Xlsb | 5.355 ± 0.185 | 6889 | 890.710–1001.483 | 15 |
| OfficeIMOOriginal | RowCount=50000&Format=Xlsb | 9.265 ± 1.259 | 5450316 | 818.375–1210.699 | 15 |
| Sylvan | RowCount=50000&Format=Xlsb | 6.342 ± 0.733 | 1910378 | 816.334–1176.226 | 15 |
| ExcelReaderOriginal | RowCount=50000&Format=Xls | 3.027 ± 0.457 | 3210 | 952.886–1458.129 | 15 |
| OfficeIMOOriginal | RowCount=50000&Format=Xls | 6.126 ± 0.783 | 10775227 | 932.509–1484.208 | 15 |
| Sylvan | RowCount=50000&Format=Xls | 6.410 ± 1.524 | 1759176 | 772.422–1511.204 | 15 |

Native full report: D:\Dev\Scratch\officeimo-excelreader-performance\final-runs\qualified-830951-long-v1-domain0-generated\20261008-155637\OfficeIMO.Excel.ReaderComparison.Benchmarks.RawReadBenchmarks-report-full.json

### TypedAsyncReadBenchmarks

Original 50K XLSX automatic class projection and full checksum/count. OfficeIMO sync byte[] opener plus RowsAsAsync, peer async Stream opener/parser, Sylvan create plus GetRecordsAsync. Synchronous CPU parsing and prepared memory input remain explicit.

| Method | Full parameters | Mean ± SD (ms/op) | Allocated B/op | Actual iteration min–max (ms) | N |
| --- | --- | ---: | ---: | ---: | ---: |
| OfficeIMOTypedAsync | RowCount=50000&Shape=Original | 16.930 ± 0.719 | 2479858 | 157.814–179.745 | 15 |
| ExcelReaderTypedAsync | RowCount=50000&Shape=Original | 12.202 ± 0.547 | 4054576 | 186.752–220.329 | 15 |
| SylvanTypedAsync | RowCount=50000&Shape=Original | 55.690 ± 7.028 | 10984848 | 762.122–1077.209 | 15 |

Native full report: D:\Dev\Scratch\officeimo-excelreader-performance\final-runs\qualified-830951-long-v1-domain0-generated\20261008-155637\OfficeIMO.Excel.ReaderComparison.Benchmarks.TypedAsyncReadBenchmarks-report-full.json

### TypedModelReadBenchmarks

Same original 50K XLSX ordinary automatic class/struct model contract. OfficeIMO RowsAs versus peer attribute parser, both consume Name/Id/Date/Value. Full record validation outside timing; scalar/string representation and model strategy visible.

| Method | Full parameters | Mean ± SD (ms/op) | Allocated B/op | Actual iteration min–max (ms) | N |
| --- | --- | ---: | ---: | ---: | ---: |
| ExcelReaderAutomatic | RowCount=50000&Model=Class | 10.860 ± 1.548 | 4054600 | 680.130–1053.328 | 15 |
| OfficeIMOAutomatic | RowCount=50000&Model=Class | 17.674 ± 0.335 | 2519646 | 1106.511–1188.306 | 15 |
| ExcelReaderAutomatic | RowCount=50000&Model=Struct | 11.787 ± 0.893 | 1660540 | 804.560–1060.279 | 15 |
| OfficeIMOAutomatic | RowCount=50000&Model=Struct | 15.934 ± 0.842 | 176065 | 376.639–462.760 | 15 |

Native full report: D:\Dev\Scratch\officeimo-excelreader-performance\final-runs\qualified-830951-long-v1-domain0-generated\20261008-155637\OfficeIMO.Excel.ReaderComparison.Benchmarks.TypedModelReadBenchmarks-report-full.json

### TypedStreamAsyncReadBenchmarks

Original 50K XLSX through public async Stream openers and automatic class projection; create/dispose prepared MemoryStream per invocation. OfficeIMO bounded buffering/decode/discovery included. MemoryStream does not model blocked I/O.

| Method | Full parameters | Mean ± SD (ms/op) | Allocated B/op | Actual iteration min–max (ms) | N |
| --- | --- | ---: | ---: | ---: | ---: |
| OfficeIMOStreamOpenTypedAsync | RowCount=50000&Shape=Original | 17.514 ± 0.563 | 3254844 | 923.069–1034.572 | 15 |
| ExcelReaderStreamOpenTypedAsync | RowCount=50000&Shape=Original | 13.864 ± 0.350 | 4061084 | 962.736–1047.404 | 15 |
| SylvanStreamOpenTypedAsync | RowCount=50000&Shape=Original | 71.623 ± 2.652 | 11004338 | 266.645–310.246 | 15 |

Native full report: D:\Dev\Scratch\officeimo-excelreader-performance\final-runs\qualified-830951-long-v1-domain0-generated\20261008-155637\OfficeIMO.Excel.ReaderComparison.Benchmarks.TypedStreamAsyncReadBenchmarks-report-full.json

### TypedXlsbAsyncReadBenchmarks

Header-bearing 50K XLSB automatic class projection. OfficeIMO sync byte[] opener plus RowsAsAsync, peer async Stream opener/parser and Sylvan GetRecordsAsync; full field/count/order proof and checksum preserved.

| Method | Full parameters | Mean ± SD (ms/op) | Allocated B/op | Actual iteration min–max (ms) | N |
| --- | --- | ---: | ---: | ---: | ---: |
| ExcelReaderTypedXlsbAsync | RowCount=50000 | 9.191 ± 0.584 | 4059104 | 939.680–1179.387 | 15 |
| OfficeIMOTypedXlsbAsync | RowCount=50000 | 17.560 ± 0.850 | 9123891 | 919.640–1067.956 | 15 |
| SylvanTypedXlsbAsync | RowCount=50000 | 26.582 ± 1.680 | 10908968 | 861.604–1062.622 | 15 |

Native full report: D:\Dev\Scratch\officeimo-excelreader-performance\final-runs\qualified-830951-long-v1-domain0-generated\20261008-155637\OfficeIMO.Excel.ReaderComparison.Benchmarks.TypedXlsbAsyncReadBenchmarks-report-full.json

### TypedXlsbReadBenchmarks

Header-bearing 50K XLSB Name/Id/Date/Value. OfficeIMO direct native getters plus manual class construction; peer/Sylvan automatic projection. Complete record fields/order/count outside timing; full checksum/count timed.

| Method | Full parameters | Mean ± SD (ms/op) | Allocated B/op | Actual iteration min–max (ms) | N |
| --- | --- | ---: | ---: | ---: | ---: |
| ExcelReaderTypedXlsb | RowCount=50000 | 9.340 ± 0.419 | 4058814 | 1045.135–1210.329 | 15 |
| OfficeIMOTypedXlsb | RowCount=50000 | 10.096 ± 0.245 | 4268988 | 841.391–910.107 | 15 |
| SylvanTypedXlsb | RowCount=50000 | 25.635 ± 0.777 | 10907976 | 946.407–1051.444 | 15 |

Native full report: D:\Dev\Scratch\officeimo-excelreader-performance\final-runs\qualified-830951-long-v1-domain0-generated\20261008-155637\OfficeIMO.Excel.ReaderComparison.Benchmarks.TypedXlsbReadBenchmarks-report-full.json

## Inputs and equivalence

Each case logged actual input length/SHA and ZIP part lengths/hashes/timestamps. Engines within an instance consume identical bytes; separate children generate independently. Fields/types/order/count are validated outside timing; checksum/count remains timed.

| Shape | Instances | Bytes | Distinct package/file SHA | Parts | Distinct inflated manifests |
| --- | ---: | ---: | ---: | ---: | ---: |
| read/raw/Xls/dataRows=50000 | 12 | 3617792 | 1 | 0 | 1 |
| read/raw/Xlsb/dataRows=50000 | 12 | 870431 | 12 | 8 | 1 |
| read/raw/Xlsx/dataRows=50000 | 12 | 773466 | 12 | 6 | 1 |
| read/typed/Xlsb/dataRows=50000 | 6 | 871166 | 6 | 8 | 1 |
| read/typed/Xlsx/Original/dataRows=50000 | 12 | 773409 | 12 | 6 | 1 |

- read/raw/Xls/dataRows=50000: No ZIP parts: all retained BIFF8/OLE input bytes hash identically.
- read/raw/Xlsb/dataRows=50000: All inflated part names/bytes/SHA and compressed lengths match across instances; logged ZIP timestamps differ. Package differences are consistent with metadata; no separate bytewise ZIP difference analysis performed.
  - [Content_Types].xml: 899 inflated B; 403 compressed B; SHA256 FC62B911F2BFE6482E812242BBE93E8AB727D4453C9CA8D3C09D0A43C58DF22C
  - _rels/.rels: 438 inflated B; 248 compressed B; SHA256 93EBC98ECD0A158942C51A10F12DDC2B849917154EFC2328F6AD20D6BC47F6D2
  - docProps/app.xml: 231 inflated B; 193 compressed B; SHA256 215F432F2989969565FC2DDB8BF4F6E0B8958EFA7E752C2BB373B3129699E1C2
  - xl/_rels/workbook.bin.rels: 557 inflated B; 246 compressed B; SHA256 7F57FC54E0C74E705DAAF71856E9C7854EA19A7BFA4CEFF24AEE5C18D7C8A7B2
  - xl/sharedStrings.bin: 14 inflated B; 10 compressed B; SHA256 A598F2C2704EF01CBC4F9DFB4888054023C0B6A1E19C7E4DA7F0C06A6EE0266B
  - xl/styles.bin: 390 inflated B; 184 compressed B; SHA256 7B252C122048E3899F452448E1C33B1AE159B7DAF8FD4296B4314CAE766DC5A9
  - xl/workbook.bin: 54 inflated B; 41 compressed B; SHA256 1E3461BD8B29F0FE94FB6F4B41915D6A1600BF3EAF7E4C8ECA8EA95F9A09ED5E
  - xl/worksheets/sheet1.bin: 4925166 inflated B; 868188 compressed B; SHA256 EFFBE6186E05BE1F4C65CAA7238DBF53B6896630DC30433D089E9844727DEF5C
- read/raw/Xlsx/dataRows=50000: All inflated part names/bytes/SHA and compressed lengths match across instances; logged ZIP timestamps differ. Package differences are consistent with metadata; no separate bytewise ZIP difference analysis performed.
  - [Content_Types].xml: 679 inflated B; 324 compressed B; SHA256 38EF511C77D41512E20181A2FD53DC223E8B2E0B406ACB16319BAF234C18C3FD
  - _rels/.rels: 295 inflated B; 204 compressed B; SHA256 F2F3948A1B6F661F2A5169A86B7029166ACD4B79D7ABFD37FA2B646FE302BFD6
  - xl/_rels/workbook.xml.rels: 423 inflated B; 223 compressed B; SHA256 41469A71751EBF1183C540B5FFC9BBBA3A7009511271C1B540AB7FCC018654D8
  - xl/styles.xml: 678 inflated B; 377 compressed B; SHA256 F72F8C91B43E33BAB6356D8B9058B7AFBDA2E691843994944CAC2052811F115E
  - xl/workbook.xml: 279 inflated B; 220 compressed B; SHA256 9A4C68DE5B9BBB96D36674F27B22AD76FFD4AE1FEDC67B0DDD8B4D9E8D3A339B
  - xl/worksheets/sheet1.xml: 5969157 inflated B; 771424 compressed B; SHA256 598C042F6840BC82CC576962512A796CE0FFCCC074A3CCA0685E41E090B8A5A9
- read/typed/Xlsb/dataRows=50000: All inflated part names/bytes/SHA and compressed lengths match across instances; logged ZIP timestamps differ. Package differences are consistent with metadata; no separate bytewise ZIP difference analysis performed.
  - [Content_Types].xml: 899 inflated B; 403 compressed B; SHA256 FC62B911F2BFE6482E812242BBE93E8AB727D4453C9CA8D3C09D0A43C58DF22C
  - _rels/.rels: 438 inflated B; 248 compressed B; SHA256 93EBC98ECD0A158942C51A10F12DDC2B849917154EFC2328F6AD20D6BC47F6D2
  - docProps/app.xml: 231 inflated B; 193 compressed B; SHA256 215F432F2989969565FC2DDB8BF4F6E0B8958EFA7E752C2BB373B3129699E1C2
  - xl/_rels/workbook.bin.rels: 557 inflated B; 246 compressed B; SHA256 7F57FC54E0C74E705DAAF71856E9C7854EA19A7BFA4CEFF24AEE5C18D7C8A7B2
  - xl/sharedStrings.bin: 14 inflated B; 10 compressed B; SHA256 A598F2C2704EF01CBC4F9DFB4888054023C0B6A1E19C7E4DA7F0C06A6EE0266B
  - xl/styles.bin: 390 inflated B; 184 compressed B; SHA256 7B252C122048E3899F452448E1C33B1AE159B7DAF8FD4296B4314CAE766DC5A9
  - xl/workbook.bin: 54 inflated B; 41 compressed B; SHA256 1E3461BD8B29F0FE94FB6F4B41915D6A1600BF3EAF7E4C8ECA8EA95F9A09ED5E
  - xl/worksheets/sheet1.bin: 4925279 inflated B; 868923 compressed B; SHA256 FCB404C49DE3ED1515C95C2055B4319E0FA10C6A3A072DF365FACFCECB4431DD
- read/typed/Xlsx/Original/dataRows=50000: All inflated part names/bytes/SHA and compressed lengths match across instances; logged ZIP timestamps differ. Package differences are consistent with metadata; no separate bytewise ZIP difference analysis performed.
  - [Content_Types].xml: 679 inflated B; 324 compressed B; SHA256 38EF511C77D41512E20181A2FD53DC223E8B2E0B406ACB16319BAF234C18C3FD
  - _rels/.rels: 295 inflated B; 204 compressed B; SHA256 F2F3948A1B6F661F2A5169A86B7029166ACD4B79D7ABFD37FA2B646FE302BFD6
  - xl/_rels/workbook.xml.rels: 423 inflated B; 223 compressed B; SHA256 41469A71751EBF1183C540B5FFC9BBBA3A7009511271C1B540AB7FCC018654D8
  - xl/styles.xml: 678 inflated B; 377 compressed B; SHA256 F72F8C91B43E33BAB6356D8B9058B7AFBDA2E691843994944CAC2052811F115E
  - xl/workbook.xml: 279 inflated B; 220 compressed B; SHA256 9A4C68DE5B9BBB96D36674F27B22AD76FFD4AE1FEDC67B0DDD8B4D9E8D3A339B
  - xl/worksheets/sheet1.xml: 5969331 inflated B; 771367 compressed B; SHA256 436EF0BE5835F7320D2F0D9C2C4023F151A15ED90337A7DEDD1B03A32485628C

## Original native warnings

~~~text
MultimodalDistribution
  BorrowedRefStructReadBenchmarks.ExcelReaderMappedRefStruct: OutlierMode=DontRemove, Affinity=00000000000000001111111111111111, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12 -> It seems that the distribution can have several modes (mValue = 3)
MultimodalDistribution
  MaterializedRawAsyncReadBenchmarks.SylvanAsync: OutlierMode=DontRemove, Affinity=00000000000000001111111111111111, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12 -> It seems that the distribution is bimodal (mValue = 3.25)
MultimodalDistribution
  RawAsyncReadBenchmarks.ExcelReaderAsync: OutlierMode=DontRemove, Affinity=00000000000000001111111111111111, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12 -> It seems that the distribution can have several modes (mValue = 2.89)
  RawAsyncReadBenchmarks.SylvanAsync: OutlierMode=DontRemove, Affinity=00000000000000001111111111111111, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12      -> It seems that the distribution can have several modes (mValue = 3)
  RawAsyncReadBenchmarks.ExcelReaderAsync: OutlierMode=DontRemove, Affinity=00000000000000001111111111111111, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12 -> It seems that the distribution is bimodal (mValue = 3.25)
MultimodalDistribution
  RawReadBenchmarks.OfficeIMOOriginal: OutlierMode=DontRemove, Affinity=00000000000000001111111111111111, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12 -> It seems that the distribution is bimodal (mValue = 3.71)
  RawReadBenchmarks.Sylvan: OutlierMode=DontRemove, Affinity=00000000000000001111111111111111, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12            -> It seems that the distribution is bimodal (mValue = 3.75)
MultimodalDistribution
  TypedAsyncReadBenchmarks.SylvanTypedAsync: OutlierMode=DontRemove, Affinity=00000000000000001111111111111111, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12 -> It seems that the distribution is bimodal (mValue = 3.33)
MultimodalDistribution
  TypedXlsbAsyncReadBenchmarks.OfficeIMOTypedXlsbAsync: OutlierMode=DontRemove, Affinity=00000000000000001111111111111111, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12 -> It seems that the distribution can have several modes (mValue = 2.86)
~~~

## Identity and retained artifacts

All 41 sidecar artifacts were verified by exact SHA and length. The JSON/manifest retains sidecar/context/normalized/outer-log hashes and native artifact references. Originals remain unchanged; nothing was copied.

| Artifact | SHA256 |
| --- | --- |
| Harness | 5E79575325D94AE8D09B97CD0C1C341EBB6AC0A24C3EEE6AE4817A897F97E7A4 |
| OfficeIMO.Excel | F2853A4C62D5C03C5E3F0CBB7CCBB5776FB63CE58CE8933BE4EBAA4F5887502F |
| OfficeIMO.Core | B5565DE58D83BFC91F4FFB69A797CE02DFCB10A5A6409323845D05A5732E1A84 |
| OfficeIMO.CSV | B9D19DBE2957F6E2E92CD12D0C8A3003D290621EF2AB3E276953CE5A01BBE4B6 |
| OfficeIMO.Data.Arrow | ED4EBF11E9A152C126E28D3BF8FBE588F8431FBAA175920BF8836AB92D5058E8 |

Primary progress: 110 sealed/542 pending of 652; supplementary 78 sealed; historical 36df 106 outside both. This stage adds 54 primary current cases only. No source mutation, build, test, timing, archive, fixture copy, cleanup or external publication performed.
