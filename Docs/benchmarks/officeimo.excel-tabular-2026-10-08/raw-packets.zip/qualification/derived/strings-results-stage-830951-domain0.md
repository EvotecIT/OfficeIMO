# Sealed strings stage: domain 0, frozen830951

This primary stage has 47 successful cases across six native tables and 564 measured samples. Capture/runtime source: 83095146282a96143b23a79a7ecca058a24a709b; benchmark source unchanged from e676775a59458d1095606386c39506ceb8a9bc33. Captured 2026-10-08T14:55:47.4313992+00:00 through 2026-10-08T15:17:40.9451379+00:00; context sealed 2026-10-08T15:17:41.1133709Z.

High priority, affinity 65535/domain 0, one launch,8 warmups,12 measurements,1000 ms automatic Pilot,unroll 1,DontRemove. Actual measured durations 239.2738–1733.6062 ms, all >= 100 ms. Native diagnostics retain 0 distribution warning rows, 13 outlier hint rows, 0 short-iteration warning rows. All 25 artifacts match length/SHA; child runtime hashes match the captured four-owner metadata.

- All 47 cases/564 measured samples succeeded; all measured durations exceed 100 ms. Adequate duration does not remove variance/distribution limits or establish domain 1/global rankings.
- Keep valid materialized/UTF8 losses. OfficeIMO complete worksheet qualification, normalized SST loading, encoding and fresh reader-owned cache costs remain included.
- First-row caller latency is distinct from equivalent complete validation. The completed owner notes establish native XLSX validation and complete referenced SST loading before first delivery.
- SST count/uniqueCount are capacity hints, not independently validated indexes. The 256-slot UTF8 cache derives from decoded strings. This explains costs; no parser design/shortcut is proposed.
- Default/prefetch, Stream/ReadOnlyMemory, materialized/interned/borrowed and Stored/Deflated/XLSX/XLSB remain distinct. Prepared memory input does not establish blocked-I/O scalability.
- Only sealed strings domain0 is inspected. No later writer/CSV/domain1 or incomplete native results are used.

Host snapshots: 88 before / 94 after processes, 35 new IDs, maximum observed persistent CPU delta 9.359375 s. They establish neither full isolation nor causal contamination; exact context remains in JSON.

## Input and work equivalence

The pinned upstream generator has eight text plus Id/Amount/Date columns. 65,536/100,000 data rows plus header give 65,537/100,001 sheet rows × 11 fields. Setup checks every expected field/type/order/count; public UTF8 setup also checks each borrowed byte against UTF8 of expected text and peer public values. Timing consumes complete checksums/counts except the explicitly first-row class.

| Shape | Child instances | Bytes | Distinct package hashes | Inflated manifests | ZIP parts |
| --- | ---: | ---: | ---: | ---: | ---: |
| Xlsb/Deflated/dataRows=100000 | 3 | 11119470 | 3 | 1 | 8 |
| Xlsb/Deflated/dataRows=65536 | 11 | 8126462 | 11 | 1 | 8 |
| Xlsb/Stored/dataRows=100000 | 3 | 32010972 | 3 | 1 | 8 |
| Xlsx/Deflated/dataRows=100000 | 3 | 9441878 | 3 | 1 | 7 |
| Xlsx/Deflated/dataRows=65536 | 16 | 6652350 | 16 | 1 | 7 |
| Xlsx/Stored/dataRows=100000 | 3 | 37514547 | 3 | 1 | 7 |
| Xlsx/Stored/dataRows=65536 | 8 | 25686810 | 8 | 1 | 7 |

Each shape has one inflated-part and compressed-length manifest. Stored/Deflated preserve identical inflated parts per format/row count; package hashes differ while inflated-part hashes and compressed lengths stay identical; logged timestamp variation supports a ZIP-metadata explanation. Every child actual SHA,part length/compressed length/timestamp/SHA and parameters are retained. No fixture regeneration, rereading, copying or decompression occurred in this derivation.

## First-row and cache interpretation

Completed owner notes establish native XLSX selected-worksheet qualification before first Read and complete SST loading on reference, with late item/count/character limits. Large stream-backed SST loading still materializes all strings. count/uniqueCount are capacity hints; the 256-slot UTF8 cache derives from decoded items. This report records that cost without proposing sampling, A1 range, GetSheetNames or unchecked-count substitutes. First-row caller latency and full scans remain separate. Jobs warm process/JIT; each measured invocation creates a fresh reader/cache.

- [Completed owner assessment](D:/Dev/Scratch/officeimo-xlsb-string-discovery-20261008/shared-string-first-row-source-note.md)
- [Completed owner assessment](D:/Dev/Scratch/officeimo-xlsb-string-discovery-20261008/shared-string-validation-metadata-assessment.md)

## MaterializedStringHeavyReadBenchmarks

Same complete eleven-field input, all strings materialized. Peer default versus InternStrings=true are separate policies. Numeric/date APIs and scalar boxing remain visible; full count/checksum consumed and fields/types/order checked. Fresh reader opening/scan/disposal included; byte/Stream variants separate.

| Method | Complete parameters | Mean ms | SD ms | Allocated bytes | Actual iteration min ms |
| --- | --- | ---: | ---: | ---: | ---: |
| ExcelReaderStringsMaterialized | Format=Xlsx&RowCount=65536 | 69.111301 | 2.094625 | 15989503 | 992.9361 |
| ExcelReaderStringsInterned | Format=Xlsx&RowCount=65536 | 75.555367 | 3.324121 | 16660479 | 981.3390 |
| OfficeIMOBytes | Format=Xlsx&RowCount=65536 | 136.579096 | 6.802780 | 26455173 | 989.2373 |
| OfficeIMOStream | Format=Xlsx&RowCount=65536 | 125.655407 | 7.362919 | 33107479 | 928.7359 |
| Sylvan | Format=Xlsx&RowCount=65536 | 219.545733 | 7.563269 | 18256508 | 845.0256 |
| ExcelReaderStringsMaterialized | Format=Xlsb&RowCount=65536 | 62.709122 | 3.359513 | 15989124 | 876.6442 |
| ExcelReaderStringsInterned | Format=Xlsb&RowCount=65536 | 72.326189 | 2.460868 | 18555428 | 1079.6158 |
| OfficeIMOBytes | Format=Xlsb&RowCount=65536 | 75.654808 | 3.162715 | 38247849 | 917.5007 |
| OfficeIMOStream | Format=Xlsb&RowCount=65536 | 70.816429 | 1.995795 | 48956142 | 886.3526 |
| Sylvan | Format=Xlsb&RowCount=65536 | 63.840019 | 7.414167 | 18228284 | 855.0300 |

## SharedStringBorrowedScanBenchmarks

Peer-only full borrowed UTF8 scan on Deflated/Stored XLSX at 65,536 data rows, default versus PrefetchDecompression=true. Complete semantic proof/checksum/count. No paired OfficeIMO method in this class; the separate 100K public UTF8 class provides OfficeIMO coverage.

| Method | Complete parameters | Mean ms | SD ms | Allocated bytes | Actual iteration min ms |
| --- | --- | ---: | ---: | ---: | ---: |
| ExcelReaderBorrowed | RowCount=65536&Storage=Deflated | 46.111402 | 1.058865 | 2688956 | 984.0307 |
| ExcelReaderBorrowedPrefetch | RowCount=65536&Storage=Deflated | 34.418288 | 0.816446 | 2673744 | 930.5085 |
| ExcelReaderBorrowed | RowCount=65536&Storage=Stored | 23.705257 | 0.825585 | 2490920 | 955.7167 |
| ExcelReaderBorrowedPrefetch | RowCount=65536&Storage=Stored | 23.911084 | 0.977118 | 2541061 | 830.1390 |

## SharedStringFirstRowBenchmarks

Public open through first Read/MoveNext, then disposal. Timed result is header-row availability; complete fields/input proved outside timing. Deflated/Stored XLSX separate. OfficeIMO qualifies the selected worksheet and loads complete referenced SST before delivery; peer public initialization/validation lifecycles differ. First-row caller latency is separate from full-sheet validation work and process-cold first-use.

| Method | Complete parameters | Mean ms | SD ms | Allocated bytes | Actual iteration min ms |
| --- | --- | ---: | ---: | ---: | ---: |
| ExcelReaderOpenThroughFirstRow | RowCount=65536&Storage=Deflated | 16.308502 | 0.232099 | 908205 | 991.0867 |
| OfficeIMOOpenThroughFirstRow | RowCount=65536&Storage=Deflated | 93.223373 | 3.743423 | 20955372 | 937.8736 |
| SylvanOpenThroughFirstRow | RowCount=65536&Storage=Deflated | 0.100065 | 0.003021 | 328832 | 1158.1938 |
| ExcelReaderOpenThroughFirstRow | RowCount=65536&Storage=Stored | 4.215237 | 0.091666 | 801149 | 996.2670 |
| OfficeIMOOpenThroughFirstRow | RowCount=65536&Storage=Stored | 71.484954 | 2.002704 | 21213609 | 959.0338 |
| SylvanOpenThroughFirstRow | RowCount=65536&Storage=Stored | 0.088617 | 0.012173 | 327775 | 1119.7229 |

## SharedStringFullScanBenchmarks

Complete materialized eleven-field scan at 65,536 data rows plus header, Stored XLSX. Stored rewrite preserves inflated parts. Full count/checksum consumed; expected fields/types/order checked. Opening/scan/disposal included; separate from first-row/borrowed/cache policies.

| Method | Complete parameters | Mean ms | SD ms | Allocated bytes | Actual iteration min ms |
| --- | --- | ---: | ---: | ---: | ---: |
| ExcelReaderStringsMaterialized | RowCount=65536&Storage=Stored | 43.741666 | 1.632063 | 15988277 | 1035.4851 |
| OfficeIMOStringsMaterialized | RowCount=65536&Storage=Stored | 91.610081 | 2.426888 | 24179147 | 887.1456 |
| SylvanStringsMaterialized | RowCount=65536&Storage=Stored | 202.676002 | 6.842304 | 18253142 | 753.7323 |

## SharedStringUtf8ReadBenchmarks

100,000 data rows plus header, eight text and three typed columns, XLSX/XLSB and Deflated/Stored. Every normalized UTF8 byte and scalar field checked individually. Full byte-length/checksum/count consumed through public borrowing: OfficeIMO TryGetUtf8Text with normal GetValue for three scalars versus peer public borrowed row parsing. Each invocation opens a fresh reader and includes OfficeIMO complete validation/normalized SST loading, encoding/cache misses. Default/prefetch separate; no retained-cache or zero-allocation claim.

| Method | Complete parameters | Mean ms | SD ms | Allocated bytes | Actual iteration min ms |
| --- | --- | ---: | ---: | ---: | ---: |
| ExcelReaderBorrowed | Format=Xlsx&RowCount=100000&Storage=Deflated | 66.664940 | 1.360850 | 4186713 | 965.6760 |
| ExcelReaderBorrowedPrefetch | Format=Xlsx&RowCount=100000&Storage=Deflated | 44.203115 | 0.852040 | 3142557 | 894.3812 |
| OfficeIMOBorrowedSharedUtf8 | Format=Xlsx&RowCount=100000&Storage=Deflated | 232.662050 | 4.422496 | 93471462 | 911.0044 |
| ExcelReaderBorrowed | Format=Xlsx&RowCount=100000&Storage=Stored | 33.335763 | 1.388577 | 3035472 | 888.2858 |
| ExcelReaderBorrowedPrefetch | Format=Xlsx&RowCount=100000&Storage=Stored | 34.151546 | 2.939209 | 3055668 | 988.4007 |
| OfficeIMOBorrowedSharedUtf8 | Format=Xlsx&RowCount=100000&Storage=Stored | 195.682938 | 7.888617 | 93052554 | 734.7331 |
| ExcelReaderBorrowed | Format=Xlsb&RowCount=100000&Storage=Deflated | 55.137188 | 1.595428 | 4023091 | 887.1898 |
| ExcelReaderBorrowedPrefetch | Format=Xlsb&RowCount=100000&Storage=Deflated | 37.034557 | 1.327566 | 3797779 | 929.4739 |
| OfficeIMOBorrowedSharedUtf8 | Format=Xlsb&RowCount=100000&Storage=Deflated | 154.872454 | 9.858827 | 118062642 | 1011.7133 |
| ExcelReaderBorrowed | Format=Xlsb&RowCount=100000&Storage=Stored | 27.691123 | 0.263256 | 3034960 | 954.2686 |
| ExcelReaderBorrowedPrefetch | Format=Xlsb&RowCount=100000&Storage=Stored | 34.029152 | 3.450946 | 3548194 | 997.4510 |
| OfficeIMOBorrowedSharedUtf8 | Format=Xlsb&RowCount=100000&Storage=Stored | 119.637996 | 6.198422 | 116855794 | 849.6139 |

## StringHeavyReadBenchmarks

65,536 data rows plus header: eight text and three typed columns from the pinned upstream generator. Full expected fields/types/order/count checked outside timing; checksum/count inside. Peer borrowed raw text, default/prefetch and ReadOnlyMemory routes differ from ordinary GetValue strings/scalar objects in OfficeIMO/Sylvan. Byte/Stream routes are separate; no matched-materialization allocation claim for raw APIs.

| Method | Complete parameters | Mean ms | SD ms | Allocated bytes | Actual iteration min ms |
| --- | --- | ---: | ---: | ---: | ---: |
| ExcelReaderOriginal | Format=Xlsx&RowCount=65536 | 46.178044 | 1.522289 | 2286056 | 954.4201 |
| ExcelReaderPrefetch | Format=Xlsx&RowCount=65536 | 26.083364 | 2.313891 | 2370309 | 698.8222 |
| ExcelReaderMemory | Format=Xlsx&RowCount=65536 | 37.885638 | 5.816881 | 2285800 | 974.5686 |
| OfficeIMOBytes | Format=Xlsx&RowCount=65536 | 101.557781 | 2.468834 | 20035860 | 384.8041 |
| OfficeIMOStream | Format=Xlsx&RowCount=65536 | 106.820936 | 3.094449 | 26688578 | 923.7210 |
| Sylvan | Format=Xlsx&RowCount=65536 | 219.174360 | 6.022491 | 18253424 | 846.1323 |
| ExcelReaderOriginal | Format=Xlsb&RowCount=65536 | 40.008453 | 1.428426 | 2285544 | 896.9745 |
| ExcelReaderPrefetch | Format=Xlsb&RowCount=65536 | 31.155744 | 1.785556 | 2793765 | 1121.4043 |
| ExcelReaderMemory | Format=Xlsb&RowCount=65536 | 39.491670 | 0.769989 | 7490115 | 916.7364 |
| OfficeIMOBytes | Format=Xlsb&RowCount=65536 | 63.533007 | 2.009342 | 33078979 | 909.3214 |
| OfficeIMOStream | Format=Xlsb&RowCount=65536 | 69.327546 | 1.960703 | 48401793 | 918.7807 |
| Sylvan | Format=Xlsb&RowCount=65536 | 68.322090 | 4.471295 | 18228764 | 239.2738 |

## Native warnings and hints

Type/method/job/native parameters remain authoritative. Diagnostic prose omitting parameters retains explicit ambiguity; native per-case confidence intervals/outlier arrays/durations are exact.

~~~text
// * Hints *
Outliers
  MaterializedStringHeavyReadBenchmarks.OfficeIMOStream: OutlierMode=DontRemove, Affinity=00000000000000001111111111111111, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=12, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=8 -> 1 outlier  was  detected (75.16 ms)
// * Hints *
Outliers
  SharedStringFirstRowBenchmarks.SylvanOpenThroughFirstRow: OutlierMode=DontRemove, Affinity=00000000000000001111111111111111, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=12, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=8      -> 1 outlier  was  detected (107.67 us)
  SharedStringFirstRowBenchmarks.ExcelReaderOpenThroughFirstRow: OutlierMode=DontRemove, Affinity=00000000000000001111111111111111, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=12, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=8 -> 1 outlier  was  detected (4.42 ms)
  SharedStringFirstRowBenchmarks.OfficeIMOOpenThroughFirstRow: OutlierMode=DontRemove, Affinity=00000000000000001111111111111111, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=12, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=8   -> 1 outlier  was  detected (75.86 ms)
  SharedStringFirstRowBenchmarks.SylvanOpenThroughFirstRow: OutlierMode=DontRemove, Affinity=00000000000000001111111111111111, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=12, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=8      -> 2 outliers were detected (106.23 us, 118.27 us)
// * Hints *
Outliers
  SharedStringFullScanBenchmarks.OfficeIMOStringsMaterialized: OutlierMode=DontRemove, Affinity=00000000000000001111111111111111, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=12, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=8 -> 2 outliers were detected (95.31 ms, 96.62 ms)
// * Hints *
Outliers
  SharedStringUtf8ReadBenchmarks.ExcelReaderBorrowedPrefetch: OutlierMode=DontRemove, Affinity=00000000000000001111111111111111, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=12, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=8 -> 2 outliers were detected (39.31 ms, 40.11 ms)
  SharedStringUtf8ReadBenchmarks.OfficeIMOBorrowedSharedUtf8: OutlierMode=DontRemove, Affinity=00000000000000001111111111111111, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=12, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=8 -> 1 outlier  was  detected (106.20 ms)
// * Hints *
Outliers
  StringHeavyReadBenchmarks.ExcelReaderOriginal: OutlierMode=DontRemove, Affinity=00000000000000001111111111111111, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=12, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=8 -> 1 outlier  was  detected (49.44 ms)
  StringHeavyReadBenchmarks.ExcelReaderPrefetch: OutlierMode=DontRemove, Affinity=00000000000000001111111111111111, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=12, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=8 -> 1 outlier  was  detected (32.16 ms)
  StringHeavyReadBenchmarks.OfficeIMOBytes: OutlierMode=DontRemove, Affinity=00000000000000001111111111111111, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=12, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=8      -> 1 outlier  was  detected (96.20 ms)
  StringHeavyReadBenchmarks.ExcelReaderPrefetch: OutlierMode=DontRemove, Affinity=00000000000000001111111111111111, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=12, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=8 -> 1 outlier  was  detected (36.01 ms)
  StringHeavyReadBenchmarks.Sylvan: OutlierMode=DontRemove, Affinity=00000000000000001111111111111111, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=12, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=8              -> 2 outliers were detected (59.82 ms, 78.50 ms)
~~~

All native statistics/actual samples included; all 564 normalized samples verified successful and retained by immutable import identity. This stage contributes 47 primary cases; shared counters await separate ADO 9 qualification. Supplementary 78 and historical 36df 106 remain distinct. No global/domain1 winner claim.

No source edits, builds, tests, timings, fixture copies, archives, cleanup or public actions. Source/runtime/harness/input identities and all 25 artifact hashes remain unchanged.
