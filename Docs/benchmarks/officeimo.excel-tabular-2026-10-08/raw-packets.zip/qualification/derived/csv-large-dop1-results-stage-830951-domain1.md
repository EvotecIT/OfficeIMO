# Qualified original large CSV DOP1 capture, domain1

All 27 cases and successful children, with 216 actual samples, match native BDN and normalized statistics/GC/allocation metrics. All nine native artifacts match sidecar SHA-256 and byte length. Children load frozen 830951 owners at High/0xFFFF0000. The run is qualified-830951-long-v2-domain1-csv-large-dop1. Capture identity comes from sealed context/sidecar; importer IDs/timestamps are retained as import metadata.

Original huge recipe: DOP1, 1 launch, 4 warmups, 8 actual iterations, 250 ms target, unroll 1, DontRemove. Raw actuals 1350.4845–11482.2415 ms, all at least 100 ms. Native diagnostics: 0 short-iteration warnings, 0 distribution warnings, 8 outlier hint rows, 9 retained native outlier values. Capture elapsed 1630.2066116 seconds; 2026-10-08T20:28:19.9153196+00:00 to 2026-10-08T20:55:30.1219312+00:00, sealed 2026-10-08T20:55:30.2378643Z. Native total: Global total time: 00:27:08 (1628.59 sec), executed benchmarks: 27

## Input identity and output proof

Each original input has nine method cases. All 27 child declarations match domain0 SHA-256, bytes, row count and field count. Full Input/Rows/Dop are resolved from actual declarations and the frozen fixture contract; abbreviated BDN Input parameters remain visible without grouping on a null RowCount.

| Original input | Rows | Fields | File bytes | SHA-256 |
|---|---:|---:|---:|---|
| ConversionHeavy-4300000 | 4300000 | 6 | 207563853 | 86B1EE25363929A54CEA19CDA95BD63BC5F08B053B3DF7FBC83E76A0AA2634EF |
| ConversionHeavy3M-3000000 | 3000000 | 6 | 144811299 | FB01381C6257B7E716EF069DD14CCC19F1128DDDD3584A3409D5BA05BB240F63 |
| NarrowInt-8000000 | 8000000 | 3 | 209597884 | 23CC15B690540E2D15F6BDA51184E5B4D20EB3219447B860497CE02052EC0680 |

Fifteen typed-mapping children run Setup with field validation enabled for all five methods: every mapped value is checked against its source index, preserving full row order/count. Twelve direct-reduction children qualify all four methods, checking every consumed heavy field or narrow integer and the exact multiplicity of each source pattern. Independent seen-count proofs catch lost/duplicated records even when sums match. Timed operations retain expected count/sum checks. Setup validation and probe storage are absent from timed calls; no output workbook or serialized byte artifact is invented.

Twelve UNTIMED GlobalSetup probes of public OfficeIMO asynchronous Stream aggregate, one in each direct-aggregate child including peer/TextOwned timed-method children. AsyncReads>0/SyncReads=0 proves only those Setup operations. Probe wrappers are absent from timed methods; no peer/TextOwned or per-measured-invocation IO claim.

## CsvDirectAggregateBenchmarks

Three original full files,DOP1. Peer CsvParallel.AggregateAsync uses UTF8 ref/struct fields and independent native states; OfficeIMO public AggregateTextRowsAsParallel reads/decodes whole file inside timing, public AggregateRowsAsParallelAsync path/stream reads incrementally with decoded UTF16 field snapshots. All6 heavy fields/all3 narrow integers consumed; states sum Units/A and count rows without mapped result arrays. Every consumed field and repeating-row multiplicity is proved in Setup. UTF8 versus decoded text/materialization pipeline remains explicit; bounded retained state is not low cumulative allocation.

Input ConversionHeavy-4300000, DOP1:

| Method | Complete caller strategy | Mean ms | SD ms | Cumulative managed bytes/op, native diagnostic |
|---|---|---:|---:|---:|
| ExcelReaderAggregate | Public native UTF8 direct aggregate with ref/struct mapping and count/sum states; full file reading inside timing. | 599.352391 | 36.323294 | 1258384 |
| OfficeIMOTextOwnedAggregate | Public decoded-text direct aggregate; File.ReadAllText and decoding inside timing, caller accumulator factory/merge, no per-row mapped result arrays. | 588.731712 | 36.767022 | 832283348 |
| OfficeIMOAsyncPathAggregate | Public asynchronous path direct aggregate; full file IO and decoded-field snapshots inside timing, no text preloading. | 2197.806741 | 188.957667 | 1948777492 |
| OfficeIMOAsyncStreamAggregate | Owned asynchronous FileStream/public Stream direct aggregate; incremental IO/decode inside timing. Read counters apply to the separate untimed Setup probe only. | 2262.360103 | 97.038964 | 1948788664 |

Input ConversionHeavy3M-3000000, DOP1:

| Method | Complete caller strategy | Mean ms | SD ms | Cumulative managed bytes/op, native diagnostic |
|---|---|---:|---:|---:|
| ExcelReaderAggregate | Public native UTF8 direct aggregate with ref/struct mapping and count/sum states; full file reading inside timing. | 445.786503 | 21.368048 | 878752 |
| OfficeIMOTextOwnedAggregate | Public decoded-text direct aggregate; File.ReadAllText and decoding inside timing, caller accumulator factory/merge, no per-row mapped result arrays. | 468.723581 | 14.133155 | 580676010 |
| OfficeIMOAsyncPathAggregate | Public asynchronous path direct aggregate; full file IO and decoded-field snapshots inside timing, no text preloading. | 1551.402859 | 98.541692 | 1359629344 |
| OfficeIMOAsyncStreamAggregate | Owned asynchronous FileStream/public Stream direct aggregate; incremental IO/decode inside timing. Read counters apply to the separate untimed Setup probe only. | 1632.902816 | 79.679721 | 1359627172 |

Input NarrowInt-8000000, DOP1:

| Method | Complete caller strategy | Mean ms | SD ms | Cumulative managed bytes/op, native diagnostic |
|---|---|---:|---:|---:|
| ExcelReaderAggregate | Public native UTF8 direct aggregate with ref/struct mapping and count/sum states; full file reading inside timing. | 488.974500 | 29.479641 | 1256996 |
| OfficeIMOTextOwnedAggregate | Public decoded-text direct aggregate; File.ReadAllText and decoding inside timing, caller accumulator factory/merge, no per-row mapped result arrays. | 685.096084 | 24.800358 | 840533916 |
| OfficeIMOAsyncPathAggregate | Public asynchronous path direct aggregate; full file IO and decoded-field snapshots inside timing, no text preloading. | 2621.930228 | 153.989761 | 2260882624 |
| OfficeIMOAsyncStreamAggregate | Owned asynchronous FileStream/public Stream direct aggregate; incremental IO/decode inside timing. Read counters apply to the separate untimed Setup probe only. | 2378.751600 | 257.088487 | 2260885304 |

## CsvParallelTypedBenchmarks

Same4.3M/8M/3M full files,DOP1. Same materialized heavy6-field/narrow3-integer classes across automatic peer CsvParallel/attribute sequential parser, OfficeIMO Core.RowsAsParallel, public decoded-text factory ReadTextRowsAsParallel, Sylvan GetRecords sequential. Text factory includes File.ReadAllText/UTF8 decode in each timed call. Each engine Setup checks every mapped field/source order/count before timing; result rows are consumed into same Units/A checksum. Parallel and sequential pipelines remain distinct.

Input ConversionHeavy-4300000, DOP1:

| Method | Complete caller strategy | Mean ms | SD ms | Cumulative managed bytes/op, native diagnostic |
|---|---|---:|---:|---:|
| ExcelReaderParallel | Original public typed CsvParallel.ParseAsync with attributes and DOP1; automatic class output/full file reading. | 618.392272 | 5.867380 | 704022168 |
| ExcelReaderSequential | Original public FromCsvFile plus sequential attribute parser; automatic same class output/full file reading. | 834.619972 | 49.863781 | 702335344 |
| OfficeIMOCoreParallel | Ordinary file DataReader plus Core RowsAsParallel; automatic same class projection/DOP1 and source input parsing. | 532.428681 | 7.677664 | 1352875624 |
| OfficeIMOTextParallel | Full-file ReadAllText followed by public parallel factory projection; managed UTF16 input/typed mapped outputs, IO/decode included. | 612.508125 | 8.787331 | 1534612996 |
| SylvanSequential | Normal file StreamReader/CsvDataReader/GetRecords sequential automatic class projection. | 890.871509 | 31.462890 | 1354773944 |

Input ConversionHeavy3M-3000000, DOP1:

| Method | Complete caller strategy | Mean ms | SD ms | Cumulative managed bytes/op, native diagnostic |
|---|---|---:|---:|---:|
| ExcelReaderParallel | Original public typed CsvParallel.ParseAsync with attributes and DOP1; automatic class output/full file reading. | 474.479416 | 22.086361 | 491182224 |
| ExcelReaderSequential | Original public FromCsvFile plus sequential attribute parser; automatic same class output/full file reading. | 427.393631 | 9.957267 | 490002016 |
| OfficeIMOCoreParallel | Ordinary file DataReader plus Core RowsAsParallel; automatic same class projection/DOP1 and source input parsing. | 499.711928 | 31.324921 | 943867768 |
| OfficeIMOTextParallel | Full-file ReadAllText followed by public parallel factory projection; managed UTF16 input/typed mapped outputs, IO/decode included. | 570.461225 | 17.717535 | 1071028234 |
| SylvanSequential | Normal file StreamReader/CsvDataReader/GetRecords sequential automatic class projection. | 761.205519 | 29.705505 | 945204488 |

Input NarrowInt-8000000, DOP1:

| Method | Complete caller strategy | Mean ms | SD ms | Cumulative managed bytes/op, native diagnostic |
|---|---|---:|---:|---:|
| ExcelReaderParallel | Original public typed CsvParallel.ParseAsync with attributes and DOP1; automatic class output/full file reading. | 487.720981 | 18.891081 | 257691650 |
| ExcelReaderSequential | Original public FromCsvFile plus sequential attribute parser; automatic same class output/full file reading. | 385.565484 | 63.684551 | 256001784 |
| OfficeIMOCoreParallel | Ordinary file DataReader plus Core RowsAsParallel; automatic same class projection/DOP1 and source input parsing. | 491.099312 | 8.820841 | 1214821720 |
| OfficeIMOTextParallel | Full-file ReadAllText followed by public parallel factory projection; managed UTF16 input/typed mapped outputs, IO/decode included. | 894.333347 | 33.079240 | 1096530244 |
| SylvanSequential | Normal file StreamReader/CsvDataReader/GetRecords sequential automatic class projection. | 649.836603 | 112.860424 | 1214862504 |

## Interpretation boundaries

Native UTF8 borrowed/ref-struct aggregation, owned UTF16 whole-file text, decoded incremental async snapshots and materialized automatic/factory mapping have different caller/materialization contracts. Each method opens/reads/parses its complete file in the measured operation; decoded-text methods include File.ReadAllText/UTF8 decode. Direct accumulators avoid per-row result objects but do not make parser allocations disappear. Managed allocated bytes/op is cumulative BDN diagnostic allocation, not retained or peak memory; bounded in-flight state does not imply low total allocation.

Every measured loss and full-scale result is retained. The three original row shapes remain separate; no universal speed win, linear scaling assertion, DOP4 claim or cross-domain pooling is made. Domain1 timings/allocation are independent observations, without assigning differences to cache placement or isolation. BDN MemoryDiagnoser allocation is separate from elapsed actual samples; sample allocatedBytes is null and native diagnostic values remain in metrics. DontRemove preserves outlier samples. Native hint labels can omit Input/Dop; method-level hints are retained without invented parameter assignment.

Host endpoints: 42/40 entries; 34 persistent matches; maximum observed CPU delta 0.531250 seconds, sum 6.609375 seconds. Pre/post snapshots do not identify process roles, CPU during individual cases, or activity of processes absent at either endpoint. They do not prove an idle host or establish causal contamination. Fresh benchmark children and generated builds occur within the capture; original snapshots are retained. No live host audit or later-group inspection.

Source 83095146282a96143b23a79a7ecca058a24a709b; unchanged benchmark source e676775a59458d1095606386c39506ceb8a9bc33. Harness 5E79575325D94AE8D09B97CD0C1C341EBB6AC0A24C3EEE6AE4817A897F97E7A4; v2 resume runner C52377235F70A38C61333009FFA2CC97C0BE2B3C102041CB127587B09AB32A95; generated-reference hook CEDF3A831603914A5E024C980CCA65AAAAF25544D98538BC416E963DD8632B12. Saved measured owner binaries are unchanged; reference import affects generated compile references only. Every native artifact/input declaration and source reference is retained with SHA/length in JSON and manifest.

Only this three-file packet is written. No source/build/test/package/timing activity, live session poll, DOP4/later-group read, fixture copy, archive or cleanup. Logical bytes removed 0; compact derivations and original native/import evidence remain retained in place. Shared report/coverage files are coordinator-owned.
