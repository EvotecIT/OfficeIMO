# Source-start versus published 3.4.4 attribution

The [pinned upstream benchmark project](https://github.com/GabrielMarquezMatte/ExcelReader/blob/ca5b50f99e8ef57ab476f0a2bc8043558d58b28d/tests/ExcelReader.Benchmarks/ExcelReader.Benchmarks.csproj) references OfficeIMO.Excel **3.4.4 from NuGet**, rather than an OfficeIMO source checkout. The published package's nuspec repository commit and embedded Excel/Core informational versions identify `7ea881d08359b4fddddef8e2aa7782d1ee2265b8`.

| Artifact | Published 3.4.4, net10.0 | Task-start source78 bundle |
| --- | --- | --- |
| Source identity | 7ea881d08359b4fddddef8e2aa7782d1ee2265b8 | 78bfbd96dc3967b6f3c5e2376ce4c98000213e2c |
| Excel DLL bytes | 5,549,024 | 5,831,680 |
| Excel DLL SHA256 | BEB5A238B4802DAA4B43244E9E3D69E7349FBA8483D2EF4884D90CC81AAD72D3 | 29A145238D67CC254AD211EA26FBC887D7748F45232F9D092BE72DF7BFF80340 |
| Core DLL bytes | 2,940,384 | 4,323,840 |
| Core DLL SHA256 | 44B3C7657F79296D2F52488328BB14CB7363DDF1784F12E4E8527FD20D4F8745 | B952AF0AAA5B03E6587AD32DD35DD2C83925DD01F932FAA8DC778BF22595DA99 |

These are demonstrably different binaries and recorded source snapshots. Their shared three-part version does not establish identity or equivalent performance. No inspected packet proves source78 semantically identical to the published package. Existing published-package validation logs identify exactly the published hashes above, and the latest package-only compilation proof succeeds with CSV enabled and current APIs disabled.

The compact `published344-identities.json` also records the inspected published nupkg hashes: Excel `6826377231097A99F01CA3B51C8C7FCFAAF0C37FBBDE7B46FECAAD6A3EC23362`; Core `FA04B42A0DF4CC8F6C7D4FA73C68652B232E02E62A40F824D7F951867A2A534C`. No package was rebuilt or copied for this discovery.

The original retained audit already reproduces the package's typed-read gap on the upstream shape: three libraries, old Short-job recipe, eight warmups/ten measurements. That historical proof answers whether the package gap can reproduce; it does not supply fresh same-harness, rotated source-start/current/package results. Its source comparison used another source snapshot, `5dabfd1caa0c061cad460fa02d5794129d103065`, rather than source78.

## Coordinator-adopted final lane

The coordinator keeps source78 before/current as the task's engineering comparison. The final plan includes a separate published 3.4.4 headline lane with the same final harness source, peers, selected Original/SharedStrings shapes, 50,000 rows, ordinary writer, domains and focused job. This is eight native cases per domain: three typed readers for each shape plus two ordinary writers. The public-package lane uses `OfficeIMOBenchmarkPackageVersion=3.4.4` and disables current-only APIs; the published Excel/Core hashes must match this inventory. It does not need artificial adapters or a forced 306-case old-package matrix.

Do not reuse the old package Short-job timings in the new final headline table. Keep them in historical context. The adopted main order is source-start → published → current in domain 0 and current → published → source-start in domain 1, with all three harnesses built from the same final benchmark source. Sixteen published-package cases are part of the 652-case final plan; captures and findings remain pending.

## Proposed public wording

“The engineering baseline is OfficeIMO source `78bfbd96dc3967b6f3c5e2376ce4c98000213e2c`. The upstream benchmark uses the separately published OfficeIMO.Excel 3.4.4 package, whose embedded source identity is `7ea881d08359b4fddddef8e2aa7782d1ee2265b8`. We identify and measure these artifacts separately. Improvements over the task-start source snapshot do not, by themselves, quantify an improvement over the published package.”

Append the final package findings only after that lane completes. Keep current source, published package, source-start snapshot and Core-only intervention as four distinct attribution boundaries.
