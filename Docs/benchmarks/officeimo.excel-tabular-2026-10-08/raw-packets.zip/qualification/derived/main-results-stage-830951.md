# Final current headline stage — 2026-10-08

The final 830 original typed comparison is effectively tied in domain 0 and slower in domain 1, while OfficeIMO allocates fewer bytes in both. Shared-string means are close and OfficeIMO allocates more. The default writer remains slower in both domains. These results support specific allocation and implementation improvements; they do not support a universal speed win.

Both current contexts are sealed: 16 successful cases, 240 retained measurements and 18 original native artifacts verified. Current runtime/capture: 83095146282a96143b23a79a7ecca058a24a709b. Benchmark source is unchanged from e676775a59458d1095606386c39506ceb8a9bc33. Native statistics, confidence intervals, actual operation counts/durations, input/output identities and warnings remain in the JSON.

The primary headline uses these current 16 cases plus the 32 original source-start/published cases captured at e676. Their capture source, harness and runtime hashes remain unchanged. Previous e676 current 16 cases are historical stage evidence. Remaining primary matrix coverage is still pending.

## Current paired headline work

Means and SD are milliseconds; allocation is exact bytes per operation. Ratios below are arithmetic from displayed means, not pooled native ratios or significance tests.

| Domain | Contract | OfficeIMO mean ± SD | ExcelReader mean ± SD | Office/peer mean | OfficeIMO bytes | Peer bytes | Office allocation reduction |
|---|---|---:|---:|---:|---:|---:|---:|
| 0 | Original | 12.095 ± 0.516 | 12.060 ± 0.276 | 1.003 | 2560880 | 4069313 | 37.07% |
| 0 | SharedStrings | 10.886 ± 0.763 | 11.069 ± 0.717 | 0.984 | 2558904 | 2420609 | -5.71% |
| 0 | DefaultWriter | 18.648 ± 0.878 | 10.606 ± 0.289 | 1.758 | 4238334 | 4218069 | -0.48% |
| 1 | Original | 10.616 ± 0.841 | 9.659 ± 0.441 | 1.099 | 2560854 | 4069313 | 37.07% |
| 1 | SharedStrings | 8.325 ± 0.519 | 8.399 ± 0.332 | 0.991 | 2558866 | 2420609 | -5.71% |
| 1 | DefaultWriter | 15.193 ± 0.365 | 9.854 ± 0.513 | 1.542 | 4234869 | 4217477 | -0.41% |

Typed methods validate every Name/Id/Date/Value field, order and count before timing. Writer setup validates complete output fields, date styles and package structure with independent ExcelReader and Sylvan readers. Ordinary Office output includes row/cell coordinates and dimension; ordinary peer output omits them. Both are valid. Keep compact coordinate-omission and SST writer options in their own configured comparison lanes.

## All selected current cases, including Sylvan

| Domain | Type.Method | Full parameters | Mean ± SD (ms) | Allocated bytes |
|---|---|---|---:|---:|
| 0 | TypedReadBenchmarks.ExcelReaderTyped | RowCount=50000&Shape=Original | 12.060 ± 0.276 | 4069313 |
| 0 | TypedReadBenchmarks.OfficeIMOTyped | RowCount=50000&Shape=Original | 12.095 ± 0.516 | 2560880 |
| 0 | TypedReadBenchmarks.SylvanTyped | RowCount=50000&Shape=Original | 62.948 ± 2.809 | 10984234 |
| 0 | TypedReadBenchmarks.ExcelReaderTyped | RowCount=50000&Shape=SharedStrings | 11.069 ± 0.717 | 2420609 |
| 0 | TypedReadBenchmarks.OfficeIMOTyped | RowCount=50000&Shape=SharedStrings | 10.886 ± 0.763 | 2558904 |
| 0 | TypedReadBenchmarks.SylvanTyped | RowCount=50000&Shape=SharedStrings | 64.602 ± 1.993 | 9342732 |
| 0 | WriterBenchmarks.OfficeIMO | RowCount=50000 | 18.648 ± 0.878 | 4238334 |
| 0 | WriterBenchmarks.ExcelReaderWriter | RowCount=50000 | 10.606 ± 0.289 | 4218069 |
| 1 | TypedReadBenchmarks.ExcelReaderTyped | RowCount=50000&Shape=Original | 9.659 ± 0.441 | 4069313 |
| 1 | TypedReadBenchmarks.OfficeIMOTyped | RowCount=50000&Shape=Original | 10.616 ± 0.841 | 2560854 |
| 1 | TypedReadBenchmarks.SylvanTyped | RowCount=50000&Shape=Original | 48.564 ± 2.022 | 10984234 |
| 1 | TypedReadBenchmarks.ExcelReaderTyped | RowCount=50000&Shape=SharedStrings | 8.399 ± 0.332 | 2420609 |
| 1 | TypedReadBenchmarks.OfficeIMOTyped | RowCount=50000&Shape=SharedStrings | 8.325 ± 0.519 | 2558866 |
| 1 | TypedReadBenchmarks.SylvanTyped | RowCount=50000&Shape=SharedStrings | 45.500 ± 1.951 | 9342348 |
| 1 | WriterBenchmarks.OfficeIMO | RowCount=50000 | 15.193 ± 0.365 | 4234869 |
| 1 | WriterBenchmarks.ExcelReaderWriter | RowCount=50000 | 9.854 ± 0.513 | 4217477 |

## Original claim attribution: published and source-start are distinct

| Domain | Runtime lane | Exact runtime Excel version | Capture source | OfficeIMO mean ± SD | Peer mean ± SD | Office/peer mean | Office bytes | Peer bytes |
|---|---|---|---|---:|---:|---:|---:|---:|
| 0 | before | 3.4.4+78bfbd96dc3967b6f3c5e2376ce4c98000213e2c | e676775a59458d1095606386c39506ceb8a9bc33 | 112.129 ± 3.723 | 14.417 ± 0.448 | 7.778 | 2540469 | 4054464 |
| 0 | published | 3.4.4+7ea881d08359b4fddddef8e2aa7782d1ee2265b8 | e676775a59458d1095606386c39506ceb8a9bc33 | 123.642 ± 3.655 | 12.699 ± 0.435 | 9.736 | 5969752 | 4054464 |
| 0 | current | 3.4.4+83095146282a96143b23a79a7ecca058a24a709b | 83095146282a96143b23a79a7ecca058a24a709b | 12.095 ± 0.516 | 12.060 ± 0.276 | 1.003 | 2560880 | 4069313 |
| 1 | before | 3.4.4+78bfbd96dc3967b6f3c5e2376ce4c98000213e2c | e676775a59458d1095606386c39506ceb8a9bc33 | 107.824 ± 6.915 | 12.126 ± 0.554 | 8.892 | 2621818 | 4069313 |
| 1 | published | 3.4.4+7ea881d08359b4fddddef8e2aa7782d1ee2265b8 | e676775a59458d1095606386c39506ceb8a9bc33 | 121.815 ± 5.729 | 12.194 ± 1.209 | 9.990 | 6051153 | 4069313 |
| 1 | current | 3.4.4+83095146282a96143b23a79a7ecca058a24a709b | 83095146282a96143b23a79a7ecca058a24a709b | 10.616 ± 0.841 | 9.659 ± 0.441 | 1.099 | 2560854 | 4069313 |

The audited upstream project uses OfficeIMO.Excel NuGet 3.4.4, embedded source 7ea881d08359b4fddddef8e2aa7782d1ee2265b8. Source-start is 78bfbd96dc3967b6f3c5e2376ce4c98000213e2c and its DLL hashes differ. The package lane independently supports the original order-of-magnitude timing claim on this host; it does not reproduce the quoted hardware/time exactly. Published package/DLL identities remain in published344-identities.json and published344-attribution.md. No same-version identity assumption is used.

## Actual inputs across the primary headline 48

| Typed input | Instances | Package bytes | Package SHA256 count | Inflated manifest count | Worksheet SHA256 |
|---|---:|---:|---:|---:|---|
| read/typed/Xlsx/Original/dataRows=50000 | 18 | 773409 | 18 | 1 | 436EF0BE5835F7320D2F0D9C2C4023F151A15ED90337A7DEDD1B03A32485628C |
| read/typed/Xlsx/SharedStrings/dataRows=50000 | 18 | 777338 | 18 | 1 | B16621C749BD5C651EA7562110654E1F0FDB19396C86E57BFB01561372264ADF |

Primary headline inputs have identical inflated part names, lengths and SHA256 per shape across original baselines and final current. Each child generated/logged its actual package; timestamps and package hashes vary. This does not establish that every differing ZIP byte is metadata. Writer hashes identify setup-validated outputs, not inputs or every timed output. JSON keeps these boundaries explicit.

## Runtime hashes and measured limits

Final Excel SHA256: F2853A4C62D5C03C5E3F0CBB7CCBB5776FB63CE58CE8933BE4EBAA4F5887502F. Core SHA256: B5565DE58D83BFC91F4FFB69A797CE02DFCB10A5A6409323845D05A5732E1A84. Harness SHA256: 5E79575325D94AE8D09B97CD0C1C341EBB6AC0A24C3EEE6AE4817A897F97E7A4. Peer DLL identities are verified unchanged within each packet and retained in JSON.

Current minimum actual iteration: 239.541 ms. All actual invocations and outliers are retained; no current headline iteration is below 100 ms. Exact distribution warnings remain below. One launch and observed dispersion still limit small-margin rankings; no blanket statistical-stability claim is made.

### qualified-830951-v1-domain0-main-current

- Sealed 10/08/2026 15:19:18; expected/completed/successful: 8/8/8; capture clean: True.
- Native grouped table: [OfficeIMO.Excel.ReaderComparison.Benchmarks.TypedReadBenchmarks-report-github.md](D:\Dev\Scratch\officeimo-excelreader-performance\final-runs\qualified-830951-v1-domain0-main-current\20261008-151548\OfficeIMO.Excel.ReaderComparison.Benchmarks.TypedReadBenchmarks-report-github.md).
- Native grouped table: [OfficeIMO.Excel.ReaderComparison.Benchmarks.WriterBenchmarks-report-github.md](D:\Dev\Scratch\officeimo-excelreader-performance\final-runs\qualified-830951-v1-domain0-main-current\20261008-151548\OfficeIMO.Excel.ReaderComparison.Benchmarks.WriterBenchmarks-report-github.md).

> MultimodalDistribution
>   WriterBenchmarks.OfficeIMO: OutlierMode=DontRemove, Affinity=00000000000000001111111111111111, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, InvocationCount=32, IterationCount=15, LaunchCount=1, UnrollFactor=1, WarmupCount=12 -> It seems that the distribution can have several modes (mValue = 3.14)

### qualified-830951-v1-domain1-main-current

- Sealed 10/08/2026 15:22:06; expected/completed/successful: 8/8/8; capture clean: True.
- Native grouped table: [OfficeIMO.Excel.ReaderComparison.Benchmarks.TypedReadBenchmarks-report-github.md](D:\Dev\Scratch\officeimo-excelreader-performance\final-runs\qualified-830951-v1-domain1-main-current\20261008-151919\OfficeIMO.Excel.ReaderComparison.Benchmarks.TypedReadBenchmarks-report-github.md).
- Native grouped table: [OfficeIMO.Excel.ReaderComparison.Benchmarks.WriterBenchmarks-report-github.md](D:\Dev\Scratch\officeimo-excelreader-performance\final-runs\qualified-830951-v1-domain1-main-current\20261008-151919\OfficeIMO.Excel.ReaderComparison.Benchmarks.WriterBenchmarks-report-github.md).

> MultimodalDistribution
>   TypedReadBenchmarks.OfficeIMOTyped: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, InvocationCount=32, IterationCount=15, LaunchCount=1, UnrollFactor=1, WarmupCount=12 -> It seems that the distribution can have several modes (mValue = 3)

This stage is a read-only extraction into task scratch. Source, original native packets, fixtures and archives remain unchanged. Native grouped tables are authoritative; this heterogeneous matrix is not fed into current generic website grouping.
