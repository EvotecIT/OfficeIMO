# Sealed Arrow conversion: domain 1, frozen 830951

Seven successful cases across two native tables; 105 measured samples. Source/runtime 83095146282a96143b23a79a7ecca058a24a709b; benchmark source unchanged from e676775a59458d1095606386c39506ceb8a9bc33. Started 2026-10-08T21:16:56.3801762+00:00; finished 2026-10-08T21:20:50.0936396+00:00; context ended 2026-10-08T21:20:50.1819979Z.

Ordinary recipe: one launch / 12 warmups / 15 measurements / 1000 ms automatic Pilot / unroll 1 / DontRemove, High priority and0xFFFF0000. All actual durations 668.3467–1256.8063ms; all>=100ms. 0 short/1 distribution rows; 4 outlier hints/5 native outlier values.

- 7 successful domain 1 cases retain all native/normalized measurements, allocations, outliers and actual input identities. Input content is compared with domain 0; timings and allocations remain separate observations.
- Six explicit one-owned-batch conversions use the same required schemas and every-field proof. The peer-only inferred four-string case remains unpaired; its schema differs from OfficeIMO ordinary inference. No dedicated RecordBatch writer is implied.
- Actual XLSB package hashes and entry timestamps are retained alongside identical inflated payloads. Observed metadata differences do not establish an exclusive cause for container hash differences.
- No global speed or parallel-scaling claim. Valid slower results are included in full tables and samples; endpoint process snapshots establish neither isolation nor causal contamination.

## Validated output and API ownership

100,000 rows delivered in one owned RecordBatch with required fields. Explicit CSV typed and XLSB typed schemas are string/int64/timestamp(microsecond,no timezone)/float64; eight-string CSV schema is c0..c7 strings. Both public conversion routes open identical byte-backed inputs inside timing, publish the full batch, consume its length and dispose all batches/readers. Schema, nullability, null counts, every field and source order are validated outside timing.

| Native class / method | Full selected scenario | Mean ms | SD ms | Allocated managed bytes | Min actual iteration ms |
| --- | --- | ---: | ---: | ---: | ---: |
| ArrowConversionBenchmarks.ExcelReader | CsvAllString / 100000 rows | 11.420143 | 1.024590 | 17058713 | 891.5386 |
| ArrowConversionBenchmarks.OfficeIMO | CsvAllString / 100000 rows | 38.486446 | 2.102910 | 51819047 | 871.4415 |
| ArrowConversionBenchmarks.ExcelReader | CsvTyped / 100000 rows | 8.073942 | 0.827740 | 8529309 | 910.2677 |
| ArrowConversionBenchmarks.OfficeIMO | CsvTyped / 100000 rows | 22.283030 | 1.635129 | 22598100 | 725.7911 |
| ArrowConversionBenchmarks.ExcelReader | XlsbTyped / 100000 rows | 12.134137 | 0.378912 | 8590061 | 930.6329 |
| ArrowConversionBenchmarks.OfficeIMO | XlsbTyped / 100000 rows | 17.631106 | 1.004014 | 9529518 | 991.1252 |

Unpaired upstream peer inference diagnostic: 100,000 typed CSV rows delivered as four required string fields. Setup also validates ordinary OfficeIMO inference as string/int32/microsecond timestamp/decimal128(29,10); these schemas differ and no paired ratio is published.

| Native class / method | Full selected scenario | Mean ms | SD ms | Allocated managed bytes | Min actual iteration ms |
| --- | --- | ---: | ---: | ---: | ---: |
| ArrowInferredConversionBenchmarks.ExcelReader_CsvTypedWithInference | CsvTypedInference / 100000 rows | 6.610962 | 0.411762 | 15610020 | 668.3467 |

The optional OfficeIMO.Data.Arrow provider converts ordinary Excel/CSV DbDataReaders through ReadArrowBatches. Required nullability, field names/types, null counts, microsecond timestamp unit/timezone, every value and source order are qualified in child Setup. BatchSize100000 emits one complete owned batch just as the peer explicit ToArrowRecordBatch route. Input opening, full reading/parsing, conversion, count consumption and reader/batch disposal are inside timing; validation occurs before timing. Managed allocation is not total unmanaged Arrow memory.

The peer inference row is separate: parseText=false defaults produce four required strings. OfficeIMO ordinary inference produces string/int32/microsecond timestamp/decimal128(29,10), all checked outside timing. There is no paired inference ranking. This packet contains neither bounded8192 conversion, Arrow export nor Arrow string writing; the separately measured caller row.WriteUtf8 orchestration does not establish a dedicated RecordBatch writer API.

## Actual input identities

| Prepared input (all three logged per child) | Occurrences | Bytes | Distinct package hashes | SHA256 identity |
| --- | ---: | ---: | ---: | --- |
| read/arrow/CsvAllString/rows=100000/columns=8 | 7 | 4600000 | 1 | 3E5EA7EA00C63E66CFA5DCD6CA75B2DDAB78533F249A6660CE6994E4A86B40F5 |
| read/arrow/CsvTyped/dataRows=100000/columns=4 | 7 | 4689844 | 1 | 27329B5DEC85816F43EF9DDFF983B5CED3DF900C8F89FA3275D021A57364A6D8 |
| read/typed/Xlsb/dataRows=100000 | 7 | 1748715 | 7 | All actual package hashes retained per child in JSON; inflated parts match |

Every case records its selected timed input separately from the other two prepared inputs. All seven XLSB instances have identical eight inflated entry names/lengths/SHA256 values; package hashes and ZIP timestamps differ and are retained without exclusive causal attribution. No source bytes are recopied or regenerated by this report task.

| XLSB inflated part | Occurrences | Inflated bytes | SHA256 |
| --- | ---: | ---: | --- |
| _rels/.rels | 7 | 438 | 93EBC98ECD0A158942C51A10F12DDC2B849917154EFC2328F6AD20D6BC47F6D2 |
| [Content_Types].xml | 7 | 899 | FC62B911F2BFE6482E812242BBE93E8AB727D4453C9CA8D3C09D0A43C58DF22C |
| docProps/app.xml | 7 | 231 | 215F432F2989969565FC2DDB8BF4F6E0B8958EFA7E752C2BB373B3129699E1C2 |
| xl/_rels/workbook.bin.rels | 7 | 557 | 7F57FC54E0C74E705DAAF71856E9C7854EA19A7BFA4CEFF24AEE5C18D7C8A7B2 |
| xl/sharedStrings.bin | 7 | 14 | A598F2C2704EF01CBC4F9DFB4888054023C0B6A1E19C7E4DA7F0C06A6EE0266B |
| xl/styles.bin | 7 | 390 | 7B252C122048E3899F452448E1C33B1AE159B7DAF8FD4296B4314CAE766DC5A9 |
| xl/workbook.bin | 7 | 54 | 1E3461BD8B29F0FE94FB6F4B41915D6A1600BF3EAF7E4C8ECA8EA95F9A09ED5E |
| xl/worksheets/sheet1.bin | 7 | 9850279 | 558D0D1243BE283CD8C0D26087113CB5BE55E4BD1EF2EE8687E9EDE2FEDA557D |

## Runtime, host boundary and native diagnostics

Outer harness 5E79575325D94AE8D09B97CD0C1C341EBB6AC0A24C3EEE6AE4817A897F97E7A4; runner C52377235F70A38C61333009FFA2CC97C0BE2B3C102041CB127587B09AB32A95; generated-project-only saved-reference hook CEDF3A831603914A5E024C980CCA65AAAAF25544D98538BC416E963DD8632B12. All28 loaded-owner hashes/versions match the frozen quartet. Context and provenance artifacts are preserved and SHA/length verified.

Boundary snapshots 50/50 entries; 48 persistent/2 newIDs; max persistent CPUdelta 13.078125s,sum 39.234375s. Boundary data lacks command roles/per-case timelines and does not establish isolation or causal contamination. No live audit.

Warning prose omitting parameters retains ambiguity; native grouped class/parameter/job tables and all sample distributions remain authoritative. Every native interval, outlier array, Actual/Result, statistic and allocation is retained.

~~~text
// * Hints *
Outliers
  ArrowConversionBenchmarks.ExcelReader: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12 -> 1 outlier  was  detected (14.00 ms)
  ArrowConversionBenchmarks.OfficeIMO: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12   -> 1 outlier  was  detected (33.52 ms)
  ArrowConversionBenchmarks.OfficeIMO: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12   -> 1 outlier  was  detected (26.93 ms)
  ArrowConversionBenchmarks.OfficeIMO: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12   -> 2 outliers were detected (19.70 ms, 19.82 ms)
// * Warnings *
MultimodalDistribution
  ArrowInferredConversionBenchmarks.ExcelReader_CsvTypedWithInference: OutlierMode=DontRemove, Affinity=11111111111111110000000000000000, Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true, IterationCount=15, IterationTime=1s, LaunchCount=1, UnrollFactor=1, WarmupCount=12 -> It seems that the distribution is bimodal (mValue = 3.25)
~~~

This qualifies seven additional primary cases; shared counters wait for reconciliation with DOP4 and separately assigned encryption/cold packets. Native originals unchanged; only assigned sealed domain 1 results inspected and no source/build/test/timer/package/profile/fixturecopy/archive/cleanup/public action.