```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host] : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Dry    : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

Job=Dry  Affinity=00000000000000001111111111111111  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=1  LaunchCount=1  RunStrategy=ColdStart  
UnrollFactor=1  WarmupCount=1  

```
| Method      | RowCount | Scenario     | Mean      | Error | Ratio | Allocated | Alloc Ratio |
|------------ |--------- |------------- |----------:|------:|------:|----------:|------------:|
| **ExcelReader** | **100000**   | **CsvAllString** |  **32.60 ms** |    **NA** |  **1.00** |  **16.27 MB** |        **1.00** |
| OfficeIMO   | 100000   | CsvAllString | 142.59 ms |    NA |  4.37 |   49.4 MB |        3.04 |
|             |          |              |           |       |       |           |             |
| **ExcelReader** | **100000**   | **CsvTyped**     |  **51.04 ms** |    **NA** |  **1.00** |   **8.13 MB** |        **1.00** |
| OfficeIMO   | 100000   | CsvTyped     |  77.30 ms |    NA |  1.51 |  21.54 MB |        2.65 |
|             |          |              |           |       |       |           |             |
| **ExcelReader** | **100000**   | **XlsbTyped**    |  **75.55 ms** |    **NA** |  **1.00** |   **8.14 MB** |        **1.00** |
| OfficeIMO   | 100000   | XlsbTyped    |  70.46 ms |    NA |  0.93 |   9.09 MB |        1.12 |
