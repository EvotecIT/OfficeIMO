```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host] : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Dry    : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

Job=Dry  Affinity=00000000000000001111111111111111  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=1  LaunchCount=1  RunStrategy=ColdStart  
UnrollFactor=1  WarmupCount=1  

```
| Method                        | Input              | MemoryInput | Mean      | Error | Ratio | Allocated   | Alloc Ratio |
|------------------------------ |------------------- |------------ |----------:|------:|------:|------------:|------------:|
| **ExcelReaderVerifiedFullFields** | **OriginalSmallXlsx**  | **False**       |  **22.36 ms** |    **NA** |  **1.00** |   **192.63 KB** |        **1.00** |
| OfficeIMOVerifiedFullFields   | OriginalSmallXlsx  | False       |  33.70 ms |    NA |  1.51 |   269.47 KB |        1.40 |
|                               |                    |             |           |       |       |             |             |
| **ExcelReaderVerifiedFullFields** | **OriginalSmallXlsx**  | **True**        |  **27.42 ms** |    **NA** |  **1.00** |   **189.71 KB** |        **1.00** |
| OfficeIMOVerifiedFullFields   | OriginalSmallXlsx  | True        |  23.19 ms |    NA |  0.85 |   249.97 KB |        1.32 |
|                               |                    |             |           |       |       |             |             |
| **ExcelReaderVerifiedFullFields** | **GeneratedLargeXlsx** | **False**       |  **96.63 ms** |    **NA** |  **1.00** |  **9846.73 KB** |        **1.00** |
| OfficeIMOVerifiedFullFields   | GeneratedLargeXlsx | False       | 146.90 ms |    NA |  1.52 | 68508.05 KB |        6.96 |
|                               |                    |             |           |       |       |             |             |
| **ExcelReaderVerifiedFullFields** | **GeneratedLargeXlsx** | **True**        |  **81.95 ms** |    **NA** |  **1.00** | **18741.98 KB** |        **1.00** |
| OfficeIMOVerifiedFullFields   | GeneratedLargeXlsx | True        | 146.64 ms |    NA |  1.79 | 63947.45 KB |        3.41 |
