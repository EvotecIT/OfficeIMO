```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host] : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Dry    : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

Job=Dry  Affinity=00000000000000001111111111111111  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=1  LaunchCount=1  RunStrategy=ColdStart  
UnrollFactor=1  WarmupCount=1  

```
| Method                         | Input              | Mean      | Error | Ratio | Allocated   | Alloc Ratio |
|------------------------------- |------------------- |----------:|------:|------:|------------:|------------:|
| **ExcelReaderVerifiedStreamAsync** | **OriginalSmallXlsx**  |  **31.88 ms** |    **NA** |  **1.00** |   **262.88 KB** |        **1.00** |
| OfficeIMOVerifiedStreamAsync   | OriginalSmallXlsx  |  23.48 ms |    NA |  0.74 |   270.83 KB |        1.03 |
|                                |                    |           |       |       |             |             |
| **ExcelReaderVerifiedStreamAsync** | **GeneratedLargeXlsx** | **117.80 ms** |    **NA** |  **1.00** |  **10329.7 KB** |        **1.00** |
| OfficeIMOVerifiedStreamAsync   | GeneratedLargeXlsx | 176.58 ms |    NA |  1.50 | 68508.62 KB |        6.63 |
