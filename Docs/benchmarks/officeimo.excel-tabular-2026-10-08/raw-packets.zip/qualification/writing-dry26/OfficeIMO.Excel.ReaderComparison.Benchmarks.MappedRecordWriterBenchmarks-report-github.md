```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host] : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Dry    : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

Job=Dry  Affinity=00000000000000001111111111111111  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=1  LaunchCount=1  RunStrategy=ColdStart  
UnrollFactor=1  WarmupCount=1  

```
| Method                    | Format | RowCount | Mean      | Error | Ratio | Gen0       | Gen1      | Gen2      | Allocated | Alloc Ratio |
|-------------------------- |------- |--------- |----------:|------:|------:|-----------:|----------:|----------:|----------:|------------:|
| **OfficeIMOPublicTypedWrite** | **Xlsx**   | **50000**    |  **32.43 ms** |    **NA** |  **0.67** |          **-** |         **-** |         **-** |   **4.14 MB** |        **1.03** |
| ExcelReaderMappedRecords  | Xlsx   | 50000    |  48.17 ms |    NA |  1.00 |          - |         - |         - |   4.02 MB |        1.00 |
|                           |        |          |           |       |       |            |           |           |           |             |
| **OfficeIMOPublicTypedWrite** | **Xlsb**   | **50000**    | **835.11 ms** |    **NA** | **42.20** | **10000.0000** | **9000.0000** | **3000.0000** | **444.26 MB** |      **110.54** |
| ExcelReaderMappedRecords  | Xlsb   | 50000    |  19.79 ms |    NA |  1.00 |          - |         - |         - |   4.02 MB |        1.00 |
