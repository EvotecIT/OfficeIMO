```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host] : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Dry    : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

Job=Dry  Affinity=00000000000000001111111111111111  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=1  LaunchCount=1  RunStrategy=ColdStart  
UnrollFactor=1  WarmupCount=1  

```
| Method                     | RowCount | Mean     | Error | Ratio | Allocated | Alloc Ratio |
|--------------------------- |--------- |---------:|------:|------:|----------:|------------:|
| OfficeIMOWithoutReferences | 50000    | 28.45 ms |    NA |  0.87 |   4.14 MB |        1.03 |
| ExcelReaderWriter          | 50000    | 32.68 ms |    NA |  1.00 |   4.03 MB |        1.00 |
| ExcelReaderWriterPrefetch  | 50000    | 40.33 ms |    NA |  1.23 |    4.1 MB |        1.02 |
