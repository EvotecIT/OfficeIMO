```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host] : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Dry    : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

Job=Dry  Affinity=00000000000000001111111111111111  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=1  LaunchCount=1  RunStrategy=ColdStart  
UnrollFactor=1  WarmupCount=1  

```
| Method                             | RowCount | Mean      | Error | Ratio | Gen0       | Gen1       | Gen2      | Allocated | Alloc Ratio |
|----------------------------------- |--------- |----------:|------:|------:|-----------:|-----------:|----------:|----------:|------------:|
| OfficeIMOModelAndSaveInlineStrings | 50000    | 670.36 ms |    NA | 27.72 | 15000.0000 | 10000.0000 | 3000.0000 | 439.99 MB |      108.07 |
| OfficeIMOModelAndSaveSharedStrings | 50000    | 603.15 ms |    NA | 24.94 | 15000.0000 | 10000.0000 | 3000.0000 | 430.41 MB |      105.72 |
| ExcelReaderXlsbWriterSharedStrings | 50000    |  24.18 ms |    NA |  1.00 |          - |          - |         - |   4.07 MB |        1.00 |
| ExcelReaderXlsbWriterPrefetch      | 50000    |  15.43 ms |    NA |  0.64 |          - |          - |         - |   4.04 MB |        0.99 |
