```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26300.9457)
AMD Ryzen 9 9950X3D2 4.30GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.112
  [Host] : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4
  Dry    : .NET 10.0.12 (10.0.12, 10.0.1226.42308), X64 RyuJIT x86-64-v4

Job=Dry  Affinity=00000000000000001111111111111111  Arguments=/p:UseSharedCompilation=false,/p:OfficeIMOBenchmarkAssemblyDirectory="D:\Dev\Scratch\officeimo-excelreader-performance\current-owner-bundle-830951",/p:OfficeIMOBenchmarkNewApis=true,/p:OfficeIMOBenchmarkCsv=true,/p:OfficeIMOBenchmarkArrow=true  
IterationCount=1  LaunchCount=1  RunStrategy=ColdStart  
UnrollFactor=1  WarmupCount=1  

```
| Method                | Format | RowCount | Mean      | Error | Ratio | Gen0      | Gen1      | Gen2      | Allocated | Alloc Ratio |
|---------------------- |------- |--------- |----------:|------:|------:|----------:|----------:|----------:|----------:|------------:|
| OfficeIMOModelAndSave | Xlsb   | 50000    | 875.66 ms |    NA | 58.27 | 9000.0000 | 8000.0000 | 2000.0000 | 448.87 MB |      111.68 |
| ExcelReaderWriter     | Xlsb   | 50000    |  15.03 ms |    NA |  1.00 |         - |         - |         - |   4.02 MB |        1.00 |
